package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/5.
 */
public class MessageListModel {
    private int page;
    private int numberOfMessagesPerPage;
    private int totalNumberOfMessages;
    private List<Message> messages;

    public MessageListModel() {
    }

    public int getPage(){
        return page;
    }

    public void setPage(int page){
        this.page = page;
    }

    public int getNumberOfMessagesPerPage(){
        return numberOfMessagesPerPage;
    }

    public void setNumberOfMessagesPerPage(int numberOfMessagesPerPage){
        this.numberOfMessagesPerPage = numberOfMessagesPerPage;
    }

    public int getTotalNumberOfMessages(){
        return totalNumberOfMessages;
    }

    public void setTotalNumberOfMessages(int totalNumberOfMessages){
        this.totalNumberOfMessages = totalNumberOfMessages;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }
}
