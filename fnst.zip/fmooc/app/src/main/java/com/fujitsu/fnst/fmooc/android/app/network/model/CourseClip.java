package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by wangc.fnst on 2016/1/15.
 */
public class CourseClip implements Serializable {
    public static String STATE_CANVIEW = "canView";
    public static String STATE_CANNOTVIEW = "cannotView";
    public static String STATE_VIEWING = "viewing";
    public static String STATE_VIEWED = "viewed";
    public static String TYPE_REPORT = "Report";
    public static String TYPE_COURSECLIP = "CourseClip";
    public static String TYPE_REMOVE = "Remove";
    private String contentId;
    private String playlistId;
    private String courseId;
    private String authorId;
    private String name;
    private String description;
    private String youtubeId;
    private int lengthInSeconds;
    private int percentageViewed;
    private String state;

    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    public String getPlaylistId() {
        return playlistId;
    }

    public void setPlaylistId(String playlistId) {
        this.playlistId = playlistId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getAuthorId() {
        return authorId;
    }

    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getYoutubeId() {
        return youtubeId;
    }

    public void setYoutubeId(String youtubeId) {
        this.youtubeId = youtubeId;
    }

    public int getLengthInSeconds() {
        return lengthInSeconds;
    }

    public void setLengthInSeconds(int lengthInSeconds) {
        this.lengthInSeconds = lengthInSeconds;
    }

    public int getPercentageViewed() {
        return percentageViewed;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setPercentageViewed(int percentageViewed) {
        this.percentageViewed = percentageViewed;
    }
}
