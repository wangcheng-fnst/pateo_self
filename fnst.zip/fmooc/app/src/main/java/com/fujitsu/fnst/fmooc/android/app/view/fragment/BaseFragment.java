package com.fujitsu.fnst.fmooc.android.app.view.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.BasePresenter;
import com.fujitsu.fnst.fmooc.android.app.view.BaseViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.MainFragmentActivity;
import com.fujitsu.fnst.fmooc.android.app.view.component.ProgressDialog;
import rx.Observable;
import rx.functions.Action1;

import java.util.concurrent.TimeUnit;

/**
 * Created by wangc.fnst on 2015/12/14.
 */
public abstract class BaseFragment<T extends BasePresenter> extends Fragment implements BaseViewInterface ,View.OnClickListener{

    private Activity context;
    protected T presenter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public BaseFragment() {
        context = getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return getView(inflater,container);
    }

    @Override
    public void onResume() {
        init();
        super.onResume();
    }

    private View getView(LayoutInflater inflater, @Nullable ViewGroup container){
        View view = inflater.inflate(getLayout(),container,false);
        ButterKnife.bind(this, view);

        return view;
    }

    protected abstract int getLayout();
    protected  abstract void init();
    @Override
    public void showToast(String msg) {
        Toast.makeText(getActivity(),msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {

    }
    @Override
    public void hideWaitingDialog(){
        ((MainFragmentActivity)getActivity()).hideWaitingDialog();

    }
    @Override
    public void showWaitingDialog(){
        ((MainFragmentActivity)getActivity()).showWaitingDialog();
    }
}
