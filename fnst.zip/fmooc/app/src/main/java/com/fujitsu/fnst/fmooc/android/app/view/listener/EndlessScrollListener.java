package com.fujitsu.fnst.fmooc.android.app.view.listener;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public abstract class EndlessScrollListener extends RecyclerView.OnScrollListener {

    // The minimum amount of items to have below your current scroll position
    // before loading more.
    private int visibleThreshold = 1;
    // The current offset index of data you have loaded
    private int currentPage = 0;
    // The total number of items in the dataset after the last load
    private int previousTotalItemCount = 0;
    // True if we are still waiting for the last set of data to load.
    private boolean loading = true;
    // Sets the starting page index
    private int startingPageIndex = 0;

    private LinearLayoutManager mLinearLayoutManager;

    public EndlessScrollListener(LinearLayoutManager layoutManager) {
        this.mLinearLayoutManager = layoutManager;
    }

    @Override
    public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
        super.onScrolled(recyclerView, dx, dy);
        int firstVisibleItem = mLinearLayoutManager.findFirstVisibleItemPosition();
        int lastVisibleItem = mLinearLayoutManager.findLastVisibleItemPosition();
        int visibleItemCount = recyclerView.getChildCount();
        int totalItemCount = mLinearLayoutManager.getItemCount();
        Log.e("onScrolled","firstVisibleItem:"+firstVisibleItem+"visibleItemCount:"+visibleItemCount+"totalItemCount:"+totalItemCount);

        // If the total item count is zero and the previous isn't, assume the
        // list is invalidated and should be reset back to initial state
        if (totalItemCount < previousTotalItemCount) {
            this.currentPage = this.startingPageIndex;
            this.previousTotalItemCount = totalItemCount;
            if (totalItemCount == 0) {
                this.loading = true;
            }
        }
        // If it’s still loading, we check to see if the dataset count has
        // changed, if so we conclude it has finished loading and update the current page
        // number and total item count.
        if (loading && (totalItemCount > previousTotalItemCount)) {
            loading = false;
            previousTotalItemCount = totalItemCount;
        }

        // If it isn’t currently loading, we check to see if we have breached
        // the visibleThreshold and need to reload more data.
        // If we do need to reload some more data, we execute onLoadMore to fetch the data.
        if (!loading) {
            if ((totalItemCount - visibleItemCount) <= (firstVisibleItem + visibleThreshold)
                    && firstVisibleItem > visibleThreshold){
                //only add end
                currentPage++;
                onLoadMore(currentPage, totalItemCount,0);
                loading = true;
            }else if ((totalItemCount - visibleItemCount) <= (firstVisibleItem + visibleThreshold)
                    && firstVisibleItem <= visibleThreshold){
                //add end and start
                currentPage++;
                onLoadMore(currentPage, totalItemCount,1);
                loading = true;
            } else if ((totalItemCount - visibleItemCount) > (firstVisibleItem + visibleThreshold)
                    && firstVisibleItem <= visibleThreshold){
                //only add start
                currentPage++;
                onLoadMore(currentPage, totalItemCount,2);
                loading = true;
            }


        }

    }



    public abstract void onLoadMore(int page,int totalItemsCount,int addMode);
}
