package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by lijl.fnst on 2016/01/20.
 */
public class ReportEvaluationActivity implements Serializable {
    private String label;
    private List<ReportEvaluationActivityChoice> choices;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<ReportEvaluationActivityChoice> getChoices() {
        return choices;
    }

    public void setChoices(List<ReportEvaluationActivityChoice> choices) {
        this.choices = choices;
    }
}
