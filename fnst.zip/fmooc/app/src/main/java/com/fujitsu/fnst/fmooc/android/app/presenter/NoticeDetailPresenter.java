package com.fujitsu.fnst.fmooc.android.app.presenter;

import com.fujitsu.fnst.fmooc.android.app.view.NoticeDetailViewInterface;

/**
 * Created by wangc.fnst on 2016/1/12.
 */
public class NoticeDetailPresenter extends BasePresenter {
    private NoticeDetailViewInterface view;

    public NoticeDetailPresenter(NoticeDetailViewInterface view) {
        super();
        this.view = view;
    }
}
