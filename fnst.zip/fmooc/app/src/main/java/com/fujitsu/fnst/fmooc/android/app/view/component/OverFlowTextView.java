package com.fujitsu.fnst.fmooc.android.app.view.component;

import android.content.Context;
import android.graphics.Paint;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by wangc.fnst on 2016/1/22.
 */
public class OverFlowTextView extends TextView {

    public OverFlowTextView(Context context) {
        super(context);
    }

    public OverFlowTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public OverFlowTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public OverFlowTextView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }
    private int getAvailableWidth()
    {
        return getWidth() - getPaddingLeft() - getPaddingRight();
    }
    public boolean isOverFlowed()
    {
        Paint paint = getPaint();
        float width = paint.measureText(getText().toString());
        if (width > getAvailableWidth()) return true;
        return false;
    }

}
