package com.fujitsu.fnst.fmooc.android.app.network;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.activity.LoginActivity;
import retrofit.Response;
import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.functions.Func1;

/**
 * Created by wangc.fnst on 2016/1/13.
 */
public class ObserverConvert<T> implements Func1<Response<T>, Observable<T>> {
    @Override
    public Observable<T> call(Response<T> tResponse) {
        return Observable.create(new NetObservable(tResponse));
    }


    class NetObservable implements Observable.OnSubscribe<T>{
        private Response<T> serverResult;

        public NetObservable(Response<T> serverResult) {
            this.serverResult = serverResult;
        }
        private void parseResponse(Response response ){
            for (String header : response.headers().names()){
                if (header.equals(Constants.CONTENT_TOKEN)){
                    String token = response.headers().get(Constants.CONTENT_TOKEN);
                    ApplicationUtils.setToken(token);
                }

            }
        }

        @Override
        public void call(Subscriber<? super T> subscriber) {
            if (serverResult.isSuccess()){
                parseResponse(serverResult);
                subscriber.onNext(serverResult.body());
                subscriber.onCompleted();
            }else{
                switch (serverResult.code()) {
                    case ErrorCode.ERROR_AUTH:
                        subscriber.onError(new ServerException(ErrorCode.ERROR_AUTH, "auth error " + serverResult.message()));
                        Intent intent = new Intent(FmoocApplication.getInstance(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        FmoocApplication.getInstance().startActivity(intent);
                        break;
                    case ErrorCode.ERROR_NOT_FONT:
                        subscriber.onError(new ServerException(ErrorCode.ERROR_NOT_FONT, "not found"+serverResult.message()));
                        break;
                    case ErrorCode.ERROR_PARAMETER:
                        subscriber.onError(new ServerException(ErrorCode.ERROR_PARAMETER, "parameter error"+serverResult.message()));
                        break;
                    case ErrorCode.ERROR_PERMISSION:
                        subscriber.onError(new ServerException(ErrorCode.ERROR_PERMISSION, "permission error"+serverResult.message()));
                        break;
                    case ErrorCode.ERROR_TOO_LARGE:
                        subscriber.onError(new ServerException(ErrorCode.ERROR_TOO_LARGE, "uri too large error"+serverResult.message()));
                        break;
                    case ErrorCode.ERROR_URI:
                        subscriber.onError(new ServerException(ErrorCode.ERROR_URI, "uri error"+serverResult.message()));
                        break;
                    default:
                        subscriber.onError(new ServerException(ErrorCode.ERROR_OTHER, "other error"+serverResult.message()));
                }
            }
        }
    }
}
