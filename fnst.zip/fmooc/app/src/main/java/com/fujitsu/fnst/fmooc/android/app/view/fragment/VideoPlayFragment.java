package com.fujitsu.fnst.fmooc.android.app.view.fragment;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.DeveloperKey;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerFragment;

/**
 * Created by wangc.fnst on 2015/12/24.
 */
public class VideoPlayFragment extends YouTubePlayerFragment implements YouTubePlayer.OnInitializedListener {

    private YouTubePlayer player;
    private String videoId;
    private YouTubePlayer.OnFullscreenListener onFullscreenListener;
    private YouTubePlayer.PlayerStateChangeListener playerStateChangeListener;
    private SuccessPlayerInitListener successPlayerInitListener;
    private boolean isOnResume;
    public interface  SuccessPlayerInitListener{
        void onSuccessInit(boolean isOnResume);
    }

    public SuccessPlayerInitListener getSuccessPlayerInitListener() {
        return successPlayerInitListener;
    }

    public void setSuccessPlayerInitListener(SuccessPlayerInitListener successPlayerInitListener) {
        this.successPlayerInitListener = successPlayerInitListener;
    }

    public static VideoPlayFragment getInstance(){
        return new VideoPlayFragment();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        initialize(false);
    }
    public int getCurrentTimeMillis(){
        return player.getCurrentTimeMillis();
    }
    public int getDurationMillis(){
        return player.getDurationMillis();
    }
    public void seekToMillis(int millis){
        player.seekToMillis(millis);
    }

    public void initialize(boolean isOnResume){
        this.isOnResume = isOnResume;
        initialize(DeveloperKey.DEVELOPER_KEY, this);
    }

    @Override
    public void onPause() {
        if (player != null){
            player.release();
        }
        super.onPause();
    }

    @Override
    public void onDestroy() {
        Log.e("VideoPlayFragment","onDestroy");
        super.onDestroy();
    }
    public void setVideoId(String videoId) {
        if (videoId != null && !videoId.equals(this.videoId)) {
            this.videoId = videoId;
            if (player != null) {
                player.loadVideo(videoId);

            }
        }
    }
    public void cueVideo(String videoId){
        if (videoId != null && !videoId.equals(this.videoId)) {
            this.videoId = videoId;
            if (player != null) {
                player.cueVideo(videoId);
            }

        }
    }
    public void play(){
        if (player != null &&! player.isPlaying()) {
            player.play();
        }
    }
    public boolean isPlaying(){
        if (player!=null) {
            return player.isPlaying();
        }
        return false;
    }
    public void setFullscreen(boolean fullscreen){
        player.setFullscreen(fullscreen);
    }

    public void pause() {
        if (player != null) {
            player.pause();
        }
    }


    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean restored) {
        player = youTubePlayer;
        player.setPlaybackEventListener(new YouTubePlayer.PlaybackEventListener() {
            @Override
            public void onPlaying() {
                Log.e("PlaybackEventListener", "onPlaying");
            }

            @Override
            public void onPaused() {
                Log.e("PlaybackEventListener", "onPaused");
            }

            @Override
            public void onStopped() {
                Log.e("PlaybackEventListener", "onStopped");
            }

            @Override
            public void onBuffering(boolean b) {
                Log.e("PlaybackEventListener", "onBuffering"+b);
            }

            @Override
            public void onSeekTo(int i) {
                Log.e("PlaybackEventListener", "onSeekTo");
            }
        });
        if (successPlayerInitListener != null) {
            successPlayerInitListener.onSuccessInit(isOnResume);
        }
    }



    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

    }

    public YouTubePlayer.OnFullscreenListener getOnFullscreenListener() {
        return onFullscreenListener;
    }

    public void setOnFullscreenListener(YouTubePlayer.OnFullscreenListener onFullscreenListener) {
        this.onFullscreenListener = onFullscreenListener;
        int controlFlags = player.getFullscreenControlFlags();
        if (onFullscreenListener != null) {
            controlFlags |= YouTubePlayer.FULLSCREEN_FLAG_ALWAYS_FULLSCREEN_IN_LANDSCAPE;
            player.addFullscreenControlFlag(controlFlags);
            player.setOnFullscreenListener(onFullscreenListener);
        }
    }

    public YouTubePlayer.PlayerStateChangeListener getPlayerStateChangeListener() {
        return playerStateChangeListener;
    }

    public void setPlayerStateChangeListener(YouTubePlayer.PlayerStateChangeListener playerStateChangeListener) {
        this.playerStateChangeListener = playerStateChangeListener;
        if (playerStateChangeListener != null){
            player.setPlayerStateChangeListener(playerStateChangeListener);
        }
    }
}
