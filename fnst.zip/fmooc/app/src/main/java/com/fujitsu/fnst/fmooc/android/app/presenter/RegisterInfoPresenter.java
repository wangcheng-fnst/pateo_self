package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import android.widget.Toast;

import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.model.EmptyModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.LoginModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.view.RegisterInfoViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.MainFragmentActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.RegisterActivity;

/**
 * Created by lijl.fnst on 2015/12/14.
 */
public class RegisterInfoPresenter  extends BasePresenter {
    private RegisterInfoViewInterface view;
    private String requestType = UserRepository.DUMMY_CODE_RESPONSE;
    private String code = "dummyConfirmationCode";
    public RegisterInfoPresenter(RegisterInfoViewInterface viewInterface){
        super();
        view = viewInterface;

    }



}
