package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.ListHeadModel;
import com.fujitsu.fnst.fmooc.android.app.network.ServerException;
import com.fujitsu.fnst.fmooc.android.app.network.download.OkHttpClientManager;
import com.fujitsu.fnst.fmooc.android.app.network.model.*;
import com.fujitsu.fnst.fmooc.android.app.repository.CourseRepository;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.view.CoursePlayViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.*;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.ExpandableAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.CustomDialog;
import com.fujitsu.fnst.fmooc.android.app.view.component.stickylistheaders.ExpandableStickyListHeadersListView;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.VideoPlayFragment;
import com.google.android.youtube.player.YouTubePlayer;
import com.squareup.okhttp.Request;
import rx.Subscriber;
import rx.Subscription;

import java.io.File;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/22.
 */
public class CoursePlayPresenter extends BasePresenter implements AdapterView.OnItemClickListener,ExpandableAdapter.ButtonClickListener {

    public static final String STATUS_OPEN_ENROLLING = "status_open_enrolling";
    public static final String STATUS_OPEN_COMPLETE = "status_open_complete";
    public static final String STATUS_CLOSE_ENROLLING = "status_close_enrolling";
    public static final String STATUS_CLOSE_COMPLETE = "status_close_complete";
    public static final String STATUS_UNAVAILABLE_ENROLLING = "status_unavailable_enrolling";
    public static final String STATUS_UNAVAILABLE_COMPLETE = "status_unavailable_complete";

    private CoursePlayViewInterface view;
    private int playIngPosition;
    private List<CourseModel> playlist;
    private List<ListHeadModel> headModels;
    VideoPlayFragment fragment;
    private ExpandableAdapter.ViewHolder currentItemHolder;
    private ExpandableAdapter adapter;
    private PlayStateListener listener;
    private String courseId;
    private Subscription updateSubscription,removeSubscription;
    private Course course;
    private String status;
    private CustomDialog dialog;
    private ExpandableStickyListHeadersListView listView;
    private boolean isResume;
    private String realName;

    public void setCurrentItemHolder(ExpandableAdapter.ViewHolder currentItemHolder) {
        this.currentItemHolder = currentItemHolder;
    }

    public void setListView(ExpandableStickyListHeadersListView listView) {
        this.listView = listView;
    }

    public ExpandableAdapter getAdapter() {
        return adapter;
    }

    public void setAdapter(ExpandableAdapter adapter) {
        this.adapter = adapter;
    }

    public CoursePlayPresenter(String courseId,CoursePlayViewInterface view,List<CourseModel> playlist,VideoPlayFragment fragment,List<ListHeadModel> headModels) {
        super();
        this.courseId = courseId;
        this.view = view;
        this.fragment = fragment;
        this.playlist = playlist;
        this.headModels = headModels;
        getCourseFromNet();
        isResume = false;
    }


    @Override
    public void onResume() {
        if (isResume) {
            fragment.initialize(true);
        }
        super.onResume();
    }

    public void resumePlayer(){
        CourseModel oldModel = playlist.get(playIngPosition);
        if (oldModel != null ) {
            if (oldModel.getContentType().equals(CourseClip.TYPE_COURSECLIP)) {
                fragment.cueVideo("test");
                fragment.setVideoId(oldModel.getYoutubeId());
                playlist.get(playIngPosition).setState(CourseClip.STATE_VIEWING);

            }else {
                oldModel.setState(CourseClip.STATE_VIEWING);
//                if (playIngPosition > 0) {
//                    fragment.cueVideo("test");
//                    fragment.setVideoId(playlist.get(playIngPosition - 1).getYoutubeId());
//                    playlist.get(playIngPosition - 1).setState(CourseClip.STATE_VIEWING);
//                }
            }
            adapter.notifyDataSetChanged();
            setChangeListener();
        }
    }



    public void setPlaylist(List<CourseModel> playlist) {
        this.playlist = playlist;
    }

    public List<ListHeadModel> getHeadModels() {
        return headModels;
    }

    public void setHeadModels(List<ListHeadModel> headModels) {
        this.headModels = headModels;
    }

    private void getCourseFromNet(){
        view.showWaitingDialog();
        CourseRepository.getInstance().getCourseById(courseId, getCourseSubscriber());
    }
    private Subscriber<Course> getCourseSubscriber(){
        return new Subscriber<Course>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }
            @Override
            public void onError(Throwable e) {
                view.hideWaitingDialog();
                e.printStackTrace();
                view.showToast(e.getMessage());
            }

            @Override
            public void onNext(Course course) {
                view.setData(course);
            }
        };
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public void setPosition(int position){
        this.playIngPosition = position;
    }

    public void init(){
        listener = new PlayStateListener();
    }
    public void setChangeListener(){
        fragment.setPlayerStateChangeListener(listener);
    }

    public void setPlayIngPosition(int playIngPosition){
        this.playIngPosition = playIngPosition;
        if (ApplicationUtils.isOpenNetwork() || ApplicationUtils.isAgreeWithoutWifi()){
            CourseModel model = playlist.get(playIngPosition);
            if (model.getContentType().equals(CourseClip.TYPE_COURSECLIP)) {
                fragment.cueVideo(model.getYoutubeId());
            }
            model.setState(CourseClip.STATE_VIEWING);
            adapter.notifyDataSetChanged();
        }
    }
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (ApplicationUtils.isOpenNetwork() || ApplicationUtils.isAgreeWithoutWifi()) {
            CourseModel oldModel = (CourseModel) adapter.getItem(playIngPosition);
            if (oldModel.getContentType().equals(CourseClip.TYPE_COURSECLIP)) {
                if (oldModel.getState().equals(CourseClip.STATE_CANVIEW)
                        || oldModel.getState().equals(CourseClip.STATE_VIEWING)) {
                    oldModel.setState(CourseClip.STATE_VIEWED);
                    if (oldModel.getPercentageViewed() < 100) {
                        updateCourseClipState(oldModel);
                    }
                }
            }else{
                oldModel.setState(CourseClip.STATE_VIEWED);
            }

            listView.smoothScrollToPosition(position);
            CourseModel model = (CourseModel) adapter.getItem(position);
            if (model.getContentType().equals(CourseClip.TYPE_COURSECLIP)) {
                model.setState(CourseClip.STATE_VIEWING);
            }
            adapter.notifyDataSetChanged();
            ExpandableAdapter.ViewHolder holder = (ExpandableAdapter.ViewHolder) view.getTag();
            if (model.getContentType().equals(CourseClip.TYPE_REPORT)) {
                Intent intent = new Intent(context, ReportMainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("contentId", model.getContentId());
                context.startActivity(intent);
            } else if (model.getContentType().equals(CourseClip.TYPE_COURSECLIP)) {
                fragment.setVideoId(model.getYoutubeId());
                holder.playImg.setVisibility(View.VISIBLE);
                playIngPosition = position;
            }
        }
    }

    /**
     * change state from canView to viewed
     * @param model: the courseClip needs change state from canView to viewed
     */
    private void updateCourseClipState(final CourseModel model){
        if (!model.isSendOk()) {
            updateSubscription = CourseRepository.getInstance().updateCourse(model.getContentId(), 100, new Subscriber<EmptyModel>() {
                @Override
                public void onCompleted() {
                }

                @Override
                public void onError(Throwable e) {
                    view.showToast(e.getMessage());
                }

                @Override
                public void onNext(EmptyModel emptyModel) {
                    model.setIsSendOk(true);
                }
            });
        }

    }

    private CustomDialog getDialog(){
        if (dialog == null){
            dialog = new CustomDialog((Activity) view);
            dialog.setNoStr(context.getResources().getString(R.string.no));
            dialog.setYesStr(context.getResources().getString(R.string.yes));
            dialog.setTitleStr(context.getResources().getString(R.string.course_remove_message));
            dialog.setListener(new CustomDialog.YesOrNoClickListener() {
                @Override
                public void yesClick() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    removeCourse(courseId);
                }

                @Override
                public void noClick() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                }
            });
        }
        return dialog;
    }

    /**
     * remove course
     * @param courseId
     */
    private void removeCourse(String courseId){
        //TODO: send remove course request
        view.showWaitingDialog();
        CourseRepository.getInstance().deleteCourse(courseId, new Subscriber<EmptyModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.hideWaitingDialog();
                view.showToast(e.getMessage());
            }

            @Override
            public void onNext(EmptyModel emptyModel) {
                view.hideWaitingDialog();
                view.back();
            }
        });
    }

    /**
     * remove this course
     */
    @Override
    public void clickButton() {
        view.showDialog(getDialog());
    }

    /**
     * play the next video in nextPosition
     * @param nextPosition:the courseClip needed to play
     */
    public void playNext(int nextPosition){
        CourseModel model = (CourseModel)adapter.getItem(nextPosition);
        if (model != null && model.getContentType().equals(CourseClip.TYPE_COURSECLIP)){
            model.setState(CourseClip.STATE_VIEWING);
            view.getListView().smoothScrollToPosition(playIngPosition);
            fragment.setVideoId(model.getYoutubeId());
            fragment.play();
        }
    }

    /**
     * change state of the previous video
     * @param previousPosition: the position of previous video
     */
    public void changePrevious(int previousPosition){
        CourseModel oldModel = ((CourseModel) (adapter.getItem(previousPosition)));
        if (oldModel != null) {
            oldModel.setState(CourseClip.STATE_VIEWED);
            if (oldModel.getState() != null
                    && (oldModel.getState().equals(CourseClip.STATE_CANVIEW)||oldModel.getState().equals(CourseClip.STATE_VIEWING))) {
                oldModel.setState(CourseClip.STATE_VIEWED);
                if (oldModel.getPercentageViewed() < 100) {
                    updateCourseClipState(oldModel);
                }
            }
        }
    }

    public void goCredentials(){

        String id = ShareReferencesManager.getInstance(context).getStringValue(Constants.SP_USER_ID);
        String data = Constants.USER_DATA_BASIC;
        Subscription getUserSubscription = UserRepository.getInstance().getUserInformation(id,data,getSubscriber());
    }

    private Subscriber getSubscriber(){
        return new Subscriber<UserInfoModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(UserInfoModel user) {
                realName = user.getUser().getRealName();
                if(realName == null || realName.equals("")){
                    view.showDialog(setNameDialog());
                }else{
                    CourseRepository.getInstance().getMadePDF(courseId, getMadeSubscriber());
                }
            }
        };
    }

    private Subscriber getMadeSubscriber(){
        return new Subscriber<FilenameModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                ServerException serverException = (ServerException)e;
                if(((ServerException) e).getErrorCode() == 404){
                    view.showDialog(getCredentialsDialog(realName));
                }else{
                    view.showToast(e.getMessage());
                }
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(final FilenameModel filenameModel) {
                File file = new File(FmoocApplication.staticDataPath );
                final String filename = filenameModel.getFilename();
                try {
                    if (!file.exists()) {
                        file.mkdirs();
                        file.createNewFile();
                    } else {
                        file.delete();
                        file.createNewFile();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
                OkHttpClientManager.downloadAsyn(Constants.DOWNLOAD_URL+"/"+filenameModel.getFilename(), file.getAbsolutePath(), new OkHttpClientManager.ResultCallback<String>() {
                    @Override
                    public void onError(Request request, Exception e) {
                        view.hideWaitingDialog();
                    }

                    @Override
                    public void onResponse(String response) {
                        view.hideWaitingDialog();
                        File file2 = new File(FmoocApplication.staticDataPath + filename);
                        Uri path1 = Uri.fromFile(file2);
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(path1, "application/pdf");
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        try {
                            context.startActivity(intent);
                        }
                        catch (ActivityNotFoundException e) {
                            view.showToast(e.getMessage());
                        }
                    }
                });
            }
        };
    }

    private Subscriber getFirstSubscriber(){
        return new Subscriber<FilenameModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(FilenameModel filenameModel) {
                File file = new File(FmoocApplication.staticDataPath );
                final String filename = filenameModel.getFilename();
                try {
                    if (!file.exists()) {
                        file.mkdirs();
                        file.createNewFile();
                    } else {
                        file.delete();
                        file.createNewFile();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
                OkHttpClientManager.downloadAsyn(Constants.DOWNLOAD_URL+"/"+filenameModel.getFilename(), file.getAbsolutePath(), new OkHttpClientManager.ResultCallback<String>() {
                    @Override
                    public void onError(Request request, Exception e) {
                        view.hideWaitingDialog();
                    }

                    @Override
                    public void onResponse(String response) {
                        view.hideWaitingDialog();
                        File file2 = new File(FmoocApplication.staticDataPath + filename);
                        Uri path1 = Uri.fromFile(file2);
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(path1, "application/pdf");
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        try {
                            context.startActivity(intent);
                        }
                        catch (ActivityNotFoundException e) {
                            view.showToast(e.getMessage());
                        }
                    }
                });
            }
        };
    }

    private CustomDialog setNameDialog(){
//        if (dialog == null){
            dialog = new CustomDialog((Activity) view);
            dialog.setNoStr(context.getResources().getString(R.string.no));
            dialog.setYesStr(context.getResources().getString(R.string.name_yes));
            dialog.setTitleStr(context.getResources().getString(R.string.message_name));
            dialog.setListener(new CustomDialog.YesOrNoClickListener() {
                @Override
                public void yesClick() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    Intent intent = new Intent(context, ProfileSelectActivity.class);
                    intent.putExtra(Constants.PROFILE_SETTING_TYPE, Constants.PROFILE_SETTING_FIRSTNAME);
                    ((CoursePlayActivity) view).startActivityForResult(intent, 1000);
                }

                @Override
                public void noClick() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                }
            });
//        }
        return dialog;
    }

    private CustomDialog getCredentialsDialog(String realName){
//        if (dialog == null){
            dialog = new CustomDialog((Activity) view);
            dialog.setNoStr(context.getResources().getString(R.string.no));
            dialog.setYesStr(context.getResources().getString(R.string.yes));
            String name = "";
            if(realName.length()>8){
                name = realName.substring(0,8)+"...";
            }else{
                name = realName;
            }
            dialog.setTitleStr(context.getResources().getString(R.string.credentials_name1)+name+context.getResources().getString(R.string.credentials_name2));
            dialog.setListener(new CustomDialog.YesOrNoClickListener() {
                @Override
                public void yesClick() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    CourseRepository.getInstance().getPDF(courseId, getFirstSubscriber());
                }

                @Override
                public void noClick() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                }
            });
//        }
        return dialog;
    }

    @Override
    public void onPause() {
        isResume = true;
        super.onPause();
    }

    @Override
    public void onDestroy() {
        Log.e("PlayState:","onDestroy");
        super.onDestroy();
    }

    /**
     * the listener observer YouTube player
     */
    class PlayStateListener implements YouTubePlayer.PlayerStateChangeListener{

        @Override
        public void onLoading() {
            Log.e("playStateChange", "onLoading");

        }

        @Override
        public void onLoaded(String s) {
            Log.e("playStateChange", "onLoaded");
        }

        @Override
        public void onAdStarted() {
            Log.e("playStateChange", "onAdStarted");
        }

        @Override
        public void onVideoStarted() {
            Log.e("playStateChange", "onVideoStarted");
        }

        /**
         * called when one video over,then change ui and play next automatically
         */
        @Override
        public void onVideoEnded() {
            Log.e("playStateChange", "onVideoEnded");
            changePrevious(playIngPosition);
            playIngPosition++;
            CourseModel model = (CourseModel)adapter.getItem(playIngPosition);
            if (model != null ) {
                if (model.getContentType().equals("Report")) {
                    // go to next position
                } else if (model.getContentType().equals("CourseClip")) {
                    playNext(playIngPosition);
                    adapter.notifyDataSetChanged();
                }
                if (isClosedHeader()) {
                    expandHeader(playIngPosition);
                }

            }
        }

        @Override
        public void onError(YouTubePlayer.ErrorReason errorReason) {
            Log.e("playStateChange", "onError");
        }

        /**
         * jude if the header is closed
         * @return : true if closed ,or false if open
         */
        private boolean isClosedHeader(){
            Long headerId = adapter.getHeaderId(playIngPosition);
            return view.getListView().isHeaderCollapsed(headerId);
        }
        /**
         * close header with position
         */
        private void closedHeader(int position){
            Long headerId = adapter.getHeaderId(position);
            view.getListView().collapse(headerId);
        }
        /**
         * open header with position
         */
        private void expandHeader(int position){
            Long headerId = adapter.getHeaderId(position);
            view.getListView().expand(headerId);
        }
    }
}
