package com.fujitsu.fnst.fmooc.android.app.network.model;

/**
 * Created by wangc.fnst on 2016/1/4.
 */
public class Message {
    private String courseId;
    private String senderId;
    private User sender;
    private String messageId;
    private String subject;
    private String sentAt;
    private String textAbstract;
    private String replyOfNb;
    private String senderName;
    private String senderHeadUrl;
    private int topicId;
    private int messageNb;
    private String sendingDateTime;
    private String text;
    private String replyOfId;

    public Message() {
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSentAt() {
        return sentAt;
    }

    public void setSentAt(String sentAt) {
        this.sentAt = sentAt;
    }

    public String getTextAbstract() {
        return textAbstract;
    }

    public void setTextAbstract(String textAbstract) {
        this.textAbstract = textAbstract;
    }

    public String getReplyOfNb() {
        return replyOfNb;
    }

    public void setReplyOfNb(String replyOfNb) {
        this.replyOfNb = replyOfNb;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getSenderHeadUrl() {
        return senderHeadUrl;
    }

    public void setSenderHeadUrl(String senderHeadUrl) {
        this.senderHeadUrl = senderHeadUrl;
    }

    public User getSender(){
        return sender;
    }

    public void setSender(User sender){
        this.sender = sender;
    }

    public int getTopicId(){
        return this.topicId;
    }

    public void setTopicId(int topicId){
        this.topicId = topicId;
    }

    public int getMessageNb(){
        return messageNb;
    }

    public void setMessageNb(int messageNb){
        this.messageNb = messageNb;
    }

    public String getSendingDateTime(){
        return sendingDateTime;
    }

    public void setSendingDateTime(String sendingDateTime){
        this.sendingDateTime = sendingDateTime;
    }

    public String getText(){
        return text;
    }

    public void setText(String text){
        this.text = text;
    }

    public String getReplyOfId(){
        return replyOfId;
    }

    public void setReplyOfId(String replyOfId){
        this.replyOfId = replyOfId;
    }

}
