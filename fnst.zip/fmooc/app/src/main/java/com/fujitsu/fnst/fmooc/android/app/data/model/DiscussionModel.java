package com.fujitsu.fnst.fmooc.android.app.data.model;

import android.util.Log;
import com.fujitsu.fnst.fmooc.android.app.data.BaseModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Message;

import java.util.Date;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public class DiscussionModel extends BaseModel {
    private String id;
    private String parentId;
    private int order;
    private String time;
    private String headId;
    private String userId;
    private String userName;
    private String content;
    private String replyOf;
    private String courseId;
    private String replyOfNumber;

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public DiscussionModel() {
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getHeadId() {
        return headId;
    }

    public void setHeadId(String headId) {
        this.headId = headId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getReplyOf() {
        return replyOf;
    }

    public void setReplyOf(String replyOf) {
        this.replyOf = replyOf;
    }

    public String getReplyOfNumber(){
        return replyOfNumber;
    }

    public void setReplyOfNumber(String replyOfNumber){
        this.replyOfNumber = replyOfNumber;
    }

    public static DiscussionModel convertFromMessage(Message message){
        DiscussionModel model = new DiscussionModel();
        model.setContent(message.getText());
        model.setHeadId(message.getSender().getProfileImage().getImageId());
        model.setReplyOf(message.getReplyOfId());
        model.setReplyOfNumber(message.getReplyOfNb());
        model.setTime(message.getSentAt());
        model.setUserId(message.getSender().getUserId());
        model.setCourseId(message.getCourseId());
        model.setOrder(message.getMessageNb());
        model.setUserName(message.getSender().getDisplayName());
        model.setId(message.getMessageId());
        return model;
    }
}
