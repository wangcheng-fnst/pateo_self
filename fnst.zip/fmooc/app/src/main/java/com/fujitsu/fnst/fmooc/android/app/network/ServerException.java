package com.fujitsu.fnst.fmooc.android.app.network;

/**
 * custom net Exception
 * errorCode: net error code
 * errorMessage: custom message map errorCode
 * Created by wangc.fnst on 2016/1/14.
 */
public class ServerException extends Throwable {
    private int errorCode;
    private String errorMessage;

    public ServerException(int errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
