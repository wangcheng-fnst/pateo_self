package com.fujitsu.fnst.fmooc.android.app.network.service;

/**
 * Created by wangc.fnst on 2016/1/19.
 */
public class MessageService  {




    interface MessageInterface{

    }
}
