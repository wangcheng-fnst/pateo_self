package com.fujitsu.fnst.fmooc.android.app.data.model;

/**
 * Created by wangc.fnst on 2015/12/24.
 */
public class VideoModel {

    private String videoName;
    private String videoId;

    public VideoModel(String videoName, String videoId) {
        this.videoName = videoName;
        this.videoId = videoId;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }
}
