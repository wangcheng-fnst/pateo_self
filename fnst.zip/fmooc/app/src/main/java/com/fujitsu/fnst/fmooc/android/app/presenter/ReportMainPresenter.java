package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import com.fujitsu.fnst.fmooc.android.app.network.model.Report;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportDetailModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportSubmission;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.repository.ReportRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ReportMainViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.*;
import rx.Subscriber;
import rx.Subscription;

/**
 * Created by zhaod.fnst on 2016/01/12.
 */
public class ReportMainPresenter extends BasePresenter {
    private ReportMainViewInterface view;
    private String contentId;
    private Subscription getReportSubscription;
    private Report content;
    private ReportSubmission submission;
    private ReportDetailModel reportModel;

    public ReportMainPresenter(ReportMainViewInterface loginViewInterface){
        super();
        view = loginViewInterface;
        contentId = view.getContentId();
        getReportDetail();
    }
    public void getReportDetail(){
        view.showWaitingDialog();
        getReportSubscription = ReportRepository.getInstance().getContentInformation(contentId, true, getSubscriber());
    }

    private Subscriber getSubscriber(){
        return new Subscriber<ReportDetailModel>() {
            @Override
            public void onCompleted() {
                //view.showToast("onCompleted");
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(ReportDetailModel report) {
                reportModel = report;
                content=report.getContent();
                submission=report.getSubmission();
                view.setReportDetail(report);
                view.hideWaitingDialog();
            }
        };
    }

    public void sendReport(){
        Intent intent = new Intent(context,ReportSendActivity.class);
        intent.putExtra(Constants.EXTRA_REPORT, reportModel);
//        context.startActivity(intent);
        ((ReportMainActivity) view).startActivityForResult(intent, 1000);
    }

    public void scoreMyself(){
        Intent intent = new Intent(context,ReportSelfActivity.class);
        intent.putExtra(Constants.EXTRA_REPORT,reportModel);
//        context.startActivity(intent);
        ((ReportMainActivity) view).startActivityForResult(intent, 1000);
    }

    public void scoreOthers(int position){
        Intent intent = new Intent(context,ReportOtherActivity.class);
        intent.putExtra(Constants.EXTRA_REPORT,reportModel);
        intent.putExtra("position", position);
        intent.putExtra("hasEvaluation", false);
//        context.startActivity(intent);
        ((ReportMainActivity) view).startActivityForResult(intent, 1000);
    }

    public void reflection(){
        Intent intent = new Intent(context,ReportReflectionActivity.class);
        intent.putExtra(Constants.EXTRA_REPORT, reportModel);
//        context.startActivity(intent);
        ((ReportMainActivity) view).startActivityForResult(intent, 1000);
    }

    public void toHelp(){
        Intent intent = new Intent(context,ReportHelpActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
