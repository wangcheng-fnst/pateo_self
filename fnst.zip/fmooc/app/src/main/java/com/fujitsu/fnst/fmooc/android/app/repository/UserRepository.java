package com.fujitsu.fnst.fmooc.android.app.repository;

import android.util.Log;
import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.NetCallback;
import com.fujitsu.fnst.fmooc.android.app.network.model.*;
import com.fujitsu.fnst.fmooc.android.app.network.service.UserService;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;

import retrofit.Call;
import retrofit.Response;
import rx.Subscriber;
import rx.Subscription;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by wangc.fnst on 2015/12/24.
 */
public class UserRepository {
    private String TAG_LOG = UserRepository.class.getName();

    public static final String LOGIN_ACTIVITY = "login_activity";//发出请求的来源
    public static final String LAUNCH_ACTIVITY = "launch_activity";//发出请求的来源

    public static final String DUMMY_CODE_RESPONSE = "dummy_code_response";
    public static final String LOGIN_RESPONSE = "login_response";//返回的类型
    public static final String REGISTER_RESPONSE = "register_response";
    public static final String SEND_CODE_RESPONSE = "send_code_response";
    public static final String RESET_PASSWORD_RESPONSE = "reset_password_response";
    public static final String FORGET_PASSWORD_RESPONSE = "forget_password_response";
    public static final String GET_USERINFO_RESPONSE = "get_userinfo_response";



    private Map<String,OnGetModelFinishImpl> listeners ;

    private static UserRepository instance;

    public static UserRepository getInstance(){
        if (instance == null){
            instance = new UserRepository();
        }
        return instance;
    }

    public UserRepository() {
        listeners = new HashMap<String,OnGetModelFinishImpl>();
    }

    public void dummyCode(String code, final String type){
        Call<EmptyModel> call = UserService.getService().dummyCode(code);
        call.enqueue(new NetCallback<EmptyModel>() {
            @Override
            public void onSuccess(Response<EmptyModel> response) {
                //TODO:success
                Log.e(TAG_LOG, "send code");
                getListener(type).onSuccess(DUMMY_CODE_RESPONSE,response.body());
            }

            @Override
            public void failure(int code,String message) {
                Log.e(TAG_LOG,message);
                getListener(type).onFailed(DUMMY_CODE_RESPONSE, message);
            }
        });
    }
    public void login(String mail,String pwd, final String type){
        Call<LoginModel> call = UserService.getService().login(mail, pwd);
        call.enqueue(new NetCallback<LoginModel>() {
            @Override
            public void onSuccess(Response<LoginModel> response) {
                //TODO:success
                Log.e(TAG_LOG, response.body().getUserId());
                getListener(type).onSuccess(LOGIN_RESPONSE,response.body());
            }

            @Override
            public void failure(int code,String message) {
                Log.e(TAG_LOG,message);
                getListener(type).onFailed(LOGIN_RESPONSE, message);
            }

        });
    }

    public void newUser(String name,String email,String pwd, final String type){
        Call<LoginModel> call = UserService.getService().newUser(name, email, pwd);
        call.enqueue(new NetCallback<LoginModel>() {
            @Override
            public void onSuccess(Response<LoginModel> response) {
                //TODO:success
                Log.e(TAG_LOG, "create " + response.body().getUserId());
                getListener(type).onSuccess(REGISTER_RESPONSE, response.body());

            }

            @Override
            public void failure(int code,String message) {
                Log.e(TAG_LOG,"create error");
                getListener(type).onFailed(REGISTER_RESPONSE, message);
            }
        });

    }
    public Subscription changeHead(String id,String imageId,Subscriber subscriber){
        return UserService.getService().changeHeadImage(id,imageId,subscriber);
    }
    public void sendCode(String mail, String codeFor, final String type){
        Call<EmptyModel> call = UserService.getService().sendCode(mail, codeFor);
        call.enqueue(new NetCallback<EmptyModel>() {
            @Override
            public void onSuccess(Response<EmptyModel> response) {
                //TODO:success
                Log.e(TAG_LOG, "get code");
                getListener(type).onSuccess(SEND_CODE_RESPONSE,response.body());
            }

            @Override
            public void failure(int code,String message) {
                Log.e(TAG_LOG,message);
                getListener(type).onFailed(SEND_CODE_RESPONSE, message);
            }
        });
    }

    public Subscription getImagesFromNet(Subscriber<Image> subscriber){
        return UserService.getService().getImages(subscriber);
    }

    public Subscription confirmCode(Subscriber<CodeEmail> subscriber, String code){
        return UserService.getService().confirmCode(subscriber, code);
    }

//    public void resetPwd(String id, String oldPassword, String newPassword, final String type){
//        Call<EmptyModel> call = UserService.getService().resetPwd(id, oldPassword, newPassword);
//        call.enqueue(new NetCallback<EmptyModel>() {
//            @Override
//            public void onSuccess(Response<EmptyModel> response) {
//                //TODO:success
//                Log.e(TAG_LOG, "reset password");
//                getListener(type).onSuccess(RESET_PASSWORD_RESPONSE,response.body());
//            }
//
//            @Override
//            public void failure(int code,String message) {
//                Log.e(TAG_LOG,message);
//                getListener(type).onFailed(RESET_PASSWORD_RESPONSE);
//            }
//        });
//    }

    public void forgetPwd(String mail, String newPassword, final String type){
        Call<EmptyModel> call = UserService.getService().forgetPwd(mail, newPassword);
        call.enqueue(new NetCallback<EmptyModel>() {
            @Override
            public void onSuccess(Response<EmptyModel> response) {
                //TODO:success
                //Log.e(TAG_LOG, response.body().getUserId());
                getListener(type).onSuccess(FORGET_PASSWORD_RESPONSE,response.body());
            }

            @Override
            public void failure(int code,String message) {
                Log.e(TAG_LOG,message);
                getListener(type).onFailed(FORGET_PASSWORD_RESPONSE,message);
            }
        });
    }

    public Subscription getUserInformation(String id,String data, Subscriber<UserInfoModel> subscriber){
        return UserService.getService().getUserInformation(id,data,subscriber);
    }
    public Subscription setUserInformation(String id,Map<String, Object> data, Subscriber<UserInfoModel> subscriber){
        return UserService.getService().setUserInformation(id, data, subscriber);
    }
    public Subscription resetPwd(String id, String oldPassword, String newPassword,Subscriber<EmptyModel> subscriber){
        return UserService.getService().resetPwd(id, oldPassword, newPassword, subscriber);
    }
    public Subscription userLogout(Subscriber<EmptyModel> subscriber){
        return UserService.getService().userLogout(subscriber);
    }

    public void getUserInfo(String id, String data, final String type){
        Call<EmptyModel> call = UserService.getService().getUserInfo(id, data);
        call.enqueue(new NetCallback<EmptyModel>() {
            @Override
            public void onSuccess(Response<EmptyModel> response) {
                //TODO:success
                //Log.e(TAG_LOG, response.body().getUserId());
                getListener(type).onSuccess(GET_USERINFO_RESPONSE,response.body());
            }

            @Override
            public void failure(int code,String message) {
                Log.e(TAG_LOG,message);
                getListener(type).onFailed(GET_USERINFO_RESPONSE, message);
            }
        });
    }


    private OnGetModelFinishImpl getListener(String type){

        for (String key : listeners.keySet()){
            if (key.equals(type)){
                return listeners.get(key);
            }
        }
        OnGetModelFinishImpl listener = new OnGetModelFinishImpl() {
            @Override
            public void onSuccess(String type, Object result) {

            }

            @Override
            public void onFailed(String type, String message) {

            }
        };
        return listener;
    }

    public void register(String type,OnGetModelFinishImpl listener){
        listeners.put(type,listener);
    }
    public void unRegister(String type){
        listeners.remove(type);
    }

}
