package com.fujitsu.fnst.fmooc.android.app.network;


import android.util.Log;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import retrofit.Callback;
import retrofit.Response;
import retrofit.Retrofit;
import retrofit.http.Header;

/**
 * Created by wangc.fnst on 2015/12/25.
 */
public abstract class NetCallback<T> implements Callback<T>{


    private void parseResponse(Response response ){
        for (String header : response.headers().names()){
            if (header.equals(Constants.CONTENT_TOKEN)){
                String token = response.headers().get(Constants.CONTENT_TOKEN);
                ApplicationUtils.setToken(token);
            }

        }
    }

    @Override
    public void onResponse(Response<T> response, Retrofit retrofit) {
        if (response.isSuccess()){
            parseResponse(response);
            onSuccess(response);
        }else{
            switch (response.code()) {
                case ErrorCode.ERROR_AUTH:
                    failure(ErrorCode.ERROR_AUTH, response.message());
                    break;
                case ErrorCode.ERROR_NOT_FONT:
                    failure(ErrorCode.ERROR_NOT_FONT, response.message());
                    break;
                case ErrorCode.ERROR_PARAMETER:
                    failure(ErrorCode.ERROR_PARAMETER, response.message());
                    break;
                case ErrorCode.ERROR_PERMISSION:
                    failure(ErrorCode.ERROR_PERMISSION, response.message());
                    break;
                case ErrorCode.ERROR_TOO_LARGE:
                    failure(ErrorCode.ERROR_TOO_LARGE, response.message());
                    break;
                case ErrorCode.ERROR_URI:
                    failure(ErrorCode.ERROR_URI, response.message());
                    break;
                default:
                    failure(ErrorCode.ERROR_OTHER, response.message());
            }

        }

    }

    @Override
    public void onFailure(Throwable throwable) {
        failure(ErrorCode.ERROR_OTHER,throwable.getMessage());
    }



    public abstract void onSuccess(Response<T> response);
    public abstract void failure(int errorCode,String errorMessage);

}
