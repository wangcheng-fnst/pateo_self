package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.SubmittedReport;
import com.fujitsu.fnst.fmooc.android.app.repository.ReportRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.ReportReflectionViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.ReportSelfViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ReportReflectionActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ReportSelfActivity;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;
import rx.Subscriber;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by lijl.fnst on 2016/01/19.
 */
public class ReportReflectionPresenter extends BasePresenter implements EditChangeListener.TextChangeCallback{
    private ReportReflectionViewInterface view;
    private String comment;
    public ReportReflectionPresenter(ReportReflectionViewInterface reportReflectionViewInterface){
        super();
        view = reportReflectionViewInterface;
        init();
    }
    public void init(){
        EditChangeListener answerWatcher = new EditChangeListener();
        answerWatcher.setCallback(this);
        view.setCommentListener(answerWatcher);
    }

    public void submit(String contentId,String submissionId,String reflectionText){
        if(reflectionText.length() > 250){
            view.showToast(context.getResources().getString(R.string.report_comment_too_long));
        }else {
            Map<String, Object> data = new HashMap<String, Object>();
            data.put("forSubmission", submissionId);
            data.put("reflectionText", reflectionText);
            ReportRepository.getInstance().addReportAnswer(contentId, data, getSubscriber());
        }
    }

    private Subscriber getSubscriber(){
        return new Subscriber<SubmittedReport>() {
            @Override
            public void onCompleted() {
//                view.showToast("onCompleted");
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(SubmittedReport report) {
//                view.showToast("onNext");
                view.hideWaitingDialog();
//                Intent intent = new Intent(context,ReportMainActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                intent.putExtra(Constants.EXTRA_CONTENTID, view.getContentId());
//                context.startActivity(intent);

                Intent intent = new Intent();
                intent.putExtra(Constants.EXTRA_CONTENTID, view.getContentId());
                ((ReportReflectionActivity)view).setResult(Constants.REPORT_STEP4, intent);
                ((ReportReflectionActivity)view).finish();
            }
        };
    }

    @Override
    public void formatRight() {
        if (checkValue()){
            view.enableBtn();
        }else{
            view.disableBtn();
        }
    }

    private boolean checkValue(){
        comment = view.getComment();
        if (!StringUtils.isBlank(comment)){
            return true;
        }
        return false;
    }
}
