package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.view.View;
import android.widget.Button;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.RegisterSuccessPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.view.RegisterSuccessViewInterface;

import butterknife.Bind;

public class RegisterSuccessViewActivity extends BaseActivity<RegisterSuccessPresenter> implements RegisterSuccessViewInterface {
    @Bind(R.id.id_register_success_btn)
    Button successBtn;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new RegisterSuccessPresenter(this);
        presenter.setStatus();
        successBtn.setOnClickListener(this);
    }
    @Override
    protected int getLayout() {
        return R.layout.activity_register_success;
    }

    @Override
    public boolean showBackImg() {
        return false;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.register_title);
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_register_success_btn){
            presenter.login();
        }

    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();
    }
}
