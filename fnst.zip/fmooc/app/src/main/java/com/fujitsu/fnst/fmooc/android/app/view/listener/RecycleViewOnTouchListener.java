package com.fujitsu.fnst.fmooc.android.app.view.listener;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public class RecycleViewOnTouchListener implements View.OnTouchListener {

    public interface CallbackFromMove {
        void move(boolean isNext);
    }

    private float downX, x;
    private CallbackFromMove callbackFromMove;
    private boolean moveOver;

    public boolean isMoveOver() {
        return moveOver;
    }

    public void setMoveOver(boolean moveOver) {
        this.moveOver = moveOver;
    }

    public CallbackFromMove getCallbackFromMove() {
        return callbackFromMove;
    }

    public void setCallbackFromMove(CallbackFromMove callbackFromMove) {
        this.callbackFromMove = callbackFromMove;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        x = event.getX();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                Log.e("move", "ACTION_DOWN");
                downX = x;
                break;
            case MotionEvent.ACTION_MOVE:
                Log.e("move", "ACTION_MOVE");
                break;
            case MotionEvent.ACTION_UP:
                Log.e("move", "ACTION_UP");
                if (x - downX > 70) {
                    if (getCallbackFromMove() != null) {
                        getCallbackFromMove().move(false);
                    }
                }
                if (downX - x > 70) {
                    if (getCallbackFromMove() != null) {
                        getCallbackFromMove().move(true);
                    }
                }
                break;
        }
        if (!ApplicationUtils.isOver && event.getAction() == MotionEvent.ACTION_DOWN)
            return false;
        return true;
    }
}
