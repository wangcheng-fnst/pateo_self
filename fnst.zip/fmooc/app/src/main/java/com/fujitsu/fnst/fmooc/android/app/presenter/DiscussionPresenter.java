package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.os.Handler;
import android.util.Log;
import android.view.View;
import com.fujitsu.fnst.fmooc.android.app.data.model.DiscussionModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Message;
import com.fujitsu.fnst.fmooc.android.app.repository.DiscussionRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.TimeUtils;
import com.fujitsu.fnst.fmooc.android.app.view.DiscussionViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;
import rx.Subscriber;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public class DiscussionPresenter extends BasePresenter implements PullRefleashListView.OnRefleashListener {

    private DiscussionViewInterface view;
    private List<DiscussionModel> mData;
    private Handler mHandler;
    private int page = 1;
    private String id;
    boolean notifyData = true;
    private boolean checkNet=true;

    public DiscussionPresenter(DiscussionViewInterface view,int page, String id) {
        this.view = view;
        this.page = page;
        this.id = id;
        mHandler= new Handler();

    }

    public void setCheckNet(boolean checkNet){
        this.checkNet = checkNet;
    }
    public void setNotifyData(boolean notifyData){
        this.notifyData = notifyData;
    }
    public List<DiscussionModel> getmData(){
        return mData;
    }

    public void submitMessage(boolean isToOther,String id,String replyOf,int length){
        String message = view.getEditContent();
        if (!isToOther){
            if (!StringUtils.isBlank(message)){
                sendMessageToNet(id, message, "");
            }
        }else{
            if (!StringUtils.isBlank(message) && !StringUtils.isBlank(replyOf)){
                if(message.length() > length){
                    message = message.substring(length,message.length());
                    sendMessageToNet(id, message, replyOf);
                }
            }
        }
    }

    public void getMessageById(String messageId){
        DiscussionRepository.getInstance().getMessageById(id, messageId, getDiscussionModelSubscriber());
    }

    private void sendMessageToNet(String id, String text,String replyto){
        String replace = StringUtils.replacePostString(text);
        view.showWaitingDialog();
        DiscussionRepository.getInstance().sendMessage(id, replace, replyto, getMessageSubscriber());
    }

    private DiscussionModel getReplyOfModel(String replyOf){
        for (DiscussionModel model : mData){
            if (model.getId().equals(replyOf)){
                return model;
            }
        }
        return  null;
    }

    @Override
    public void onRefresh() {
        page++;
        notifyData=false;
        checkNet=false;
        getMessages();
    }

    @Override
    public void onLoadMore() {
        page=1;
        notifyData=true;
        checkNet=false;
        getMessages();
    }

    /**
     * get data from net
     */
    public void getMessages(){
        Subscriber<List<DiscussionModel>> subscriber = new Subscriber<List<DiscussionModel>>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable throwable) {
                view.hideWaitingDialog();
                if(checkNet){
                    view.getDiscussionLayout().setVisibility(View.GONE);
                    view.getDiscussionErrorLayout().setVisibility(View.VISIBLE);
                }
//                else{
//                    view.showToast("network wrong");
//                }
                view.onLoad();
            }

            @Override
            public void onNext(List<DiscussionModel> discussionModels) {
                view.hideWaitingDialog();
                view.getDiscussionLayout().setVisibility(View.VISIBLE);
                view.getDiscussionErrorLayout().setVisibility(View.GONE);
                if (page == 1){
                    view.resetData();
                }
                view.addItems(discussionModels);
                view.notifyData(notifyData);
                view.onLoad();
            }
        };
        DiscussionRepository.getInstance().getMessages(id,page,subscriber);
    }

    private Subscriber getDiscussionModelSubscriber(){
        return new Subscriber<DiscussionModel>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable throwable) {
                view.showToast(throwable.getMessage());
            }

            @Override
            public void onNext(DiscussionModel discussionModel) {
                view.hideWaitingDialog();
                view.setMessage(discussionModel);
            }
        };
    }

    private Subscriber getMessageSubscriber(){
        return new Subscriber<Message>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable throwable) {
                view.hideWaitingDialog();
                view.showToast(throwable.getMessage());
            }

            @Override
            public void onNext(Message discussionModel) {
                page=1;
                notifyData=true;
                view.removeEditListener();
                getMessages();
            }
        };
    }
}
