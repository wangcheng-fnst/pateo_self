package com.fujitsu.fnst.fmooc.android.app.view.adapter;

import android.view.View;
import butterknife.ButterKnife;

/**
 * Created by wangc.fnst on 2015/12/16.
 */
public interface BaseViewHolder {


}
