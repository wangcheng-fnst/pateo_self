package com.fujitsu.fnst.fmooc.android.app.view;

/**
 * Created by wangc.fnst on 2015/12/10.
 */
public interface LaunchViewInterface extends BaseViewInterface {



}
