package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by lijl.fnst on 2016/01/19.
 */
public class ReportEvaluationWording implements Serializable {
    private List<ReportEvaluationActivity> activities;

    public List<ReportEvaluationActivity> getActivities() {
        return activities;
    }

    public void setActivities(List<ReportEvaluationActivity> activities) {
        this.activities = activities;
    }
}
