package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.model.LoginModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.service.RssService;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;

import java.util.Timer;
import java.util.TimerTask;

import retrofit.http.Url;

public class FisdomActivity extends AppCompatActivity implements OnGetModelFinishImpl<LoginModel> {

    private String userName, password;
    private String requestType = UserRepository.LAUNCH_ACTIVITY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fisdom);
        ApplicationUtils.isSetting = false;
        Intent urlIntent = getIntent();
        String action = urlIntent.getAction();
        if (Intent.ACTION_VIEW.equals(action)){
            Uri uri = urlIntent.getData();
            String registerStatus = ShareReferencesManager.getInstance(this).getStringValue(Constants.SP_REGISTER_STATUS);
            String changeStatus = ShareReferencesManager.getInstance(this).getStringValue(Constants.SP_CHANGE_STATUS);
            if (uri != null){
                String code = uri.getQueryParameter("code");
                if (uri.getQueryParameter("action").equals("newUser")){
//                    if (registerStatus == null ||registerStatus.equals("failed")) {
                        final Intent it = new Intent(this, RegisterActivity.class);
                        it.putExtra("code", code);
                        it.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        Timer timer = new Timer();
                        TimerTask task = new TimerTask() {
                            @Override
                            public void run() {
                                startActivity(it);
                                finish();
                            }
                        };
                        timer.schedule(task, 1000 * 2);
//                    }else {
//                        userName = ShareReferencesManager.getInstance(this).getStringValue(Constants.SP_USER_NAME);
//                        password = ShareReferencesManager.getInstance(this).getStringValue(Constants.SP_USER_PASSWORD);
//                        if (!StringUtils.isBlank(userName)
//                                &&!StringUtils.isBlank(password)){
//                            UserRepository.getInstance().register(requestType,this);
//                            UserRepository.getInstance().login(userName, password, requestType);
//                        } else {
//                            final Intent it = new Intent(this, LoginActivity.class);
//                            Timer timer = new Timer();
//                            TimerTask task = new TimerTask() {
//                                @Override
//                                public void run() {
//                                    startActivity(it);
//                                    finish();
//                                }
//                            };
//                            timer.schedule(task, 1000 * 2);
//                        }
//                    }
                } else if (uri.getQueryParameter("action").equals("resetPassword")){
//                    if (changeStatus == null || changeStatus.equals(Constants.SP_CHANGE_STATUS_FAILED)) {
                        final Intent it = new Intent(this, ChangePwdActivity.class);
                        it.putExtra("code", code);
                        it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        Timer timer = new Timer();
                        TimerTask task = new TimerTask() {
                            @Override
                            public void run() {
                                startActivity(it);
                                finish();
                            }
                        };
                        timer.schedule(task, 1000 * 2);
//                    }else {
//                        userName = ShareReferencesManager.getInstance(this).getStringValue(Constants.SP_USER_NAME);
//                        password = ShareReferencesManager.getInstance(this).getStringValue(Constants.SP_USER_PASSWORD);
//                        if (!StringUtils.isBlank(userName)
//                                &&!StringUtils.isBlank(password)){
//                            UserRepository.getInstance().register(requestType,this);
//                            UserRepository.getInstance().login(userName, password, requestType);
//                        } else {
//                            final Intent it = new Intent(this, LoginActivity.class);
//                            Timer timer = new Timer();
//                            TimerTask task = new TimerTask() {
//                                @Override
//                                public void run() {
//                                    startActivity(it);
//                                    finish();
//                                }
//                            };
//                            timer.schedule(task, 1000 * 2);
//                        }
//                    }
                } else if (uri.getQueryParameter("action").equals("report")){
                    final Intent it = new Intent(this, ReportMainActivity.class);
                    it.putExtra("code", code);
                    it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    Timer timer = new Timer();
                    TimerTask task = new TimerTask() {
                        @Override
                        public void run() {
                            startActivity(it);
                            finish();
                        }
                    };
                    timer.schedule(task, 1000 * 2);
                }

            }

        } else {
            userName = ShareReferencesManager.getInstance(this).getStringValue(Constants.SP_USER_NAME);
            password = ShareReferencesManager.getInstance(this).getStringValue(Constants.SP_USER_PASSWORD);
            if (!StringUtils.isBlank(userName)
                    &&!StringUtils.isBlank(password)){
                UserRepository.getInstance().register(requestType,this);
                UserRepository.getInstance().login(userName, password, requestType);
            } else {
                final Intent it = new Intent(this, LoginActivity.class);
                Timer timer = new Timer();
                TimerTask task = new TimerTask() {
                    @Override
                    public void run() {
                        startActivity(it);
                        finish();
                    }
                };
                timer.schedule(task, 1000 * 2);
            }

        }

    }

    @Override
    public void onSuccess(String type, LoginModel result) {
        if (type.equals(UserRepository.LOGIN_RESPONSE)){

            ShareReferencesManager.getInstance(this).setValue(Constants.SP_USER_ID, result.getUserId());
            final Intent intent = new Intent(this, MainFragmentActivity.class);
//        Intent intent = new Intent(context, CourseDetailActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
            final Intent intentService = new Intent(this, RssService.class);
            intentService.setAction(Constants.ACTION_GET_RSS);
//            startService(intentService);

            Timer timer = new Timer();
            TimerTask task = new TimerTask() {
                @Override
                public void run() {
                    startActivity(intent);
                    startService(intentService);
                    finish();
                }
            };
            timer.schedule(task, 1000 * 2);

        }

    }

    @Override
    public void onFailed(String type,String message) {
        final Intent it = new Intent(this, LoginActivity.class);
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                startActivity(it);
                finish();
            }
        };
        timer.schedule(task, 1000 * 2);
    }

    @Override
    public void onDestroy() {
        UserRepository.getInstance().unRegister(requestType);
        super.onDestroy();

    }

}
