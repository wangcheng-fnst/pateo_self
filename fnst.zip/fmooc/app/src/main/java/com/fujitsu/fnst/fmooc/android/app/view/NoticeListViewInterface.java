package com.fujitsu.fnst.fmooc.android.app.view;

/**
 * Created by wangc.fnst on 2016/1/12.
 */
public interface NoticeListViewInterface extends BaseViewInterface {
    void stopLoad();
    void notifyData();
}
