package com.fujitsu.fnst.fmooc.android.app.view.component.tree;


import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.DiscussionModel;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import org.w3c.dom.Text;

import java.util.List;

/**
 * Created by zhaod.fnst on 2016/1/20.
 */
public class DiscussionDetailDialog extends Dialog implements android.view.View.OnClickListener {

	private LinearLayout ll;
	private Context context;
	private float width;
	private DiscussionModel model;
	private List<DiscussionModel> mData;

	private MyDialogListener listener;

	public interface MyDialogListener{
		public void onClick(View view);
	}

	private TextView orderTxt;
	private TextView timeTxt1;
	private TextView timeTxt2;
	private TextView nameTxt;
	private ImageView headImg;
	private TextView contentTxt;
	private Button closeBtn;
	private LinearLayout replyLayout;
	private TextView replyTxt;


	public static DiscussionDetailDialog instance = null;

	public DiscussionDetailDialog(Context context,DiscussionModel model,List<DiscussionModel> mData,MyDialogListener listener) {
		super(context, R.style.style_discussion_dialog);
		this.context = context;
		this.model=model;
		this.mData = mData;
		this.listener = listener;
		init();
	}

	public DiscussionDetailDialog(Context context, int theme) {
		super(context, R.style.style_discussion_dialog);
		this.context = context;
		init();
	}

	protected DiscussionDetailDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
		super(context, cancelable, cancelListener);
		this.context = context;
		init();
	}

	public void refreshDialog(String id){
		DiscussionModel newModel = getById(id);
		this.model = newModel;
		init();
	}
	private void init(){
		this.setCancelable(true);
		Rect frame = new Rect();
		((Activity)context).getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
		int margin = context.getResources().getDimensionPixelSize(R.dimen.dp_20);
		int width = context.getResources().getDimensionPixelSize(R.dimen.dp_340);
		int height = frame.bottom - frame.top - margin;
		LayoutInflater inflater = LayoutInflater.from(context);
		ll = (LinearLayout) inflater.inflate(R.layout.discussion_detail_activity, null);
		orderTxt = (TextView) ll.findViewById(R.id.id_item_order_txt);
		timeTxt1 = (TextView) ll.findViewById(R.id.id_item_time1_txt);
		timeTxt2 = (TextView) ll.findViewById(R.id.id_item_time2_txt);
		nameTxt = (TextView) ll.findViewById(R.id.id_item_name_txt);
		headImg = (ImageView) ll.findViewById(R.id.id_item_head_img);
		contentTxt = (TextView) ll.findViewById(R.id.id_item_content_txt);
		closeBtn = (Button) ll.findViewById(R.id.id_close_btn);
		replyLayout = (LinearLayout) ll.findViewById(R.id.id_reply_layout);
		replyTxt = (TextView) ll.findViewById(R.id.id_reply_txt);
		if (!StringUtils.isBlank(model.getReplyOf())){
			if (getById(model.getReplyOf()) != null) {
				replyLayout.setVisibility(View.VISIBLE);
				replyTxt.setTag(R.id.id,model.getReplyOf());
				replyTxt.setOnClickListener(this);
				replyTxt.setText("No." +getById(model.getReplyOf()).getOrder());
				replyTxt.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
			}else {
				replyLayout.setVisibility(View.GONE);
			}
		}else {
			replyLayout.setVisibility(View.GONE);
		}
		headImg.setImageResource(Constants.getImageResId_30(model.getHeadId() + ""));
		orderTxt.setText("No."+model.getOrder());
		timeTxt1.setText(model.getTime().substring(0, 10));
		timeTxt2.setText(model.getTime().substring(11, 16));
		nameTxt.setText(model.getUserName());
		contentTxt.setText(model.getContent());

		closeBtn.setOnClickListener(this);


		LinearLayout.LayoutParams params  = new LinearLayout.LayoutParams(width, height);
		setContentView(ll, params);
		WindowManager.LayoutParams lp = this.getWindow().getAttributes();
		lp.gravity = Gravity.CENTER;
		getWindow().setAttributes(lp);


	}

	public void show() {
		super.show();
	}

	private DiscussionModel getById(String id){
		for (DiscussionModel model : mData){
			if (model.getId().equals(id)){
				return model;
			}
		}
		return  null;

	}

	@Override
	public void onClick(View v) {
		ApplicationUtils.getDeviceDp(context);
		listener.onClick(v);
	}
}
