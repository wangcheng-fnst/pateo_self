package com.fujitsu.fnst.fmooc.android.app.utils;

import android.content.pm.ApplicationInfo;

import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.network.model.ProfileImage;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/7.
 */
public class Constants {

    //for Fnst
//    public static final String BASE_URL = "http://192.168.20.202:8080";
//    public static final String HOST_NAME = "http://192.168.20.202:8080";
//    public static final String BASE_URL = "http://pf.fisdom.org/api/";
    //for japan
    public static final String BASE_URL = "http://133.162.204.217/api/";
    public static final String HOST_NAME = "http://133.162.204.217/";
    public static final String CONTENT_TOKEN = "Fisdom-User-Token";
    public static final String CONTENT_REFERER = "http://www.fisdom.org/index.html";
    public static final String AGREEMENT_URL = "https://www.fisdom.org/terms_of_service";
    public static final String POLICY_URL = "https://www.fisdom.org/privacy_policy";
    public static final String ABOUT_URL = "https://www.fisdom.org/overview";
    public static final String ACTION_URL = "https://www.fisdom.org/help";
    public static final String DOWNLOAD_URL = "https://pf.fisdom.org/tmp";



    public static final String ACTION_GET_RSS = "action_get_rss";
    public static final String ACTION_HAS_NEW_RSS = "action_has_new_rss";


    public static final int CHANGE_PWD_TYPE_FORGET = 0x00;
    public static final int CHANGE_PWD_TYPE_CHANGE = 0x01;

    public static final int COURSE_ING_MODE = 0x00;
    public static final int COURSE_END_MODE = 0x01;

    public static final String URL = "";




    public static final String SP_USER_NAME = "sp_user_name";
    public static final String SP_USER_PASSWORD = "sp_user_password";
    public static final String SP_REGISTER_STATUS = "sp_register_status";
    public static final String SP_CHANGE_STATUS = "sp_change_status";
    public static final String SP_CHANGE_STATUS_SUCCESS = "sp_change_status_success";
    public static final String SP_CHANGE_STATUS_FAILED = "sp_change_status_failed";

    public static final String SP_USER_ID = "sp_user_id";


    public static final String EXTRA_TYPE = "extra_type";
    public static final String EXTRA_COURSE = "extra_course";
    public static final String EXTRA_COURSE_ID = "extra_course_id";
    public static final String EXTRA_USER = "extra_user";
    public static final String EXTRA_RESULT = "extra_result";
    public static final String EXTRA_DISCUSSION = "extra_discussion";
    public static final String EXTRA_NOTICE = "extra_notice";
    public static final String EXTRA_IMAGES = "extra_images";
    public static final String EXTRA_STATUS = "extra_status";
    public static final String EXTRA_USER_STATUS = "extra_user_status";

    public static final int INTRODUCE_TYPE = 0x00;
    public static final int TEA_TYPE = 0x01;

    public static final String PROFILE_SETTING_TYPE = "profile_type";
    public static final int PROFILE_SETTING_IMAGE = 0X00;
    public static final int PROFILE_SETTING_FIRSTNAME = 0X01;
    public static final int PROFILE_SETTING_SEX = 0X02;
    public static final int PROFILE_SETTING_BIRTHDAY = 0X03;
    public static final int PROFILE_SETTING_EDUCATION = 0X04;

    public static final String SETTING_INWIFI_PLAY = "inwifi_play";

    public static final String USER_DATA_BASIC = "basic";
    public static final String USER_DATA_EXTENDED = "extended";


    public static final String COURSE_BEGIN = "cannotEnrollAnymore";
    public static final String COURSE_DOING = "canEnroll";
    public static final String COURSE_END = "cannotEnrollYet";

    public static final String EXTRA_REPORT = "extra_report";

    public static final String EXTRA_CONTENTID = "contentId";


    public static int PLAY_STATUS_PLAYING = 0x01;
    public static int PLAY_STATUS_PLAYED = 0x02;
    public static int PLAY_STATUS_UNPLAY = 0x03;


    public static final int REPORT_STEP1 = 0X00;
    public static final int REPORT_STEP2 = 0X01;
    public static final int REPORT_STEP3 = 0X02;
    public static final int REPORT_STEP4 = 0X03;

    public static final String MALE = "MALE";
    public static final String FEMALE = "FEMALE";
    public static final String OTHER = "OTHER";

    public static final String ISSETTING = "isSetting";

    public static final String CODE_CREATEACCOUNT = "createAccount";
    public static final String CODE_RESETPASSWORD = "resetPassword";

    public static final String CONTENT_TYPE_REPORT = "Report";

    private static List<ProfileImage> images;

    public static List<ProfileImage> getImages() {
        if (images == null) {
            images = new ArrayList<ProfileImage>();
            for (int i = 1; i < 9; i++) {
                ProfileImage profileImage = new ProfileImage();
                profileImage.setImageId(i + "");
                images.add(profileImage);
            }
        }
        return images;
    }

    public static int getImageResId_120(String imageId) {
        ApplicationInfo app = FmoocApplication.getInstance().getApplicationInfo();
            return FmoocApplication.getInstance().getResources().getIdentifier("photo_img_0" + imageId + "_120", "drawable", app.packageName);
    }

    public static int getImageResId_71(String imageId) {
        ApplicationInfo app = FmoocApplication.getInstance().getApplicationInfo();
            return FmoocApplication.getInstance().getResources().getIdentifier("photo_img_0" + imageId + "_120", "drawable", app.packageName);
    }

    public static int getImageResId_30(String imageId) {
        ApplicationInfo app = FmoocApplication.getInstance().getApplicationInfo();
            return FmoocApplication.getInstance().getResources().getIdentifier("photo_img_0" + imageId + "_120", "drawable", app.packageName);
    }
}
