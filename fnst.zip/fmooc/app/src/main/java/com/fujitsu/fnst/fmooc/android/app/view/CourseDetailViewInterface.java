package com.fujitsu.fnst.fmooc.android.app.view;

import com.fujitsu.fnst.videoplayer.app2.model.Video;
import com.fujitsu.fnst.videoplayer.app2.view.MediaController;
import com.fujitsu.fnst.videoplayer.app2.view.SuperVideoPlayer;

import java.util.ArrayList;

/**
 * Created by wangc.fnst on 2015/12/21.
 */
public interface CourseDetailViewInterface extends BaseViewInterface {

    void showWaitingDialog();
    void dismissWaitingDialog();
    void loadVideo(ArrayList<Video> videos);
    void setVideoPlayCallback(SuperVideoPlayer.VideoPlayCallbackImpl callback);
    void resetPageToPortrait();
    void showPlayBtn();
    void dismissPlayBtn();
    void showVideoPlayer();
    void dismissVideoPlayer();
    void videoClose();
    void setPageType(MediaController.PageType pageType);

    void showTitleBar();
    void dismissTitleBar();
    void showIntroduce();
    void dismissIntroduce();


}
