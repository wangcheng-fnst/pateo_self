package com.fujitsu.fnst.fmooc.android.app.view;

import android.widget.LinearLayout;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;

import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/18.
 */
public interface CourseViewInterface extends BaseViewInterface {
    void addItems(List<Course> data);
    void onLoad();
    void notify(boolean isRefresh);
    void changeMode(int mode);
    void resetData();
    LinearLayout getCourseLayout();
    LinearLayout getCourseErrorLayout();
    LinearLayout getNullLayout();
    PullRefleashListView getList();
}
