package com.fujitsu.fnst.fmooc.android.app.view;

import android.text.TextWatcher;

/**
 * Created by wangc.fnst on 2015/12/11.
 */
public interface ChangePwdViewInterface extends BaseViewInterface {

    void enableBtn();
    void disableBtn();
    void setOldTextChangeWatcher(TextWatcher watcher);
    void setNewTextChangeWatcher(TextWatcher watcher);
    void setConfTextChangeWatcher(TextWatcher watcher);
    String getOldPwd();
    String getNewPwd();
    String getConfPwd();

}
