package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by lijl.fnst on 2016/01/20.
 */
public class ReportEvaluationActivityChoice implements Serializable {
    private String label;
    private Integer score;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }
}
