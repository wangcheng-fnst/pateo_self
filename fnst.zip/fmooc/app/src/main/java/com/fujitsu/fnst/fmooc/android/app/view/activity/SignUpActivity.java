package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.LaunchPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.SignUpPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.view.SignUpViewInterface;

import butterknife.Bind;

public class SignUpActivity extends BaseActivity<SignUpPresenter> implements SignUpViewInterface {

    @Bind(R.id.id_sign_up_text)
    TextView textInfo;
    @Bind(R.id.id_sign_up_email)
    EditText mailEdit;
    @Bind(R.id.id_sign_up_btn)
    Button signUpBtn;


    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new SignUpPresenter(this);
        signUpBtn.setClickable(false);
        disableBtn();
    }
    @Override
    protected int getLayout() {
        return R.layout.activity_sign_up;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.sign_up_title);
    }

    @Override
    public void enableBtn() {
        signUpBtn.setClickable(true);
        signUpBtn.setAlpha(1);
        signUpBtn.setOnClickListener(this);
        signUpBtn.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public void disableBtn() {
        signUpBtn.setClickable(false);
        signUpBtn.setAlpha(0.5f);
        signUpBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }

    @Override
    public String getEmail() {
        return mailEdit.getText().toString();
    }

    @Override
    public void setEmailListener(TextWatcher watcher) {
        mailEdit.addTextChangedListener(watcher);
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_sign_up_btn){
            presenter.send();
        }

    }

}
