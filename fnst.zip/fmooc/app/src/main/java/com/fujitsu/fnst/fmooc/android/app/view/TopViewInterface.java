package com.fujitsu.fnst.fmooc.android.app.view;

import android.widget.LinearLayout;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;

import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/16.
 */
public interface TopViewInterface extends BaseViewInterface {

    void onLoad();
    void addItems(List<Course> data);
    void notify(boolean isRefresh);
    void resetData();
    LinearLayout getCourseLayout();
    LinearLayout getCourseErrorLayout();
    void hideFoot();
    void showFoot();
}
