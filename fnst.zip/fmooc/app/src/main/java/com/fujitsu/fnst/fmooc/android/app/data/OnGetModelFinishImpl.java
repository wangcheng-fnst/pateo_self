package com.fujitsu.fnst.fmooc.android.app.data;

/**
 * Created by wangc.fnst on 2015/12/24.
 */
public interface OnGetModelFinishImpl<T> {
    void onSuccess(String type,T result);
    void onFailed(String type, String message);
}
