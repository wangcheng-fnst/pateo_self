package com.fujitsu.fnst.fmooc.android.app.utils;


import com.google.gson.*;

import java.lang.reflect.Type;
import java.util.Date;

/**
 * Created by wangc.fnst on 2015/11/6.
 */
public class GsonUtil {
    private static Gson gson;
    private static GsonUtil instance;

    public GsonUtil() {
        JsonSerializer<Date> ser = new JsonSerializer<Date>() {
            @Override
            public JsonElement serialize(Date date, Type typeOfSrc, JsonSerializationContext
                    context) {
                return new JsonPrimitive(TimeUtils.formatToNetDay(date));
            }
        };

        JsonDeserializer<Date> deser = new JsonDeserializer<Date>() {
            @Override
            public Date deserialize(JsonElement json, Type typeOfT,
                                    JsonDeserializationContext context) throws JsonParseException {
                return TimeUtils.parseNetDay(json.getAsJsonPrimitive().getAsString());
            }
        };
        gson = new GsonBuilder()
                .registerTypeAdapter(Date.class, ser)
                .registerTypeAdapter(Date.class, deser).create();
    }
    public static GsonUtil getInstance(){
        if (null == instance){
            instance = new GsonUtil();
        }
        return  instance;
    }
    public String toJson(Object o){
        return gson.toJson(o);
    }
    public <T> T getObjectFromJson (String json,Class<T> tClass){
        return gson.fromJson(json, tClass);
    }

}
