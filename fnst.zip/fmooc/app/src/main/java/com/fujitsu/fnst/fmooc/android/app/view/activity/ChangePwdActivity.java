package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.ChangePwdPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.view.ChangePwdViewInterface;

/**
 * Created by wangc.fnst on 2015/12/11.
 */
public class ChangePwdActivity extends BaseActivity<ChangePwdPresenter> implements ChangePwdViewInterface {

    @Bind(R.id.id_old_txt)
    TextView oldTxt;
    @Bind(R.id.id_old_edit)
    EditText oldEdit;
    @Bind(R.id.id_new_txt)
    TextView newTxt;
    @Bind(R.id.id_new_edit)
    EditText newEdit;
    @Bind(R.id.id_conf_txt)
    TextView confTxt;
    @Bind(R.id.id_conf_edit)
    EditText confEdit;
    @Bind(R.id.id_send_btn)
    Button sendBtn;
    @Bind(R.id.id_title_back_btn)
    Button backImg;
    @Override
    protected void onCreateView() {
        super.onCreateView();

        presenter = new ChangePwdPresenter(this);

        Intent intent = getIntent();
        int type = intent.getIntExtra(Constants.EXTRA_TYPE,Constants.CHANGE_PWD_TYPE_FORGET);
        if (type == Constants.CHANGE_PWD_TYPE_FORGET){
            oldTxt.setVisibility(View.GONE);
            oldEdit.setVisibility(View.GONE);
            presenter.setIsForgetPwd();
//            presenter.setEmail(intent.getStringExtra("email"));
            ShareReferencesManager.getInstance(this).setValue(Constants.SP_CHANGE_STATUS, Constants.SP_CHANGE_STATUS_FAILED);
            presenter.confirmCode(intent.getStringExtra("code"));
        } else{
            oldTxt.setVisibility(View.VISIBLE);
            oldEdit.setVisibility(View.VISIBLE);
            backImg.setVisibility(View.VISIBLE);
        }
        sendBtn.setClickable(false);
        disableBtn();
    }

    @Override
    protected int getLayout() {
        return R.layout.change_pwd_activity_layout;
    }

    @Override
    public boolean showBackImg() {
        return false;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        Intent intent = getIntent();
        int type = intent.getIntExtra(Constants.EXTRA_TYPE,Constants.CHANGE_PWD_TYPE_FORGET);
        if (type == Constants.CHANGE_PWD_TYPE_FORGET) {
            return getResources().getString(R.string.change_title);
        }else {
            return getResources().getString(R.string.change_password);
        }
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (R.id.id_send_btn == v.getId()){
            presenter.send();
        }
    }

    @Override
    public void enableBtn() {
        sendBtn.setClickable(true);
        sendBtn.setAlpha(1);
        sendBtn.setOnClickListener(this);
        sendBtn.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public void disableBtn() {
        sendBtn.setClickable(false);
        sendBtn.setAlpha(0.5f);
        sendBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }

    @Override
    public void setOldTextChangeWatcher(TextWatcher watcher) {
        oldEdit.addTextChangedListener(watcher);
    }

    @Override
    public void setNewTextChangeWatcher(TextWatcher watcher) {
        newEdit.addTextChangedListener(watcher);
    }

    @Override
    public void setConfTextChangeWatcher(TextWatcher watcher) {
        confEdit.addTextChangedListener(watcher);
    }

    @Override
    public String getOldPwd() {
        return oldEdit.getText().toString();
    }

    @Override
    public String getNewPwd() {
        return newEdit.getText().toString();
    }

    @Override
    public String getConfPwd() {
        return confEdit.getText().toString();
    }
}
