package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.model.LoginModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.service.RssService;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.LoginViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.*;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;

/**
 * Created by wangc.fnst on 2015/12/10.
 */
public class LoginPresenter extends BasePresenter implements EditChangeListener.TextChangeCallback,OnGetModelFinishImpl<LoginModel> {

    private LoginViewInterface view;
    private boolean nameOk = false;
    private boolean passwordOk = false;
    private boolean isSaveUserInfo = false;
    private String userName,password;
    private String requestType = UserRepository.LOGIN_ACTIVITY;


    public LoginPresenter(LoginViewInterface viewInterface) {
        super();
        view = viewInterface;
        init();
    }

    public void init(){
        UserRepository.getInstance().register(requestType,this);
        EditChangeListener nameWatcher = new EditChangeListener();
        EditChangeListener passwordWatcher = new EditChangeListener();
        nameWatcher.setCallback(this);
        passwordWatcher.setCallback(this);
        view.setNameListener(nameWatcher);
        view.setPasswordListener(passwordWatcher);
        userName = ShareReferencesManager.getInstance(context).getStringValue(Constants.SP_USER_NAME);
        password = ShareReferencesManager.getInstance(context).getStringValue(Constants.SP_USER_PASSWORD);
//        if (!StringUtils.isBlank(userName)
//                &&!StringUtils.isBlank(password)){
//            view.setValue(userName,password);
//        }

    }

    public void setSaveUserInfo(boolean isSaveUserInfo){
        this.isSaveUserInfo = isSaveUserInfo;
    }

    public void login(){
        if (! checkFormat()){
            return;
        }
        view.showWaitingDialog();
        UserRepository.getInstance().login(userName, password, requestType);
//        UserRepository.getInstance().login("test.user2@isit.or.jp", "Secret02", requestType);
    }
    public void forgetPwdClick(){
        Intent intent = new Intent(context, SendActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
    private boolean checkFormat(){
        if (!StringUtils.isEmail(userName)){
            view.showToast(context.getResources().getString(R.string.mail_error));
            return false;
        }
        if (StringUtils.isBlank(password)){
            view.showToast(context.getResources().getString(R.string.password_error));
            return false;
        }
        return  true;
    }
    public void register(){
        Intent intent = new Intent(context, SignUpActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }


    @Override
    public void formatRight() {
        if (checkValue()){
            view.enableBtn();
        }else{
            view.disableBtn();
        }
    }

    private boolean checkValue(){
        userName = view.getName();
        password = view.getPwd();
        if (!StringUtils.isBlank(userName)
                && !StringUtils.isBlank(password)){
            return true;
        }
        return false;
    }

    private void saveUserInfo(){
        ShareReferencesManager.getInstance(context).setValue(Constants.SP_USER_NAME,userName);
        ShareReferencesManager.getInstance(context).setValue(Constants.SP_USER_PASSWORD,password);
    }
    private void cleanUserInfo(){
        ShareReferencesManager.getInstance(context).deleteValue(Constants.SP_USER_NAME);
        ShareReferencesManager.getInstance(context).deleteValue(Constants.SP_USER_PASSWORD);
    }

    @Override
    public void onSuccess(String type, LoginModel result) {
        if (type.equals(UserRepository.LOGIN_RESPONSE)){
            view.hideWaitingDialog();
            ShareReferencesManager.getInstance(context).setValue(Constants.SP_USER_ID, result.getUserId());
            Intent intent = new Intent(context, MainFragmentActivity.class);
//        Intent intent = new Intent(context, CourseDetailActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            Intent intentService = new Intent(context, RssService.class);
            intentService.setAction(Constants.ACTION_GET_RSS);
            context.startService(intentService);
            saveUserInfo();
            ((LoginActivity)view).finish();
        }

    }

    @Override
    public void onFailed(String type,String message) {
        view.hideWaitingDialog();
        view.showToast(context.getResources().getString(R.string.mail_password_wrong));
    }

    @Override
    public void onDestroy() {
        UserRepository.getInstance().unRegister(requestType);
        super.onDestroy();

    }
}
