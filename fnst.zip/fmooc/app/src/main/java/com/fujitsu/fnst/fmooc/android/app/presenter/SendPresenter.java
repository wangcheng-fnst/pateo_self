package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import android.widget.Toast;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.model.EmptyModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.SendViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ChangePwdActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.LoginActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.RegisterActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.SendActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.SendSuccessActivity;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;

/**
 * Created by wangc.fnst on 2015/12/11.
 */
public class SendPresenter extends BasePresenter implements EditChangeListener.TextChangeCallback, OnGetModelFinishImpl<EmptyModel> {

    private SendViewInterface view;
    private boolean isSendOk = false;
    private String email;
    private String requestType = UserRepository.SEND_CODE_RESPONSE;

    public SendPresenter(SendViewInterface view) {
        super();
        this.view = view;
        init();
    }

    private void init(){
        UserRepository.getInstance().register(requestType, this);
        EditChangeListener emailListener = new EditChangeListener();
        emailListener.setCallback(this);
        view.setChangeListener(emailListener);
    }

    @Override
    public void formatRight() {
        email = view.getEmail();
        if (!StringUtils.isBlank(email)) {
            view.enableBtn();
        }else {
            view.disableBtn();
        }
    }

    public void sendEmail(){
        if (!checkFormat()){
//            Intent intent = new Intent(context, ChangePwdActivity.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            context.startActivity(intent);
            return;
        }
        view.showWaitingDialog();
        UserRepository.getInstance().sendCode(email, Constants.CODE_RESETPASSWORD, requestType);
    }
    private boolean checkFormat(){
        if (!StringUtils.isEmail(email)){
            view.showToast(((SendActivity) view).getString(R.string.mail_error));
            return false;
        }
        return  true;
    }
    @Override
    public void onSuccess(String type, EmptyModel result) {
        view.hideWaitingDialog();
        if (type.equals(UserRepository.SEND_CODE_RESPONSE)){
            Intent intent = new Intent(context, SendSuccessActivity.class);
//        Intent intent = new Intent(context, CourseDetailActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }

    }

    @Override
    public void onFailed(String type,String message) {
        view.hideWaitingDialog();
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onDestroy() {
        UserRepository.getInstance().unRegister(requestType);
        super.onDestroy();

    }
}
