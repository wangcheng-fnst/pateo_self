package com.fujitsu.fnst.fmooc.android.app.view.component;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.MotionEvent;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;

/**
 * Created by wangc.fnst on 2016/1/12.
 */
public class CustomRecycleView extends RecyclerView {

    public CustomRecycleView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        if (!ApplicationUtils.isOver){
            return false;
        }
        return super.onInterceptTouchEvent(e);
    }
}
