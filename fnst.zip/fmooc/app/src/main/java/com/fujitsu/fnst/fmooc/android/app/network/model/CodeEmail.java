package com.fujitsu.fnst.fmooc.android.app.network.model;

/**
 * Created by lijl.fnst on 2016/02/16.
 */
public class CodeEmail {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
