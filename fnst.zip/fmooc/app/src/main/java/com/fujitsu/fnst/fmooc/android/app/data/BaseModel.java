package com.fujitsu.fnst.fmooc.android.app.data;

import java.io.Serializable;

/**
 * Created by wangc.fnst on 2015/12/16.
 */
public class BaseModel extends Object implements Serializable {
}
