package com.fujitsu.fnst.fmooc.android.app.view;

import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import android.widget.LinearLayout;
import com.fujitsu.fnst.fmooc.android.app.network.model.CourseDetailModel;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.VideoPlayFragment;

/**
 * Created by wangc.fnst on 2015/12/22.
 */
public interface CourseDetailNewViewInterface extends BaseViewInterface {

    void showIntroduceView();
    void showTeaView();
    void dismissIntroduceView();
    void dismissTeaView();
    void showBeginBtn();
    void dismissBeginBtn();
    void setFullScreen(boolean isFullScreen);
    void showBtn(String btnInfo);
    void missBtn(String btnInfo);
    void setCourseInfo(Course course);
    void finishActivity();
    LinearLayout getCourseDetailLayout();
    LinearLayout getCourseDetailErrorLayout();
    VideoPlayFragment getPlayFragment();


}
