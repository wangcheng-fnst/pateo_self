package com.fujitsu.fnst.fmooc.android.app.utils;

import android.content.Context;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Map;

/**
 * Created by chenjie.fnst
 */
public class RequestWithHeadImageDownloader extends BaseImageDownloader {

    public RequestWithHeadImageDownloader(Context context) {
        super(context);
    }

    public RequestWithHeadImageDownloader(Context context, int connectTimeout, int readTimeout) {
        super(context, connectTimeout, readTimeout);
    }

    @Override
    protected HttpURLConnection createConnection(String url, Object extra) throws IOException {
        HttpURLConnection connection =  super.createConnection(url, extra);
        Map<String,String> header = (Map<String, String>) extra;
        if (null != header){
            for (Map.Entry<String,String> entry: header.entrySet()){
                connection.setRequestProperty(entry.getKey(),entry.getValue());
            }
        }
        return connection;
    }
}
