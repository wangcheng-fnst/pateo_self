package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import android.provider.ContactsContract;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.ProfileSelectViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ProfileSelectActivity;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;

import java.util.HashMap;
import java.util.Map;

import rx.Subscriber;
import rx.Subscription;

/**
 * Created by lijl.fnst on 2015/12/22.
 */
public class ProfileSelectPresenter extends BasePresenter implements EditChangeListener.TextChangeCallback{

    private String firstname;
    private String sexStr;
    private String passStr;
    private String educationStr;
    private String id;
    Map<String, Object> data= new HashMap<String, Object>();
    private int profileType;
    private ProfileSelectViewInterface view;

    private Subscription subscription;
    private Subscriber<UserInfoModel> subscriber;

    public ProfileSelectPresenter(ProfileSelectViewInterface viewInterface){
        super();
        view = viewInterface;
        init();
    }

    private void init(){
        EditChangeListener nameWatcher = new EditChangeListener();
        nameWatcher.setCallback(this);
        view.setNameListener(nameWatcher);
    }

    public void setUserInfo(){
        id = ShareReferencesManager.getInstance(context).getStringValue(Constants.SP_USER_ID);

//        if (subscriber == null){
//            getSubscriber();
//        }
        view.showWaitingDialog();
        subscription = UserRepository.getInstance().setUserInformation(id,data,getSubscriber());
    }

    private Subscriber<UserInfoModel> getSubscriber(){
        return subscriber = new Subscriber<UserInfoModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }

            @Override
            public void onNext(UserInfoModel user) {
                sendSuccess();
            }
        };
    }

    public String getTitleStr(){
        switch (profileType){
            case Constants.PROFILE_SETTING_IMAGE:
                return ((ProfileSelectActivity)view).getString(R.string.profile_image_title);

            case Constants.PROFILE_SETTING_FIRSTNAME:
                return ((ProfileSelectActivity)view).getString(R.string.profile_firstname_title);

            case Constants.PROFILE_SETTING_SEX:
                return ((ProfileSelectActivity)view).getString(R.string.profile_sex_title);

            case Constants.PROFILE_SETTING_BIRTHDAY:
                return ((ProfileSelectActivity)view).getString(R.string.profile_birthday_title);

            case Constants.PROFILE_SETTING_EDUCATION:
                return ((ProfileSelectActivity)view).getString(R.string.profile_education_title);
        }
        return ((ProfileSelectActivity)view).getString(R.string.profile_title);
    }

    public void setProfileType(int type){
        profileType = type;
    }
    public void setData(String data){
        passStr = data;
    }


    public void showSetting(){
        switch (profileType){
            case Constants.PROFILE_SETTING_IMAGE:
                break;

            case Constants.PROFILE_SETTING_FIRSTNAME:
                view.showFirstname();
                break;
            case Constants.PROFILE_SETTING_SEX:
                view.showSex();
                break;
            case Constants.PROFILE_SETTING_BIRTHDAY:
                view.showYear();
                break;

            case Constants.PROFILE_SETTING_EDUCATION:
                view.showEducation();
                break;

        }
    }

    public void sendSuccess(){
        Intent intent = new Intent();
        intent.putExtra("result", passStr);
        ((ProfileSelectActivity)view).setResult(profileType, intent);
        ((ProfileSelectActivity)view).finish();
    }

    public void sendFail(){

    }

    public void saveClick(){
        if (profileType == Constants.PROFILE_SETTING_FIRSTNAME){
            data.put("realName",view.getName());
            passStr = view.getName();
        } else if (profileType == Constants.PROFILE_SETTING_SEX){
            if (passStr.equals(((ProfileSelectActivity)view).getString(R.string.profile_male))){
                data.put("gender",Constants.MALE);
            } else if (passStr.equals(((ProfileSelectActivity)view).getString(R.string.profile_female))){
                data.put("gender",Constants.FEMALE);
            } else if (passStr.equals(((ProfileSelectActivity)view).getString(R.string.profile_other))){
                data.put("gender",Constants.OTHER);
            }
        } else if (profileType == Constants.PROFILE_SETTING_BIRTHDAY){
            data.put("birthYear",passStr);
        } else if (profileType == Constants.PROFILE_SETTING_EDUCATION){
            data.put("lastDegree",passStr);
        }

        setUserInfo();

    }

    @Override
    public void formatRight() {
        if (checkValue()){
            view.enableBtn();
        }else{
            view.disableBtn();
        }
    }

    private boolean checkValue(){
        firstname = view.getName();
        if (!StringUtils.isBlank(firstname)){
            return true;
        }
        return false;
    }

    @Override
    public void onDestroy() {
        if (subscription!=null && !subscription.isUnsubscribed()){
            subscription.unsubscribe();
        }
        super.onDestroy();
    }
}
