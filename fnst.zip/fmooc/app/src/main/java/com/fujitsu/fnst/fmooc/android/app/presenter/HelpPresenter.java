package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.HelpInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.AgreementActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.AppAboutActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.HelpActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.MainFragmentActivity;


/**
 * Created by lijl.fnst on 2015/12/14.
 */
public class HelpPresenter extends BasePresenter{
    private HelpInterface view;

    public HelpPresenter(HelpInterface viewInterface){
        super();
        view = viewInterface;
    }

    public void toFmoocAbout(){
        Intent intent = new Intent(context, AgreementActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("title", ((HelpActivity) view).getString(R.string.help_fmooc_about));
        intent.putExtra("url", Constants.ABOUT_URL);
        context.startActivity(intent);
    }

    public void toFaq(){
        Intent intent = new Intent(context, AgreementActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("title", ((HelpActivity) view).getString(R.string.help_faq));
        intent.putExtra("url", Constants.ACTION_URL);
        context.startActivity(intent);
    }

    public void toAppAbout(){
        Intent intent = new Intent(context, AppAboutActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

}
