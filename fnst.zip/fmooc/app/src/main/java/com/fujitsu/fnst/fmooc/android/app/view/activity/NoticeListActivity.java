package com.fujitsu.fnst.fmooc.android.app.view.activity;

import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.NoticeModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.RssItemModel;
import com.fujitsu.fnst.fmooc.android.app.presenter.NoticeListPresenter;
import com.fujitsu.fnst.fmooc.android.app.view.NoticeListViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.NoticeItemAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/12.
 */
public class NoticeListActivity extends BaseActivity<NoticeListPresenter> implements NoticeListViewInterface {

    @Bind(R.id.id_notice_list)
    PullRefleashListView noticeList;
    private NoticeItemAdapter adapter;
    private List<RssItemModel> mData = new ArrayList<RssItemModel>();


    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new NoticeListPresenter(this,mData);
        adapter = new NoticeItemAdapter(mData);
        noticeList.setPullLoadEnable(true);
        noticeList.setPullRefreshEnable(true);
        noticeList.setAdapter(adapter);
        noticeList.setRefleashListener(presenter);
        noticeList.setOnItemClickListener(adapter);
//        FmoocApplication.setHasNewRss(false);
    }
    @Override
    protected int getLayout() {
        return R.layout.notice_list_activity;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.notice_set);
    }

    @Override
    public void stopLoad() {
        noticeList.stopLoadMore();
        noticeList.stopRefresh();
        noticeList.setRefreshTime("");
    }

    @Override
    public void notifyData() {
        noticeList.stopLoadMore();
        noticeList.stopRefresh();
        noticeList.setRefreshTime("");
        adapter.notifyDataSetChanged();
    }
}
