package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zhaod.fnst on 2016/01/18.
 */
public class ReportDetailModel implements Serializable {
    private Report content;
    private ReportSubmission submission;
    private SubmissionStats submissionStats;
    private Date now;

    public Report getContent() {
        return content;
    }

    public void setContent(Report content) {
        this.content = content;
    }

    public ReportSubmission getSubmission() {
        return submission;
    }

    public void setSubmission(ReportSubmission submission) {
        this.submission = submission;
    }

    public SubmissionStats getSubmissionStats() {
        return submissionStats;
    }

    public void setSubmissionStats(SubmissionStats submissionStats) {
        this.submissionStats = submissionStats;
    }

    public Date getNow() {
        return now;
    }

    public void setNow(Date now) {
        this.now = now;
    }
}
