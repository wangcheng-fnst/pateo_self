package com.fujitsu.fnst.fmooc.android.app.presenter;

import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.view.BaseViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.ScoreViewInterface;

import rx.Subscriber;
import rx.Subscription;

/**
 * Created by lijl.fnst on 2016/01/29.
 */
public class ScorePresenter extends BasePresenter{
    private ScoreViewInterface view;
    private Subscription getUserSubscription;
    private String id,data;
    public ScorePresenter(ScoreViewInterface scoreViewInterface){
        super();
        view = scoreViewInterface;
        init();
    }

    private void init(){
        id = ShareReferencesManager.getInstance(context).getStringValue(Constants.SP_USER_ID);
        data = Constants.USER_DATA_BASIC;
        getUserInformation();
    }
    public void getUserInformation(){
        view.showWaitingDialog();
        getUserSubscription = UserRepository.getInstance().getUserInformation(id,data,getSubscriber());
    }

    private Subscriber getSubscriber(){
        return new Subscriber<UserInfoModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {

                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(UserInfoModel user) {
                if (user.getUser().getRealName() != null){
                    view.setScoreTitle(user.getUser().getRealName());
                } else {
                    view.setScoreTitle(user.getUser().getDisplayName());
                }
            }
        };
    }

}
