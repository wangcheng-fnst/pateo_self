package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.HelpPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.LoginPresenter;
import com.fujitsu.fnst.fmooc.android.app.view.HelpInterface;

import butterknife.Bind;

public class HelpActivity extends BaseActivity<HelpPresenter> implements HelpInterface {

    @Bind(R.id.help_fmooc_about)
    TextView fmoocAbout;
    @Bind(R.id.help_faq)
    TextView faq;
    @Bind(R.id.help_app_about)
    TextView appAbout;
    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new HelpPresenter(this);
        fmoocAbout.setOnClickListener(this);
        faq.setOnClickListener(this);
        appAbout.setOnClickListener(this);

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_help;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.help_title);
    }

    public void onClick(View v){
        super.onClick(v);
        if(v.getId() == R.id.help_fmooc_about){
            presenter.toFmoocAbout();
        } else if (v.getId() == R.id.help_faq){
            presenter.toFaq();
        } else if (v.getId() == R.id.help_app_about){
            presenter.toAppAbout();
        }
    }

}
