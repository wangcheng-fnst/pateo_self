package com.fujitsu.fnst.fmooc.android.app.view;

/**
 * Created by wangc.fnst on 2015/12/14.
 */
public interface MainViewInterface extends BaseViewInterface {
    void leftClick();
    void middleClick();
    void rightClick();
    void resetBottom();
    void changeContent(int item);
}
