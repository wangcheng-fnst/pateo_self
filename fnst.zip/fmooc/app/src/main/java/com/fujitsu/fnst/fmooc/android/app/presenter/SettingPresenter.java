package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.ServerException;
import com.fujitsu.fnst.fmooc.android.app.network.model.EmptyModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.User;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.view.SettingViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.*;
import com.fujitsu.fnst.fmooc.android.app.view.component.CustomDialog;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.SettingFragment;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;
import rx.Subscriber;
import rx.Subscription;

/**
 * Created by wangc.fnst on 2015/12/14.
 */
public class SettingPresenter extends BasePresenter implements OnGetModelFinishImpl<EmptyModel>{
    public static final int USER_TAB = 0x00;
    public static final int SET_TAB = 0x01;
    private String requestType = UserRepository.GET_USERINFO_RESPONSE;
    private SettingViewInterface view;
    private String id,data,realName, sex, education, displayName, primaryEmail;
    private Integer year;
    private UserInfoModel userInfoModel;
    private Subscription getUserSubscription;
    private Subscription logoutSubscription;
    private CustomDialog dialog;

    public SettingPresenter(SettingViewInterface view) {
        this.view = view;
        init();
    }
    private void init(){
        id = ShareReferencesManager.getInstance(context).getStringValue(Constants.SP_USER_ID);
        data = Constants.USER_DATA_BASIC;
    }
    public void getUserInformation(){
        view.showWaitingDialog();
        getUserSubscription = UserRepository.getInstance().getUserInformation(id,data,getSubscriber());
    }

    private Subscriber logoutSubscription(){
        return new Subscriber<EmptyModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(EmptyModel emptyModel) {
                view.hideWaitingDialog();
                cleanUserInfo();
                ((SettingFragment)view).getActivity().finish();
                Intent intent = new Intent(context, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                //view.showToast("userid:" + user.getUser().getGender());
            }
        };
    }

    private Subscriber getSubscriber(){
        return new Subscriber<UserInfoModel>() {
            @Override
            public void onCompleted() {
                view.apiSuccess();
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.apiFailed();
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(UserInfoModel user) {
                userInfoModel = user;
                displayName = user.getUser().getDisplayName();
                primaryEmail = user.getUser().getPrimaryEmail();
                realName = user.getUser().getRealName();
                sex = user.getUser().getGender();
                year = user.getUser().getBirthYear();
                education = user.getUser().getLastDegree();
                ApplicationUtils.userInfoModel = user;
                view.setUserInfo(realName, sex, year, education, displayName, primaryEmail,user.getUser().getProfileImage().getImageId());
            }
        };
    }

    public void noticeClick(){
        Intent intent = new Intent(context, NoticeListActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public void profileClick(){
        Intent intent = new Intent(context, ProfileSettingActivity.class);
        intent.putExtra(Constants.EXTRA_USER,userInfoModel);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public void helpClick(){
        Intent intent = new Intent(context, HelpActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public void changeClick(){
        Intent intent = new Intent(context, ChangePwdActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(Constants.EXTRA_TYPE, Constants.CHANGE_PWD_TYPE_CHANGE);
        context.startActivity(intent);
    }

    public void actionClick(){
        Intent intent = new Intent(context, ActionSettingActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public void logoutClick(Activity activity){
//        Intent intent = new Intent(context, LoginActivity.class);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        context.startActivity(intent);
        view.showDialog(getDialog(activity));



    }
    private CustomDialog getDialog(Activity activity){
        if (dialog == null){
            dialog = new CustomDialog(activity);
            dialog.setTitleStr(context.getResources().getString(R.string.logout_title));
            dialog.setYesStr(context.getResources().getString(R.string.logout_logout));
            dialog.setNoStr(context.getResources().getString(R.string.logout_cansel));
            dialog.setListener(new CustomDialog.YesOrNoClickListener() {
                @Override
                public void yesClick() {
                    if (dialog.isShowing()){
                        dialog.dismiss();
                    }
                    view.showWaitingDialog();
                    logoutSubscription = UserRepository.getInstance().userLogout(logoutSubscription());
                }

                @Override
                public void noClick() {
                    if (dialog.isShowing()){
                        dialog.dismiss();
                    }

                }
            });
        }
        return dialog;
    }

    public void tabClick(int mode){
        view.resetTab();
        switch (mode){
            case USER_TAB:
                view.leftClick();
                view.showLeft();
                view.dismissRight();
                getUserInformation();
                break;
            case SET_TAB:
                view.rightClick();
                view.showRight();
                view.dismissLeft();
                break;
        }

    }

    private void cleanUserInfo(){
        ShareReferencesManager.getInstance(context).deleteValue(Constants.SP_USER_NAME);
        ShareReferencesManager.getInstance(context).deleteValue(Constants.SP_USER_PASSWORD);
    }

    @Override
    public void onSuccess(String type, EmptyModel result) {
        view.hideWaitingDialog();
        if (type.equals(UserRepository.GET_USERINFO_RESPONSE)){
//            Intent intent = new Intent(context, ChangePwdActivity.class);
////        Intent intent = new Intent(context, CourseDetailActivity.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            context.startActivity(intent);
        }

    }

    @Override
    public void onFailed(String type,String message) {
        view.hideWaitingDialog();
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onDestroy() {
       if (getUserSubscription.isUnsubscribed()){
           getUserSubscription.unsubscribe();
       }
        super.onDestroy();

    }
}
