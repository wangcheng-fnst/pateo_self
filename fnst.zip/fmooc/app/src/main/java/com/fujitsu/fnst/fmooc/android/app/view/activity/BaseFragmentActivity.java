package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.view.BaseViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.TestFragmentFirst;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.TestFragmentSecond;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.TestFragmentThird;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/14.
 */
public class BaseFragmentActivity extends FragmentActivity implements View.OnClickListener,BaseViewInterface {

    @Bind(R.id.id_pager)
    ViewPager viewPager;
    private FragmentManager fragmentManager;
    private FragmentPagerAdapter adapter;
    private TestFragmentFirst f1;
    private TestFragmentSecond f2;
    private TestFragmentThird f3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_fragment);
        ButterKnife.bind(this);
        init();
    }
    private void init(){
        f1 = new TestFragmentFirst();
        f2 = new TestFragmentSecond();
        f3 = new TestFragmentThird();
        List<Fragment> list = new ArrayList<Fragment>();
        list.add(f1);
        list.add(f2);
        list.add(f3);
        fragmentManager = getSupportFragmentManager();
        adapter = new MyAdapter(fragmentManager,list);
        viewPager.setAdapter(adapter);


    }

    @Override
    public void showToast(String msg) {

    }

    @Override
    public void hideWaitingDialog() {

    }

    @Override
    public void showWaitingDialog() {

    }

    @Override
    public void onClick(View v) {

    }


    class MyAdapter extends FragmentPagerAdapter{
        private List<Fragment> fragmentList;

        public MyAdapter(FragmentManager fm,List<Fragment> fragments) {
            super(fm);
            fragmentList = fragments;
        }

        @Override
        public Fragment getItem(int i) {
            return fragmentList.get(i);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }
    }
}
