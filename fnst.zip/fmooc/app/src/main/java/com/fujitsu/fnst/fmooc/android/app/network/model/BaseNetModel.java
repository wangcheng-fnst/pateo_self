package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by wangc.fnst on 2016/1/14.
 */
public class BaseNetModel implements Serializable {
}
