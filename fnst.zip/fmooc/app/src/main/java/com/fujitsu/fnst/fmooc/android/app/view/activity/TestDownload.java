package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.download.*;
import com.fujitsu.fnst.fmooc.android.app.network.service.CourseService;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.ExpandableAdapter;
import com.squareup.okhttp.*;
import rx.Subscriber;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

/**
 * Created by wangc.fnst on 2016/2/19.
 */
public class TestDownload extends BaseActivity {

    @Bind(R.id.id_begin_btn)
    Button beginBtn;
    @Bind(R.id.download_progress)
    ProgressBar downloadProgeress;
    private static final OkHttpClient client = new OkHttpClient();



    @Override
    protected int getLayout() {
        return R.layout.download_test;
    }

    @Override
    protected void onCreateView() {
        super.onCreateView();
        beginBtn.setOnClickListener(this);
        initClient();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (v.getId() == R.id.id_begin_btn){
            showWaitingDialog();
            File file = new File(FmoocApplication.staticDataPath );
            try {
                if (!file.exists()) {
                    file.mkdirs();
                    file.createNewFile();
                } else {
                    file.delete();
                    file.createNewFile();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            OkHttpClientManager.downloadAsyn("http://www.people.com.cn/mediafile/pic/20151015/3/13819161782863104375.jpg", file.getAbsolutePath(), new OkHttpClientManager.ResultCallback<String>() {
                @Override
                public void onError(Request request, Exception e) {
                    hideWaitingDialog();
                }

                @Override
                public void onResponse(String response) {
                    hideWaitingDialog();
                    Log.e("TAG", "ok");


                }
            });
        }
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return null;
    }
    private void initClient() {
        client.setConnectTimeout(1000, TimeUnit.MINUTES);
        client.setReadTimeout(1000, TimeUnit.MINUTES);
        client.setWriteTimeout(1000, TimeUnit.MINUTES);
    }
}
