package com.fujitsu.fnst.fmooc.android.app.view.listener;

import android.view.View;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.BasePresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.CoursePlayPresenter;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.ExpandableAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.stickylistheaders.ExpandableStickyListHeadersListView;
import com.fujitsu.fnst.fmooc.android.app.view.component.stickylistheaders.StickyListHeadersListView;

/**
 * Created by wangc.fnst on 2016/1/8.
 */
public class OnHeaderClickListener implements StickyListHeadersListView.OnHeaderClickListener {

    private ExpandableStickyListHeadersListView listView;
    private ExpandableAdapter adapter;
    private CoursePlayPresenter presenter;

    public OnHeaderClickListener(ExpandableStickyListHeadersListView listView, ExpandableAdapter adapter,CoursePlayPresenter presenter) {
        this.listView = listView;
        this.adapter = adapter;
        this.presenter = presenter;
    }

    @Override
    public void onHeaderClick(StickyListHeadersListView l, View header, int itemPosition, long headerId, boolean currentlySticky) {
        ExpandableAdapter.HeaderViewHolder holder = (ExpandableAdapter.HeaderViewHolder) header.getTag();
        if (listView.isHeaderCollapsed(headerId)) {
            holder.downImg.setImageResource(R.drawable.arrow_up);
            adapter.getHeadItem(itemPosition).setIcon(R.drawable.arrow_up);
            listView.expand(headerId);
        } else {
            holder.downImg.setImageResource(R.drawable.arrow_down);
            adapter.getHeadItem(itemPosition).setIcon(R.drawable.arrow_down);
            listView.collapse(headerId);
        }
    }
}
