package com.fujitsu.fnst.fmooc.android.app.data.model;

import com.fujitsu.fnst.fmooc.android.app.data.BaseModel;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public class UserModel extends BaseModel{

    private String email;
    private String pwd;
    private String name;
    private int headId;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHeadId() {
        return headId;
    }

    public void setHeadId(int headId) {
        this.headId = headId;
    }
}
