package com.fujitsu.fnst.fmooc.android.app.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by chenjie.fnst
 */
public class ShareReferencesManager {

    private String name = "fmooc";

    private static Context context;
    private static SharedPreferences mySharedPreferences;
    private static SharedPreferences.Editor editor;

    private static ShareReferencesManager referencesManager;

    private ShareReferencesManager(){
        mySharedPreferences= context.getSharedPreferences("test",
                Activity.MODE_PRIVATE);
        editor = mySharedPreferences.edit();
    }

    public static synchronized ShareReferencesManager getInstance(Context context1){
        context = context1;
        if (null == referencesManager){
            synchronized (new Object()){
                if (null == referencesManager){
                    referencesManager = new ShareReferencesManager();
                }
            }
        }
        return  referencesManager;
    }

    public void setValue(String name, Object value){
        if (value instanceof String){
            editor.putString(name, (String) value);
        } else if (value instanceof Integer){
            editor.putInt(name, (Integer) value);
        } else if (value instanceof Float){
            editor.putFloat(name, (Float) value);
        } else if (value instanceof Boolean){
            editor.putBoolean(name, (Boolean) value);
        } else if (value instanceof Long){
            editor.putLong(name, (Long) value);
        }
        editor.commit();
    }

    public void deleteValue(String name){
        editor.remove(name);
        editor.commit();
    }

//    public void setClassValue(String name,Object value){
//        Gson gson = new Gson();
//        String jsonStr = gson.toJson(value);
//        editor.putString(name,jsonStr);
//        editor.commit();
//    }

    public String getStringValue(String name) {
        return mySharedPreferences.getString(name,null);
    }

    public long getLongValue(String name) {
        return mySharedPreferences.getLong(name, -1);
    }

    public boolean getBoolean(String name) { return mySharedPreferences.getBoolean(name,false);}
}
