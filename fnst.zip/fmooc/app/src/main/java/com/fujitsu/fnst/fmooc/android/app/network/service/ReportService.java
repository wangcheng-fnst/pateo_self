package com.fujitsu.fnst.fmooc.android.app.network.service;

import com.fujitsu.fnst.fmooc.android.app.network.ObserverConvert;
import com.fujitsu.fnst.fmooc.android.app.network.ServiceBuilder;
import com.fujitsu.fnst.fmooc.android.app.network.model.*;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import retrofit.Response;
import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;
import retrofit.Call;
import retrofit.http.*;

import java.util.Map;

/**
 * Created by lijl.fnst on 2016/01/06.
 */
public class ReportService {
    private static ReportService service;
    private ReportInterface reportInterface;

    public ReportService() {
        reportInterface = ServiceBuilder.getInstance().build(ReportInterface.class);
    }

    public static ReportService getService() {
        if (service == null) {
            service = new ReportService();
        }
        return service;
    }

    public Subscription insertUserReport(String contentId,Map<String, Object> data,Subscriber<SubmittedReport> subscriber){
        Observable<Response<SubmittedReport>> observable =
                reportInterface.insertUserReport(ApplicationUtils.getToken(), Constants.CONTENT_REFERER,contentId, data);
        return observable.flatMap(new ObserverConvert<SubmittedReport>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public Subscription getContentInformation(String id,boolean withSubmission, Subscriber<ReportDetailModel> subscriber){
        Observable<Response<ReportDetailModel>> observable =
                reportInterface.getContentInformation(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id, withSubmission);
        return observable.flatMap(new ObserverConvert<ReportDetailModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }


    public interface ReportInterface {

        @FormUrlEncoded
        @POST("contents/{id}")
        Observable<Response<SubmittedReport>> insertUserReport(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String contentId,@FieldMap Map<String, Object> data);

        @GET("contents/{id}")
        Observable<Response<ReportDetailModel>> getContentInformation(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@Query("withSubmission") boolean withSubmission);
    }
}
