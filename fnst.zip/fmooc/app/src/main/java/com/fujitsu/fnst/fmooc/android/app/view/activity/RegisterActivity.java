package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.LinkMovementMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.LoginPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.RegisterPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.view.RegisterViewInterface;

import butterknife.Bind;

public class RegisterActivity extends BaseActivity<RegisterPresenter> implements RegisterViewInterface {

    @Bind(R.id.id_register_email_text)
    TextView emailText;
    @Bind(R.id.id_register_email_edit)
    EditText emailEdit;
    @Bind(R.id.id_register_username_text)
    TextView usernameText;
    @Bind(R.id.id_register_username_info)
    TextView uesrnameInfo;
    @Bind(R.id.id_register_username_edit)
    EditText usernameEdit;
    @Bind(R.id.id_register_password_text)
    TextView passwordText;
    @Bind(R.id.id_register_password_info)
    TextView passwordInfo;
    @Bind(R.id.id_register_password_edit)
    EditText passwordEdit;
    @Bind(R.id.id_register_agree_checkbox)
    CheckBox agreeCheckbox;
    @Bind(R.id.id_register_policy_text)
    TextView policyText;
    @Bind(R.id.id_register_agreement_text)
    TextView agreementText;
    @Bind(R.id.id_register_btn)
    Button registerBtn;
    @Bind((R.id.id_register_see_password))
    ImageView seePasswordBtn;


    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new RegisterPresenter(this);
        presenter.setStatus();
        policyText.setText(presenter.getClickableSpan(getResources().getString(R.string.register_policy)));
        policyText.setMovementMethod(LinkMovementMethod.getInstance());
        agreementText.setText(presenter.getClickableSpan(getResources().getString(R.string.register_agreement)));
        agreementText.setMovementMethod(LinkMovementMethod.getInstance());
        registerBtn.setClickable(false);
        disableBtn();
        registerBtn.setOnClickListener(this);
        agreeCheckbox.setOnCheckedChangeListener(checkedChangeListener);
        seePasswordBtn.setOnClickListener(this);
        Intent intent = getIntent();
        presenter.confirmCode(intent.getStringExtra("code"));
//        emailEdit.setText(intent.getStringExtra("code"));
//        emailEdit.setEnabled(false);
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_register;
    }

    @Override
    public boolean showBackImg() {
        return false;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.register_title);
    }

    @Override
    public void setEmailText(String email){
        emailEdit.setText(email);
        emailEdit.setEnabled(false);
    }

    @Override
    public void enableBtn() {
        registerBtn.setClickable(true);
        registerBtn.setAlpha(1);
        registerBtn.setOnClickListener(this);
        registerBtn.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public void disableBtn() {
        registerBtn.setClickable(false);
        registerBtn.setAlpha(0.5f);
        registerBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }
    @Override
    public void setNameListener(TextWatcher watcher) {
        usernameEdit.addTextChangedListener(watcher);
    }

    @Override
    public void setPasswordListener(TextWatcher watcher) {
        passwordEdit.addTextChangedListener(watcher);
    }

    @Override
    public String getUserName() {
        return usernameEdit.getText().toString();
    }

    @Override
    public String getPwd() {
        return passwordEdit.getText().toString();
    }

    @Override
    public String getEmail() {
        return emailEdit.getText().toString();
    }

    @Override
    public void showPassword(){ passwordEdit.setTransformationMethod(HideReturnsTransformationMethod.getInstance());}

    @Override
    public void hidePassword(){ passwordEdit.setTransformationMethod(PasswordTransformationMethod.getInstance());}


    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_register_btn){
            presenter.register();
        } else if (v.getId() == R.id.id_register_see_password){
            presenter.setPasswordEditStatus();
        }

    }
    private CompoundButton.OnCheckedChangeListener checkedChangeListener = new CompoundButton.OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            presenter.setUserAgree(isChecked);
        }
    };

}
