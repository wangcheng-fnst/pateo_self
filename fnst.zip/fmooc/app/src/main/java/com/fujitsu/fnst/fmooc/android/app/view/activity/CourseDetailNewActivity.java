package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.Dialog;
import android.content.Intent;
import android.provider.SyncStateContract;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.*;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.network.model.CourseDetailModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.User;
import com.fujitsu.fnst.fmooc.android.app.presenter.CourseDetailNewPresenter;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.CourseDetailNewViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.component.CustomDialog;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.VideoPlayFragment;
import com.google.android.youtube.player.YouTubePlayer;
import com.nostra13.universalimageloader.core.ImageLoader;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;

/**
 * Created by wangc.fnst on 2015/12/22.
 */
public class CourseDetailNewActivity extends BaseActivity<CourseDetailNewPresenter> implements YouTubePlayer.OnFullscreenListener, CourseDetailNewViewInterface,VideoPlayFragment.SuccessPlayerInitListener {

    public static final String STATUS_ENROLL = "status_enroll";
    public static final String STATUS_ENROLLING = "status_enrolling";
    public static final String STATUS_COMPLETE = "status_complete";
    public static final String STATUS_CLOSE = "status_close";

    @Bind(R.id.id_introduce_list)
    LinearLayout introduceList;
    @Bind(R.id.id_introduce_txt)
    TextView introduceTxt;
    @Bind(R.id.id_tea_txt)
    TextView teaTxt;
    @Bind(R.id.id_introduce_layout)
    ScrollView introduceView;
    @Bind(R.id.id_introduce_title_txt)
    TextView introduceTitleTxt;
    @Bind(R.id.id_introduce_content_txt)
    TextView introduceContentTxt;

    @Bind(R.id.id_title_txt)
    TextView courseTitleTxt;
    @Bind(R.id.id_tea_layout)
    ScrollView teaView;
    @Bind(R.id.id_head_img)
    ImageView headImg;
    @Bind(R.id.id_duty_txt)
    TextView dutyTxt;
    @Bind(R.id.id_part_txt)
    TextView partTxt;
    @Bind(R.id.id_subject_txt)
    TextView subjectTxt;
    @Bind(R.id.id_tea_title_txt)
    TextView teaTitleTxt;
    @Bind(R.id.id_tea_content_txt)
    TextView teaContentTxt;
    @Bind(R.id.id_begin_btn)
    Button beginBtn;
    @Bind(R.id.id_doing_btn)
    Button doingBtn;
    @Bind(R.id.id_end_btn)
    Button endBtn;
    @Bind(R.id.id_play_layout)
    FrameLayout playLayout;

    @Bind(R.id.id_introduce_linear_layout)
    LinearLayout introduceLayout;

    @Bind(R.id.id_tea_linear_layout)
    LinearLayout teaLayout;

    @Bind(R.id.id_course_detail_layout)
    LinearLayout courseDetailLayout;
    @Bind(R.id.id_course_detail_error_layout)
    LinearLayout courseDetailErrorLayout;
    @Bind(R.id.course_detail_refresh_btn)
    Button courseDetailRefreshBtn;

    VideoPlayFragment playFragment;
    private Course course;
    private String courseId;
    private String allStatus;

    private int currentMode;
    private CourseDetailModel courseInfo;
    private boolean fullscreen;


    @Bind(R.id.id_line1)
    View line1;
    @Bind(R.id.id_line2)
    View line2;
    @Bind(R.id.id_title_bar)
    View titleLayout;
    @Bind(R.id.id_other_layout)
    LinearLayout otherLayout;
    private boolean isFirst;
    private int height;

    @Override
    protected int getLayout() {
        return R.layout.course_deatil_activity_new;
    }

    @Override
    protected void onCreateView() {
        super.onCreateView();
        Intent intent = getIntent();
        courseId = intent.getStringExtra(Constants.EXTRA_COURSE_ID);
        presenter = new CourseDetailNewPresenter(this, getViewHeight(playLayout),courseId);
        playFragment = (VideoPlayFragment) getFragmentManager().findFragmentById(R.id.video_fragment_container);
//        playFragment.setOnFullscreenListener(presenter);
        introduceLayout.setOnClickListener(this);
        teaLayout.setOnClickListener(this);
        beginBtn.setOnClickListener(this);
        playLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (isFirst) {
                    isFirst = false;
                    height = playLayout.getLayoutParams().height;

                }

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.init();
    }

    @Override
    public void finishActivity() {
        finish();
    }
    @Override
    public void setCourseInfo(Course course){
        if (course != null){
            this.course = course;
                //course open
                if (course.getUserStatus().equals(Course.USER_STATUS_NOT_ENROLLED)) {
                    //user not enroll
                    allStatus = STATUS_ENROLL;
                } else if (course.getUserStatus().equals(Course.USER_STATUS_COMPLETED)){
                    //user complete
                    allStatus = STATUS_COMPLETE;
                } else if (course.getUserStatus().equals(Course.USER_STATUS_ENROLLED)){
                    //user enrolling
                    allStatus = STATUS_ENROLLING;
                }

        }
        User tea = course.getAuthor();
        if (StringUtils.isNumber(tea.getProfileImage().getImageId())){
            int headId = Integer.valueOf(tea.getProfileImage().getImageId());
            if (headId > 7){
                String headUrl = Constants.HOST_NAME+"images/120/"+ tea.getProfileImage().getFileName();
                ImageLoader.getInstance().displayImage(headUrl,headImg);
            }else {
                headImg.setImageResource(Constants.getImageResId_120(tea.getProfileImage().getImageId()));
            }
        }
        dutyTxt.setText(tea.getDisplayName());
        partTxt.setText(tea.getGender());
        subjectTxt.setText(tea.getAffiliation());
        teaContentTxt.setText(tea.getSelfIntroduction());
        playFragment.cueVideo(course.getDemoVideoYoutubeId());
        introduceLayout.setOnClickListener(this);
        teaLayout.setOnClickListener(this);
        beginBtn.setOnClickListener(this);
        courseDetailRefreshBtn.setOnClickListener(this);
        courseTitleTxt.setText(course.getName());
        introduceTitleTxt.setText(course.getShortDescription());
        introduceContentTxt.setText(course.getLongDescription());
        if (allStatus.equals(STATUS_ENROLL)){
            showBtn(Constants.COURSE_BEGIN);
        }else if (allStatus.equals(STATUS_ENROLLING)){
            showBtn(Constants.COURSE_DOING);
        } else if (allStatus.equals(STATUS_COMPLETE)){
            showBtn(Constants.COURSE_END);
        }
    }






    @Override
    public LinearLayout getCourseDetailLayout() {
        return courseDetailLayout;
    }

    @Override
    public void onBackPressed() {
        if (fullscreen){
            playFragment.setFullscreen(!fullscreen);
        }else {
            super.onBackPressed();
        }
    }

    @Override
    public LinearLayout getCourseDetailErrorLayout() {
        return courseDetailErrorLayout;
    }

    @Override
    public VideoPlayFragment getPlayFragment() {
        return playFragment;
    }


    private int getViewHeight(View targetView) {
        return targetView.getMeasuredHeight();
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.detail_title);
    }


    public void showBtn(String btnInfo){
        if (btnInfo == Constants.COURSE_BEGIN){
            beginBtn.setVisibility(View.VISIBLE);
            doingBtn.setVisibility(View.GONE);
            endBtn.setVisibility(View.GONE);
        } else if (btnInfo == Constants.COURSE_DOING){
            doingBtn.setVisibility(View.VISIBLE);
            beginBtn.setVisibility(View.GONE);
            endBtn.setVisibility(View.GONE);
        } else if (btnInfo == Constants.COURSE_END){
            endBtn.setVisibility(View.VISIBLE);
            beginBtn.setVisibility(View.GONE);
            doingBtn.setVisibility(View.GONE);
        }
        if (course.getStatus().equals(Course.COURSE_STATUS_OPEN)){
            beginBtn.setBackgroundResource(R.drawable.login_btn_bg);
            beginBtn.setClickable(true);
        }else {
            beginBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
            beginBtn.setClickable(false);

        }
    }

    public void missBtn(String btnInfo){
        if (btnInfo == Constants.COURSE_BEGIN){
            beginBtn.setVisibility(View.GONE);
        } else if (btnInfo == Constants.COURSE_DOING){
            doingBtn.setVisibility(View.GONE);
        } else if (btnInfo == Constants.COURSE_END){
            endBtn.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (ApplicationUtils.isFastClick()){
            return;
        }
        if (v.getId() == R.id.id_title_more_img) {

        } else if (v.getId() == R.id.id_introduce_linear_layout) {
            if (currentMode != Constants.INTRODUCE_TYPE) {
                currentMode = Constants.INTRODUCE_TYPE;
                showIntroduceView();
                dismissTeaView();
                introduceLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_left_o));
                teaLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_right_n));
                introduceTxt.setTextColor(getResources().getColor(R.color.white));
                teaTxt.setTextColor(getResources().getColor(R.color.orange));
            }
        } else if (v.getId() == R.id.id_tea_linear_layout) {
            if (currentMode != Constants.TEA_TYPE) {
                currentMode = Constants.TEA_TYPE;
                showTeaView();
                dismissIntroduceView();
                introduceLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_left_n));
                teaLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_right_o));
                introduceTxt.setTextColor(getResources().getColor(R.color.orange));
                teaTxt.setTextColor(getResources().getColor(R.color.white));
            }
        } else if (v.getId() == R.id.id_begin_btn){
            presenter.btnClick();
        }else if(v.getId() == R.id.course_detail_refresh_btn){
            presenter.init();
        }
    }


    @Override
    public void showIntroduceView() {
        introduceView.setVisibility(View.VISIBLE);
    }

    @Override
    public void showTeaView() {
        teaView.setVisibility(View.VISIBLE);
    }


    @Override
    public void dismissIntroduceView() {
        introduceView.setVisibility(View.GONE);
    }

    @Override
    public void dismissTeaView() {
        teaView.setVisibility(View.GONE);
    }

    @Override
    public void showBeginBtn() {
        beginBtn.setVisibility(View.VISIBLE);

    }

    @Override
    public void dismissBeginBtn() {
        beginBtn.setVisibility(View.GONE);
    }

    @Override
    public void setFullScreen(boolean isFullScreen) {
        if (isFullScreen) {
            //TODO: open fullScreen
            dismissIntroduceView();
            //dismissBeginBtn();
            presenter.missBtn();
            dismissTitle();
            presenter.setViewFullscreen(playLayout,MATCH_PARENT,MATCH_PARENT);

        } else {
            //TODO: close fullScreen
            //showBeginBtn();
            presenter.showBtn();
            showIntroduceView();
            showTitle();
            presenter.setViewFullscreen(playLayout,MATCH_PARENT,presenter.getSmallHeight());
        }
    }


    @Override
    public void onSuccessInit(boolean isOnResume) {
        playFragment.setPlayerStateChangeListener(presenter);
        if (ApplicationUtils.isOpenNetwork() || ApplicationUtils.isAgreeWithoutWifi()){
                playFragment.setVideoId(course.getDemoVideoYoutubeId());
        }
    }



    @Override
    public void onFullscreen(boolean b) {
        fullscreen = b;
        doLayout();

    }
    private void doLayout(){
        LinearLayout.LayoutParams playerParams =
                (LinearLayout.LayoutParams) playLayout.getLayoutParams();
        if (fullscreen){
            playerParams.width = LinearLayout.LayoutParams.MATCH_PARENT;
            playerParams.height = LinearLayout.LayoutParams.MATCH_PARENT;
            line1.setVisibility(View.GONE);
            line2.setVisibility(View.GONE);
            titleLayout.setVisibility(View.GONE);
            otherLayout.setVisibility(View.GONE);
        }else{
            playerParams.width = LinearLayout.LayoutParams.MATCH_PARENT;
            playerParams.height = height;
            line1.setVisibility(View.VISIBLE);
            line2.setVisibility(View.VISIBLE);
            titleLayout.setVisibility(View.VISIBLE);
            otherLayout.setVisibility(View.VISIBLE);
        }
    }
}
