package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.graphics.Paint;
import android.view.View;
import android.widget.*;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.Report;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportDetailModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportSubmission;
import com.fujitsu.fnst.fmooc.android.app.network.model.SubmittedReport;
import com.fujitsu.fnst.fmooc.android.app.network.model.SubmittedReportEvaluation;
import com.fujitsu.fnst.fmooc.android.app.presenter.ReportMainPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.TimeUtils;
import com.fujitsu.fnst.fmooc.android.app.view.ReportMainViewInterface;

import java.util.Date;
import java.util.List;

public class ReportMainActivity extends BaseActivity<ReportMainPresenter> implements ReportMainViewInterface {
    @Bind(R.id.report_main)
    LinearLayout reportMain;
    @Bind(R.id.id_layout1)
    LinearLayout layout1;
    @Bind(R.id.id_step1_layout)
    LinearLayout setpLayout1;
    @Bind(R.id.id_step1_txt)
    TextView stepTxt1;
    @Bind(R.id.id_step1_time)
    TextView timeTxt1;
    @Bind(R.id.arrow_down1)
    ImageView arrowDown1;
    @Bind(R.id.arrow_up1)
    ImageView arrowUp1;
    @Bind(R.id.id_step1_down_layout)
    LinearLayout downLayout1;
    @Bind(R.id.id_message1_txt)
    TextView message1;
    @Bind(R.id.id_status1_txt)
    TextView status1;
    @Bind(R.id.arrow_right1)
    ImageView arrowRight1;

    @Bind(R.id.id_layout2)
    LinearLayout layout2;
    @Bind(R.id.id_step2_layout)
    LinearLayout setpLayout2;
    @Bind(R.id.id_step2_txt)
    TextView stepTxt2;
    @Bind(R.id.id_step2_time)
    TextView timeTxt2;
    @Bind(R.id.arrow_down2)
    ImageView arrowDown2;
    @Bind(R.id.arrow_up2)
    ImageView arrowUp2;
    @Bind(R.id.id_step2_down_layout)
    LinearLayout downLayout2;
    @Bind(R.id.id_message2_txt)
    TextView message2;
    @Bind(R.id.id_status2_txt)
    TextView status2;
    @Bind(R.id.arrow_right2)
    ImageView arrowRight2;

    @Bind(R.id.id_layout3)
    LinearLayout layout3;
    @Bind(R.id.id_step3_layout)
    LinearLayout setpLayout3;
    @Bind(R.id.id_step3_txt)
    TextView stepTxt3;
    @Bind(R.id.id_step3_time)
    TextView timeTxt3;
    @Bind(R.id.arrow_down3)
    ImageView arrowDown3;
    @Bind(R.id.arrow_up3)
    ImageView arrowUp3;
    @Bind(R.id.id_step3_down_layout)
    LinearLayout downLayout3;
    @Bind(R.id.id_message3_txt)
    TextView message3;
    @Bind(R.id.id_status3_txt)
    TextView status3;
    @Bind(R.id.arrow_right3)
    ImageView arrowRight3;

    @Bind(R.id.id_layout4)
    LinearLayout layout4;
    @Bind(R.id.id_step4_layout)
    LinearLayout setpLayout4;
    @Bind(R.id.id_step4_txt)
    TextView stepTxt4;
    @Bind(R.id.id_step4_time)
    TextView timeTxt4;
    @Bind(R.id.arrow_down4)
    ImageView arrowDown4;
    @Bind(R.id.arrow_up4)
    ImageView arrowUp4;
    @Bind(R.id.id_step4_down_layout)
    LinearLayout downLayout4;
    @Bind(R.id.id_message4_txt)
    TextView message4;
    @Bind(R.id.id_status4_txt)
    TextView status4;
    @Bind(R.id.arrow_right4)
    ImageView arrowRight4;

    @Bind(R.id.report_help)
    TextView reportHelp;

    @Bind(R.id.report_step3_text)
    RelativeLayout stepText3;
    @Bind(R.id.report_step3_user)
    LinearLayout stepUser3;
    @Bind(R.id.report_user1_image)
    ImageView userImage1;
    @Bind(R.id.report_user1_text)
    TextView userText1;
    @Bind(R.id.report_user2_image)
    ImageView userImage2;
    @Bind(R.id.report_user2_text)
    TextView userText2;
    @Bind(R.id.report_user3_image)
    ImageView userImage3;
    @Bind(R.id.report_user3_text)
    TextView userText3;
    @Bind(R.id.report_user4_image)
    ImageView userImage4;
    @Bind(R.id.report_user4_text)
    TextView userText4;
    @Bind(R.id.report_user5_image)
    ImageView userImage5;
    @Bind(R.id.report_user5_text)
    TextView userText5;


    private String contentId;
    private Report report;
    private ReportSubmission reportSubmission;
    private List<SubmittedReport> assignedSubmissions;
    private List<SubmittedReportEvaluation> evaluationsForAssignedSubmission;
    private int step1 = 0;
    private int step2 = 0;
    private int step3 = 0;
    private int step4 = 0;


    @Override
    protected void onCreateView() {
        super.onCreateView();
        Intent intent = getIntent();
        contentId = intent.getExtras().getString("contentId");
        presenter = new ReportMainPresenter(this);

        reportHelp.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);

        setpLayout1.setOnClickListener(this);
        setpLayout2.setOnClickListener(this);
        setpLayout3.setOnClickListener(this);
        setpLayout4.setOnClickListener(this);

        downLayout1.setOnClickListener(this);
        downLayout2.setOnClickListener(this);
        downLayout3.setOnClickListener(this);
        downLayout4.setOnClickListener(this);

        reportHelp.setOnClickListener(this);
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_report_main;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.report);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (R.id.id_step1_layout == v.getId()){
            if(downLayout1.getVisibility()==View.GONE){
                switch (step1){
                    case 0:
                        setOrangeOpen(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                        break;
                    case 1:
                        setBlackOpen(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                        break;
                    case 2:
                        setGrayClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                        break;
                }
            }else{
                switch (step1){
                    case 0:
                        setOrangeClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                        break;
                    case 1:
                        setBlackClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                        break;
                    case 2:
                        setGrayClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                        break;
                }
            }
        }else if(R.id.id_step2_layout == v.getId()){
            if(downLayout2.getVisibility()==View.GONE){
                switch (step2){
                    case 0:
                        setOrangeOpen(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                        break;
                    case 1:
                        setBlackOpen(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                        break;
                    case 2:
                        setGrayClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                        break;
                }
            }else{
                switch (step2){
                    case 0:
                        setOrangeClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                        break;
                    case 1:
                        setBlackClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                        break;
                    case 2:
                        setGrayClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                        break;
                }
            }
        }else if(R.id.id_step3_layout == v.getId()){
            if(downLayout3.getVisibility()==View.GONE){
                if (report.getState().equals(Report.WAITING_FOR_EVALUATION) || report.getState().equals(Report.WAITING_FOR_EVALUATION_ON_MY_REPORT)  || report.getState().equals(Report.WAITING_FOR_REFLECTION)  || report.getState().equals(Report.COMPLETED)){
                    switch (step3){
                        case 0:
                            setOrangeUserOpen(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                            break;
                        case 1:
                            setBlackUserOpen(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                            break;
                        case 2:
                            setGrayClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                            break;
                    }
                } else {
                    switch (step3){
                        case 0:
                            setOrangeOpen(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                            break;
                        case 1:
                            setBlackOpen(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                            break;
                        case 2:
                            setGrayClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                            break;
                    }
                }

            }else{
//                if (report.getState().equals(Report.WAITING_FOR_EVALUATION) || report.getState().equals(Report.WAITING_FOR_EVALUATION_ON_MY_REPORT)){
//                    switch (step3){
//                        case 0:
//                            setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
//                            break;
//                        case 1:
//                            setBlackClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
//                            break;
//                        case 2:
//                            setGrayClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
//                            break;
//                    }
//                } else {
//                    switch (step3){
//                        case 0:
//                            setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
//                            break;
//                        case 1:
//                            setBlackClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
//                            break;
//                        case 2:
//                            setGrayClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
//                            break;
//                    }
//                }
                switch (step3){
                    case 0:
                        setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                        break;
                    case 1:
                        setBlackClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                        break;
                    case 2:
                        setGrayClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                        break;
                }
            }
        }else if(R.id.id_step4_layout == v.getId()){
            if(downLayout4.getVisibility()==View.GONE){
                switch (step4){
                    case 0:
                        setOrangeOpen(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                        break;
                    case 1:
                        setBlackOpen(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                        break;
                    case 2:
                        setGrayClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                        break;
                }
            }else{
                switch (step4){
                    case 0:
                        setOrangeClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                        break;
                    case 1:
                        setBlackClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                        break;
                    case 2:
                        setGrayClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                        break;
                }
            }
        }else if(R.id.id_step1_down_layout == v.getId()){
            presenter.sendReport();
        }else if(R.id.id_step2_down_layout == v.getId()){
            presenter.scoreMyself();
        }else if(R.id.report_user1_text == v.getId()){
            presenter.scoreOthers(0);
        }else if(R.id.report_user2_text == v.getId()){
            presenter.scoreOthers(1);
        }else if(R.id.report_user3_text == v.getId()){
            presenter.scoreOthers(2);
        }else if(R.id.report_user4_text == v.getId()){
            presenter.scoreOthers(3);
        }else if(R.id.report_user5_text == v.getId()){
            presenter.scoreOthers(4);
        }else if(R.id.id_step4_down_layout == v.getId()){
            presenter.reflection();
        }else if (R.id.report_help == v.getId()){
            presenter.toHelp();
        }
    }


    @Override
    public String getContentId() {
        return contentId;
    }

    @Override
    public void setReportDetail(ReportDetailModel detail) {
        reportMain.setVisibility(View.VISIBLE);
        this.report = detail.getContent();
        this.reportSubmission = detail.getSubmission();
        this.assignedSubmissions = detail.getSubmission().getAssignedSubmissions();
        this.evaluationsForAssignedSubmission = detail.getSubmission().getEvaluationsForAssignedSubmission();
        String state = report.getState();

        Date maySubmitFrom = report.getMaySubmitFrom();
        Date shouldSubmitBefore = report.getShouldSubmitBefore();

        Date maySendSelfEvaluationFrom = report.getMaySendSelfEvaluationFrom();
        Date shouldSendSelfEvaluationBefore = report.getShouldSendSelfEvaluationBefore();

        Date maySendEvaluationFrom = report.getMaySendEvaluationFrom();
        Date shouldSendEvaluationBefore = report.getShouldSendEvaluationBefore();

        Date maySendReflectionFrom = report.getMaySendReflectionFrom();
        Date shouldSendReflectionBefore = report.getShouldSendReflectionBefore();
        Date now = detail.getNow();
        timeTxt1.setText(getResources().getString(R.string.report_date) + TimeUtils.formatForReport(report.getShouldSubmitBefore()) + " JST");
        timeTxt2.setText(getResources().getString(R.string.report_date) + TimeUtils.formatForReport(report.getShouldSendSelfEvaluationBefore()) + " JST");
        timeTxt3.setText(getResources().getString(R.string.report_date) + TimeUtils.formatForReport(report.getShouldSendEvaluationBefore()) + " JST");
        timeTxt4.setText(getResources().getString(R.string.report_date) + TimeUtils.formatForReport(report.getShouldSendReflectionBefore()) + " JST");
        if(state!=null){
            switch (state){
                case Report.CANNOT_SUBMIT:
                    setTextForTextview(message1, status1, false, now, maySubmitFrom, shouldSubmitBefore,1);
                    setTextForTextview(message2, status2, false, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore, 2);
                    setTextForTextview(message3, status3, false, now, maySendEvaluationFrom, shouldSendEvaluationBefore, 3);
                    setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);

                    break;
                case Report.WAITING_FOR_REPORT_ANSWER:
                    setTextForTextview(message1, status1, false, now, maySubmitFrom, shouldSubmitBefore,1);
                    setTextForTextview(message2, status2, false, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore,2);
                    setTextForTextview(message3, status3, false, now, maySendEvaluationFrom, shouldSendEvaluationBefore, 3);
                    setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);
                    downLayout2.setClickable(false);
                    downLayout3.setClickable(false);
                    downLayout4.setClickable(false);
                    arrowRight2.setVisibility(View.GONE);
                    arrowRight3.setVisibility(View.GONE);
                    arrowRight4.setVisibility(View.GONE);
                    setOrangeOpen(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                    setOrangeClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                    setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                    setOrangeClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);

                    if (now.after(shouldSubmitBefore)){
                        setBlackOpen(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                        setGrayClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                        setGrayClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                        setGrayClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                        downLayout1.setClickable(false);
                        setpLayout2.setClickable(false);
                        setpLayout3.setClickable(false);
                        setpLayout4.setClickable(false);
                        arrowRight1.setVisibility(View.GONE);
                        step1 = 1;
                        step2 = 2;
                        step3 = 2;
                        step4 = 2;
                    }
                    break;

                case Report.WAITING_FOR_SELF_EVALUATION_PERIOD_TO_START:
                    setTextForTextview(message1, status1, true, now, maySubmitFrom, shouldSubmitBefore, 1);
                    setTextForTextview(message2, status2, false, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore, 2);
                    setTextForTextview(message3, status3, false, now, maySendEvaluationFrom, shouldSendEvaluationBefore, 3);
                    setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);
                    downLayout2.setClickable(false);
                    downLayout3.setClickable(false);
                    downLayout4.setClickable(false);
                    arrowRight2.setVisibility(View.GONE);
                    arrowRight3.setVisibility(View.GONE);
                    arrowRight4.setVisibility(View.GONE);
                    setOrangeClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                    setOrangeOpen(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                    setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                    setOrangeClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                    break;

                case Report.WAITING_FOR_SELF_EVALUATION:
                    setTextForTextview(message1, status1, true, now, maySubmitFrom, shouldSubmitBefore,1);
                    setTextForTextview(message2, status2, false, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore,2);
                    setTextForTextview(message3, status3, false, now, maySendEvaluationFrom, shouldSendEvaluationBefore, 3);
                    setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);
                    downLayout2.setClickable(true);
                    arrowRight2.setVisibility(View.VISIBLE);
                    downLayout3.setClickable(false);
                    downLayout4.setClickable(false);
                    arrowRight3.setVisibility(View.GONE);
                    arrowRight4.setVisibility(View.GONE);
                    setOrangeClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                    setOrangeOpen(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                    setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                    setOrangeClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                    if (now.after(shouldSendSelfEvaluationBefore)){
                        setBlackOpen(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                        setBlackOpen(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                        setGrayClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                        setGrayClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                        setpLayout3.setClickable(false);
                        setpLayout4.setClickable(false);
                        arrowRight2.setVisibility(View.GONE);
                        step1 = 1;
                        step2 = 1;
                        step3 = 2;
                        step4 = 2;
                    }
                    break;

                case Report.WAITING_FOR_EVALUATION_PERIOD_TO_START:
                    setTextForTextview(message1, status1, true, now, maySubmitFrom, shouldSubmitBefore,1);
                    setTextForTextview(message2, status2, true, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore,2);
                    setTextForTextview(message3, status3, false, now, maySendEvaluationFrom, shouldSendEvaluationBefore, 3);
                    setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);
                    downLayout3.setClickable(false);
                    downLayout4.setClickable(false);
                    arrowRight3.setVisibility(View.GONE);
                    arrowRight4.setVisibility(View.GONE);
                    setOrangeClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                    setOrangeClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                    setOrangeOpen(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                    setOrangeClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
//                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelSize(R.dimen.dp_126));
//                    downLayout3.setLayoutParams(layoutParams);
//                    stepText3.setVisibility(View.GONE);
//                    stepUser3.setVisibility(View.VISIBLE);
//                    userText1.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
//                    userText2.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
//                    userText3.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
//                    userText4.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
//                    userText5.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    break;

                case Report.WAITING_FOR_EVALUATION:
//                    setTextForTextview(message1, status1, true, now, maySubmitFrom, shouldSubmitBefore, 1);
//                    setTextForTextview(message2, status2, true, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore, 2);
                    message1.setText(getResources().getString(R.string.report_date_after));
                    message2.setText(getResources().getString(R.string.report_date_after));
                    status1.setText(getResources().getString(R.string.report_step1_finish));
                    status2.setText(getResources().getString(R.string.report_step2_finish));
                    setTextForTextview(message3, status3, false, now, maySendEvaluationFrom, shouldSendEvaluationBefore, 3);
                    message3.setText(getResources().getString(R.string.report_date_before));
                    setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);
                    downLayout4.setClickable(false);
                    arrowRight4.setVisibility(View.GONE);
                    setOrangeClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                    setOrangeClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                    setOrangeClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                    setOrangeUserOpen(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                    LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelSize(R.dimen.dp_126));
                    downLayout3.setLayoutParams(layoutParams1);
                    stepText3.setVisibility(View.GONE);
                    stepUser3.setVisibility(View.VISIBLE);

                    userText1.setTextColor(getResources().getColor(R.color.btn_login_bg));
                    userText1.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
                    userText1.setOnClickListener(this);

                    userText2.setTextColor(getResources().getColor(R.color.btn_login_bg));
                    userText2.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
                    userText2.setOnClickListener(this);

                    userText3.setTextColor(getResources().getColor(R.color.btn_login_bg));
                    userText3.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
                    userText3.setOnClickListener(this);

                    userText4.setTextColor(getResources().getColor(R.color.btn_login_bg));
                    userText4.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
                    userText4.setOnClickListener(this);

                    userText5.setTextColor(getResources().getColor(R.color.btn_login_bg));
                    userText5.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
                    userText5.setOnClickListener(this);
                    for (int i = 0; i < assignedSubmissions.size();i++){
                        for (SubmittedReportEvaluation submit : evaluationsForAssignedSubmission){
                            if (submit.getForSubmissionId().equals(assignedSubmissions.get(i).getSubmissionId())){
                                switch (i){
                                    case 0:
                                        userText1.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                                        userText1.setText(getResources().getString(R.string.report_step3_user1));
                                        userText1.getPaint().setUnderlineText(false);
                                        userImage1.setVisibility(View.VISIBLE);
                                        userText1.setClickable(false);
                                        break;
                                    case 1:
                                        userText2.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                                        userText2.setText(getResources().getString(R.string.report_step3_user2));
                                        userText2.getPaint().setUnderlineText(false);
                                        userImage2.setVisibility(View.VISIBLE);
                                        userText2.setClickable(false);
                                        break;
                                    case 2:
                                        userText3.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                                        userText3.setText(getResources().getString(R.string.report_step3_user3));
                                        userText3.getPaint().setUnderlineText(false);
                                        userImage3.setVisibility(View.VISIBLE);
                                        userText3.setClickable(false);
                                        break;
                                    case 3:
                                        userText4.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                                        userText4.setText(getResources().getString(R.string.report_step3_user4));
                                        userText4.getPaint().setUnderlineText(false);
                                        userImage4.setVisibility(View.VISIBLE);
                                        userText4.setClickable(false);
                                        break;
                                    case 4:
                                        userText5.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                                        userText5.setText(getResources().getString(R.string.report_step3_user5));
                                        userText5.getPaint().setUnderlineText(false);
                                        userImage5.setVisibility(View.VISIBLE);
                                        userText5.setClickable(false);
                                        break;
                                }
                            }
                        }
//                        if (evaluationsForAssignedSubmission.get(i).getComments() == null){
//                            switch (i){
//                                case 0:
//                                    userText1.setTextColor(getResources().getColor(R.color.btn_login_bg));
//                                    userText1.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
//                                    userText1.setOnClickListener(this);
//                                    userImage1.setVisibility(View.VISIBLE);
//                                    break;
//                                case 1:
//                                    userText2.setTextColor(getResources().getColor(R.color.btn_login_bg));
//                                    userText2.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
//                                    userText2.setOnClickListener(this);
//                                    break;
//                                case 2:
//                                    userText3.setTextColor(getResources().getColor(R.color.btn_login_bg));
//                                    userText3.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
//                                    userText3.setOnClickListener(this);
//                                    break;
//                                case 3:
//                                    userText4.setTextColor(getResources().getColor(R.color.btn_login_bg));
//                                    userText4.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
//                                    userText4.setOnClickListener(this);
//                                    break;
//                                case 4:
//                                    userText5.setTextColor(getResources().getColor(R.color.btn_login_bg));
//                                    userText5.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
//                                    userText5.setOnClickListener(this);
//                                    break;
//                            }
//                        } else {
//                            switch (i){
//                                case 0:
//                                    userText1.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
//                                    userImage1.setVisibility(View.VISIBLE);
//                                    userText1.setClickable(false);
//                                    break;
//                                case 1:
//                                    userText2.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
//                                    userImage2.setVisibility(View.VISIBLE);
//                                    userText1.setClickable(false);
//                                    break;
//                                case 2:
//                                    userText3.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
//                                    userImage3.setVisibility(View.VISIBLE);
//                                    userText1.setClickable(false);
//                                    break;
//                                case 3:
//                                    userText4.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
//                                    userImage4.setVisibility(View.VISIBLE);
//                                    userText1.setClickable(false);
//                                    break;
//                                case 4:
//                                    userText5.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
//                                    userImage5.setVisibility(View.VISIBLE);
//                                    userText1.setClickable(false);
//                                    break;
//                            }
//                        }
                    }


                    if (now.after(shouldSendEvaluationBefore)){
                        setBlackOpen(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                        setBlackOpen(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                        setBlackClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                        setGrayClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                        setpLayout4.setClickable(false);
                        arrowRight3.setVisibility(View.GONE);
                        step1 = 1;
                        step2 = 1;
                        step3 = 1;
                        step4 = 2;
                        stepText3.setVisibility(View.GONE);
                        stepUser3.setVisibility(View.VISIBLE);
                        userText1.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                        userImage1.setVisibility(View.GONE);
                        userText1.setClickable(false);
                        userText2.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                        userImage2.setVisibility(View.GONE);
                        userText2.setClickable(false);
                        userText3.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                        userImage3.setVisibility(View.GONE);
                        userText3.setClickable(false);
                        userText4.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                        userImage4.setVisibility(View.GONE);
                        userText4.setClickable(false);
                        userText5.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                        userImage5.setVisibility(View.GONE);
                        userText5.setClickable(false);
                    }
                    break;

                case Report.WAITING_FOR_EVALUATION_ON_MY_REPORT:
//                    setTextForTextview(message1, status1, true, now, maySubmitFrom, shouldSubmitBefore,1);
//                    setTextForTextview(message2, status2, true, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore,2);
                    message1.setText(getResources().getString(R.string.report_date_after));
                    message2.setText(getResources().getString(R.string.report_date_after));
                    status1.setText(getResources().getString(R.string.report_step1_finish));
                    status2.setText(getResources().getString(R.string.report_step2_finish));
                    setTextForTextview(message3, status3, true, now, maySendEvaluationFrom, shouldSendEvaluationBefore,3);
                    setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);
                    message4.setText(getResources().getString(R.string.report_date_before));
                    downLayout4.setClickable(false);
                    arrowRight4.setVisibility(View.GONE);
                    setOrangeClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                    setOrangeClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                    setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                    setOrangeOpen(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelSize(R.dimen.dp_126));
                    downLayout3.setLayoutParams(layoutParams2);
                    stepText3.setVisibility(View.GONE);
                    stepUser3.setVisibility(View.VISIBLE);
                    userImage1.setVisibility(View.VISIBLE);
                    userImage2.setVisibility(View.VISIBLE);
                    userImage3.setVisibility(View.VISIBLE);
                    userImage4.setVisibility(View.VISIBLE);
                    userImage5.setVisibility(View.VISIBLE);
                    userText1.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText2.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText3.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText4.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText5.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    break;

                case Report.WAITING_FOR_REFLECTION_PERIOD_TO_START:
//                    setTextForTextview(message1, status1, true, now, maySubmitFrom, shouldSubmitBefore,1);
//                    setTextForTextview(message2, status2, true, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore,2);
                    message1.setText(getResources().getString(R.string.report_date_after));
                    message2.setText(getResources().getString(R.string.report_date_after));
                    status1.setText(getResources().getString(R.string.report_step1_finish));
                    status2.setText(getResources().getString(R.string.report_step2_finish));
                    setTextForTextview(message3, status3, true, now, maySendEvaluationFrom, shouldSendEvaluationBefore,3);
                    setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);
                    message4.setText(getResources().getString(R.string.report_date_before));
                    downLayout4.setClickable(false);
                    arrowRight4.setVisibility(View.GONE);
                    setOrangeClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                    setOrangeClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                    setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                    setOrangeOpen(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                    LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelSize(R.dimen.dp_126));
                    downLayout3.setLayoutParams(layoutParams3);
                    stepText3.setVisibility(View.GONE);
                    stepUser3.setVisibility(View.VISIBLE);
                    userImage1.setVisibility(View.VISIBLE);
                    userImage2.setVisibility(View.VISIBLE);
                    userImage3.setVisibility(View.VISIBLE);
                    userImage4.setVisibility(View.VISIBLE);
                    userImage5.setVisibility(View.VISIBLE);
                    userText1.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText2.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText3.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText4.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText5.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    break;

                case Report.WAITING_FOR_REFLECTION:
//                    setTextForTextview(message1, status1, true, now, maySubmitFrom, shouldSubmitBefore,1);
//                    setTextForTextview(message2, status2, true, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore,2);
                    message1.setText(getResources().getString(R.string.report_date_after));
                    message2.setText(getResources().getString(R.string.report_date_after));
                    status1.setText(getResources().getString(R.string.report_step1_finish));
                    status2.setText(getResources().getString(R.string.report_step2_finish));
                    setTextForTextview(message3, status3, true, now, maySendEvaluationFrom, shouldSendEvaluationBefore,3);
                    setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);
                    setOrangeClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                    setOrangeClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                    setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                    setOrangeOpen(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                    LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelSize(R.dimen.dp_126));
                    downLayout3.setLayoutParams(layoutParams4);
                    stepText3.setVisibility(View.GONE);
                    stepUser3.setVisibility(View.VISIBLE);
                    userImage1.setVisibility(View.VISIBLE);
                    userImage2.setVisibility(View.VISIBLE);
                    userImage3.setVisibility(View.VISIBLE);
                    userImage4.setVisibility(View.VISIBLE);
                    userImage5.setVisibility(View.VISIBLE);
                    userText1.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText2.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText3.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText4.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText5.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    break;

                case Report.COMPLETED:
//                    setTextForTextview(message1, status1, true, now, maySubmitFrom, shouldSubmitBefore,1);
//                    setTextForTextview(message2, status2, true, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore,2);
                    message1.setText(getResources().getString(R.string.report_date_after));
                    message2.setText(getResources().getString(R.string.report_date_after));
                    status1.setText(getResources().getString(R.string.report_step1_finish));
                    status2.setText(getResources().getString(R.string.report_step2_finish));
                    setTextForTextview(message3, status3, true, now, maySendEvaluationFrom, shouldSendEvaluationBefore, 3);
                    setTextForTextview(message4, status4, true, now, maySendReflectionFrom, shouldSendReflectionBefore,4);

                    setOrangeClose(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                    setOrangeClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                    setOrangeClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                    setOrangeClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                    LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelSize(R.dimen.dp_126));
                    downLayout3.setLayoutParams(layoutParams5);
                    stepText3.setVisibility(View.GONE);
                    stepUser3.setVisibility(View.VISIBLE);
                    userImage1.setVisibility(View.VISIBLE);
                    userImage2.setVisibility(View.VISIBLE);
                    userImage3.setVisibility(View.VISIBLE);
                    userImage4.setVisibility(View.VISIBLE);
                    userImage5.setVisibility(View.VISIBLE);
                    userText1.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText2.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText3.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText4.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    userText5.setTextColor(getResources().getColor(R.color.title_bar_line_bottom));
                    break;

                case Report.ABORTED:
                    break;

            }
        } else {
            setTextForTextview(message1, status1, false, now, maySubmitFrom, shouldSubmitBefore,1);
            setTextForTextview(message2, status2, false, now, maySendSelfEvaluationFrom, shouldSendSelfEvaluationBefore,2);
            setTextForTextview(message3, status3, false, now, maySendEvaluationFrom, shouldSendEvaluationBefore,3);
            setTextForTextview(message4, status4, false, now, maySendReflectionFrom, shouldSendReflectionBefore, 4);
            setOrangeOpen(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
            if (now.after(shouldSubmitBefore)){
                setBlackOpen(layout1, stepTxt1, timeTxt1, downLayout1, arrowDown1, arrowUp1, arrowRight1);
                setGrayClose(layout2, stepTxt2, timeTxt2, downLayout2, arrowDown2, arrowUp2, arrowRight2);
                setGrayClose(layout3, stepTxt3, timeTxt3, downLayout3, arrowDown3, arrowUp3, arrowRight3);
                setGrayClose(layout4, stepTxt4, timeTxt4, downLayout4, arrowDown4, arrowUp4, arrowRight4);
                downLayout1.setClickable(false);
                setpLayout2.setClickable(false);
                setpLayout3.setClickable(false);
                setpLayout4.setClickable(false);
                arrowRight1.setVisibility(View.GONE);
                step1 = 1;
                step2 = 2;
                step3 = 2;
                step4 = 2;
            }
        }
    }

    private void setTextForTextview(TextView message, TextView status ,Boolean done, Date now, Date before, Date after, Integer step){
        String statusStr = "";
        switch (step){
            case 1:
                if (!done){
                    statusStr = getResources().getString(R.string.report_step1_do);
                } else {
                    statusStr = getResources().getString(R.string.report_step1_finish);
                }
                break;
            case 2:
                if (!done){
                    statusStr = getResources().getString(R.string.report_step2_do);
                } else {
                    statusStr = getResources().getString(R.string.report_step2_finish);
                }
                break;
            case 3:
                if (!done){
                    statusStr = getResources().getString(R.string.report_step3_do);
                } else {
                    statusStr = getResources().getString(R.string.report_step3_finish);
                }
                break;
            case 4:
                if (!done){
                    statusStr = getResources().getString(R.string.report_step4_do);
                } else {
                    statusStr = getResources().getString(R.string.report_step4_finish);
                }
                break;
        }
        if (now.before(before)){
            message.setText(getResources().getString(R.string.report_date_before));
            status.setText(statusStr);
        } else if (now.after(before) && now.before(after)){
            if (done){
                message.setText(getResources().getString(R.string.report_date_in));
                status.setText(statusStr);
            } else {
                message.setText(getResources().getString(R.string.report_date_in));
                status.setText(statusStr);
            }
        } else if (now.after(after)){
            if (done){
                message.setText(getResources().getString(R.string.report_date_after));
                status.setText(statusStr);
            } else {
                message.setText(getResources().getString(R.string.report_date_after));
                status.setText(statusStr);
                status.setTextColor(getResources().getColor(R.color.report_error));
            }
        }

    }
    private void setOrangeClose(LinearLayout layout, TextView stepTxt, TextView timeTxt, LinearLayout downLayout, ImageView arrowDown, ImageView arrowUp, ImageView arrowRight){
        layout.setBackground(getResources().getDrawable(R.drawable.report_base_close_n));
        stepTxt.setTextColor(getResources().getColor(R.color.orange));
        timeTxt.setTextColor(getResources().getColor(R.color.orange));
        downLayout.setVisibility(View.GONE);
        arrowDown.setImageResource(R.drawable.report_open_n_arr);
        arrowDown.setVisibility(View.VISIBLE);
        arrowUp.setVisibility(View.GONE);

    }

    private void setOrangeOpen(LinearLayout layout, TextView stepTxt, TextView timeTxt, LinearLayout downLayout, ImageView arrowDown, ImageView arrowUp, ImageView arrowRight){
        layout.setBackground(getResources().getDrawable(R.drawable.report_base_open_s));
        stepTxt.setTextColor(getResources().getColor(R.color.white));
        timeTxt.setTextColor(getResources().getColor(R.color.white));
        downLayout.setVisibility(View.VISIBLE);
        arrowDown.setVisibility(View.GONE);
        arrowUp.setVisibility(View.VISIBLE);
    }
    private void setOrangeUserOpen(LinearLayout layout, TextView stepTxt, TextView timeTxt, LinearLayout downLayout, ImageView arrowDown, ImageView arrowUp, ImageView arrowRight){
        layout.setBackground(getResources().getDrawable(R.drawable.report_5base_open_s));
        stepTxt.setTextColor(getResources().getColor(R.color.white));
        timeTxt.setTextColor(getResources().getColor(R.color.white));
        downLayout.setVisibility(View.VISIBLE);
        arrowDown.setVisibility(View.GONE);
        arrowUp.setVisibility(View.VISIBLE);
    }

    private void setBlackClose(LinearLayout layout, TextView stepTxt, TextView timeTxt, LinearLayout downLayout, ImageView arrowDown, ImageView arrowUp, ImageView arrowRight){
        layout.setBackground(getResources().getDrawable(R.drawable.report_base_close_ds));
        stepTxt.setTextColor(getResources().getColor(R.color.white));
        timeTxt.setTextColor(getResources().getColor(R.color.white));
        downLayout.setVisibility(View.GONE);
        arrowDown.setImageResource(R.drawable.report_open_d_arr);
        arrowDown.setVisibility(View.VISIBLE);
        arrowUp.setVisibility(View.GONE);

    }

    private void setBlackOpen(LinearLayout layout, TextView stepTxt, TextView timeTxt, LinearLayout downLayout, ImageView arrowDown, ImageView arrowUp, ImageView arrowRight){
        layout.setBackground(getResources().getDrawable(R.drawable.report_base_open_sd));
        stepTxt.setTextColor(getResources().getColor(R.color.white));
        timeTxt.setTextColor(getResources().getColor(R.color.white));
        downLayout.setVisibility(View.VISIBLE);
        arrowDown.setVisibility(View.GONE);
        arrowUp.setVisibility(View.VISIBLE);
    }

    private void setBlackUserOpen(LinearLayout layout, TextView stepTxt, TextView timeTxt, LinearLayout downLayout, ImageView arrowDown, ImageView arrowUp, ImageView arrowRight){

        layout.setBackground(getResources().getDrawable(R.drawable.report_5base_open_sd));
        layout.setPadding(0, 0, 0, 0);
        stepTxt.setTextColor(getResources().getColor(R.color.white));
        timeTxt.setTextColor(getResources().getColor(R.color.white));
        downLayout.setVisibility(View.VISIBLE);
        arrowDown.setVisibility(View.GONE);
        arrowUp.setVisibility(View.VISIBLE);
    }

    private void setGrayClose(LinearLayout layout, TextView stepTxt, TextView timeTxt, LinearLayout downLayout, ImageView arrowDown, ImageView arrowUp, ImageView arrowRight){
        layout.setBackground(getResources().getDrawable(R.drawable.report_base_close_d));
        stepTxt.setTextColor(getResources().getColor(R.color.gray_text));
        timeTxt.setTextColor(getResources().getColor(R.color.gray_text));
        downLayout.setVisibility(View.GONE);
        arrowDown.setVisibility(View.GONE);
        arrowUp.setVisibility(View.GONE);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if (data != null){
            presenter.getReportDetail();
        }

    }


}
