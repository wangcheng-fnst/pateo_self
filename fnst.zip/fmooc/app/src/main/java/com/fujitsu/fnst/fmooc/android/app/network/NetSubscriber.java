package com.fujitsu.fnst.fmooc.android.app.network;

import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import rx.Subscriber;
import retrofit.Response;

/**
 * Created by wangc.fnst on 2016/1/13.
 */
public class NetSubscriber<T> extends Subscriber<T> {

    @Override
    public void onCompleted() {

    }

    @Override
    public void onError(Throwable e) {

    }

    @Override
    public void onNext(T t) {

    }
}
