package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.NoticeModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.RssItemModel;
import com.fujitsu.fnst.fmooc.android.app.presenter.NoticeDetailPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.NoticeDetailViewInterface;

/**
 * Created by wangc.fnst on 2016/1/12.
 */
public class NoticeDetailActivity extends BaseActivity<NoticeDetailPresenter> implements NoticeDetailViewInterface {

    @Bind(R.id.id_notice_content_txt)
    TextView contentTxt;
    @Bind(R.id.id_notice_title_txt)
    TextView titleTxt;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new NoticeDetailPresenter(this);
        Intent intent = getIntent();
        RssItemModel model = (RssItemModel)intent.getSerializableExtra(Constants.EXTRA_NOTICE);
        if (model != null){
            contentTxt.setText(model.getDescription());
            titleTxt.setText(model.getTitle());
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.notice_detail_activity_layout;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.notice_detail);
    }
}
