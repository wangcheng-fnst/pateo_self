package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/13.
 */
public class NotificationDetail implements Serializable {

    private List<Notification> notifications;

    public NotificationDetail() {
    }

    public List<Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<Notification> notifications) {
        this.notifications = notifications;
    }
}
