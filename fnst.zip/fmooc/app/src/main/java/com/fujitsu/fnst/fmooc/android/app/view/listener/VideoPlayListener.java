package com.fujitsu.fnst.fmooc.android.app.view.listener;

import android.view.View;
import com.fujitsu.fnst.videoplayer.app2.view.SuperVideoPlayer;

/**
 * Created by wangc.fnst on 2015/12/21.
 */
public class VideoPlayListener implements SuperVideoPlayer.VideoPlayCallbackImpl {

    private SuperVideoPlayer videoPlayer;
    private View mPlayBtnView;

    public VideoPlayListener(SuperVideoPlayer videoPlayer, View mPlayBtnView) {
        this.videoPlayer = videoPlayer;
        this.mPlayBtnView = mPlayBtnView;
    }

    @Override
    public void onCloseVideo() {

    }

    @Override
    public void onSwitchPageType() {

    }

    @Override
    public void onPlayFinish() {

    }
}
