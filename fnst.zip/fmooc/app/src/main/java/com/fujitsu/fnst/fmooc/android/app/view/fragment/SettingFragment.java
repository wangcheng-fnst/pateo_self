package com.fujitsu.fnst.fmooc.android.app.view.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.presenter.SettingPresenter;
import com.fujitsu.fnst.fmooc.android.app.repository.RssRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.view.SendViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.SettingViewInterface;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.Locale;

/**
 * Created by wangc.fnst on 2015/12/14.
 */
public class SettingFragment extends BaseFragment<SettingPresenter> implements SettingViewInterface {

    @Bind(R.id.id_tab_left_layout)
    LinearLayout tabLeftLayout;
    @Bind(R.id.id_tab_left_icon)
    ImageView tabLeftImg;
    @Bind(R.id.id_tab_left_txt)
    TextView tabLeftTxt;
    @Bind(R.id.id_tab_right_layout)
    LinearLayout tabRightLayout;
    @Bind(R.id.id_tab_right_icon)
    ImageView tabRightImg;
    @Bind(R.id.id_tab_right_txt)
    TextView tabRightTxt;
    @Bind(R.id.id_head_img)
    ImageView headImg;

    @Bind(R.id.id_left_list)
    LinearLayout userLayout;
    @Bind(R.id.id_right_list)
    LinearLayout setLayout;

    @Bind(R.id.profile_left_firstname)
    TextView firstnameText;
    @Bind(R.id.profile_left_sex)
    TextView sexText;
    @Bind(R.id.profile_left_birthday)
    TextView birthdayText;
    @Bind(R.id.profile_left_education)
    TextView educationText;
    @Bind(R.id.id_right_list_profile)
    TextView profileText;
    @Bind(R.id.id_right_list_help)
    TextView helpText;
    @Bind(R.id.id_right_list_action)
    TextView actionText;
    @Bind(R.id.id_right_list_change)
    TextView changeText;
    @Bind(R.id.id_right_list_notice)
    RelativeLayout noticeLayout;
    @Bind(R.id.id_notice_img)
    ImageView noticeImg;
    @Bind(R.id.id_logout_btn)
    Button logoutBtn;
    @Bind(R.id.id_name_txt)
    TextView nameText;
    @Bind(R.id.id_email_txt)
    TextView emailText;
    @Bind(R.id.setting_layout)
    LinearLayout settingLayout;
    @Bind(R.id.setting_error)
    LinearLayout errorLayout;
    @Bind(R.id.setting_retry)
    Button retryButton;

    public SettingFragment() {
        presenter = new SettingPresenter(this);
    }

    @Override
    protected void init() {
        tabLeftLayout.setOnClickListener(this);
        tabRightLayout.setOnClickListener(this);
        profileText.setOnClickListener(this);
        helpText.setOnClickListener(this);
        actionText.setOnClickListener(this);
        changeText.setOnClickListener(this);
        logoutBtn.setOnClickListener(this);
        noticeLayout.setOnClickListener(this);
        retryButton.setOnClickListener(this);
        leftClick();
        showLeft();
        dismissRight();
        settingLayout.setVisibility(View.VISIBLE);

    }

    @Override
    public void apiSuccess(){
        settingLayout.setVisibility(View.VISIBLE);
        errorLayout.setVisibility(View.GONE);
    }

    @Override
    public void apiFailed(){
        settingLayout.setVisibility(View.GONE);
        errorLayout.setVisibility(View.VISIBLE);
    }

    @Override
    public void showDialog(Dialog dialog) {
        dialog.show();
    }

    public void checkHasRss() {
        if (RssRepository.getInstance().hasNew()) {
            if (noticeImg != null)
                noticeImg.setVisibility(View.VISIBLE);
        } else {
            if (noticeImg != null)
                noticeImg.setVisibility(View.GONE);
        }
    }

    @Override
    public void onResume() {
        checkHasRss();
        super.onResume();
        if (ApplicationUtils.isSetting){
            rightClick();
            showRight();
            dismissLeft();
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.setting_fragment_layout;
    }

    @Override

    public void setUserInfo(String realName, String sex, Integer year, String education, String displayName, String primaryEmail,String url){
        if (displayName != null){
            nameText.setText(displayName);
        }

        if (primaryEmail != null){
            emailText.setText(primaryEmail);
        }

        if (realName != null){
            firstnameText.setText(realName);
        }
        if (sex != null){
            if (sex.equals(Constants.MALE)){
                sexText.setText(getString(R.string.profile_male));
            } else if (sex.equals(Constants.FEMALE)) {
                sexText.setText(getString(R.string.profile_female));
            } else if (sex.equals(Constants.OTHER)) {
                sexText.setText(getString(R.string.profile_other));
            }

        }
        if (year != null) {
            birthdayText.setText(year.toString());
        }
        if (education != null) {
            educationText.setText(education);
        }
        if (url != null){
            headImg.setImageResource(Constants.getImageResId_71(url));
//            ImageLoader.getInstance().displayImage(url,headImg);
        }

    }

    @Override
    public void leftClick() {
        tabLeftLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_left_o));
        tabRightLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_right_n));
        //tabLeftLayout.setBackgroundColor(getResources().getColor(R.color.bottom_bg));
        tabLeftImg.setImageResource(R.drawable.tab_profile_n);
        tabRightImg.setImageResource(R.drawable.tab_setting_o);
        tabLeftTxt.setTextColor(getResources().getColor(R.color.white));
        tabRightTxt.setTextColor(getResources().getColor(R.color.orange));
        //TODO:change img src
    }


    @Override
    public void rightClick() {
        tabLeftLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_left_n));
        tabRightLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_right_o));
        //tabLeftLayout.setBackgroundColor(getResources().getColor(R.color.bottom_bg));
        tabLeftImg.setImageResource(R.drawable.tab_profile_o);
        tabRightImg.setImageResource(R.drawable.tab_setting_n);
        tabLeftTxt.setTextColor(getResources().getColor(R.color.orange));
        tabRightTxt.setTextColor(getResources().getColor(R.color.white));
        //TODO:change img src
    }

    @Override
    public void showLeft() {
        userLayout.setVisibility(View.VISIBLE);
    }

    @Override
    public void showRight() {
        setLayout.setVisibility(View.VISIBLE);
    }

    @Override
    public void dismissLeft() {
        userLayout.setVisibility(View.GONE);
    }

    @Override
    public void dismissRight() {
        setLayout.setVisibility(View.GONE);
    }

    @Override
    public void resetTab() {
        tabLeftLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_left_n));
        tabRightLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_right_n));
        //tabLeftLayout.setBackgroundColor(getResources().getColor(R.color.bottom_bg));
        tabLeftImg.setImageResource(R.drawable.tab_profile_o);
        tabRightImg.setImageResource(R.drawable.tab_setting_o);
        tabLeftTxt.setTextColor(getResources().getColor(R.color.orange));
        tabRightTxt.setTextColor(getResources().getColor(R.color.orange));
        //TODO: change img src
    }
    protected void dialog() {
          AlertDialog.Builder builder = new AlertDialog.Builder(this.getActivity());
          builder.setMessage(getResources().getString(R.string.logout_title));
          builder.setPositiveButton(getResources().getString(R.string.logout_logout), new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
//                  presenter.logoutClick();
              }
          });
          builder.setNegativeButton(getResources().getString(R.string.logout_cansel), new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
              }
          });
          builder.create().show();
        }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (v.getId() == R.id.id_tab_left_layout) {
//            ShareReferencesManager.getInstance(this.getActivity()).setValue(Constants.ISSETTING, false);
            ApplicationUtils.isSetting = false;
            presenter.tabClick(SettingPresenter.USER_TAB);
        } else if (v.getId() == R.id.id_tab_right_layout) {
//            ShareReferencesManager.getInstance(this.getActivity()).setValue(Constants.ISSETTING, true);
            ApplicationUtils.isSetting = true;
            presenter.tabClick(SettingPresenter.SET_TAB);
        } else if (v.getId() == R.id.id_right_list_help) {
            presenter.helpClick();
        } else if (v.getId() == R.id.id_right_list_action) {
            presenter.actionClick();
        } else if (v.getId() == R.id.id_right_list_change) {
            presenter.changeClick();
        } else if (v.getId() == R.id.id_right_list_profile) {
            presenter.profileClick();
        } else if (v.getId() == R.id.id_logout_btn) {
            presenter.logoutClick(getActivity());
        } else if (v.getId() == R.id.id_right_list_notice) {
            presenter.noticeClick();
        } else if (v.getId() == R.id.setting_retry){
            presenter.getUserInformation();
        }
    }

    public void getDataFromNet() {
        presenter.getUserInformation();
    }

}
