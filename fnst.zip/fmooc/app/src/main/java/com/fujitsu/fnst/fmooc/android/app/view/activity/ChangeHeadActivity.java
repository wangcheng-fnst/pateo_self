package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.graphics.PointF;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSmoothScroller;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.HeadModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.UserModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Image;
import com.fujitsu.fnst.fmooc.android.app.network.model.ProfileImage;
import com.fujitsu.fnst.fmooc.android.app.network.model.User;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.presenter.ChangeHeadPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.ChangeHeadViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.HeadAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.CustomRecycleView;
import com.fujitsu.fnst.fmooc.android.app.view.component.SingleItemHorizontalScrollView;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EndlessScrollListener;
import com.fujitsu.fnst.fmooc.android.app.view.listener.SpeedLayoutManager;
import com.jakewharton.rxbinding.view.RxView;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by wangc.fnst on 2015/12/25.
 */
public class ChangeHeadActivity extends BaseActivity<ChangeHeadPresenter> implements ChangeHeadViewInterface {

    @Bind(R.id.id_head_list)
    CustomRecycleView headList;
    @Bind(R.id.id_pre_btn)
    Button preBtn;
    @Bind(R.id.id_next_btn)
    Button nextBtn;
    @Bind(R.id.id_save_btn)
    Button saveBtn;
    @Bind(R.id.head_layout)
    LinearLayout headLayout;
    @Bind(R.id.head_error)
    LinearLayout errorLayout;


    private HeadAdapter adapter;
    private List<ProfileImage> mData = new ArrayList<ProfileImage>();
    private LinearLayoutManager manager;
    private int position = 1;
    private User user;
    private Image images;

    private String[] urls = new String []{
    "http://d.hiphotos.baidu.com/zhidao/wh%3D450%2C600/sign=29ca5ab40ed79123e0b59c70980475b4/0b7b02087bf40ad18193cd5f552c11dfa9ecce13.jpg",
    "http://www.qqleju.com/uploads/allimg/150330/30-022109_497.png",
    "http://h.hiphotos.baidu.com/zhidao/wh%3D450%2C600/sign=84adc38f9045d688a357baa091f25128/4ec2d5628535e5dda041af6374c6a7efce1b6218.jpg"};

    @Override
    protected int getLayout() {
        return R.layout.change_head_activity_layout;
    }

    @Override
    protected void onCreateView() {
        super.onCreateView();
        Intent intent = getIntent();
        user = ((UserInfoModel)intent.getSerializableExtra(Constants.EXTRA_USER)).getUser();
//        images = (Image)intent.getSerializableExtra(Constants.EXTRA_IMAGES);
        mData = Constants.getImages();
        presenter = new ChangeHeadPresenter(this,user);
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        final int width = wm.getDefaultDisplay().getWidth();
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(headList.getLayoutParams());
        lp.width = (int) (1.65 * width);
        int margin = (int) ((width / 3.08f) + 0.5);
        lp.setMargins(0 - margin, 0, 0, 0);
        headList.setLayoutParams(lp);
        manager = new SpeedLayoutManager(this, 0, false);
        adapter = new HeadAdapter(mData);
        headList.setAdapter(adapter);
        headList.setLayoutManager(manager);
        preBtn.setOnClickListener(this);
        nextBtn.setOnClickListener(this);
        saveBtn.setOnClickListener(this);

//        position = Integer.MAX_VALUE/2 + 1;
//        headList.scrollToPosition(Integer.MAX_VALUE/2);
        headList.addOnScrollListener(new RecyclerView.OnScrollListener() {
//            @Override
//            public void onLoadMore(int page, int totalItemsCount, int addMode) {
//                customLoadMoreDataFromApi(page, addMode);
//            }

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    ApplicationUtils.isOver = true;
                } else if (newState == RecyclerView.SCROLL_STATE_DRAGGING) {
                    ApplicationUtils.isOver = false;
                } else if (newState == RecyclerView.SCROLL_STATE_SETTLING) {
                    ApplicationUtils.isOver = false;
                }
            }
        });

    }

    private void moveToPosition(int targetId){
//        headList.scrollToPosition(Integer.MAX_VALUE/2+1);
        int id = Integer.valueOf(adapter.getItem(Integer.MAX_VALUE/2 + 1).getImageId());
        int offset = targetId - id;
        headList.scrollToPosition(Integer.MAX_VALUE/2+offset);
        position = Integer.MAX_VALUE/2+offset+1;
    }

    @Override
    protected void onResume() {
        String id = user.getProfileImage().getImageId();
        if (StringUtils.isNumber(id)) {
            moveToPosition(Integer.valueOf(id));
        }else {
            headList.scrollToPosition(Integer.MAX_VALUE/2);
        }
        super.onResume();
    }

    @Override
    public void apiSuccess(){
        headLayout.setVisibility(View.VISIBLE);
        errorLayout.setVisibility(View.GONE);
    }

    @Override
    public void apiFailed(){
        headLayout.setVisibility(View.GONE);
        errorLayout.setVisibility(View.VISIBLE);
    }



    public void customLoadMoreDataFromApi(int offset, int addMode) {
        // Use the offset value and add it as a parameter to your API request to retrieve appropriate data.
        // Deserialize API response and then construct new objects to append to the adapter
        // Add new objects to the data source for the adapter
        int curSize = adapter.getItemCount();
        if (addMode == 0){
            //only add end
            adapter.setItemCount(curSize+mData.size());
            adapter.notifyItemRangeInserted(curSize, curSize + mData.size()-1);
        } else if (addMode == 1){
            //add end and start
            adapter.setItemCount(curSize+mData.size()*2);
            adapter.notifyItemRangeInserted(curSize, curSize + mData.size() - 1);
            adapter.notifyItemRangeInserted(0, mData.size());
        }else if (addMode == 2){
            //only add start
            adapter.setItemCount(curSize+mData.size());
            adapter.notifyItemRangeInserted(0, mData.size());
        }
    }




    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (R.id.id_pre_btn == v.getId()) {
            move(false);
        } else if (R.id.id_next_btn == v.getId()) {
            move(true);
        } else if (R.id.id_save_btn == v.getId()){
            presenter.sendChange();
        }
    }
    @Override
    public void move(boolean isNext){
        if (isNext){
            position = manager.findLastCompletelyVisibleItemPosition();
            headList.smoothScrollToPosition(manager.findLastCompletelyVisibleItemPosition()+1);
        }else {
            position = manager.findFirstCompletelyVisibleItemPosition();
            headList.smoothScrollToPosition(position <= 0?position:position-1);
        }
    }

    @Override
    public void setOnTouch(View.OnTouchListener listener) {
        headList.setOnTouchListener(listener);
    }

    @Override
    public ProfileImage getSelectHead() {
        return adapter.getItem(position);
    }

    @Override
    public void back() {
        finish();
    }

    @Override
    public void setData(Image images) {
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.profile_image_title);
    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();
    }
}
