package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.LaunchPresenter;
import com.fujitsu.fnst.fmooc.android.app.view.LaunchViewInterface;

/**
 * Created by wangc.fnst on 2015/12/10.
 */
public class LaunchActivity extends BaseActivity<LaunchPresenter> implements LaunchViewInterface {

    @Bind(R.id.id_launch_tip_txt)
    TextView tipTxt;
    @Bind(R.id.id_facebook_btn)
    Button facebookBtn;
    @Bind(R.id.id_google_btn)
    Button googleBtn;
    @Bind(R.id.id_login_btn)
    Button loginBtn;
    @Bind(R.id.id_register_btn)
    Button registerBtn;


    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new LaunchPresenter(this);
        facebookBtn.setOnClickListener(this);
        googleBtn.setOnClickListener(this);
        loginBtn.setOnClickListener(this);
        registerBtn.setOnClickListener(this);
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.launch_main_title);
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_launch_layout;
    }



    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (R.id.id_facebook_btn == v.getId()){
            presenter.facebookLink();
        }else if(R.id.id_google_btn == v.getId()){
            presenter.googleLink();
        } else if (R.id.id_login_btn == v.getId()){
            presenter.login();
        } else if (R.id.id_register_btn == v.getId()){
            presenter.register();
        }
    }

    @Override
    protected void onDestroy() {
        presenter.onDestroy();
        super.onDestroy();

    }
}
