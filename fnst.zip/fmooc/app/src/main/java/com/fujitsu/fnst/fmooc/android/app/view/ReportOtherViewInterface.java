package com.fujitsu.fnst.fmooc.android.app.view;

import android.text.TextWatcher;

/**
 * Created by lijl.fnst on 2016/01/19.
 */
public interface ReportOtherViewInterface extends BaseViewInterface {
    String getContentId();
    void disableBtn();
    void enableBtn();
    String getUserComment();
    void setCommentListener(TextWatcher watcher);
}
