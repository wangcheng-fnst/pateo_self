package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by zhaod.fnst on 2016/02/01.
 */
public class QuestionModel implements Serializable {
    String label;
    List<QuestionChoices> choices;

    public String getLabel(){
        return label;
    }

    public void setLabel(String label){
        this.label = label;
    }

    public List<QuestionChoices> getChoices(){
        return choices;
    }

    public void setChoices(List<QuestionChoices> choices){
        this.choices = choices;
    }
}
