package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by lijl.fnst on 2016/01/20.
 */
public class SubmittedReportEvaluation implements Serializable {
    private String forSubmissionId;
    private List<Integer> selectedChoices;
    private List<Integer> selectedScores;
    private String comments;
    private Date submittedAt;

    public String getForSubmissionId() {
        return forSubmissionId;
    }

    public void setForSubmissionId(String forSubmissionId) {
        this.forSubmissionId = forSubmissionId;
    }

    public List<Integer> getSelectedChoices() {
        return selectedChoices;
    }

    public void setSelectedChoices(List<Integer> selectedChoices) {
        this.selectedChoices = selectedChoices;
    }

    public List<Integer> getSelectedScores() {
        return selectedScores;
    }

    public void setSelectedScores(List<Integer> selectedScores) {
        this.selectedScores = selectedScores;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getSubmittedAt() {
        return submittedAt;
    }

    public void setSubmittedAt(Date submittedAt) {
        this.submittedAt = submittedAt;
    }
}
