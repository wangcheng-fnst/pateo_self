package com.fujitsu.fnst.fmooc.android.app.view;

/**
 * Created by lijl.fnst on 2016/02/05.
 */
public interface ReportHelpViewInterface extends BaseViewInterface {
}
