package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.app.Activity;
import android.content.Intent;
import com.fujitsu.fnst.fmooc.android.app.data.model.HeadModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.EmptyModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Image;
import com.fujitsu.fnst.fmooc.android.app.network.model.ProfileImage;
import com.fujitsu.fnst.fmooc.android.app.network.model.User;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ChangeHeadViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.listener.RecycleViewOnTouchListener;
import rx.Subscriber;
import rx.observers.SafeSubscriber;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public class ChangeHeadPresenter extends BasePresenter implements RecycleViewOnTouchListener.CallbackFromMove {
    private ChangeHeadViewInterface view;
    private RecycleViewOnTouchListener onTouchListener;
    private boolean moveOver = true;
    private User user;
    Map<String, Object> data= new HashMap<String, Object>();

    public ChangeHeadPresenter(ChangeHeadViewInterface view,User user) {
        this.view = view;
        this.user = user;
        onTouchListener = new RecycleViewOnTouchListener();
        onTouchListener.setCallbackFromMove(this);
        onTouchListener.setMoveOver(moveOver);
        view.setOnTouch(onTouchListener);
    }

    @Override
    public void move(boolean isNext) {
        view.move(isNext);
    }

    public void sendChange(){
        view.showWaitingDialog();
        final  ProfileImage model = view.getSelectHead();
        UserRepository.getInstance().changeHead(user.getUserId(), model.getImageId(), new Subscriber<EmptyModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
                Intent intent = new Intent();
                intent.putExtra(Constants.EXTRA_RESULT, model);
                ((Activity) view).setResult(Constants.PROFILE_SETTING_IMAGE, intent);
                view.back();
            }
            @Override
            public void onError(Throwable e) {
                view.hideWaitingDialog();
                view.showToast(e.getMessage());
            }
            @Override
            public void onNext(EmptyModel o) {

            }
        });

    }
    public void setScrollState(boolean moveOver){
        this.moveOver = moveOver;
        onTouchListener.setMoveOver(moveOver);
    }


}
