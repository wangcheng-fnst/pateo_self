package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import com.fujitsu.fnst.fmooc.android.app.view.CourseDetailViewInterface;
import com.fujitsu.fnst.videoplayer.app2.model.Video;
import com.fujitsu.fnst.videoplayer.app2.model.VideoUrl;
import com.fujitsu.fnst.videoplayer.app2.view.MediaController;
import com.fujitsu.fnst.videoplayer.app2.view.SuperVideoPlayer;

import java.util.ArrayList;

/**
 * Created by wangc.fnst on 2015/12/21.
 */
public class CourseDetailPresenter extends BasePresenter implements SuperVideoPlayer.VideoPlayCallbackImpl {

    private CourseDetailViewInterface view;
    private ArrayList<Video> videoArrayList;

    public CourseDetailPresenter(CourseDetailViewInterface view) {
        this.view = view;
        init();
    }

    public void init(){
        view.showWaitingDialog();
        getVideo();
        view.setVideoPlayCallback(this);
        view.dismissWaitingDialog();
    }

    private void getVideo(){
        Video video = new Video();
        VideoUrl videoUrl3 = new VideoUrl();
        videoUrl3.setFormatName("720P");
        videoUrl3.setFormatUrl("http://7xkbzx.com1.z0.glb.clouddn.com/SampleVideo_1080x720_10mb.mp4");
        ArrayList<VideoUrl> arrayList2 = new ArrayList<VideoUrl>();
        arrayList2.add(videoUrl3);
        video.setVideoUrl(arrayList2);
        videoArrayList = new ArrayList<>();
        videoArrayList.add(video);
    }

    public void loadVideo(){
        view.loadVideo(videoArrayList);
    }

    @Override
    public void onCloseVideo() {
        view.videoClose();
        view.showPlayBtn();
        view.dismissVideoPlayer();
        view.resetPageToPortrait();

    }

    @Override
    public void onSwitchPageType() {
        if (((Activity)view).getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE){
            view.showTitleBar();
            view.showIntroduce();
            ((Activity) view).setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            view.setPageType(MediaController.PageType.SHRINK);

        } else {
            view.dismissIntroduce();
            view.dismissTitleBar();
            ((Activity) view).setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            view.setPageType(MediaController.PageType.EXPAND);
        }

    }

    @Override
    public void onPlayFinish() {
        view.videoClose();
        view.showPlayBtn();
        view.dismissVideoPlayer();
        if (((Activity)view).getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE){
            view.showTitleBar();
            view.showIntroduce();
            ((Activity) view).setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            view.setPageType(MediaController.PageType.SHRINK);
        }
        view.resetPageToPortrait();
    }
}
