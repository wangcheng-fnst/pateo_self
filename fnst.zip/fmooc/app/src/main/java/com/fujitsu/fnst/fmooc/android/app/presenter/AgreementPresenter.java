package com.fujitsu.fnst.fmooc.android.app.presenter;

import com.fujitsu.fnst.fmooc.android.app.view.AgreementViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.RegisterInfoViewInterface;

/**
 * Created by lijl.fnst on 2015/12/14.
 */
public class AgreementPresenter extends BasePresenter {
    private AgreementViewInterface view;

    public AgreementPresenter(AgreementViewInterface viewInterface){
        super();
        view = viewInterface;

    }


}
