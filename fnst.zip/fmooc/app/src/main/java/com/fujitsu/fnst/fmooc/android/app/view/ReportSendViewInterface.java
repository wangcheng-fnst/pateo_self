package com.fujitsu.fnst.fmooc.android.app.view;

import android.app.Dialog;
import android.text.TextWatcher;
import android.widget.EditText;

/**
 * Created by lijl.fnst on 2016/01/07.
 */
public interface ReportSendViewInterface extends BaseViewInterface{
    void enableBtn();
    void disableBtn();
    String getContentId();
    String getUserAnswer();
    int getMaxNumberOfCharacters();
    EditText getEditText();
    void setAnswerListener(TextWatcher watcher);
    void showDialog(Dialog dialog);
}
