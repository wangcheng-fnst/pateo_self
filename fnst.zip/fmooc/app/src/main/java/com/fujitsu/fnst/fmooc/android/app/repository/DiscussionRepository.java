package com.fujitsu.fnst.fmooc.android.app.repository;

import com.fujitsu.fnst.fmooc.android.app.data.model.DiscussionModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Message;
import com.fujitsu.fnst.fmooc.android.app.network.model.MessageListModel;
import com.fujitsu.fnst.fmooc.android.app.network.service.DiscussionService;
import rx.Observable;
import rx.Scheduler;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import java.util.List;
import java.util.Observer;


/**
 * Created by wangc.fnst on 2016/1/5.
 */
public class DiscussionRepository {


    private static DiscussionRepository instance;

    public static DiscussionRepository getInstance(){
        if (instance == null){
            instance = new DiscussionRepository();
        }
        return instance;
    }
    public DiscussionRepository() {
    }


    public Subscription getMessages(String id,int page, Subscriber<List<DiscussionModel>> subscriber){
        Subscription subscription = DiscussionService.getInstance().getMessages(id,page,subscriber);
        return subscription;
    }

    public Subscription sendMessage(String id,String text,String replyto,Subscriber<Message> subscriber){
        Subscription subscription = DiscussionService.getInstance().sendMessage(id,text,replyto,subscriber);
        return subscription;
    }

    public Subscription getMessageById(String id,String messageId,Subscriber<DiscussionModel> subscriber){
        Subscription subscription = DiscussionService.getInstance().getMessageById(id, messageId, subscriber);
        return subscription;
    }
}
