package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;

import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.*;
import com.fujitsu.fnst.fmooc.android.app.presenter.ReportOtherPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.ReportSelfPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ReportOtherViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.QuestionAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.CustomDialog;
import com.fujitsu.fnst.fmooc.android.app.view.component.NoScrollListview;

import java.util.ArrayList;
import java.util.List;

public class ReportOtherActivity extends BaseActivity<ReportOtherPresenter> implements ReportOtherViewInterface {

    @Bind(R.id.id_question_list)
    NoScrollListview questionList;
    @Bind(R.id.id_report_self_btn)
    Button submit;
    @Bind(R.id.id_score)
    TextView myScore;
    @Bind(R.id.id_score_total)
    TextView totalScore;
    @Bind(R.id.id_report_your)
    TextView reportContent;
    @Bind(R.id.id_quesiton)
    TextView question;
    @Bind(R.id.id_report_comment)
    EditText reportComment;
    @Bind(R.id.id_report_pass_comment)
    TextView reportPassComment;
    @Bind(R.id.id_message_text)
    TextView messageText;

    private QuestionAdapter adapter;
    private List<ReportEvaluationActivity> mData = new ArrayList<ReportEvaluationActivity>();
    int[] scores = null;
    int[] selectedChoices = null;
    private ReportDetailModel reportModel;
    String contentId,submissionId;
    int position;
    boolean hasEvaluation;
    private View.OnTouchListener onTouchListener;
    private CustomDialog dialog;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        Intent intent = getIntent();
        reportModel =((ReportDetailModel)intent.getSerializableExtra(Constants.EXTRA_REPORT));
        position = intent.getExtras().getInt("position");
        hasEvaluation = intent.getExtras().getBoolean("hasEvaluation");
        mData = reportModel.getSubmission().getEvaluationWording().getActivities();
        contentId = reportModel.getContent().getContentId();
        question.setFocusable(true);
        question.setFocusableInTouchMode(true);
        question.requestFocus();
        reportContent.setMovementMethod(ScrollingMovementMethod.getInstance());
        reportContent.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        messageText.setText(getResources().getString(R.string.report_other_answer));

        SubmittedReport submittedReport = reportModel.getSubmission().getAssignedSubmissions().get(position);
        submissionId = submittedReport.getSubmissionId();
        List<SubmittedReportEvaluation> submittedReportEvaluations = reportModel.getSubmission().getEvaluationsForAssignedSubmission();

        reportContent.setText(submittedReport.getSubmittedAnswerText());

        onTouchListener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if(event.getAction()==MotionEvent.ACTION_MOVE){
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if(event.getAction()==MotionEvent.ACTION_UP){
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                }
                return false;
            }
        };

        List<Integer> passChoices = null;
        int maxScore = 0;
        int initScore = 0;
        scores = new int[mData.size()];
        selectedChoices = new int[mData.size()];
        for(int i=0;i<mData.size();i++){
            List<ReportEvaluationActivityChoice> choices=mData.get(i).getChoices();
            initScore += choices.get(0).getScore();
            scores[i] = choices.get(0).getScore();
            selectedChoices[i] = 0;
            int score=0;
            for(int k=0;k<choices.size();k++){
                if(choices.get(k).getScore()>score)
                    score = choices.get(k).getScore();
            }
            maxScore += score;
        }
        totalScore.setText("/"+maxScore+getResources().getString(R.string.report_score));
        if(hasEvaluation){
            disableBtn();
            SubmittedReportEvaluation thisModel = null;
            for(int i=0;i<submittedReportEvaluations.size();i++){
                if(submissionId.equals(submittedReportEvaluations.get(i).getForSubmissionId())){
                    thisModel = submittedReportEvaluations.get(i);
                    break;
                }
            }
            reportPassComment.setVisibility(View.VISIBLE);
            reportPassComment.setText(thisModel.getComments());
            reportPassComment.setMovementMethod(ScrollingMovementMethod.getInstance());
            reportPassComment.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
            reportPassComment.setOnTouchListener(onTouchListener);
            reportComment.setVisibility(View.GONE);
            passChoices = thisModel.getSelectedChoices();
            List<Integer> scores = thisModel.getSelectedScores();
            Integer getScore = 0;
            for(int k=0;k<scores.size();k++){
                getScore += scores.get(k);
            }
            myScore.setText(String.valueOf(getScore));
            disableBtn();
        }else{
            reportPassComment.setVisibility(View.GONE);
            reportComment.setVisibility(View.VISIBLE);
            reportComment.setMovementMethod(ScrollingMovementMethod.getInstance());
            reportComment.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
            reportComment.setOnTouchListener(onTouchListener);
            myScore.setText(String.valueOf(initScore));
            disableBtn();
        }
        presenter = new ReportOtherPresenter(this);

        adapter = new QuestionAdapter(mData,passChoices,this);
        questionList.setAdapter(adapter);
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton button = (RadioButton)v;
                if(button!=null){
                    int position = (int)button.getTag(R.id.position);
                    int score = (int)button.getTag(R.id.score);
                    int radioPosition = (int)button.getTag(R.id.radio_position);
                    scores[position]=score;
                    selectedChoices[position] = radioPosition;
                    int total = 0;
                    for(int i=0;i<scores.length;i++){
                        total += scores[i];
                    }
                    myScore.setText(String.valueOf(total));
                }
            }
        });
//        adapter.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                RadioButton button = (RadioButton)group.findViewById(checkedId);
//                if(button!=null){
//                    int position = (int)button.getTag(R.id.position);
//                    int score = (int)button.getTag(R.id.score);
//                    int radioPosition = (int)button.getTag(R.id.radio_position);
//                    scores[position]=score;
//                    selectedChoices[position] = radioPosition;
//                    int total = 0;
//                    for(int i=0;i<scores.length;i++){
//                        total += scores[i];
//                    }
//                    myScore.setText(String.valueOf(total));
//                }
//            }
//        });
    }

    @Override
    public void disableBtn() {
        submit.setClickable(false);
        submit.setAlpha(0.5f);
        submit.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }

    @Override
    public void enableBtn() {
        submit.setClickable(true);
        submit.setAlpha(1);
        submit.setOnClickListener(this);
        submit.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public String getUserComment() {
        return reportComment.getText().toString();
    }

    @Override
    public void setCommentListener(TextWatcher watcher) {
        reportComment.addTextChangedListener(watcher);
    }

    @Override
    public String getContentId() {
        return contentId;
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_report_self_btn) {
            if (dialog == null){
                dialog = new CustomDialog(this);
                dialog.setNoStr(getResources().getString(R.string.no));
                dialog.setYesStr(getResources().getString(R.string.sign_up_btn));
                dialog.setTitleStr(getResources().getString(R.string.report_other_dialog));
                dialog.setListener(new CustomDialog.YesOrNoClickListener() {
                    @Override
                    public void yesClick() {
                        if (dialog.isShowing()) {
                            dialog.dismiss();
                        }

                        String selected = "";
                        for(int i=0;i<selectedChoices.length;i++){
                            if(i == selectedChoices.length-1)
                                selected += String.valueOf(selectedChoices[i]);
                            else
                                selected += String.valueOf(selectedChoices[i])+",";
                        }
                        String comments = reportComment.getText().toString();
                        presenter.submit(contentId,submissionId,selected,comments);
                    }

                    @Override
                    public void noClick() {
                        if (dialog.isShowing()) {
                            dialog.dismiss();
                        }
                    }
                });
            }
            dialog.show();
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_report_self;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }


    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.report_other_title);
    }
}
