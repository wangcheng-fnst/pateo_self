package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/13.
 */
public class MessageInformation implements Serializable {
    private int pageNumber;
    private int numberOfMessagesPerPage;
    private int totalNumberOfMessages;
    private List<Message> messages;

    public MessageInformation() {
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public int getNumberOfMessagesPerPage() {
        return numberOfMessagesPerPage;
    }

    public void setNumberOfMessagesPerPage(int numberOfMessagesPerPage) {
        this.numberOfMessagesPerPage = numberOfMessagesPerPage;
    }

    public int getTotalNumberOfMessages() {
        return totalNumberOfMessages;
    }

    public void setTotalNumberOfMessages(int totalNumberOfMessages) {
        this.totalNumberOfMessages = totalNumberOfMessages;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }
}
