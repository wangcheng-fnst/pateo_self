package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import android.widget.Toast;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.model.EmptyModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.SignUpViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.RegisterActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.RegisterInfoViewActivity;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;

/**
 * Created by lijl.fnst on 2015/12/10.
 */
public class SignUpPresenter extends BasePresenter implements EditChangeListener.TextChangeCallback, OnGetModelFinishImpl<EmptyModel>{
    private SignUpViewInterface view;
    private boolean emailOk = false;
    private String userName;
    private String requestType = UserRepository.SEND_CODE_RESPONSE;

    public SignUpPresenter(SignUpViewInterface signUpViewInterface){
        super();
        view = signUpViewInterface;
        init();
    }
    public void init(){
        UserRepository.getInstance().register(requestType,this);
        EditChangeListener nameWatcher = new EditChangeListener();
        nameWatcher.setCallback(this);
        view.setEmailListener(nameWatcher);


    }

    public void send(){
        if (!checkValue()){
            //Toast.makeText(context, "register btn click", Toast.LENGTH_SHORT).show();
//            Intent intent = new Intent(context, RegisterActivity.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            context.startActivity(intent);
            return;
        }
        view.showWaitingDialog();
        UserRepository.getInstance().sendCode(userName, Constants.CODE_CREATEACCOUNT, requestType);

    }

    @Override
    public void formatRight() {
        userName = view.getEmail();
        if (!StringUtils.isBlank(userName)){
            view.enableBtn();
        }else{
            view.disableBtn();
        }

    }

    private boolean checkValue(){
       if (!StringUtils.isEmail(userName)){
           view.showToast(context.getResources().getString(R.string.mail_error));
           return  false;
       }
        return true;
    }

    @Override
    public void onSuccess(String type, EmptyModel result) {
        if (type.equals(UserRepository.SEND_CODE_RESPONSE)){
            view.hideWaitingDialog();
            Intent intent = new Intent(context, RegisterInfoViewActivity.class);
//        Intent intent = new Intent(context, CourseDetailActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }

    }

    @Override
    public void onFailed(String type,String message) {
        view.hideWaitingDialog();
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        UserRepository.getInstance().unRegister(requestType);
        super.onDestroy();

    }

}
