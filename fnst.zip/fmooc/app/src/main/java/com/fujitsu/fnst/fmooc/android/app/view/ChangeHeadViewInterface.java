package com.fujitsu.fnst.fmooc.android.app.view;

import android.view.View;
import com.fujitsu.fnst.fmooc.android.app.data.model.HeadModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Image;
import com.fujitsu.fnst.fmooc.android.app.network.model.ProfileImage;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public interface ChangeHeadViewInterface extends BaseViewInterface {

    void move(boolean isNext);
    void setOnTouch(View.OnTouchListener listener);
    ProfileImage getSelectHead();
    void back();
    void setData(Image images);
    void apiSuccess();
    void apiFailed();
}
