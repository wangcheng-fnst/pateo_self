package com.fujitsu.fnst.fmooc.android.app.view.fragment;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.presenter.TopPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.TopViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.CourseItemAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/16.
 */
public class TopFragment extends BaseFragment<TopPresenter> implements TopViewInterface {

    @Bind(R.id.id_last_list)
    PullRefleashListView listView;
    @Bind(R.id.id_top_layout)
    LinearLayout courseLayout;
    @Bind(R.id.id_top_error_layout)
    LinearLayout courseErrorLayout;
    @Bind(R.id.top_refresh_btn)
    Button topRefreshBtn;

    private CourseItemAdapter adapter;
    private List<Course> mData = new ArrayList<Course>();
    private int page = 1;


    @Override
    protected int getLayout() {
        return R.layout.top_fragment_layout;
    }

    @Override
    protected void init() {
        presenter = new TopPresenter(this,page);
        listView.setPullLoadEnable(true);
        listView.setPullRefreshEnable(true);
        adapter = new CourseItemAdapter(mData, 0);
        listView.setAdapter(adapter);
        listView.setRefleashListener(presenter);
        listView.setOnItemClickListener(adapter);
        topRefreshBtn.setOnClickListener(this);
        createData();


    }
    private void createData(){
        showWaitingDialog();
        presenter.getDataFromNet();
    }

    @Override
    public void onLoad() {
        listView.stopLoadMore();
        listView.stopRefresh();
        listView.setRefreshTime("");
    }

    @Override
    public void addItems(List<Course> data) {
        mData.addAll(mData.size()-1 < 0?0:mData.size() -1,data);
    }

    @Override
    public void notify(boolean isRefresh) {
        if (isRefresh){
            adapter.notifyDataSetChanged();
        }else{
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if(v.getId() == R.id.top_refresh_btn){
            getDataFromNet();
        }
    }

    @Override
    public LinearLayout getCourseLayout() {
        return courseLayout;
    }

    @Override
    public LinearLayout getCourseErrorLayout() {
        return courseErrorLayout;
    }

    @Override
    public void resetData() {
        mData.clear();
    }

    @Override
    public void hideFoot() {
        listView.hideFoot();
    }

    @Override
    public void showFoot() {
        listView.showFoot();

    }

    public void getDataFromNet(){
        page = 1;
        presenter.setPage(page);
        presenter.setCheckNet(true);
        showWaitingDialog();
        presenter.getDataFromNet();
    }
}
