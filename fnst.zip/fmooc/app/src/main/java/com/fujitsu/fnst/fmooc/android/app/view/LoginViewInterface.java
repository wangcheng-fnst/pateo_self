package com.fujitsu.fnst.fmooc.android.app.view;

import android.text.TextWatcher;

/**
 * Created by wangc.fnst on 2015/12/10.
 */
public interface LoginViewInterface extends BaseViewInterface {
    void enableBtn();
    void disableBtn();
    void setNameListener(TextWatcher watcher);
    void setPasswordListener(TextWatcher watcher);
    void setValue(String name,String pwd);
    String getName();
    String getPwd();

}
