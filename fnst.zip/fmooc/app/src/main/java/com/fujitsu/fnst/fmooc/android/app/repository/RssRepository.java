package com.fujitsu.fnst.fmooc.android.app.repository;

import android.database.Cursor;
import android.util.Log;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.data.DataBaseManager;
import com.fujitsu.fnst.fmooc.android.app.data.dao.RssItemModelDao;
import com.fujitsu.fnst.fmooc.android.app.data.model.RssItemModel;
import com.fujitsu.fnst.fmooc.android.app.rss.RssFeed;
import com.fujitsu.fnst.fmooc.android.app.rss.RssItem;
import com.fujitsu.fnst.fmooc.android.app.rss.RssReader;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import java.net.URL;
import java.util.*;

/**
 * Created by wangc.fnst on 2016/1/19.
 */
public class RssRepository {
    public static final String RSS_URL = "http://133.162.203.136/kanazawa_university/index.php?action=whatsnew_view_main_rss&page_id=36&block_id=64&display_number=5&_header=0";
    public static final int PAGE_COUNT = 10;

    private RssItemModelDao dao = DataBaseManager.getInstance().getDaoSession().getRssItemModelDao();
    private static RssRepository instance;
    private GetFromNetFinishListener listener;

    public interface GetFromNetFinishListener{
        void finish();
    }

    public GetFromNetFinishListener getListener() {
        return listener;
    }

    public void setListener(GetFromNetFinishListener listener) {
        this.listener = listener;
    }

    public static RssRepository getInstance() {
        if (instance == null) {
            instance = new RssRepository();
        }
        return instance;
    }

    public Observable<List<RssItem>> getNetWork() {
        Observable<List<RssItem>> observable = Observable.create(new rx.Observable.OnSubscribe<List<RssItem>>() {
            @Override
            public void call(Subscriber<? super List<RssItem>> subscriber) {
                try {
                    URL url = new URL(RSS_URL);
                    RssFeed feed = RssReader.read(url);
                    ArrayList<RssItem> rssItems = feed.getRssItems();
                    subscriber.onNext(rssItems);
                    subscriber.onCompleted();
                } catch (Exception e) {
                    e.printStackTrace();
                    subscriber.onError(e);
                }
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
        return observable;
    }

    public void getRss() {
        getNetWork().map(new Func1<List<RssItem>, List<RssItemModel>>() {
            @Override
            public List<RssItemModel> call(List<RssItem> rssItems) {
                List<RssItemModel> items = new ArrayList<RssItemModel>();
                for (RssItem item : rssItems) {
                    RssItemModel model = RssItemModel.convertFromRssItem(item);
                    items.add(model);
                }
                return items;
            }
        }).subscribe(getMessageSubscriberFromNet());
    }

    private Subscriber<List<RssItemModel>> getMessageSubscriberFromNet() {
        return new Subscriber<List<RssItemModel>>() {
            @Override
            public void onCompleted() {
                FmoocApplication.setIsRssOK(true);
            }

            @Override
            public void onError(Throwable e) {
                e.printStackTrace();

                FmoocApplication.setIsRssOK(true);
            }

            @Override
            public void onNext(List<RssItemModel> messages) {
                Collections.sort(messages, new Comparator<RssItemModel>() {
                    @Override
                    public int compare(RssItemModel lhs, RssItemModel rhs) {
                        return lhs.getPubDate().getTime() - rhs.getPubDate().getTime() < 0 ? 1 : -1;
                    }
                });
                String sql = "SELECT MAX(PUB_DATE) FROM " + dao.getTablename();
                Cursor c = dao.getDatabase().rawQuery(sql, null);
                RssItemModel oldModel = null;
                if (c.getCount() > 0) {
                    if (c.moveToFirst()) {
                        Long id = c.getLong(0);
                        if (id > -1) {
                            List<RssItemModel> list = dao.queryBuilder().where(RssItemModelDao.Properties.PubDate.eq(id)).list();
                            if (list != null && list.size() > 0) {
                                oldModel = list.get(0);
                            }
                        }

                    }
                }
                c.close();
                for (int i = 0; i < messages.size() - 1; i++) {
                    RssItemModel model = messages.get(i);
                    if (oldModel != null && !model.renew(oldModel)) {
                        continue;
                    }
                    model.setStatus(0);
                    dao.insert(model);
                    FmoocApplication.setHasNewRss(true);
                }
                if (FmoocApplication.isHasNewRss()){
                    if (listener != null){
                        listener.finish();
                    }
                }
            }
        };
    }

    public void update(RssItemModel model){
        dao.update(model);
    }
    public boolean hasNew(){
        List<RssItemModel> list = dao.queryBuilder().where(RssItemModelDao.Properties.Status.eq(RssItemModel.STATUS_UNREAD))
                .list();
        if (list.size() > 0){
            return true;
        }else {
            return false;
        }
    }

    public void getFromDB(final int page, Subscriber<List<RssItemModel>> subscriber) {
        Log.e("getFromDB","getFromDB");
        Observable.create(new Observable.OnSubscribe<List<RssItemModel>>() {
                              @Override
                              public void call(Subscriber<? super List<RssItemModel>> subscriber) {
                                  try {
                                      List<RssItemModel> list = dao.queryBuilder().offset(page * PAGE_COUNT).limit(PAGE_COUNT).list();
                                      if (list != null && list.size() > 0) {
                                          subscriber.onNext(list);
                                          subscriber.onCompleted();
                                      }else {
                                          subscriber.onCompleted();
                                      }
                                  } catch (Exception e) {
                                      e.printStackTrace();
                                      subscriber.onError(e);
                                  }

                              }
                          }

        ).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);


    }
}
