package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.app.Activity;
import android.content.Intent;

import com.fujitsu.fnst.fmooc.android.app.data.model.UserModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Image;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ProfileSettingViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.*;
import rx.Subscriber;

/**
 * Created by lijl.fnst on 2015/12/21.
 */
public class ProfileSettingPresenter extends BasePresenter {
    private ProfileSettingViewInterface view;
    private UserInfoModel userModel;

    public ProfileSettingPresenter(ProfileSettingViewInterface viewInterface) {
        super();
        view = viewInterface;
    }

    public ProfileSettingPresenter(ProfileSettingViewInterface view, UserInfoModel userModel) {
        this.view = view;
        this.userModel = userModel;
    }
    public void setRealname(String realname){
        userModel.getUser().setRealName(realname);
    }
    public void setBirthday(Integer birthday){
        userModel.getUser().setBirthYear(birthday);
    }
    public void setEducate(String educate){
        userModel.getUser().setLastDegree(educate);
    }
    public void setSex(String sex){
        userModel.getUser().setGender(sex);
    }

    public void imageClick() {
        Intent intent = new Intent(context, ChangeHeadActivity.class);
        intent.putExtra(Constants.PROFILE_SETTING_TYPE, Constants.PROFILE_SETTING_IMAGE);
        if (userModel == null) {
            userModel = new UserInfoModel();
        }
        intent.putExtra(Constants.EXTRA_USER, userModel);
        ((ProfileSettingActivity) view).startActivityForResult(intent, 1000);
//        UserRepository.getInstance().getImagesFromNet(new Subscriber<Image>() {
//            @Override
//            public void onCompleted() {
//                view.hideWaitingDialog();
//            }
//
//            @Override
//            public void onError(Throwable e) {
//                e.printStackTrace();
//                view.hideWaitingDialog();
//            }
//
//            @Override
//            public void onNext(Image image) {
//                Intent intent = new Intent(context, ChangeHeadActivity.class);
//                intent.putExtra(Constants.PROFILE_SETTING_TYPE, Constants.PROFILE_SETTING_IMAGE);
//                if (userModel == null) {
//                    userModel = new UserInfoModel();
//                    //userModel.setHeadId(3);
//                }
//                intent.putExtra(Constants.EXTRA_USER, userModel);
//                intent.putExtra(Constants.EXTRA_IMAGES, image);
//
//                ((ProfileSettingActivity) view).startActivityForResult(intent, 1000);
//            }
//        });

    }


    public void firstnameClick() {
        Intent intent = new Intent(context, ProfileSelectActivity.class);
        intent.putExtra(Constants.PROFILE_SETTING_TYPE, Constants.PROFILE_SETTING_FIRSTNAME);
        if (userModel.getUser().getRealName() != null){
            intent.putExtra("defaultData",userModel.getUser().getRealName());
        }
        ((ProfileSettingActivity) view).startActivityForResult(intent, 1000);
    }


    public void sexClick() {
        Intent intent = new Intent(context, ProfileSelectActivity.class);
        intent.putExtra(Constants.PROFILE_SETTING_TYPE, Constants.PROFILE_SETTING_SEX);
        if (userModel.getUser().getGender() != null){
            intent.putExtra("defaultData",userModel.getUser().getGender());
        }
        ((ProfileSettingActivity) view).startActivityForResult(intent, 1000);
    }

    public void birthdayClick() {
        Intent intent = new Intent(context, ProfileSelectActivity.class);
        intent.putExtra(Constants.PROFILE_SETTING_TYPE, Constants.PROFILE_SETTING_BIRTHDAY);
        if (userModel.getUser().getBirthYear() != null){
            intent.putExtra("defaultData",userModel.getUser().getBirthYear().toString());
        }
        ((ProfileSettingActivity) view).startActivityForResult(intent, 1000);
    }

    public void educationClick() {
        Intent intent = new Intent(context, ProfileSelectActivity.class);
        intent.putExtra(Constants.PROFILE_SETTING_TYPE, Constants.PROFILE_SETTING_EDUCATION);
        if (userModel.getUser().getLastDegree() != null){
            intent.putExtra("defaultData",userModel.getUser().getLastDegree());
        }
        ((ProfileSettingActivity) view).startActivityForResult(intent, 1000);
    }
}
