package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.AgreementPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.RegisterInfoPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.AgreementViewInterface;

import butterknife.Bind;

public class AgreementActivity extends BaseActivity<AgreementPresenter> implements AgreementViewInterface {
    @Bind(R.id.agreement_webview)
    WebView webview;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new AgreementPresenter(this);
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        contentText.setText(title);
        String url = intent.getStringExtra("url");
        webview.loadUrl(url);
        webview.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // TODO Auto-generated method stub
                view.loadUrl(url);
                return true;
            }
        });
    }
    @Override
    protected int getLayout() {
        return R.layout.activity_agreement;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.register_title);
    }
}
