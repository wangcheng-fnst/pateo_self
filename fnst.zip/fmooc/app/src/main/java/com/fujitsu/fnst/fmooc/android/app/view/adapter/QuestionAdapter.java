package com.fujitsu.fnst.fmooc.android.app.view.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.util.SparseBooleanArray;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportEvaluationActivity;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportEvaluationActivityChoice;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.component.ExpandableTextView;
import com.fujitsu.fnst.fmooc.android.app.view.component.NoScrollListview;

import java.util.List;

/**
 * Created by zhaod.fnst on 2016/2/1.
 */
public class QuestionAdapter extends BaseListViewAdapter<ReportEvaluationActivity> {

    private Context context;
    private View.OnClickListener onClickListener;
    private boolean readOnly = false;
    private List<Integer> passChoices;
    private final SparseBooleanArray mCollapsedStatus = new SparseBooleanArray();
    public QuestionAdapter(List<ReportEvaluationActivity> mData,List<Integer> passChoices, Context context) {
        super(mData);
        this.passChoices = passChoices;
        this.context = context;
    }

    private RadioGroup.OnCheckedChangeListener onCheckedChangeListener;

    public View.OnClickListener getOnClickListener() {
        return onClickListener;
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public void setReadOnly(boolean readOnly){
        this.readOnly = readOnly;
    }

    @Override
    protected BaseViewHolder getViewHolder(View contentView) {
        return new ViewHolder(contentView);
    }

    @Override
    protected int getItemLayout() {
        return R.layout.question_item_layout;
    }

    @Override
    protected void setItemData(BaseViewHolder viewHolder, int position) {
        final ReportEvaluationActivity model = (ReportEvaluationActivity)getItem(position);
        final ViewHolder holder = (ViewHolder) viewHolder;
        holder.title.setText(context.getResources().getString(R.string.question_num)+String.valueOf(position+1));
        holder.label.setText(model.getLabel());

        List<ReportEvaluationActivityChoice> choices = model.getChoices();
        holder.radioGroup.removeAllViews();
        for(int i=0; i<choices.size(); i++)
        {
            RadioButton tempButton = new RadioButton(context);
            tempButton.setButtonDrawable(R.drawable.radio_button);
            tempButton.setPadding(10, 10, 10, 0);
            tempButton.setText(choices.get(i).getLabel());

            tempButton.setTextSize(16);
            tempButton.setTag(R.id.score, choices.get(i).getScore());
            tempButton.setTag(R.id.position, position);
            tempButton.setTag(R.id.radio_position, i);
            tempButton.setGravity(Gravity.TOP);
            tempButton.setOnClickListener(onClickListener);
            if(passChoices != null){
                if(i == passChoices.get(position))
                    tempButton.setChecked(true);
                else
                    tempButton.setClickable(false);
            }
            holder.radioGroup.addView(tempButton, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        }
        if(passChoices == null){
//            holder.radioGroup.setOnCheckedChangeListener(onCheckedChangeListener);
//            holder.radioGroup.setOnClickListener(onClickListener);
            ((RadioButton)holder.radioGroup.getChildAt(0)).setChecked(true);
        }
    }

    public RadioGroup.OnCheckedChangeListener getOnCheckedChangeListener() {
        return onCheckedChangeListener;
    }

    public void setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener onCheckedChangeListener) {
        this.onCheckedChangeListener = onCheckedChangeListener;
    }


    class ViewHolder implements BaseViewHolder{
        @Bind(R.id.id_question_title)
        TextView title;
        @Bind(R.id.id_question_label)
        TextView label;

        @Bind(R.id.radio_group)
        RadioGroup radioGroup;

        public ViewHolder(View view) {
            ButterKnife.bind(this,view);
        }
    }


}
