package com.fujitsu.fnst.fmooc.android.app.view.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.HeadModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.ListHeadModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.CourseClip;
import com.fujitsu.fnst.fmooc.android.app.utils.TimeUtils;
import com.fujitsu.fnst.fmooc.android.app.view.component.stickylistheaders.StickyListHeadersAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangc.fnst on 2016/1/6.
 */
public class ExpandableAdapter extends BaseListViewAdapter<CourseModel> implements StickyListHeadersAdapter,SectionIndexer {
    public interface ButtonClickListener{
        void clickButton();
    }

    private List<CourseModel> mData;
    private List<ListHeadModel> mHeaders;
    private Context context;

    private int[] mSectionIndices;
    private ListHeadModel[] mSectionLetters;
    private Map<Long,HeaderViewHolder> mHeaderIdToHeaderHolder = new HashMap<Long,HeaderViewHolder>();
    private Map<Integer,ViewHolder> mPositionToItemHolder = new HashMap<Integer,ViewHolder>();
    private ButtonClickListener listener;

    public ButtonClickListener getListener() {
        return listener;
    }

    public void setListener(ButtonClickListener listener) {
        this.listener = listener;
    }

    public ExpandableAdapter(List<CourseModel> mData, Context context) {
        super(mData);
        this.mData = mData;
        if (getCount() > 0) {
            mSectionIndices = getmSectionIndices();
        }
        this.context = context;
    }

    public List<ListHeadModel> getmHeaders() {
        return mHeaders;
    }

    public void setmHeaders(List<ListHeadModel> mHeaders) {
        this.mHeaders = mHeaders;
        if (mSectionIndices != null) {
            mSectionLetters = getSectionLetters();
        }
    }

    public Map<Integer, ViewHolder> getmPositionToItemHolder() {
        return mPositionToItemHolder;
    }

    public void setmPositionToItemHolder(Map<Integer, ViewHolder> mPositionToItemHolder) {
        this.mPositionToItemHolder = mPositionToItemHolder;
    }

    public Map<Long, HeaderViewHolder> getmHeaderIdToHeaderHolder() {
        return mHeaderIdToHeaderHolder;
    }

    public void setmHeaderIdToHeaderHolder(Map<Long, HeaderViewHolder> mHeaderIdToHeaderHolder) {
        this.mHeaderIdToHeaderHolder = mHeaderIdToHeaderHolder;
    }

    private int[] getmSectionIndices(){
        ArrayList<Integer> sectionIndices = new ArrayList<Integer>();
        long lastPId = mData.get(0).getpId();
        sectionIndices.add(0);
        for (int i = 1; i < mData.size();i++){
            if (mData.get(i).getpId() != lastPId){
                lastPId = mData.get(i).getpId();
                sectionIndices.add(i);

            }

        }
        int[] sections = new int[sectionIndices.size()];
        for (int i = 0; i < sectionIndices.size(); i++) {
            sections[i] = sectionIndices.get(i);
        }
        return sections;
    }
    private ListHeadModel[] getSectionLetters() {
        ListHeadModel[] letters = new ListHeadModel[mSectionIndices.length];
        for (int i = 0; i < mSectionIndices.length; i++) {
            letters[i] = mHeaders.get(i);
        }
        return letters;
    }

    @Override
    protected BaseViewHolder getViewHolder(View contentView) {
        return new ViewHolder(contentView);
    }

    @Override
    protected int getItemLayout() {
        return R.layout.play_item_layout;
    }

    @Override
    protected void setItemData(BaseViewHolder viewHolder, int position) {
        ViewHolder holder = (ViewHolder) viewHolder;
        CourseModel model = (CourseModel) getItem(position);
        if (model.getContentType().equals(CourseClip.TYPE_COURSECLIP) && model.getState().equals(CourseClip.STATE_VIEWING)){
            holder.playImg.setVisibility(View.VISIBLE);
        }else {
            Log.e("setItemData","position:"+position+" state:"+model.getState());
            holder.playImg.setVisibility(View.INVISIBLE);
        }
        holder.subTitleTxt.setText(model.getName());
        if (model.getContentType().equals("Report")) {
            holder.btn.setVisibility(View.GONE);
            holder.layout.setVisibility(View.VISIBLE);
            holder.timeTxt.setVisibility(View.GONE);
            holder.courseLine.setVisibility(View.GONE);
            holder.reportLine.setVisibility(View.VISIBLE);
            holder.subTitleTxt.setText(model.getReportTitle());
        }else if (model.getContentType().equals("CourseClip")){
            holder.btn.setVisibility(View.GONE);
            holder.layout.setVisibility(View.VISIBLE);
            holder.courseLine.setVisibility(View.VISIBLE);
            holder.reportLine.setVisibility(View.GONE);
            holder.timeTxt.setText(TimeUtils.getMinute(model.getLengthInSeconds()));
            holder.timeTxt.setVisibility(View.VISIBLE);
        }else if (model.getContentType().equals(CourseClip.TYPE_REMOVE)){
            holder.courseLine.setVisibility(View.GONE);
            holder.reportLine.setVisibility(View.GONE);
            holder.btn.setVisibility(View.GONE);
            holder.layout.setVisibility(View.GONE);
        }

        if (model.getState().equals(CourseClip.STATE_VIEWED)){
            holder.subTitleTxt.getPaint().setFakeBoldText(false);
            holder.subTitleTxt.setTextColor(context.getResources().getColor(R.color.font_dark_gray));
        }else if (model.getState().equals(CourseClip.STATE_VIEWING)){
            holder.subTitleTxt.setTextColor(context.getResources().getColor(R.color.black));
            holder.subTitleTxt.getPaint().setFakeBoldText(true);
        } else {
            holder.subTitleTxt.getPaint().setFakeBoldText(false);
            holder.subTitleTxt.setTextColor(context.getResources().getColor(R.color.black));
        }

        if (mPositionToItemHolder.get(Integer.valueOf(position)) == null){
            mPositionToItemHolder.put(position,holder);
        }


    }
    public void clearPlayImg(){
        for(Integer index:mPositionToItemHolder.keySet()){
            mPositionToItemHolder.get(index).playImg.setVisibility(View.INVISIBLE);
        }
    }



    @Override
    public View getHeaderView(int position, View convertView, ViewGroup parent) {

        HeaderViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.play_header_layout, parent, false);
            holder = new HeaderViewHolder(convertView);
        } else {
            holder = (HeaderViewHolder) convertView.getTag();
        }
        ListHeadModel model = getHeadItem(position);
        mHeaderIdToHeaderHolder.put(model.getId(), holder);
        if (("btn").equals(model.getType())){
            holder.btn.setVisibility(View.VISIBLE);
            holder.layout.setVisibility(View.GONE);
            holder.btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.clickButton();
                    }
                }
            });
        }else {
            holder.btn.setVisibility(View.GONE);
            holder.layout.setVisibility(View.VISIBLE);
            if (model != null) {
                holder.downImg.setVisibility(View.VISIBLE);
                holder.downImg.setImageResource(model.getIcon());
                holder.downImg.setTag(R.id.position, position);
                holder.downImg.setTag(R.id.headId, getHeaderId(position));
                holder.downImg.setOnClickListener((View.OnClickListener) context);
                holder.orderTxt.setVisibility(View.VISIBLE);
                holder.orderTxt.setText("第" + (model.getId() + 1) + "回:" + model.getName());
                holder.subTitleTxt.setText(model.getDescription());
            }
        }
        convertView.setTag(holder);
        return convertView;
    }

    @Override
    public long getHeaderId(int position) {
        return mData.get(position).getpId();
    }

    public ListHeadModel getHeadItem(int position) {
        for (ListHeadModel model : mHeaders) {
            if (model.getId() == getHeaderId(position)) {
                return model;
            }
        }
        return null;
    }

    @Override
    public Object[] getSections() {
        return mSectionLetters;
    }

    @Override
    public int getPositionForSection(int section) {
        if (mSectionIndices.length == 0) {
            return 0;
        }

        if (section >= mSectionIndices.length) {
            section = mSectionIndices.length - 1;
        } else if (section < 0) {
            section = 0;
        }
        return mSectionIndices[section];
    }

    @Override
    public int getSectionForPosition(int position) {
        for (int i = 0; i < mSectionIndices.length; i++) {
            if (position < mSectionIndices[i]) {
                return i - 1;
            }
        }
        return mSectionIndices.length - 1;
    }

    public class ViewHolder implements BaseViewHolder {
        @Bind(R.id.id_play_img)
        public ImageView playImg;
        @Bind(R.id.id_sub_title_txt)
        public TextView subTitleTxt;
        @Bind(R.id.id_time_txt)
        public TextView timeTxt;
        @Bind(R.id.id_course_line)
        View courseLine;
        @Bind(R.id.id_report_line)
        View reportLine;
        @Bind(R.id.id_item_layout)
        LinearLayout layout;
        @Bind(R.id.id_remove_btn)
        Button btn;

        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
    public class HeaderViewHolder implements BaseViewHolder {
        @Bind(R.id.id_play_img)
        public ImageView playImg;
        @Bind(R.id.id_order_txt)
        public TextView orderTxt;
        @Bind(R.id.id_sub_title_txt)
        public TextView subTitleTxt;
        @Bind(R.id.id_down_img)
        public ImageView downImg;
        @Bind(R.id.id_remove_btn)
        Button btn;
        @Bind(R.id.id_header_layout)
        LinearLayout layout;

        public HeaderViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
