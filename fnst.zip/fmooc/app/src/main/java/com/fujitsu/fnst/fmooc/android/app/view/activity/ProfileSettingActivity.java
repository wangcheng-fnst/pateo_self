package com.fujitsu.fnst.fmooc.android.app.view.activity;


import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.HeadModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.UserModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.ProfileImage;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.presenter.ProfileSettingPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ProfileSettingViewInterface;

import butterknife.Bind;
import butterknife.ButterKnife;
import com.nostra13.universalimageloader.core.ImageLoader;

public class ProfileSettingActivity extends BaseActivity<ProfileSettingPresenter> implements ProfileSettingViewInterface {

    @Bind(R.id.profile_image_layout)
    RelativeLayout imageLayout;
    @Bind(R.id.profile_firstname_layout)
    RelativeLayout firstnameLayout;
    @Bind(R.id.profile_sex_layout)
    RelativeLayout sexLayout;
    @Bind(R.id.profile_birthday_layout)
    RelativeLayout birthdayLayout;
    @Bind(R.id.profile_education_layout)
    RelativeLayout educationLayout;

    @Bind(R.id.profile_setting_firstname)
    TextView firstnameText;
    @Bind(R.id.profile_setting_sex)
    TextView sexText;
    @Bind(R.id.profile_setting_education)
    TextView educationText;
    @Bind(R.id.profile_setting_year)
    TextView yearText;
    @Bind(R.id.id_head_img)
    ImageView headImg;

    private UserInfoModel userModel;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        Intent intent = getIntent();
//        userModel = (UserInfoModel) intent.getSerializableExtra(Constants.EXTRA_USER);
        userModel = ApplicationUtils.userInfoModel;
        if (userModel == null){
            userModel = new UserInfoModel();
            //userModel.setHeadId(3);
        }
        presenter = new ProfileSettingPresenter(this,userModel);
        imageLayout.setOnClickListener(this);
        firstnameLayout.setOnClickListener(this);
        sexLayout.setOnClickListener(this);
        birthdayLayout.setOnClickListener(this);
        educationLayout.setOnClickListener(this);
        setUserInfo();

    }

    private void setUserInfo(){
        if (userModel.getUser().getRealName() != null){
            firstnameText.setText(userModel.getUser().getRealName());
        }
        if (userModel.getUser().getGender() != null){

            if (userModel.getUser().getGender().equals(Constants.MALE)){
                sexText.setText(getString(R.string.profile_male));
            } else if (userModel.getUser().getGender().equals(Constants.FEMALE)){
                sexText.setText(getString(R.string.profile_female));
            } else if (userModel.getUser().getGender().equals(Constants.OTHER)){
                sexText.setText(getString(R.string.profile_other));
            }
        }
        if (userModel.getUser().getBirthYear() != null){
            yearText.setText(userModel.getUser().getBirthYear().toString());
        }
        if (userModel.getUser().getLastDegree() != null){
            educationText.setText(userModel.getUser().getLastDegree());
        }
        if (userModel.getUser().getProfileImage() != null){
            headImg.setImageResource(Constants.getImageResId_71(userModel.getUser().getProfileImage().getImageId()));
//            ImageLoader.getInstance().displayImage(userModel.getUser().getProfileImage().getUrl(),headImg);
        }

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_profile_setting;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.profile_title);
    }


    @Override
    public void onClick(View v){
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (R.id.profile_image_layout == v.getId()){
            presenter.imageClick();
        }  else if (R.id.profile_firstname_layout == v.getId()){
            presenter.firstnameClick();
        } else if (R.id.profile_sex_layout == v.getId()){
            presenter.sexClick();
        } else if (R.id.profile_birthday_layout == v.getId()){
            presenter.birthdayClick();
        } else if (R.id.profile_education_layout == v.getId()){
            presenter.educationClick();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data != null) {
            switch (resultCode) {
                case Constants.PROFILE_SETTING_IMAGE:
                    ProfileImage model = (ProfileImage) data.getSerializableExtra(Constants.EXTRA_RESULT);
                    userModel.getUser().getProfileImage().setImageId(model.getImageId());
                    headImg.setImageResource(Constants.getImageResId_71(model.getImageId()));
//                    ImageLoader.getInstance().displayImage(model.getUrl(),headImg);
                    break;
                case Constants.PROFILE_SETTING_FIRSTNAME:
                    presenter.setRealname(data.getExtras().getString("result"));
                    firstnameText.setText(data.getExtras().getString("result"));
                    break;
                case Constants.PROFILE_SETTING_SEX:
                    if (data.getExtras().getString("result") != null){
                        if (data.getExtras().getString("result").equals(getResources().getStringArray(R.array.sex)[0])){
                            presenter.setSex(Constants.MALE);
                        } else if (data.getExtras().getString("result").equals(getResources().getStringArray(R.array.sex)[1])){
                            presenter.setSex(Constants.FEMALE);
                        } else if (data.getExtras().getString("result").equals(getResources().getStringArray(R.array.sex)[2])){
                            presenter.setSex(Constants.OTHER);
                        }
                    }


                    sexText.setText(data.getExtras().getString("result"));
                    break;
                case Constants.PROFILE_SETTING_BIRTHDAY:
                    presenter.setBirthday(Integer.parseInt(data.getExtras().getString("result")));
                    yearText.setText(data.getExtras().getString("result"));
                    break;
                case Constants.PROFILE_SETTING_EDUCATION:
                    presenter.setEducate(data.getExtras().getString("result"));
                    educationText.setText(data.getExtras().getString("result"));
                    break;

            }
        }
    }
}
