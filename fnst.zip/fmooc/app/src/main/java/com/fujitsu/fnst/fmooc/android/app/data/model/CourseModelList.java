package com.fujitsu.fnst.fmooc.android.app.data.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by zhaod.fnst on 2016/01/15.
 */
public class CourseModelList implements Serializable{
    private List<CourseModel> modelList ;

    public CourseModelList() {
    }

    public List<CourseModel> getModelList() {
        return modelList;
    }

    public void setModelList(List<CourseModel> modelList) {
        this.modelList = modelList;
    }
}
