package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.BasePresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.view.BaseViewInterface;
import com.google.android.youtube.player.YouTubeBaseActivity;

/**
 * Created by wangc.fnst on 2015/12/7.
 */
public abstract class PlayBaseActivity<T extends BasePresenter> extends YouTubeBaseActivity implements View.OnClickListener,BaseViewInterface {

    protected T presenter;
    @Bind(R.id.id_title_back_btn)
    Button backImg;
    @Bind(R.id.id_title_more_img)
    ImageView moreImg;
    @Bind(R.id.id_title_content_txt)
    TextView contentText;
    @Bind(R.id.id_title_left_layout)
    LinearLayout leftLayout;
    @Bind(R.id.id_title_right_layout)
    LinearLayout rightLayout;

    @Bind(R.id.id_title_bar)
    LinearLayout titleBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayout());
        ButterKnife.bind(this);
        onCreateView();

    }

    protected abstract int getLayout();

    protected void onCreateView(){
        backImg.setOnClickListener(this);
        moreImg.setOnClickListener(this);
        if (showBackImg()){
            backImg.setVisibility(View.VISIBLE);
        }else {
            backImg.setVisibility(View.INVISIBLE);
        }
        if (showMoreImg()){
            moreImg.setVisibility(View.VISIBLE);
        }else{
            moreImg.setVisibility(View.INVISIBLE);
        }
        contentText.setText(getTitleContent());
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        if (v.getId() == R.id.id_title_back_btn){
            onBackPressed();
        }

    }
    public abstract boolean showBackImg();
    public abstract boolean showMoreImg();
    public abstract String getTitleContent();

    protected void dismissTitle(){
        titleBar.setVisibility(View.GONE);
    }
    protected void showTitle(){
        titleBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }
}
