package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.AppAboutPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.ChangePasswdSuccessPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.view.ChangePasswdSuccessViewInterface;

import butterknife.Bind;

public class ChangePasswdSuccessActivity extends BaseActivity<ChangePasswdSuccessPresenter> implements ChangePasswdSuccessViewInterface {

    @Bind(R.id.id_change_success_btn)
    Button changeSuccessBtn;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new ChangePasswdSuccessPresenter(this);
        changeSuccessBtn.setOnClickListener(this);
        ShareReferencesManager.getInstance(this).setValue(Constants.SP_CHANGE_STATUS,Constants.SP_CHANGE_STATUS_SUCCESS);

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_change_passwd_success;
    }

    @Override
    public boolean showBackImg() {
        return false;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.change_title);
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_change_success_btn){
            presenter.toLogin();
        }

    }

}
