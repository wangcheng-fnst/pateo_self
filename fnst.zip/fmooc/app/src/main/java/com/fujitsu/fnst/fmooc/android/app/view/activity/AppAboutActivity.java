package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.AppAboutPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.LoginPresenter;
import com.fujitsu.fnst.fmooc.android.app.view.AppAboutViewInterface;

public class AppAboutActivity extends BaseActivity<AppAboutPresenter> implements AppAboutViewInterface {

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new AppAboutPresenter(this);

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_app_about;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.help_app_about);
    }

}
