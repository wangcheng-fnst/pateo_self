package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/20.
 */
public class Image implements Serializable {
    private List<ProfileImage> images ;

    public Image() {
    }

    public List<ProfileImage> getImages() {
        return images;
    }

    public void setImages(List<ProfileImage> images) {
        this.images = images;
    }
}
