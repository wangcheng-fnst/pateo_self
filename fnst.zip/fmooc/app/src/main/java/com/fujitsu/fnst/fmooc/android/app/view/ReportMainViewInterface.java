package com.fujitsu.fnst.fmooc.android.app.view;

import com.fujitsu.fnst.fmooc.android.app.network.model.Report;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportDetailModel;
import com.fujitsu.fnst.fmooc.android.app.view.BaseViewInterface;

/**
 * Created by zhaod.fnst on 2016/01/12.
 */
public interface ReportMainViewInterface extends BaseViewInterface{
    String getContentId();
    void setReportDetail(ReportDetailModel detail);
}
