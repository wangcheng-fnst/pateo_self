package com.fujitsu.fnst.fmooc.android.app.presenter;

import com.fujitsu.fnst.fmooc.android.app.data.model.NoticeModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.RssItemModel;
import com.fujitsu.fnst.fmooc.android.app.repository.RssRepository;
import com.fujitsu.fnst.fmooc.android.app.view.NoticeListViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;
import rx.Subscriber;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/12.
 */
public class NoticeListPresenter extends BasePresenter implements PullRefleashListView.OnRefleashListener {

    private NoticeListViewInterface view;
    int page = 0;
    int currentPage = 0;
    private List<RssItemModel> mData;
    private boolean isRefresh = true;

    public NoticeListPresenter(NoticeListViewInterface view,List<RssItemModel> mData) {
        super();
        this.view = view;
        this.mData = mData;
        view.showWaitingDialog();
        getDataFromDB(page);
    }

    private void getDataFromDB(int page){
        RssRepository.getInstance().getFromDB(page,getSubscriber());
    }
    private void getDataFromNet(){
        RssRepository.getInstance().getRss();
        getDataFromDB(page);

    }
    private Subscriber<List<RssItemModel>> getSubscriber(){
        return  new Subscriber<List<RssItemModel>>() {
            @Override
            public void onCompleted() {
                view.stopLoad();
                view.hideWaitingDialog();
            }
            @Override
            public void onError(Throwable e) {
                e.printStackTrace();
                view.stopLoad();
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(List<RssItemModel> rssItemModels) {
                if (mData == null){
                    mData = new ArrayList<RssItemModel>();
                }
                if (isRefresh){
                    mData.clear();
                }
                mData.addAll(mData.size()-1 < 0?0:mData.size()-1,rssItemModels);
                currentPage++;
                view.notifyData();
            }
        };
    }

    @Override
    public void onLoadMore() {
        isRefresh = false;
        getDataFromDB(currentPage);
    }

    @Override
    public void onRefresh() {
        isRefresh = true;
        page = 0;
        getDataFromNet();
    }
}
