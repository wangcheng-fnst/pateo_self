package com.fujitsu.fnst.fmooc.android.app.data.model;

import com.fujitsu.fnst.fmooc.android.app.network.model.Content;
import com.fujitsu.fnst.fmooc.android.app.network.model.PlayList;
import com.fujitsu.fnst.fmooc.android.app.network.model.User;

import java.io.Serializable;
import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/15.
 */
public class PlayListModel implements Serializable {
    private long id;
    private String playlistId;
    private String courseId;
    private String name;
    private String description;
    private User author;
    private List<Content> contents;

    private int pId;

    public static PlayListModel convertFromPlayList(PlayList playList){
        PlayListModel model = new PlayListModel();
        model.author = playList.getAuthor();
        model.contents = playList.getContents();
        model.courseId = playList.getCourseId();
        model.description = playList.getDescription();
        model.name = playList.getName();
        model.playlistId = playList.getPlaylistId();
        return model;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPlaylistId() {
        return playlistId;
    }

    public void setPlaylistId(String playlistId) {
        this.playlistId = playlistId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public List<Content> getContents() {
        return contents;
    }

    public void setContents(List<Content> contents) {
        this.contents = contents;
    }

    public int getpId() {
        return pId;
    }

    public void setpId(int pId) {
        this.pId = pId;
    }
}
