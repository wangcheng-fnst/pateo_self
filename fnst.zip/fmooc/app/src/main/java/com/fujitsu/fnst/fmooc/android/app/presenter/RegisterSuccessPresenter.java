package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import android.widget.Toast;

import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.view.RegisterSuccessViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.LoginActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.RegisterSuccessViewActivity;

/**
 * Created by lijl.fnst on 2015/12/14.
 */
public class RegisterSuccessPresenter extends BasePresenter {
    private RegisterSuccessViewInterface view;

    public RegisterSuccessPresenter(RegisterSuccessViewInterface viewInterface){
        super();
        view = viewInterface;
    }
    public void login(){
        //Toast.makeText(context, "to login btn click", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(context, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
        ((RegisterSuccessViewActivity)view).finish();
    }
    public void setStatus(){
        ShareReferencesManager.getInstance(context).setValue(Constants.SP_REGISTER_STATUS,"success");
    }
}
