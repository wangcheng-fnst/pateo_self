package com.fujitsu.fnst.fmooc.android.app.repository;

import android.util.Log;
import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.NetCallback;
import com.fujitsu.fnst.fmooc.android.app.network.model.EmptyModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Report;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportDetailModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.SubmittedReport;
import com.fujitsu.fnst.fmooc.android.app.network.service.CourseService;
import com.fujitsu.fnst.fmooc.android.app.network.service.ReportService;
import retrofit.Call;
import retrofit.Response;
import retrofit.Response;
import rx.Subscriber;
import rx.Subscription;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by lijl.fnst on 2016/01/06.
 */
public class ReportRepository {
    private String TAG_LOG = ReportRepository.class.getName();

    public static final String ADD_REPORT_RESPONSE = "add_report_response";

    private Map<String,OnGetModelFinishImpl> listeners ;

    private static ReportRepository instance;

    public static ReportRepository getInstance(){
        if (instance == null){
            instance = new ReportRepository();
        }
        return instance;
    }

    public ReportRepository() {
        listeners = new HashMap<String,OnGetModelFinishImpl>();
    }


    public Subscription addReportAnswer(String contentId,Map<String, Object> data, Subscriber<SubmittedReport> subscriber){
        return ReportService.getService().insertUserReport(contentId,data,subscriber);
    }

    public Subscription getContentInformation(String id,boolean withSubmission, Subscriber<ReportDetailModel> subscriber){
        return ReportService.getService().getContentInformation(id, withSubmission, subscriber);
    }

    private OnGetModelFinishImpl getListener(String type){

        for (String key : listeners.keySet()){
            if (key.equals(type)){
                return listeners.get(key);
            }
        }
        OnGetModelFinishImpl listener = new OnGetModelFinishImpl() {
            @Override
            public void onSuccess(String type, Object result) {

            }

            @Override
            public void onFailed(String type, String message) {

            }
        };
        return listener;
    }
}
