package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;

import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.network.model.CourseDetailModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.EmptyModel;
import com.fujitsu.fnst.fmooc.android.app.repository.CourseRepository;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.CourseDetailNewViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.CourseDetailNewActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.CoursePlayActivity;
import com.google.android.youtube.player.YouTubePlayer;

import rx.Subscriber;
import rx.Subscription;

/**
 * Created by wangc.fnst on 2015/12/22.
 */
public class CourseDetailNewPresenter extends BasePresenter implements YouTubePlayer.OnFullscreenListener,YouTubePlayer.PlayerStateChangeListener,OnGetModelFinishImpl<CourseModel>{

    private CourseDetailNewViewInterface view;
    private boolean isFullscreen;
    private int smallHeight;
    private String requestType = CourseRepository.GET_COURSES_DETAIL_RESPONSE;
    private String btnInfo = Constants.COURSE_BEGIN;
    private Boolean data;
    private boolean checkNet=true;

    private Subscription subscription;
    private Subscriber<CourseDetailModel> subscriber;
    private Subscription enrollSubscription;
    private Subscriber<EmptyModel> enrollSubscriber;
    private Course course;
    private String courseId;

    public CourseDetailNewPresenter(CourseDetailNewViewInterface view,int smallHeight,String  courseId) {
        super();
        this.smallHeight = smallHeight;
        this.courseId = courseId;
        this.view = view;

    }

    public void setCheckNet(boolean checkNet){
        this.checkNet = checkNet;
    }
    public void init(){
        data = false;
        view.showWaitingDialog();
        subscription = CourseRepository.getInstance().getCourseInformation(courseId,data,getSubscriber());
    }

    private Subscriber<CourseDetailModel> getSubscriber(){
        return new Subscriber<CourseDetailModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
                if(checkNet) {
                    view.getCourseDetailLayout().setVisibility(View.GONE);
                    view.getCourseDetailErrorLayout().setVisibility(View.VISIBLE);
                }
//                }else{
//                    view.showToast("network wrong");
//
//                }
            }

            @Override
            public void onNext(CourseDetailModel courseNet) {
                course = courseNet.getCourse();
                view.setCourseInfo(course);
                view.getCourseDetailLayout().setVisibility(View.VISIBLE);
                view.getCourseDetailErrorLayout().setVisibility(View.GONE);
            }
        };
    }

    private Subscriber<EmptyModel> getEnrollSubscriber(){
        return new Subscriber<EmptyModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
//                Intent intent = new Intent(context, CoursePlayActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                context.startActivity(intent);
//                ((CourseDetailNewActivity)view).finish();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }

            @Override
            public void onNext(EmptyModel model) {
                Intent intent = new Intent(context,CoursePlayActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra(Constants.EXTRA_COURSE_ID, course.getCourseId());
                context.startActivity(intent);
//                view.finishActivity();

            }
        };
    }

    public void missBtn(){
        view.missBtn(btnInfo);
    }
    public void showBtn(){
        view.showBtn(btnInfo);
    }

    public void btnClick(){
//        if (enrollSubscriber == null){
//            getEnrollSubscriber();
//        }
        view.showWaitingDialog();
        enrollSubscription = CourseRepository.getInstance().enrollCourse(course.getCourseId(), getEnrollSubscriber());
    }

    public void setViewFullscreen(View targetView, int width, int height){
        ViewGroup.LayoutParams params = targetView.getLayoutParams();
        params.width = width;
        params.height = height;
        targetView.setLayoutParams(params);
    }

    public int getSmallHeight() {
        return smallHeight;
    }


    @Override
    public void onFullscreen(boolean isFullscreen) {
        this.isFullscreen = isFullscreen;
        view.setFullScreen(isFullscreen);
//        view.showToast("change screen");
    }

    @Override
    public void onLoading() {

    }

    @Override
    public void onLoaded(String s) {

    }

    @Override
    public void onAdStarted() {

    }

    @Override
    public void onVideoStarted() {

    }

    @Override
    public void onVideoEnded() {
//        view.showToast("video ended");

    }

    @Override
    public void onError(YouTubePlayer.ErrorReason errorReason) {

    }

    @Override
    public void onSuccess(String type, CourseModel result) {
        view.hideWaitingDialog();
        if (type.equals(CourseRepository.GET_COURSES_DETAIL_RESPONSE)){
//            Intent intent = new Intent(context, CoursePlayActivity.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            context.startActivity(intent);
        }

    }

    @Override
    public void onFailed(String type,String message) {
        view.hideWaitingDialog();
    }

    @Override
    public void onDestroy() {
        UserRepository.getInstance().unRegister(requestType);
        super.onDestroy();

    }
}
