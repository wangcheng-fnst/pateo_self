package com.fujitsu.fnst.fmooc.android.app.view;

/**
 * Created by lijl.fnst on 2015/12/16.
 */
public interface ActionSettingViewInterface extends BaseViewInterface{
    void setSwitchOn();
    void setSwitchOff();

}
