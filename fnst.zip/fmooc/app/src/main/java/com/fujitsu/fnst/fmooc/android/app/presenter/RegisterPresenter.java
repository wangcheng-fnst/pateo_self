package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.Toast;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.model.CodeEmail;
import com.fujitsu.fnst.fmooc.android.app.network.model.EmptyModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.LoginModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.RegisterViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.AgreementActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ChangePasswdSuccessActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ChangePwdActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.LoginActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.MainFragmentActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.RegisterActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.RegisterSuccessViewActivity;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;

import retrofit.Response;
import retrofit.Retrofit;
import rx.Subscriber;
import rx.Subscription;

/**
 * Created by lijl.fnst on 2015/12/11.
 */
public class RegisterPresenter extends BasePresenter implements EditChangeListener.TextChangeCallback,OnGetModelFinishImpl<LoginModel> {
    private RegisterViewInterface view;
    private boolean nameOk = false;
    private boolean passwordOk = false;
    private boolean isUserAgree = false;
    private boolean isShowPassword = false;
    private String emailStr, userName, password;
    private String requestType = UserRepository.REGISTER_RESPONSE;
    private Subscription subscription;
    private Subscriber<CodeEmail> subscriber;

    public RegisterPresenter(RegisterViewInterface viewInterface){
        super();
        view = viewInterface;
        init();
    }
    public void setStatus(){
        ShareReferencesManager.getInstance(context).setValue(Constants.SP_REGISTER_STATUS, "failed");
    }

    public void init(){
        UserRepository.getInstance().register(requestType,this);
        EditChangeListener nameListener = new EditChangeListener();
        nameListener.setCallback(this);
        EditChangeListener pwdListener = new EditChangeListener();
        pwdListener.setCallback(this);
        view.setNameListener(nameListener);
        view.setPasswordListener(pwdListener);

    }

    public void confirmCode(String code){
        view.showWaitingDialog();
        subscription = UserRepository.getInstance().confirmCode(getSubscriber(), code);
    }

    private Subscriber<CodeEmail> getSubscriber(){
        return subscriber = new Subscriber<CodeEmail>() {
            @Override
            public void onCompleted() {
                //view.showToast("onCompleted");
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                //view.showToast("onError  "+e.getMessage());
                view.hideWaitingDialog();
                ((RegisterActivity)view).finish();
            }

            @Override
            public void onNext(CodeEmail email) {
                view.setEmailText(email.getMessage());
                //sendSuccess();
                //view.showToast("userid:"+user.getUser().getBirthYear());
            }
        };
    }
    public void setUserAgree(boolean isUserAgree){
        this.isUserAgree = isUserAgree;
        if (isUserAgree){
            view.enableBtn();
        }
    }

    public void register(){
        if (!checkValue()){
            return;
        }
        view.showWaitingDialog();
        emailStr = view.getEmail();
        UserRepository.getInstance().newUser(userName, emailStr, password,requestType);
    }
    public void setPasswordEditStatus(){
        if(isShowPassword){
            isShowPassword = false;
            view.hidePassword();
        } else {
            isShowPassword = true;
            view.showPassword();
        }

    }

    public SpannableString getClickableSpan(final String textstr){
        SpannableString spanStr = new SpannableString(textstr);
        //spanStr.setSpan(new UnderlineSpan(), 16, 20, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanStr.setSpan(new NoLineClickSpan(textstr) {
            @Override
            public void onClick(View widget) {
                Intent intent = new Intent(((RegisterActivity)view), AgreementActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("title", textstr);
                if (textstr.equals(context.getResources().getString(R.string.register_agreement))){
                    intent.putExtra("url",Constants.AGREEMENT_URL);
                }else {
                    intent.putExtra("url",Constants.POLICY_URL);
                }
                ((RegisterActivity)view).startActivity(intent);
            }
        }, 0, textstr.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spanStr;
    }


    @Override
    public void formatRight() {

        userName = view.getUserName();
        password = view.getPwd();
        if (!StringUtils.isBlank(userName)
                && !StringUtils.isBlank(password) && isUserAgree){
            view.enableBtn();
        }else{
            view.disableBtn();
        }
    }

    private boolean checkValue(){
        if (!StringUtils.isUserId(userName)){
            view.showToast(context.getResources().getString(R.string.username_wrong));
            return false;
        }
        if(password.length() > 48){
            view.showToast(context.getResources().getString(R.string.password_long));
            return false;
        }
        if (!StringUtils.isValidPassword(password)) {
            view.showToast(context.getResources().getString(R.string.password_error));
            return false;
        }
//        if (!isUserAgree){
//            view.showToast("agreement not select!");
//            return false;
//        }
        return true;

    }

    @Override
    public void onSuccess(String type, LoginModel result) {
        view.hideWaitingDialog();
        if (type.equals(UserRepository.REGISTER_RESPONSE)){
            Intent intent = new Intent(context, RegisterSuccessViewActivity.class);
//        Intent intent = new Intent(context, CourseDetailActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            ((RegisterActivity)view).finish();
        }

    }

    @Override
    public void onFailed(String type,String message) {
        view.hideWaitingDialog();
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        UserRepository.getInstance().unRegister(requestType);
        super.onDestroy();

    }
    private class NoLineClickSpan extends ClickableSpan {
        String text;

        public NoLineClickSpan(String text) {
            super();
            this.text = text;
        }

        @Override
        public void updateDrawState(TextPaint ds) {
            ds.setColor(((RegisterActivity)view).getResources().getColor(R.color.link));
            ds.setUnderlineText(true);
        }

        @Override
        public void onClick(View widget) {

        }
    }
}
