package com.fujitsu.fnst.fmooc.android.app.network.service;


import com.fujitsu.fnst.fmooc.android.app.network.DownloadObserver;
import com.fujitsu.fnst.fmooc.android.app.network.ObserverConvert;

import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModelList;
import com.fujitsu.fnst.fmooc.android.app.network.ObserverConvert;

import com.fujitsu.fnst.fmooc.android.app.network.ServiceBuilder;

import com.fujitsu.fnst.fmooc.android.app.network.model.*;

import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;

import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.squareup.okhttp.ResponseBody;
import retrofit.Call;
import retrofit.Response;
import retrofit.http.DELETE;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Path;
import retrofit.http.Query;

import retrofit.Response;
import retrofit.http.*;
import rx.Observable;
import rx.Observer;
import rx.Subscriber;

import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by lijl.fnst on 2016/01/06.
 */
public class CourseService {
    private static CourseService service;
    private CourseInterface courseInterface;

    public CourseService() {
        courseInterface = ServiceBuilder.getInstance().build(CourseInterface.class);
    }

    public static CourseService getService() {
        if (service == null) {
            service = new CourseService();
        }
        return service;
    }

    public Subscription getMyCoursesList(String sort, Integer page, Subscriber<List<Course>> subscriber){
        return courseInterface.getMyCoursesList(ApplicationUtils.getToken(), Constants.CONTENT_REFERER,sort, page,false,false)
                .flatMap(new ObserverConvert<CourseList>())
                .map(new Func1<CourseList, List<Course>>() {
                    @Override
                    public List<Course> call(CourseList courseList) {
                        return courseList.getCourses();
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(subscriber);

    }

    public Subscription getMyCourses(Map<String,Object> map, String id,Subscriber<List<Course>> subscriber){

        return courseInterface.getMyCourses(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id, map)
                .flatMap(new ObserverConvert<CourseList>())
                .map(new Func1<CourseList, List<Course>>() {
                    @Override
                    public List<Course> call(CourseList courseList) {
                        return courseList.getCourses();
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(subscriber);

    }

    public Subscription getCoursesDetail(String id, boolean list,boolean data,Subscriber<Course> subscriber){
        return courseInterface.getCoursesDetail(ApplicationUtils.getToken(), Constants.EXTRA_COURSE, id, list, data)
                .flatMap(new ObserverConvert<CourseList>())
                .map(new Func1<CourseList, Course>() {
                    @Override
                    public Course call(CourseList courseList) {
                        return courseList.getCourse();
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(subscriber);
    }

    public Subscription addCourses(String id,Subscriber<EmptyModel> subscriber){
        return courseInterface.addCourses(ApplicationUtils.getToken(), Constants.EXTRA_COURSE, id)
                .flatMap(new ObserverConvert<EmptyModel>())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(subscriber);
    }

    public Subscription deleteCourses(String id,Subscriber<EmptyModel> subscriber){
        return courseInterface.deleteCourses(ApplicationUtils.getToken(), Constants.EXTRA_COURSE, id)
                .flatMap(new ObserverConvert<EmptyModel>())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(subscriber);
    }

    public Subscription getCourseInformation(String id,Boolean data, Subscriber<CourseDetailModel> subscriber){
        Observable<Response<CourseDetailModel>> observable = courseInterface.getCourseInformation(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id, data);
        return observable.flatMap(new ObserverConvert<CourseDetailModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public Subscription enrollCourse(String id, Subscriber<EmptyModel> subscriber){
        Observable<Response<EmptyModel>> observable = courseInterface.enrollCourse(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id);
        return observable.flatMap(new ObserverConvert<EmptyModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public Subscription deleteCourse(String id, Subscriber<EmptyModel> subscriber){
        Observable<Response<EmptyModel>> observable = courseInterface.deleteCourse(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id);
        return observable.flatMap(new ObserverConvert<EmptyModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public Subscription updateCourse(String id,Integer data,Subscriber<EmptyModel> subscriber){
        Observable<Response<EmptyModel>> observable = courseInterface.updateCourse(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id, data);
        return observable.flatMap(new ObserverConvert<EmptyModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);

    }

    public Subscription getReportDetail(String id,Boolean data,Subscriber<ReportDetailModel> subscriber){
        Observable<Response<ReportDetailModel>> observable = courseInterface.getReportDetail(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id, data);
        return observable.flatMap(new ObserverConvert<ReportDetailModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);

    }

    public Subscription getPDF(String courseId,Subscriber<FilenameModel> subscriber){
        Observable<Response<FilenameModel>> observable = courseInterface.getPDF(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, courseId);
        return observable.flatMap(new ObserverConvert<FilenameModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public Subscription getMadePDF(String courseId,Subscriber<FilenameModel> subscriber){
        Observable<Response<FilenameModel>> observable = courseInterface.getMadePDF(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, courseId);
        return observable.flatMap(new ObserverConvert<FilenameModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public interface CourseInterface {
        @GET("courses")
        Observable<Response<CourseList>> getMyCoursesList(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Query("sort") String sort, @Query("page") Integer page,@Query("getPlaylistsInformation") boolean list,@Query("getContentsInformation") boolean content);

        @GET("users/{id}/my-courses")
        Observable<Response<CourseList>> getMyCourses(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@QueryMap Map<String,Object> map);

        @GET("courses/{id}")
        Observable<Response<CourseList>> getCoursesDetail(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id, @Query("getPlaylistsInformation") boolean list,@Query("getContentsInformation") boolean data);

        @POST("courses/{id}/enroll")
        Observable<Response<EmptyModel>> addCourses(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id);

        @DELETE("courses/{id}/enroll")
        Observable<Response<EmptyModel>> deleteCourses(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id);


        @GET("courses/{id}")
        Observable<Response<CourseDetailModel>> getCourseInformation(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@Query("getContentsInformation") Boolean data);

        @POST("courses/{id}/enroll")
        Observable<Response<EmptyModel>> enrollCourse(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id);
        @DELETE("courses/{id}/enroll")
        Observable<Response<EmptyModel>> deleteCourse(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id);

        @FormUrlEncoded
        @POST("contents/{id}")
        Observable<Response<EmptyModel>> updateCourse(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@Field("percentageViewed") Integer data);

        @GET("contents/{id}")
        Observable<Response<ReportDetailModel>> getReportDetail(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@Query("withSubmission") Boolean data);

        @POST("courses/{courseId}/completion-certificate")
        Observable<Response<FilenameModel>> getPDF(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("courseId") String courseId);

        @GET("courses/{courseId}/completion-certificate")
        Observable<Response<FilenameModel>> getMadePDF(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("courseId") String courseId);
    }
}
