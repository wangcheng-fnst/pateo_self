package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.SubmittedReport;
import com.fujitsu.fnst.fmooc.android.app.repository.ReportRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.ReportSelfViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ReportMainActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ReportSelfActivity;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;
import rx.Subscriber;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by lijl.fnst on 2016/01/19.
 */
public class ReportSelfPresenter extends BasePresenter implements EditChangeListener.TextChangeCallback {
    private ReportSelfViewInterface view;
    private String comment;
    public ReportSelfPresenter(ReportSelfViewInterface reportSelfViewInterface){
        super();
        view = reportSelfViewInterface;
        init();
    }

    public void init(){
        EditChangeListener commentWatcher = new EditChangeListener();
        commentWatcher.setCallback(this);
        view.setCommentListener(commentWatcher);
    }

    public void submit(String contentId,String selected,String comments){
        if(comments.length() > 250){
            view.showToast(context.getResources().getString(R.string.report_comment_too_long));
        }else {
            Map<String, Object> data = new HashMap<String, Object>();
            data.put("selectedChoices", selected);
            data.put("comments", comments);
            ReportRepository.getInstance().addReportAnswer(contentId, data, getSubscriber());
        }

    }

    private Subscriber getSubscriber(){
        return new Subscriber<SubmittedReport>() {
            @Override
            public void onCompleted() {
//                view.showToast("onCompleted");
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(SubmittedReport report) {
//                view.showToast("onNext");
                view.hideWaitingDialog();
//                Intent intent = new Intent(context,ReportMainActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                intent.putExtra(Constants.EXTRA_CONTENTID, view.getContentId());
//                context.startActivity(intent);

                Intent intent = new Intent();
                intent.putExtra(Constants.EXTRA_CONTENTID, view.getContentId());
                ((ReportSelfActivity)view).setResult(Constants.REPORT_STEP2, intent);
                ((ReportSelfActivity)view).finish();
            }
        };
    }

    @Override
    public void formatRight() {
        if (checkValue()){
            view.enableBtn();
        }else{
            view.disableBtn();
        }
    }

    private boolean checkValue(){
        comment = view.getUserComment();
        if (!StringUtils.isBlank(comment)){
            return true;
        }
        return false;
    }
}
