package com.fujitsu.fnst.fmooc.android.app.view;

import android.app.Dialog;
import android.text.TextWatcher;
import android.widget.EditText;

/**
 * Created by lijl.fnst on 2016/01/19.
 */
public interface ReportReflectionViewInterface extends BaseViewInterface {
    void enableBtn();
    void disableBtn();
    String getContentId();
    String getComment();
    void setCommentListener(TextWatcher watcher);
}
