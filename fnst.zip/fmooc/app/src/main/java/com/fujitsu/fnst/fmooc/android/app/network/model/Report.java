package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by zhaod.fnst on 2016/1/18.
 */
public class Report implements Serializable {
    public static final String CANNOT_SUBMIT = "cannotSubmit";
    public static final String WAITING_FOR_REPORT_ANSWER = "waitingForReportAnswer";
    public static final String WAITING_FOR_SELF_EVALUATION_PERIOD_TO_START = "waitingForSelfEvaluationPeriodToStart";
    public static final String WAITING_FOR_SELF_EVALUATION = "waitingForSelfEvaluation";
    public static final String WAITING_FOR_EVALUATION_PERIOD_TO_START = "waitingForEvaluationPeriodToStart";
    public static final String WAITING_FOR_EVALUATION = "waitingForEvaluation";
    public static final String WAITING_FOR_EVALUATION_ON_MY_REPORT = "waitingForEvaluationOnMyReport";
    public static final String WAITING_FOR_REFLECTION_PERIOD_TO_START = "waitingForReflectionPeriodToStart";
    public static final String WAITING_FOR_REFLECTION = "waitingForReflection";
    public static final String COMPLETED = "completed";
    public static final String ABORTED = "aborted";

    private String contentId;
    private String playlistId;
    private String courseId;
    private String authorId;
    private String contentType;
    private String reportTitle;
    private String reportLabel;
    private int maxNumberOfCharacters;
    private Date maySubmitFrom;
    private Date shouldSubmitBefore;
    private Date maySendSelfEvaluationFrom;
    private Date shouldSendSelfEvaluationBefore;
    private Date maySendEvaluationFrom;
    private Date shouldSendEvaluationBefore;
    private Date maySendReflectionFrom;
    private Date shouldSendReflectionBefore;
    private String state;

    public Report() {
    }

    public String getContentId(){
        return contentId;
    }

    public void setContentId(String contentId){
        this.contentId=contentId;
    }

    public String getPlaylistId(){
        return playlistId;
    }

    public void setPlaylistId(String playlistId){
        this.playlistId=playlistId;
    }

    public String getCourseId(){
        return courseId;
    }

    public void setCourseId(String courseId){
        this.courseId=courseId;
    }

    public String getAuthorId(){
        return authorId;
    }

    public void setAuthorId(String authorId){
        this.authorId=authorId;
    }

    public String getContentType(){
        return contentType;
    }

    public void setContentType(String contentType){
        this.contentType=contentType;
    }

    public String getReportTitle(){
        return reportTitle;
    }

    public void setReportTitle(String reportTitle){
        this.reportTitle=reportTitle;
    }

    public String getReportLabel(){
        return reportLabel;
    }

    public void setReportLabel(String reportLabel){
        this.reportLabel=reportLabel;
    }

    public int getMaxNumberOfCharacters(){
        return maxNumberOfCharacters;
    }

    public void setMaxNumberOfCharacters(int maxNumberOfCharacters){
        this.maxNumberOfCharacters=maxNumberOfCharacters;
    }

    public Date getMaySubmitFrom(){
        return maySubmitFrom;
    }

    public void setMaySubmitFrom(Date maySubmitFrom){
        this.maySubmitFrom=maySubmitFrom;
    }

    public Date getShouldSubmitBefore(){
        return shouldSubmitBefore;
    }

    public void setShouldSubmitBefore(Date shouldSubmitBefore){
        this.shouldSubmitBefore=shouldSubmitBefore;
    }

    public Date getMaySendSelfEvaluationFrom(){
        return maySendSelfEvaluationFrom;
    }

    public void setMaySendSelfEvaluationFrom(String maySendSelfEvaluationFrom){
        this.maySendSelfEvaluationFrom = maySendEvaluationFrom;
    }

    public Date getShouldSendSelfEvaluationBefore(){
        return shouldSendSelfEvaluationBefore;
    }

    public void setShouldSendSelfEvaluationBefore(Date shouldSendSelfEvaluationBefore){
        this.shouldSendSelfEvaluationBefore = shouldSendSelfEvaluationBefore;
    }

    public Date getMaySendEvaluationFrom(){
        return maySendEvaluationFrom;
    }

    public void setMaySendEvaluationFrom(Date maySendEvaluationFrom){
        this.maySendEvaluationFrom = maySendEvaluationFrom;
    }

    public void setMaySendSelfEvaluationFrom(Date maySendSelfEvaluationFrom) {
        this.maySendSelfEvaluationFrom = maySendSelfEvaluationFrom;
    }

    public Date getShouldSendEvaluationBefore() {
        return shouldSendEvaluationBefore;
    }

    public void setShouldSendEvaluationBefore(Date shouldSendEvaluationBefore) {
        this.shouldSendEvaluationBefore = shouldSendEvaluationBefore;
    }

    public Date getMaySendReflectionFrom(){
        return maySendReflectionFrom;
    }

    public void setMaySendReflectionFrom(Date maySendReflectionFrom){
        this.maySendReflectionFrom = maySendReflectionFrom;
    }

    public Date getShouldSendReflectionBefore(){
        return shouldSendReflectionBefore;
    }

    public void setShouldSendReflectionBefore(Date shouldSendReflectionBefore){
        this.shouldSendReflectionBefore = shouldSendReflectionBefore;
    }
    public String getState(){
        return state;
    }

    public void setState(String state){
        this.state=state;
    }

}
