package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.support.v4.app.FragmentManager;
import android.util.Log;
import com.fujitsu.fnst.fmooc.android.app.view.MainViewInterface;

/**
 * Created by wangc.fnst on 2015/12/14.
 */
public class MainPresenter extends BasePresenter {

    public static final int RIGHT_MODE = 0x002;
    public static final int MIDDLE_MODE = 0x001;
    public static final int LEFT_MODE = 0x000;

    private MainViewInterface view;
    private FragmentManager fragmentManager;

    public MainPresenter(MainViewInterface view,FragmentManager fragmentManager) {
        this.view = view;
        this.fragmentManager = fragmentManager;
        init();
    }

    private void init(){

    }

    public void bottomClick(int mode,boolean isNeedChangeContent){
        view.resetBottom();
        switch (mode){
            case LEFT_MODE:
                Log.e("LEFT_MODE",mode+"");
                getCourse();
                view.leftClick();
                break;
            case MIDDLE_MODE:
                Log.e("MIDDLE_MODE",mode+"");
                getMyCourse();
                view.middleClick();
                break;
            case RIGHT_MODE:
                Log.e("RIGHT_MODE",mode+"");
                getUser();
                view.rightClick();
                break;
        }
        if (isNeedChangeContent){
            view.changeContent(mode);
        }
    }

    public void getCourse(){

    }
    public void getMyCourse(){

    }
    public void getUser(){

    }



}
