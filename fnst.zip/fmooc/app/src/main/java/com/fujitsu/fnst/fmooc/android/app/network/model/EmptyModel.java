package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by lijl.fnst on 2015/12/28.
 */
public class EmptyModel implements Serializable {

}
