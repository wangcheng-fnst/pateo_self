package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import android.widget.Toast;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.network.model.CodeEmail;
import com.fujitsu.fnst.fmooc.android.app.network.model.EmptyModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.repository.UserRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.ChangePwdViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ChangePasswdSuccessActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ChangePwdActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.RegisterActivity;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;

import rx.Subscriber;
import rx.Subscription;

/**
 * Created by wangc.fnst on 2015/12/11.
 */
public class ChangePwdPresenter extends BasePresenter implements EditChangeListener.TextChangeCallback, OnGetModelFinishImpl<EmptyModel>{

    private ChangePwdViewInterface view;
    private String id,oldPwd,newPwd,confPwd,emailStr;
    private boolean isForgetPwd = false;
    private String requestType;
    private Subscription subscription;
    private Subscriber<EmptyModel> subscriber;
    private Subscription codeSubscription;
    private Subscriber<CodeEmail> codeSubscriber;
    public ChangePwdPresenter(ChangePwdViewInterface view) {
        super();
        this.view = view;
        init();
    }

    private void init(){

        EditChangeListener oldListener = new EditChangeListener();
        oldListener.setCallback(this);
        EditChangeListener newListener = new EditChangeListener();
        newListener.setCallback(this);
        EditChangeListener cofListener = new EditChangeListener();
        cofListener.setCallback(this);
        view.setOldTextChangeWatcher(oldListener);
        view.setNewTextChangeWatcher(newListener);
        view.setConfTextChangeWatcher(cofListener);

    }

    public void confirmCode(String code){
        view.showWaitingDialog();
        subscription = UserRepository.getInstance().confirmCode(getCodeSubscriber(), code);
    }

    private Subscriber<CodeEmail> getCodeSubscriber(){
        return codeSubscriber = new Subscriber<CodeEmail>() {
            @Override
            public void onCompleted() {
                //view.showToast("onCompleted");
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
                ((ChangePwdActivity)view).finish();
            }

            @Override
            public void onNext(CodeEmail email) {
                setEmail(email.getMessage());
                //sendSuccess();
                //view.showToast("userid:"+user.getUser().getBirthYear());
            }
        };
    }

    public void setIsForgetPwd(){
        isForgetPwd = true;
    }
    public void setEmail(String email){
        emailStr = email;
    }
    public void send(){
        if (isForgetPwd){
            forgetPwd();
        } else {
            changePwd();
        }
    }

    public void changePwd(){
        if (!checkFormatForChange()){
            return;
        }
        id = ShareReferencesManager.getInstance(context).getStringValue(Constants.SP_USER_ID);
        requestType = UserRepository.RESET_PASSWORD_RESPONSE;
//        UserRepository.getInstance().register(requestType,this);
//        UserRepository.getInstance().resetPwd(id, oldPwd, newPwd, requestType);
//        if (subscriber == null){
//            getSubscriber();
//        }
        view.showWaitingDialog();
        subscription = UserRepository.getInstance().resetPwd(id, oldPwd, newPwd, getSubscriber());
    }
    public void forgetPwd(){
        if (!checkFormatForForget()){
//            Intent intent = new Intent(context, ChangePasswdSuccessActivity.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            context.startActivity(intent);
            return;
        }
        view.showWaitingDialog();
        requestType = UserRepository.FORGET_PASSWORD_RESPONSE;
        UserRepository.getInstance().register(requestType, this);
        UserRepository.getInstance().forgetPwd(emailStr, newPwd, requestType);
    }

    private Subscriber<EmptyModel> getSubscriber(){
        return subscriber = new Subscriber<EmptyModel>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }

            @Override
            public void onNext(EmptyModel user) {
                //sendSuccess();
                //view.showToast("userid:"+user.getUser().getBirthYear());
                if (requestType.equals(UserRepository.RESET_PASSWORD_RESPONSE)){
//                    Intent intent = new Intent(context, ChangePasswdSuccessActivity.class);
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                    context.startActivity(intent);
                    ((ChangePwdActivity)view).finish();
                } else if (requestType.equals(UserRepository.FORGET_PASSWORD_RESPONSE)){
                    Intent intent = new Intent(context, ChangePasswdSuccessActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    ((ChangePwdActivity)view).finish();
                }
            }
        };
    }

    private boolean checkFormatForChange(){
        if (!StringUtils.isValidPassword(oldPwd)){
            view.showToast(((ChangePwdActivity) view).getString(R.string.password_error));
            return false;
        }
        if(newPwd.length() > 48 || confPwd.length() > 48){
            view.showToast(((ChangePwdActivity) view).getString(R.string.password_long));
            return false;
        }
        if (!StringUtils.isValidPassword(newPwd)){
            view.showToast(((ChangePwdActivity) view).getString(R.string.password_error));
            return false;
        }
        if (!newPwd.equals(confPwd)){
            view.showToast(((ChangePwdActivity) view).getString(R.string.password_mismatch));
            return false;
        }
        return  true;
    }
    private boolean checkFormatForForget(){
        if(newPwd.length() > 48 || confPwd.length() > 48){
            view.showToast(((ChangePwdActivity) view).getString(R.string.password_long));
            return false;
        }
        if (!StringUtils.isValidPassword(newPwd)){
            view.showToast(((ChangePwdActivity) view).getString(R.string.password_error));
            return false;
        }
        if (!newPwd.equals(confPwd)){
            view.showToast(((ChangePwdActivity) view).getString(R.string.password_mismatch));
            return false;
        }

        return  true;
    }

    @Override
    public void formatRight() {
        if(isForgetPwd){
            newPwd = view.getNewPwd();
            confPwd = view.getConfPwd();
            if (!StringUtils.isBlank(newPwd)
                    && !StringUtils.isBlank(confPwd)){
                view.enableBtn();
            }else{
                view.disableBtn();
            }
        } else {
            oldPwd = view.getOldPwd();
            newPwd = view.getNewPwd();
            confPwd = view.getConfPwd();
            if (!StringUtils.isBlank(oldPwd)
                    &&!StringUtils.isBlank(newPwd)
                    && !StringUtils.isBlank(confPwd)){
                view.enableBtn();
            }else{
                view.disableBtn();
            }
        }

    }
    @Override
    public void onSuccess(String type, EmptyModel result) {
        view.hideWaitingDialog();
        if (type.equals(UserRepository.RESET_PASSWORD_RESPONSE)){
            Intent intent = new Intent(context, ChangePasswdSuccessActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } else if (type.equals(UserRepository.FORGET_PASSWORD_RESPONSE)){
            Intent intent = new Intent(context, ChangePasswdSuccessActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
        ((ChangePwdActivity)view).finish();

    }

    @Override
    public void onFailed(String type,String message) {
        view.hideWaitingDialog();
        if (type.equals(UserRepository.RESET_PASSWORD_RESPONSE)){
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        } else if (type.equals(UserRepository.FORGET_PASSWORD_RESPONSE)){
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroy() {
        UserRepository.getInstance().unRegister(requestType);
        super.onDestroy();

    }
}
