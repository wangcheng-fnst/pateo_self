package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;

import com.fujitsu.fnst.fmooc.android.app.view.ChangePasswdSuccessViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ChangePasswdSuccessActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.LoginActivity;

/**
 * Created by lijl.fnst on 2015/12/18.
 */
public class ChangePasswdSuccessPresenter extends BasePresenter {
    private ChangePasswdSuccessViewInterface view;
    public ChangePasswdSuccessPresenter(ChangePasswdSuccessViewInterface viewInterface){
        super();
        view = viewInterface;
    }
    public void toLogin(){
        Intent intent = new Intent(context, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
        ((ChangePasswdSuccessActivity)view).finish();
    }
}
