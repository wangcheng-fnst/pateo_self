package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.text.InputFilter;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.DiscussionModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Content;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.presenter.DiscussionPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.TimeUtils;
import com.fujitsu.fnst.fmooc.android.app.view.DiscussionViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.DiscussionAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;
import com.fujitsu.fnst.fmooc.android.app.view.component.tree.DiscussionDetailDialog;
import com.fujitsu.fnst.fmooc.android.app.view.listener.SendMessageEditListener;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public class DiscussionActivity extends BaseActivity<DiscussionPresenter> implements DiscussionViewInterface {

    @Bind(R.id.id_discussion_list)
    PullRefleashListView discussionList;
    @Bind(R.id.id_submit_btn)
    Button submitBtn;
    @Bind(R.id.id_content_edit)
    EditText contentEdit;
    @Bind(R.id.id_discussion_layout)
    LinearLayout discussionLayout;
    @Bind(R.id.id_discussion_error_layout)
    LinearLayout discussionErrorLayout;
    @Bind(R.id.discussion_refresh_btn)
    Button refreshBtn;
    @Bind(R.id.id_submit_layout)
    LinearLayout submitLayout;
    private int page = 1;
    private String id,status,userStatus;

    private DiscussionAdapter adapter;
    private List<DiscussionModel> mData = new ArrayList<DiscussionModel>();
    private SendMessageEditListener listener;
    private boolean isToOther;
    private DiscussionDetailDialog discussionDetailDialog;
    private static final int MAX_LENGTH = 250;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        Intent intent = getIntent();
        id=intent.getExtras().getString(Constants.EXTRA_COURSE_ID);
        status = intent.getExtras().getString(Constants.EXTRA_STATUS);
        userStatus = intent.getExtras().getString(Constants.EXTRA_USER_STATUS);
        presenter = new DiscussionPresenter(this,page,id);
        presenter.setNotifyData(true);
        presenter.setCheckNet(true);
        presenter.getMessages();
        adapter = new DiscussionAdapter(mData);
        discussionList.setPullLoadEnable(true);
        discussionList.setPullRefreshEnable(true);
        discussionList.setAdapter(adapter);
        discussionList.hideFoot();
        discussionList.setRefleashListener(presenter);
        if(mData != null)
            discussionList.setSelection(mData.size() - 1);
        adapter.setOnClickListener(this);
        refreshBtn.setOnClickListener(this);
        listener = new SendMessageEditListener(this);
        if(status != null && status.equals(Course.COURSE_STATUS_CLOSE)){
            adapter.setReadOnly(true);
            submitBtn.setClickable(false);
            submitBtn.setAlpha(0.5f);
            submitBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
            contentEdit.setKeyListener(null);
        }else{
            submitBtn.setOnClickListener(this);
        }
        contentEdit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_LENGTH)});
    }

    @Override
    protected int getLayout() {
        return R.layout.discussion_activity_layout;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.discussion_title);
    }


    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if (isShouldHideInput(v, ev)) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null && v!=null ) {
//                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
            return super.dispatchTouchEvent(ev);
        }
        if (getWindow().superDispatchTouchEvent(ev)) {
            return true;
        }
        return onTouchEvent(ev);
    }
    public  boolean isShouldHideInput(View v, MotionEvent event) {
        if (v != null && (v instanceof EditText)) {
            int[] leftTop = { 0, 0 };
            v.getLocationInWindow(leftTop);
            int left = leftTop[0];
            int top = leftTop[1];
            int bottom = top + v.getHeight();
            int right = left + v.getWidth();
            if (event.getX() > left && event.getX() < right
                    && event.getY() > top && event.getY() < bottom) {
                if (!isToOther){
                    discussionList.setSelection(mData.size());
                }
                return false;
            } else {
                return true;
            }
        }
        return true;
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_submit_btn) {
            String replyOf = (String)contentEdit.getTag(R.id.reply);
            int length = 0;
            if(replyOf != null && replyOf != "")
                length = (int) contentEdit.getTag(R.id.length);
            presenter.submitMessage(isToOther,id,replyOf,length);
        } else if (v.getId() == R.id.id_reply_btn) {
            removeEditListener();
            discussionList.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_DISABLED);
            isToOther = true;
            Integer position = (Integer) v.getTag(R.id.position);
            contentEdit.setFocusable(true);
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
            discussionList.setSelection(position+1);
            if (position != null) {
                DiscussionModel model = (DiscussionModel) adapter.getItem(position);
                String title = "No." + model.getOrder() + getResources().getString(R.string.reply_str)+": ";
                SpannableString ts = new SpannableString(title);
                ts.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.font_dark_gray)), 0, title.length()-1, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                ts.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), title.length() - 1, title.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                contentEdit.setText(ts);
                contentEdit.setSelection(title.length());
                listener.setIsWatch(true);
                listener.setWatchStr(title);
                listener.setEditText(contentEdit);
                contentEdit.addTextChangedListener(listener);
                contentEdit.setTag(R.id.reply, model.getId());
                contentEdit.setTag(R.id.length, title.length());
            }
        } else if (v.getId() == R.id.id_reply_txt){
            Integer position = (Integer) v.getTag(R.id.position);
            DiscussionModel model = (DiscussionModel) adapter.getItem(position);
            getById(model.getReplyOf());
        } else if(v.getId() == R.id.discussion_refresh_btn){
            presenter.setNotifyData(true);
            presenter.setCheckNet(true);
            showWaitingDialog();
            presenter.getMessages();
        }
    }

    private void getById(String id){
        showWaitingDialog();
        presenter.getMessageById(id);
    }

    @Override
    public String getEditContent() {
        return contentEdit.getText().toString();
    }

    @Override
    public void notifyData(boolean isToBottom) {
        adapter.notifyDataSetChanged();
        if (isToBottom){
//            discussionList.post(new Runnable() {
//                @Override
//                public void run() {
//                    discussionList.setSelection(discussionList.getBottom());
//                }
//            });
            discussionList.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
            contentEdit.setText("");
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(contentEdit.getWindowToken(), 0);
            discussionList.hideFoot();
        }else {
            discussionList.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_DISABLED);
            discussionList.post(new Runnable() {
                @Override
                public void run() {
                    discussionList.setSelection(discussionList.getTop());
                }
            });
            discussionList.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        }
    }

    @Override
    public void setIsToOther(boolean isToOther) {
        this.isToOther = isToOther;
    }

    @Override
    public void removeEditListener() {
        contentEdit.removeTextChangedListener(listener);
        setIsToOther(false);
    }

    @Override
    public void onLoad() {
        discussionList.stopRefresh();
        discussionList.stopLoadMore();
        discussionList.setRefreshTime(TimeUtils.format(new Date()));
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void notify(boolean isRefresh) {
        adapter.notifyDataSetChanged();
    }

    @Override
    public void addItems(List<DiscussionModel> data) {
        int k=0;
        for(int i=data.size()-1;i>=0;i--){
            mData.add(k,data.get(i));
            k++;
        }
    }

    @Override
    public void addItem(DiscussionModel model) {
        mData.add(mData.size()-1 < 0?0:mData.size() -1,model);
    }

    @Override
    public void resetData() {
        mData.clear();
    }

    @Override
    public LinearLayout getDiscussionLayout() {
        return discussionLayout;
    }

    @Override
    public LinearLayout getDiscussionErrorLayout() {
        return discussionErrorLayout;
    }

    @Override
    public void setMessage(DiscussionModel message) {
        if (discussionDetailDialog == null || !discussionDetailDialog.isShowing()){
            discussionDetailDialog =new DiscussionDetailDialog(this, message, mData, new DiscussionDetailDialog.MyDialogListener() {
                @Override
                public void onClick(View view) {
                    if(view.getId() == R.id.id_close_btn){
                        discussionDetailDialog.dismiss();
                    }else if(view.getId() == R.id.id_reply_txt){
                        String id = (String)view.getTag(R.id.id);
                        discussionDetailDialog.refreshDialog(id);
                    }
                }
            });
            discussionDetailDialog.show();
        }
    }
}
