package com.fujitsu.fnst.fmooc.android.app.utils;

import android.content.res.Resources;
import android.graphics.*;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory.Options;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.NinePatchDrawable;
import android.media.ExifInterface;
import android.media.ThumbnailUtils;

import java.io.*;

public class BitmapUtil {

    /**
     * 从SD中获取指定宽高的Bitmap对象
     *
     * @param url    SD绝对路径
     * @param width  宽度
     * @param height 高度
     * @return 指定大小的Bitmap对象
     */
    public static Bitmap getBitmapForSize(String url, int width, int height) {
        if (width != 0 && height != 0) {
            Bitmap bitmap = ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(url),
                    width, height, ThumbnailUtils.OPTIONS_RECYCLE_INPUT);
            return bitmap;
        }
        return null;
    }

    /**
     * 通过资源id获取Bitmap对象
     *
     * @param resources 资源管理对象
     * @param resId     资源ID
     * @return Bitmap对象
     */
    public static Bitmap getBitmapForSize(Resources resources, int resId, int width, int height) {
        // 第一次解析将inJustDecodeBounds设置为true，来获取图片大小
        final Options options = new Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(resources, resId, options);
        // 调用上面定义的方法计算inSampleSize值
        options.inSampleSize = calculateInSampleSize(options, width, height);
        // 使用获取到的inSampleSize值再次解析图片
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(resources, resId, options);
    }

    /**
     * 根据图片字节数组指定宽高的Bitmap对象
     *
     * @param data   图片字节数组
     * @param width  宽度
     * @param height 高度
     * @return 指定大小的Bitmap对象
     */
    public static Bitmap getBitmapForSize(byte[] data, int width, int height) {
        if (width != 0 && height != 0) {
            Bitmap bitmap = ThumbnailUtils.extractThumbnail(bytes2Bitmap(data),
                    width, height, ThumbnailUtils.OPTIONS_RECYCLE_INPUT);
            return bitmap;
        }
        return null;
    }

    /**
     * 获取圆角图片
     *
     * @param bitmap  需要进行圆角的Bitmap对象
     * @param angle   角度
     * @param @return 圆角图片对象
     */
    public static Bitmap getRoundedBitmap(Bitmap bitmap, float angle) {
        if (bitmap != null) {
            try {
                Bitmap targetBitmap = Bitmap.createBitmap(bitmap.getWidth(),
                        bitmap.getHeight(), Config.ARGB_8888);
                Canvas canvas = new Canvas(targetBitmap);
                Paint paint = new Paint();
                paint.setAntiAlias(true);
                Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
                RectF rectF = new RectF(rect);
                canvas.drawARGB(0, 0, 0, 0);
                canvas.drawRoundRect(rectF, angle, angle, paint);
                paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
                canvas.drawBitmap(bitmap, rect, rect, paint);
                return targetBitmap;
            } catch (Exception e) {
                e.printStackTrace();
            } catch (Error e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * 获取旋转过的Bitmap
     *
     * @param bitmap 需要旋转的Bitmap对象
     * @param angle  旋转的角度
     * @return Bitmap 旋转过的Bitmap对象
     */
    public static Bitmap getRotateBitmap(Bitmap bitmap, int angle) {
        if (null == bitmap) {
            return null;
        }
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0,
                bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        return resizedBitmap;
    }

    /**
     * 获取图片的旋转角度
     *
     * @param path 图片的SD绝对路径
     * @return 旋转的角度
     */
    public static int readPictureDegree(String path) {
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(path);
            int orientation = exifInterface.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return degree;
    }

    /**
     * 获取希望获取宽高与图片本身宽高的比例
     *
     * @param options   图片参数对象
     * @param reqWidth  希望获取的宽度
     * @param reqHeight 希望获取的高度
     * @return 两者之间的比例
     */
    private static int calculateInSampleSize(Options options,
                                             int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            final int heightRatio = Math.round((float) height
                    / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = heightRatio < widthRatio ? widthRatio : heightRatio;
        }
        return inSampleSize;
    }




    /**
     * 将Bitmap对象转换成字节数组
     *
     * @param bitmap Bitmap对象
     * @return 转换后的字节数组
     */
    public static byte[] bitmap2Bytes(Bitmap bitmap) {
        byte[] b = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(CompressFormat.PNG, 100, baos);
        try {
            b = baos.toByteArray();
            baos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return b;
    }

    /**
     * 将字节数组转换成Bitmap对象
     *
     * @param b 字节数组
     * @return 转换后的Bitmap对象
     */
    public static Bitmap bytes2Bitmap(byte[] b) {
        if (b != null && b.length > 0) {
            return BitmapFactory.decodeByteArray(b, 0, b.length);
        } else {
            return null;
        }
    }

    /**
     * 将字节数组转换成Drawable对象
     *
     * @param b 字节数组
     * @return 转换后的Drawable对象
     */
    public static Drawable bytes2Drawable(byte[] b) {
        if (b != null && b.length != 0) {
            return new BitmapDrawable(BitmapFactory.decodeByteArray(b, 0,
                    b.length));
        } else {
            return null;
        }
    }


    /**
     * 将图片压缩至指定大小
     *
     * @param image 图片对象
     * @param size  图片大小，单位KB
     * @return 压缩到指定大小的Bitmap对象
     */
    public static Bitmap compressImage(Bitmap image, int size) {
        if (image == null) {
            return null;
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(CompressFormat.JPEG, 100, baos);
        int options = 100;
        while (baos.toByteArray().length / 1024 > size) {
            options -= 10;
            baos.reset();
            image.compress(CompressFormat.JPEG, options, baos);
        }
        ByteArrayInputStream isBm = new ByteArrayInputStream(baos.toByteArray());
        Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, null);
        bitmap.getRowBytes();
        return bitmap;
    }


    /**
     * 将Bitmap对象存到SD中
     *
     * @param bitmap Bitmap对象
     * @param path   SD绝对路径
     */
    public final static void bitmapToFile(Bitmap bitmap, String path) {
        File file = new File(path);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(CompressFormat.JPEG, 100 /*ignored for PNG*/, bos);
        byte[] bitmapData = bos.toByteArray();

        //write the bytes in file
        FileOutputStream fos;
        try {
            fos = new FileOutputStream(file);
            fos.write(bitmapData);
            bitmap.recycle();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 将drawable对象转换为Bitmap
     *
     * @param Drawable drawable
     */
    public static Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        } else if (drawable instanceof NinePatchDrawable) {
            Bitmap bitmap = Bitmap
                    .createBitmap(
                            drawable.getIntrinsicWidth(),
                            drawable.getIntrinsicHeight(),
                            drawable.getOpacity() != PixelFormat.OPAQUE ? Config.ARGB_8888
                                    : Config.RGB_565);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, drawable.getIntrinsicWidth(),
                    drawable.getIntrinsicHeight());
            drawable.draw(canvas);
            return bitmap;
        } else {
            return null;
        }
    }

    /**
     *  处理图片
     * @param bm 所要转换的bitmap
     * @param newWidth新的宽
     * @param newHeight新的高
     * @return 指定宽高的bitmap
     */
    public static Bitmap zoomImg(Bitmap bm, int newWidth ,int newHeight){
        // 获得图片的宽高
        int width = bm.getWidth();
        int height = bm.getHeight();
        // 计算缩放比例
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // 取得想要缩放的matrix参数
        Matrix matrix = new Matrix();
        matrix.postScale(scaleWidth, scaleHeight);
        // 得到新的图片   www.2cto.com
        Bitmap newbm = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, true);
        return newbm;
    }

    /**
     *  处理图片
     * @param bm 所要转换的bitmap
     * @param newWidth新的宽
     * @param newHeight新的高
     * @return 指定宽高的bitmap
     */
    public static Bitmap zoomImg(Bitmap bm, float scale){
        // 获得图片的宽高
        int width = bm.getWidth();
        int height = bm.getHeight();
        // 取得想要缩放的matrix参数
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        // 得到新的图片   www.2cto.com
        Bitmap newbm = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, true);
        return newbm;
    }


}
