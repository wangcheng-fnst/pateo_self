package com.fujitsu.fnst.fmooc.android.app.view;

import android.text.TextWatcher;

/**
 * Created by lijl.fnst on 2015/12/22.
 */
public interface ProfileSelectViewInterface extends BaseViewInterface{
    String getName();
    void showYear();
    void showFirstname();
    void showSex();
    void showEducation();
    void hideAll();
    void enableBtn();
    void disableBtn();
    void setNameListener(TextWatcher watcher);
}
