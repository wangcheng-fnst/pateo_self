package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by lijl.fnst on 2016/01/06.
 */
public class CourseDetailModel implements Serializable {
private Course course;

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
}
