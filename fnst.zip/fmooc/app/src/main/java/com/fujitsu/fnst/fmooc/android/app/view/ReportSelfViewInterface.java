package com.fujitsu.fnst.fmooc.android.app.view;

import android.text.TextWatcher;
import android.widget.EditText;

/**
 * Created by lijl.fnst on 2016/01/19.
 */
public interface ReportSelfViewInterface extends BaseViewInterface {
    void disableBtn();
    String getContentId();
    void enableBtn();
    String getUserComment();
    void setCommentListener(TextWatcher watcher);
}
