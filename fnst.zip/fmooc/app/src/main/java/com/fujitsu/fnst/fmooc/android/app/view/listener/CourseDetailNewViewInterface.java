package com.fujitsu.fnst.fmooc.android.app.view.listener;

import com.fujitsu.fnst.fmooc.android.app.view.BaseViewInterface;

/**
 * Created by wangc.fnst on 2015/12/22.
 */
public interface CourseDetailNewViewInterface extends BaseViewInterface {
}
