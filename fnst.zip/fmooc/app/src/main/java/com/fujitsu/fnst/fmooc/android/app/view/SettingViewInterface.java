package com.fujitsu.fnst.fmooc.android.app.view;

import android.app.Dialog;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;

/**
 * Created by wangc.fnst on 2015/12/14.
 */
public interface SettingViewInterface extends BaseViewInterface {

    void leftClick();
    void rightClick();
    void showLeft();
    void showRight();
    void dismissLeft();
    void dismissRight();
    void resetTab();
    void setUserInfo(String username, String sex, Integer year, String education, String displayName, String primaryEmail,String url);
    void apiSuccess();
    void apiFailed();
    void showDialog(Dialog dialog);


}
