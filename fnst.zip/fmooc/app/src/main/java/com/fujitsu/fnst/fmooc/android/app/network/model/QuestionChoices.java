package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by zhaod.fnst on 2016/02/01.
 */
public class QuestionChoices implements Serializable {
    String label;
    int score;

    public String getLabel(){
        return label;
    }

    public void setLabel(String label){
        this.label = label;
    }

    public int getScore(){
        return score;
    }

    public void setScore(int score){
        this.score = score;
    }
}
