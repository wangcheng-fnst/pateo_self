package com.fujitsu.fnst.fmooc.android.app.view.listener;

import android.content.Context;
import android.graphics.PointF;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSmoothScroller;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.TypedValue;

/**
 * Created by wangc.fnst on 2015/12/28.
 * to define the speed of scroll for RecyclerView
 */
public class SpeedLayoutManager extends LinearLayoutManager {
    public SpeedLayoutManager(Context context) {
        super(context);
    }

    public SpeedLayoutManager(Context context, int orientation, boolean reverseLayout) {
        super(context, orientation, reverseLayout);
    }
    @Override
    public void smoothScrollToPosition(RecyclerView recyclerView, RecyclerView.State state, int position) {
//        super.smoothScrollToPosition( recyclerView, state,  position);
        LinearSmoothScroller smoothScroller = new LinearSmoothScroller(recyclerView.getContext()) {
            public PointF computeScrollVectorForPosition(int targetPosition) {
                return SpeedLayoutManager.this.computeScrollVectorForPosition(targetPosition);
            }

            @Override
            protected float calculateSpeedPerPixel(DisplayMetrics displayMetrics) {
                int speed = 100;//speed越大越慢
                return speed / TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 100, displayMetrics);
            }
        };
        smoothScroller.setTargetPosition(position);
        this.startSmoothScroll(smoothScroller);
    }
}
