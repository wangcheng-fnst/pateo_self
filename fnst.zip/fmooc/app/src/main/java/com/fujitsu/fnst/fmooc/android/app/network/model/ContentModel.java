package com.fujitsu.fnst.fmooc.android.app.network.model;

/**
 * Created by lijl.fnst on 2016/01/06.
 */
public class ContentModel {
    public String contentId;
    public String name;
    public String description;
    public String contentType;

    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}
