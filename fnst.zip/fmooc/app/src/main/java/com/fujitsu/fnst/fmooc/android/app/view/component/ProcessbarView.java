package com.fujitsu.fnst.fmooc.android.app.view.component;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import com.fujitsu.fnst.fmooc.android.app.R;

/**
 * Created by lijl.fnst on 2016/01/30.
 */
public class ProcessbarView extends View {
    /**
     * text
     */
    private String mTitleText = "0";
    /**
     * text color
     */
    private int mTitleTextColor = Color.BLACK;
    /**
     * text size
     */
    private int mTitleTextSize = (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, 16, getResources().getDisplayMetrics());

    /**
     * text
     */
    private Rect mBound;
    private Paint mPaint;

    private float mWidth;
    private float mHeight;
    private float textMarginLeft = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, 6, getResources().getDisplayMetrics());
    private float textMarginRight = TypedValue.applyDimension(
    TypedValue.COMPLEX_UNIT_DIP, 6, getResources().getDisplayMetrics());
    private float lineSize = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, 1, getResources().getDisplayMetrics());
    private int scoreValue = 0;
    private int mProgress = 0;
    private int mSpeed = 15;

    public ProcessbarView(Context context, AttributeSet attrs)
    {
        this(context, attrs, 0);
    }

    public ProcessbarView(Context context)
    {
        this(context, null);
    }

    public ProcessbarView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.ProcessbarView, defStyle, 0);
        int n = a.getIndexCount();
        for (int i = 0; i < n; i++)
        {
            int attr = a.getIndex(i);
            switch (attr)
            {
                case R.styleable.ProcessbarView_titleText:
                    mTitleText = a.getString(attr);
                    break;
                case R.styleable.ProcessbarView_titleTextColor:
                    mTitleTextColor = a.getColor(attr, Color.BLACK);
                    break;
                case R.styleable.ProcessbarView_titleTextSize:
                mTitleTextSize = a.getDimensionPixelSize(attr, (int) TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_SP, 16, getResources().getDisplayMetrics()));
                    break;
                case R.styleable.ProcessbarView_textMarginLeft:
                    textMarginLeft = a.getDimensionPixelSize(attr, (int) TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, 6, getResources().getDisplayMetrics()));
                    break;
                case R.styleable.ProcessbarView_textMarginRight:
                    textMarginRight = a.getDimensionPixelSize(attr, (int) TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, 6, getResources().getDisplayMetrics()));
                    break;
                case R.styleable.ProcessbarView_scoreValue:
                    scoreValue = a.getInteger(attr, 100);
                    break;
                case R.styleable.ProcessbarView_lineSize:
                    lineSize = a.getDimensionPixelSize(attr, (int) TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, 1, getResources().getDisplayMetrics()));
                    break;
                case R.styleable.ProcessbarView_mSpeed:
                    mSpeed = a.getInteger(attr, 10);

            }

        }
        a.recycle();

        /**
         * text high ang width
         */
        mPaint = new Paint();
        mPaint.setTextSize(mTitleTextSize);
        // mPaint.setColor(mTitleTextColor);
        mBound = new Rect();
        mPaint.getTextBounds(mTitleText, 0, mTitleText.length(), mBound);



    }

    public String getmTitleText() {
        return mTitleText;
    }

    public void setmTitleText(String mTitleText) {
        this.mTitleText = mTitleText;
    }

    public int getmTitleTextColor() {
        return mTitleTextColor;
    }

    public void setmTitleTextColor(int mTitleTextColor) {
        this.mTitleTextColor = mTitleTextColor;
    }

    public int getmTitleTextSize() {
        return mTitleTextSize;
    }

    public void setmTitleTextSize(int mTitleTextSize) {
        this.mTitleTextSize = mTitleTextSize;
    }

    public float getTextMarginLeft() {
        return textMarginLeft;
    }

    public void setTextMarginLeft(float textMarginLeft) {
        this.textMarginLeft = textMarginLeft;
    }

    public float getTextMarginRight() {
        return textMarginRight;
    }

    public void setTextMarginRight(float textMarginRight) {
        this.textMarginRight = textMarginRight;
    }

    public float getLineSize() {
        return lineSize;
    }

    public void setLineSize(float lineSize) {
        this.lineSize = lineSize;
    }


    public int getScoreValue() {
        return scoreValue;
    }

    public void setScoreValue(int scoreValue) {
        this.scoreValue = scoreValue;
        invalidate();
    }

    public int getmSpeed() {
        return mSpeed;
    }

    public void setmSpeed(int mSpeed) {
        this.mSpeed = mSpeed;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        // super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        int width = 0;
        int height = 0;

        /**
         * set width
         */

        int specMode = MeasureSpec.getMode(widthMeasureSpec);
        int specSize = MeasureSpec.getSize(widthMeasureSpec);
        switch (specMode)
        {
            case MeasureSpec.EXACTLY:
                width = getPaddingLeft() + getPaddingRight() + specSize;
                break;
            case MeasureSpec.AT_MOST:
                width = getPaddingLeft() + getPaddingRight() + mBound.width();
                break;
        }

        /**
         * set high
         */
        specMode = MeasureSpec.getMode(heightMeasureSpec);
        specSize = MeasureSpec.getSize(heightMeasureSpec);
        switch (specMode)
        {
            case MeasureSpec.EXACTLY:
                height = getPaddingTop() + getPaddingBottom() + specSize;
                break;
            case MeasureSpec.AT_MOST:
                height = getPaddingTop() + getPaddingBottom() + mBound.height();
                break;
        }

        setMeasuredDimension(width, height);

    }

    @Override
    protected void onDraw(Canvas canvas) {

        mPaint.setColor(getResources().getColor(R.color.white));
        canvas.drawRect(0, 0, getMeasuredWidth(), getMeasuredHeight(), mPaint);

        mPaint.setColor(getResources().getColor(R.color.orange));
        mPaint.setStrokeWidth(lineSize);
        canvas.drawLine(0, lineSize / 2, getMeasuredWidth(), lineSize / 2, mPaint);
        canvas.drawLine(lineSize / 2, 0, lineSize / 2, getMeasuredHeight(), mPaint);
        canvas.drawLine(getMeasuredWidth() - lineSize / 2, 0, getMeasuredWidth() - lineSize / 2, getMeasuredHeight() - lineSize, mPaint);
        canvas.drawLine(0, getMeasuredHeight() - lineSize / 2, getMeasuredWidth(), getMeasuredHeight() - lineSize / 2, mPaint);
//        canvas.drawLine(0, getMeasuredHeight() / 2, getMeasuredWidth(), getMeasuredHeight() / 2, mPaint);
        canvas.drawRect(0, 0, (float) (getMeasuredWidth() * mProgress / 100.0), getMeasuredHeight(), mPaint);

        if (mProgress == 100){
            mPaint.setColor(getResources().getColor(R.color.white));
        } else {
            mPaint.setColor(mTitleTextColor);
        }
        mPaint.setAntiAlias(true);
        if (mProgress == 0){
            canvas.drawText(String.valueOf(mProgress), textMarginLeft, getHeight() / 2 + mBound.height() / 2, mPaint);
        } else {
            if ((getWidth() * mProgress / 100.0 + mBound.width() + textMarginRight + textMarginLeft) > getWidth()) {
                mPaint.setTextSize(mTitleTextSize);
                mPaint.getTextBounds(mTitleText, 0, mTitleText.length(), mBound);
                canvas.drawText(String.valueOf(mProgress), (float) (getWidth() - mBound.width() - textMarginRight), getHeight() / 2 + mBound.height() / 2, mPaint);
            } else {
                canvas.drawText(String.valueOf(mProgress), (float) (getWidth() * mProgress / 100.0) + textMarginLeft, getHeight() / 2 + mBound.height() / 2, mPaint);
            }
        }

    }


    public void startDraw(){
                new Thread(){
            public void run(){
                while (mProgress != scoreValue){
                    mProgress++;
                    postInvalidate();
                    try {
                        Thread.sleep(mSpeed);
                    } catch (InterruptedException e){
                        e.printStackTrace();
                    }

                }
            }
        }.start();
    }
}
