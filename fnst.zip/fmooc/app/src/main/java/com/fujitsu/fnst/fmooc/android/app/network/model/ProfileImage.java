package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by wangc.fnst on 2016/1/14.
 */
public class ProfileImage implements Serializable {
    private String imageId;
    private String fileName;
    private String alt;

    public ProfileImage() {
    }

    public String getImageId() {
        return imageId;
    }

    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getAlt() {
        return alt;
    }

    public void setAlt(String alt) {
        this.alt = alt;
    }
}
