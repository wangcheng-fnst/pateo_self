package com.fujitsu.fnst.fmooc.android.app.data.model;

import com.fujitsu.fnst.fmooc.android.app.data.BaseModel;

import java.util.Date;

/**
 * Created by wangc.fnst on 2016/1/12.
 */
public class NoticeModel extends BaseModel {
    private String title;
    private String _id;
    private int id;
    private Date date;
    private String content;

    public NoticeModel() {
    }

    public NoticeModel(String title, String _id, int id, Date date, String content) {
        this.title = title;
        this._id = _id;
        this.id = id;
        this.date = date;
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
