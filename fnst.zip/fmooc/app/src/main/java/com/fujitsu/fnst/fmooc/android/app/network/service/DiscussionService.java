package com.fujitsu.fnst.fmooc.android.app.network.service;

import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.data.model.DiscussionModel;
import com.fujitsu.fnst.fmooc.android.app.network.ObserverConvert;
import com.fujitsu.fnst.fmooc.android.app.network.ServiceBuilder;
import com.fujitsu.fnst.fmooc.android.app.network.model.Message;
import com.fujitsu.fnst.fmooc.android.app.network.model.MessageDetailModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.MessageListModel;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import retrofit.Response;
import retrofit.http.*;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by wangc.fnst on 2016/1/5.
 */
public class DiscussionService {

    private static  DiscussionService instance;
    private DiscussionInterface service;

    public DiscussionService() {
        service = ServiceBuilder.getInstance().build(DiscussionInterface.class);
    }

    public  static DiscussionService getInstance(){
        if (instance == null){
            instance = new DiscussionService();
        }
        return instance;
    }

    public Subscription getMessages(String id,int page, Subscriber<List<DiscussionModel>> subscriber){
        Observable<Response<MessageListModel>> observable = service.getMessagesByIdAndPage(ApplicationUtils.getToken(), Constants.CONTENT_REFERER,id,page);
        return observable.flatMap(new ObserverConvert<MessageListModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Func1<MessageListModel, List<DiscussionModel>>() {
                    @Override
                    public List<DiscussionModel> call(MessageListModel messageListModel) {
                        List<DiscussionModel> list = new ArrayList<DiscussionModel>();
                        for (Message message : messageListModel.getMessages()){
                            DiscussionModel model = DiscussionModel.convertFromMessage(message);
                            list.add(model);
                        }
                        return list;
                    }
                })
                .subscribe(subscriber);
    }
    public Subscription getMessageById(String id,String mid ,Subscriber<DiscussionModel> subscriber){
        Observable<Response<MessageDetailModel>> observable = service.getMessageById(ApplicationUtils.getToken(), Constants.CONTENT_REFERER,id, mid);
        return observable.flatMap(new ObserverConvert<MessageDetailModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Func1<MessageDetailModel, DiscussionModel>() {
                    @Override
                    public DiscussionModel call(MessageDetailModel message) {
                        DiscussionModel model = DiscussionModel.convertFromMessage(message.getMessage());
                        return model;
                    }
                })
                .subscribe(subscriber);
    }

    public Subscription sendMessage(String id,String text, String replyTo, Subscriber<Message> subscriber){
        Observable<Response<Message>> observable = service.sendMessage(ApplicationUtils.getToken(), Constants.CONTENT_REFERER,id,text,replyTo);
        return observable.flatMap(new ObserverConvert<Message>())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(subscriber);
    }

    public interface DiscussionInterface{
        @GET("courses/{id}/discussion-board")
        Observable<Response<MessageListModel>> getMessagesByIdAndPage(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@Query("page") int pageNumber);

        @GET("courses/{id}/discussion-board/{mid}")
        Observable<Response<MessageDetailModel>> getMessageById(@Header("Fisdom-User-Token") String token, @Header("Referer") String referer,@Path("id") String id,@Path("mid") String mid);

        @FormUrlEncoded
        @POST("courses/{id}/discussion-board/new-message")
        Observable<Response<Message>> sendMessage(@Header("Fisdom-User-Token") String token, @Header("Referer") String referer,@Path("id") String id,@Field("text") String text,@Field("replyTo") String replyTo);
    }
}
