package com.fujitsu.fnst.fmooc.android.app.network;

import android.util.Log;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.TimeUtils;
import com.google.gson.*;
import com.squareup.okhttp.Interceptor;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.logging.HttpLoggingInterceptor;
import retrofit.GsonConverterFactory;
import retrofit.Retrofit;
import retrofit.RxJavaCallAdapterFactory;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Date;

/**
 * Created by wangc.fnst .
 */
public class ServiceBuilder {
    private static final String LOG_TAG = ServiceBuilder.class.getName();

    public static final String CONTENT_TYPE_JSON = "application/json";
    public static final String CONTENT_TYPE_FILE = "multipart/form-data";

    /**
     * http connect adapter
     */
    private  Retrofit retrofit;
    private static ServiceBuilder builder;
    Gson gson = new GsonBuilder()
            .registerTypeAdapter(Date.class, new DateSerializerUtil())
            .registerTypeAdapter(String.class, new StringSerializerUtil())
            .create();
    OkHttpClient client = new OkHttpClient();


    private ServiceBuilder(){
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        client.interceptors().add(interceptor);
        retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(client)
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }



    public synchronized static ServiceBuilder getInstance(){
       if (builder == null){
           builder = new ServiceBuilder();
       }
        return builder;
    }




    /**
     * create http service
     * @param clazz
     * @param <T>
     * @return
     */
    public <T> T build(Class<T> clazz){
        return retrofit.create(clazz);
    }





    private static class DateSerializerUtil implements JsonSerializer<Date>,JsonDeserializer<Date> {
        @Override
        public JsonElement serialize(Date date, Type type,
                                     JsonSerializationContext context) {
            //date to string
            return new JsonPrimitive(TimeUtils.formatToNetDay(date));
        }

        @Override
        public Date deserialize(JsonElement element, Type type, JsonDeserializationContext context)
                throws JsonParseException {
            //string to date
            return TimeUtils.parseNetDay(element.getAsJsonPrimitive().getAsString());
        }
    }

    private static class StringSerializerUtil implements JsonDeserializer<String>{


        @Override
        public String deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            return StringUtils.replaceJsonString(json.getAsJsonPrimitive().getAsString());
        }

    }
}
