package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.AgreementPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.SendSuccessPresenter;
import com.fujitsu.fnst.fmooc.android.app.view.SendSuccessViewInterface;

public class SendSuccessActivity extends BaseActivity<SendSuccessPresenter> implements SendSuccessViewInterface {

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new SendSuccessPresenter(this);
    }
    @Override
    protected int getLayout() {
        return R.layout.activity_send_success;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.login_forget_password);
    }
}
