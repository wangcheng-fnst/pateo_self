package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by lijl.fnst on 2016/02/02.
 */
public class Reflection implements Serializable {
    private String submittedReflectionText;
    private Date submittedAt;

    public String getSubmittedReflectionText() {
        return submittedReflectionText;
    }

    public void setSubmittedReflectionText(String submittedReflectionText) {
        this.submittedReflectionText = submittedReflectionText;
    }

    public Date getSubmittedAt() {
        return submittedAt;
    }

    public void setSubmittedAt(Date submittedAt) {
        this.submittedAt = submittedAt;
    }
}
