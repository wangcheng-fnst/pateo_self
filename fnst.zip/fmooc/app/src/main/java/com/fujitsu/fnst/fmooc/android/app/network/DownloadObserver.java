package com.fujitsu.fnst.fmooc.android.app.network;

import android.content.Intent;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.activity.LoginActivity;
import com.squareup.okhttp.ResponseBody;
import retrofit.Response;
import rx.Observable;
import rx.Subscriber;
import rx.functions.Func1;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * Created by wangc.fnst on 2016/1/13.
 */
public class DownloadObserver implements Func1<Response<ResponseBody>, Observable<Integer>> {
    @Override
    public Observable<Integer> call(Response<ResponseBody> tResponse) {
        return Observable.create(new NetObservable(tResponse));
    }

    class NetObservable implements Observable.OnSubscribe<Integer>{
        private Response<ResponseBody> serverResult;
        public NetObservable(Response<ResponseBody> serverResult) {
            this.serverResult = serverResult;
        }
        private void parseResponse(Response response ){
            for (String header : response.headers().names()){
                if (header.equals(Constants.CONTENT_TOKEN)){
                    String token = response.headers().get(Constants.CONTENT_TOKEN);
                    ApplicationUtils.setToken(token);
                }
            }
        }

        @Override
        public void call(Subscriber<? super Integer> subscriber) {
            try {
                if (serverResult.isSuccess()) {
                    parseResponse(serverResult);
                    int responseCode = serverResult.code();
                    File file = new File(FmoocApplication.staticDataPath + "/score.pdf");
                    ResponseBody body = (ResponseBody)serverResult.body();
                    InputStream is = body.byteStream();
                    if (!file.exists()) {
                        file.createNewFile();
                    } else {
                        file.delete();
                        file.createNewFile();
                    }
                    FileOutputStream fileOuputStream = null;
                    fileOuputStream = new FileOutputStream(file.getAbsolutePath());
                    int len;
                    int size = 1024;
                    byte[] buf;
                    buf = new byte[size];
                    while ((len = is.read(buf)) != -1) {
                        fileOuputStream.write(buf, 0, len);
                    }
                    if (responseCode == 200) {
                        subscriber.onNext(200);
                    } else if (responseCode == 201) {
                        subscriber.onNext(201);
                    }
                    subscriber.onCompleted();
                } else {
                    switch (serverResult.code()) {
                        case ErrorCode.ERROR_AUTH:
                            subscriber.onError(new ServerException(ErrorCode.ERROR_AUTH, "auth error " + serverResult.message()));
                            Intent intent = new Intent(FmoocApplication.getInstance(), LoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            FmoocApplication.getInstance().startActivity(intent);
                            break;
                        case ErrorCode.ERROR_NOT_FONT:
                            subscriber.onError(new ServerException(ErrorCode.ERROR_NOT_FONT, "not found" + serverResult.message()));
                            break;
                        case ErrorCode.ERROR_PARAMETER:
                            subscriber.onError(new ServerException(ErrorCode.ERROR_PARAMETER, "parameter error" + serverResult.message()));
                            break;
                        case ErrorCode.ERROR_PERMISSION:
                            subscriber.onError(new ServerException(ErrorCode.ERROR_PERMISSION, "permission error" + serverResult.message()));
                            break;
                        case ErrorCode.ERROR_TOO_LARGE:
                            subscriber.onError(new ServerException(ErrorCode.ERROR_TOO_LARGE, "uri too large error" + serverResult.message()));
                            break;
                        case ErrorCode.ERROR_URI:
                            subscriber.onError(new ServerException(ErrorCode.ERROR_URI, "uri error" + serverResult.message()));
                            break;
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
                subscriber.onError(e);
            }
        }

    }
}
