package com.fujitsu.fnst.fmooc.android.app.view;

/**
 * Created by wangc.fnst on 2015/12/7.
 */
public interface BaseViewInterface {

    void showToast(String msg);
    void hideWaitingDialog();
    void showWaitingDialog();
}
