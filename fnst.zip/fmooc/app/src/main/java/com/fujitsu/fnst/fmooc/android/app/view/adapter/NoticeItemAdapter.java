package com.fujitsu.fnst.fmooc.android.app.view.adapter;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.NoticeModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.RssItemModel;
import com.fujitsu.fnst.fmooc.android.app.repository.RssRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.TimeUtils;
import com.fujitsu.fnst.fmooc.android.app.view.activity.NoticeDetailActivity;

import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/12.
 */
public class NoticeItemAdapter extends BaseListViewAdapter<RssItemModel> {
    private List<RssItemModel> mData ;

    public NoticeItemAdapter(List<RssItemModel> mData) {
        super(mData);
        this.mData = mData;
    }

    @Override
    protected BaseViewHolder getViewHolder(View contentView) {
        return new ViewHolder(contentView);
    }

    @Override
    protected int getItemLayout() {
        return R.layout.notice_item;
    }

    @Override
    protected void setItemData(BaseViewHolder viewHolder, int position) {
        ViewHolder holder = (ViewHolder) viewHolder;
        RssItemModel model = (RssItemModel)getItem(position);
        if (model.getStatus() == RssItemModel.STATUS_UNREAD){
            holder.tittleTxt.setTextColor((FmoocApplication.getInstance().getApplicationContext().getResources().getColor(R.color.black)));
        }else {
            holder.tittleTxt.setTextColor((FmoocApplication.getInstance().getApplicationContext().getResources().getColor(R.color.font_dark_gray)));

        }
        holder.tittleTxt.setText(model.getTitle());
        holder.contentTxt.setText(model.getDescription());
        holder.dateTxt.setText(TimeUtils.format(model.getPubDate()));

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        super.onItemClick(parent, view, position, id);
        ViewHolder holder = (ViewHolder)view.getTag();
        RssItemModel model = (RssItemModel)getItem(position-1);
        holder.tittleTxt.setTextColor((FmoocApplication.getInstance().getApplicationContext().getResources().getColor(R.color.font_dark_gray)));
        model.setStatus(RssItemModel.STATUS_READED);
        RssRepository.getInstance().update(model);
        Intent intent = new Intent(FmoocApplication.getInstance().getApplicationContext(), NoticeDetailActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(Constants.EXTRA_NOTICE, model);
        FmoocApplication.getInstance().getApplicationContext().startActivity(intent);

    }

    class ViewHolder implements BaseViewHolder {
        @Bind(R.id.id_notice_title_txt)
        TextView tittleTxt;
        @Bind(R.id.id_notice_date_txt)
        TextView dateTxt;
        @Bind(R.id.id_notice_content_txt)
        TextView contentTxt;


        public ViewHolder(View view) {
            ButterKnife.bind(this,view);
        }
    }
}
