package com.fujitsu.fnst.fmooc.android.app.view.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;

import java.util.List;
import java.util.Objects;

/**
 * Created by wangc.fnst on 2015/12/16.
 */
public abstract  class BaseListViewAdapter<T> extends BaseAdapter implements AdapterView.OnItemClickListener{

    protected List<T>  mData;

    public BaseListViewAdapter(List<T> mData) {
        this.mData = mData;
    }

    @Override
    public int getCount() {
        return mData == null?0:mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData == null?null:mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        BaseViewHolder viewHolder = null;
        if (convertView == null){
            convertView = LayoutInflater.from(FmoocApplication.getInstance().getApplicationContext())
                    .inflate(getItemLayout(),parent,false);
            viewHolder = getViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else{
            viewHolder =  (BaseViewHolder)convertView.getTag();
        }
        setItemData(viewHolder,position);

        return convertView;
    }

    protected abstract BaseViewHolder getViewHolder(View contentView);
    protected abstract int getItemLayout();
    protected abstract void setItemData(BaseViewHolder viewHolder,int position);

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }
}
