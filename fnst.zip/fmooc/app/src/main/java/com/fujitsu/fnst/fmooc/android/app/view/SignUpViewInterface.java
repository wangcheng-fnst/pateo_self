package com.fujitsu.fnst.fmooc.android.app.view;

import android.text.TextWatcher;

/**
 * Created by lijl.fnst on 2015/12/10.
 */
public interface SignUpViewInterface extends BaseViewInterface {
    void enableBtn();
    void disableBtn();
    String getEmail();
    void setEmailListener(TextWatcher watcher);
}
