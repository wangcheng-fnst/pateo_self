package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.TextView;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.HelpPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.ProfileSelectPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ProfileSelectViewInterface;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import butterknife.Bind;

public class ProfileSelectActivity extends BaseActivity<ProfileSelectPresenter> implements ProfileSelectViewInterface {

    @Bind(R.id.id_title_content_txt)
    TextView contentText;
    @Bind(R.id.profile_sex_list)
    Spinner sexList;
    @Bind(R.id.profile_education_list)
    Spinner educationList;
    @Bind(R.id.profile_year_list)
    Spinner yearList;
    @Bind(R.id.profile_firstname_edit)
    EditText firstnameEdit;
    @Bind(R.id.id_profile_btn)
    Button saveBtn;
    @Bind(R.id.profile_firstname_info)
    TextView firstnameInfo;

    private ArrayAdapter sexAdapter;
    private ArrayAdapter educationAdapter;
    private ArrayAdapter yearAdapter;
    private List<String> data_list;
    private String defaultData;
    private int yearPosition = 0;

    protected void onCreateView() {
        super.onCreateView();
        presenter = new ProfileSelectPresenter(this);
        Intent intent = getIntent();
        int type = intent.getIntExtra(Constants.PROFILE_SETTING_TYPE, Constants.PROFILE_SETTING_FIRSTNAME);
        defaultData = intent.getStringExtra("defaultData");
        presenter.setProfileType(type);
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        data_list = new ArrayList<String>();
        for (int i=0;i < 120; i++){
            if(year < 1900)
                break;
            if (defaultData != null && type == Constants.PROFILE_SETTING_BIRTHDAY){
                if (year == Integer.parseInt(defaultData)){
                    yearPosition = i;
                }
            }

            data_list.add(Integer.toString(year));
            year--;
        }

        sexAdapter = ArrayAdapter.createFromResource(this, R.array.sex, android.R.layout.select_dialog_item);
        sexAdapter.setDropDownViewResource(android.R.layout.select_dialog_item);
        sexList.setAdapter(sexAdapter);
        sexList.setOnItemSelectedListener(new SpinnerXMLSelectedListener());

        yearAdapter = new ArrayAdapter<String> (this, android.R.layout.select_dialog_item, data_list);
        yearAdapter.setDropDownViewResource(android.R.layout.select_dialog_item);
        yearList.setAdapter(yearAdapter);
        yearList.setOnItemSelectedListener(new SpinnerXMLSelectedListener());

        educationAdapter = ArrayAdapter.createFromResource(this, R.array.education, android.R.layout.select_dialog_item);
        educationAdapter.setDropDownViewResource(android.R.layout.select_dialog_item);
        educationList.setAdapter(educationAdapter);
        educationList.setOnItemSelectedListener(new SpinnerXMLSelectedListener());

        saveBtn.setOnClickListener(this);
        hideAll();
        presenter.showSetting();
        contentText.setText(presenter.getTitleStr());
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_profile_select;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.profile_firstname_title);
    }

    @Override
    public void enableBtn() {
        saveBtn.setClickable(true);
        saveBtn.setAlpha(1);
        saveBtn.setOnClickListener(this);
        saveBtn.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public void disableBtn() {
        saveBtn.setClickable(false);
        saveBtn.setAlpha(0.5f);
        saveBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }

    @Override
    public void hideAll(){
        firstnameEdit.setVisibility(View.GONE);
        firstnameInfo.setVisibility(View.GONE);
        sexList.setVisibility(View.GONE);
        educationList.setVisibility(View.GONE);
    }

    @Override
    public void showFirstname(){
        if (defaultData != null){
            firstnameEdit.setText(defaultData);
        } else {
            disableBtn();
        }
        firstnameEdit.setVisibility(View.VISIBLE);
        firstnameInfo.setVisibility(View.VISIBLE);
    }
    @Override
    public void showSex(){
        if (defaultData != null){
            if (defaultData.equals(Constants.MALE)){
                sexList.setSelection(0,true);
            } else if (defaultData.equals(Constants.FEMALE)){
                sexList.setSelection(1,true);
            } else if (defaultData.equals(Constants.OTHER)){
                sexList.setSelection(2,true);
            }
        }

        sexList.setVisibility(View.VISIBLE);
    }
    @Override
    public void showEducation(){
        if (defaultData != null){
            String [] educate = getResources().getStringArray(R.array.education);
            for (int i = 0 ;i < educate.length;i++){
                 if (educate[i].equals(defaultData)){
                     educationList.setSelection(i, true);
                 }
            }
        }
        educationList.setVisibility(View.VISIBLE);
    }
    @Override
    public void showYear(){
        if (defaultData != null){
            yearList.setSelection(yearPosition, true);
        }else {
            yearList.setSelection(0, true);
        }
        yearList.setVisibility(View.VISIBLE);
    }


    @Override
    public String getName() {
        return firstnameEdit.getText().toString();
    }

    class SpinnerXMLSelectedListener implements OnItemSelectedListener {
        public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                                   long arg3) {
            presenter.setData(arg0.getItemAtPosition(arg2).toString());
        }

        public void onNothingSelected(AdapterView<?> arg0) {

        }

    }

    @Override
    public void setNameListener(TextWatcher watcher) {
        firstnameEdit.addTextChangedListener(watcher);
    }

    public void onClick(View v){
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if(v.getId() == R.id.id_profile_btn){
            presenter.saveClick();
        }
    }


}
