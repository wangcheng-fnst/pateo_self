package com.fujitsu.fnst.fmooc.android.app.view.component;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.EditText;

/**
 * Created by wangc.fnst on 2016/1/4.
 */
public class AutoHintEditText extends EditText {

    private String hintText;
    private String hintColor;
    public AutoHintEditText(Context context) {
        super(context);
    }

    public AutoHintEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public String getHintText() {
        return hintText;
    }

    public void setHintText(String hintText) {
        this.hintText = hintText;
        invalidate();
    }

    public String getHintColor() {
        return hintColor;
    }

    public void setHintColor(String hintColor) {
        this.hintColor = hintColor;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setTextSize(getTextSize());
        paint.setColor(Color.BLACK);
        canvas.drawText("no",10,getHeight() / 2, paint);
        super.onDraw(canvas);
    }
}
