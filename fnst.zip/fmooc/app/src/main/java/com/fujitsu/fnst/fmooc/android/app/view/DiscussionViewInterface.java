package com.fujitsu.fnst.fmooc.android.app.view;

import android.widget.LinearLayout;
import com.fujitsu.fnst.fmooc.android.app.data.model.DiscussionModel;

import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public interface DiscussionViewInterface extends BaseViewInterface {

    String getEditContent();
    void notifyData(boolean isToBottom);
    void setIsToOther(boolean isToOther);
    void removeEditListener();
    void onLoad();
    String getId();
    void notify(boolean isRefresh);
    void addItems(List<DiscussionModel> data);
    void addItem(DiscussionModel model);
    void resetData();
    LinearLayout getDiscussionLayout();
    LinearLayout getDiscussionErrorLayout();
    void setMessage(DiscussionModel model);
}
