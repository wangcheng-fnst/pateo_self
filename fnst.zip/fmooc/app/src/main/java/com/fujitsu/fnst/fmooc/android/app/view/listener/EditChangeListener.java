package com.fujitsu.fnst.fmooc.android.app.view.listener;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;

/**
 * Created by wangc.fnst on 2015/12/10.
 */
public class EditChangeListener implements TextWatcher {

    public interface  TextChangeCallback{
        void formatRight();
    }
    private String oldValue = "";
    private TextChangeCallback callback;



    public TextChangeCallback getCallback() {
        return callback;
    }

    public void setCallback(TextChangeCallback callback) {
        this.callback = callback;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        Log.e("EditChangeListener",s.toString());
        String value = s.toString();
//        if (!StringUtils.isBlank(oldValue)){// 非空
            if (!oldValue.equals(value)){// 发生了改变
                oldValue = value;
                if (getCallback() != null) {
                    getCallback().formatRight();
//                }
            }
        }
    }
}
