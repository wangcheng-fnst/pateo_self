package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/13.
 */
public class Course implements Serializable {

    /**
     * course states
     */
    public static final String COURSE_STATUS_NOT_OPEN = "notYetOpen";
    public static final String COURSE_STATUS_OPEN = "open";
    public static final String COURSE_STATUS_CLOSE = "close";
    public static final String COURSE_STATUS_UNAVAILABLE = "unavailable";
    public static final String USER_STATUS_NOT_ENROLLED = "notEnrolled";
    public static final String USER_STATUS_ENROLLED = "enrolled";
    public static final String USER_STATUS_COMPLETED = "completed";
    public static final String USER_STATUS_ABORTED = "aborted";


    private String courseId;
    private User author;
    private String name;
    private String thumbnailImageFile;
    private String demoVideoYoutubeId;
    private String shortDescription;
    private String longDescription;
    private String status;
    private List<PlayList> playlists;
    private Date mayEnrollFrom;
    private Date shouldEnrollBefore;
    private Date startsAt;
    private Date endsAt;
    private CompletionCriteria completionCriteria;
    private int courseCode;
    private int maxScore;
    private Date lastUpdatedAt;
    private String userStatus;
    private int userScore;
    private boolean isEnrolled;

    public Course() {
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }




    public String getDemoVideoYoutubeId() {
        return demoVideoYoutubeId;
    }

    public void setDemoVideoYoutubeId(String demoVideoYoutubeId) {
        this.demoVideoYoutubeId = demoVideoYoutubeId;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<PlayList> getPlaylists() {
        return playlists;
    }

    public void setPlaylists(List<PlayList> playlists) {
        this.playlists = playlists;
    }

    public String getThumbnailImageFile() {
        return thumbnailImageFile;
    }

    public void setThumbnailImageFile(String thumbnailImageFile) {
        this.thumbnailImageFile = thumbnailImageFile;
    }

    public Date getMayEnrollFrom() {
        return mayEnrollFrom;
    }

    public void setMayEnrollFrom(Date mayEnrollFrom) {
        this.mayEnrollFrom = mayEnrollFrom;
    }

    public Date getShouldEnrollBefore() {
        return shouldEnrollBefore;
    }

    public void setShouldEnrollBefore(Date shouldEnrollBefore) {
        this.shouldEnrollBefore = shouldEnrollBefore;
    }

    public Date getStartsAt() {
        return startsAt;
    }

    public void setStartsAt(Date startsAt) {
        this.startsAt = startsAt;
    }

    public Date getEndsAt() {
        return endsAt;
    }

    public void setEndsAt(Date endsAt) {
        this.endsAt = endsAt;
    }

    public CompletionCriteria getCompletionCriteria() {
        return completionCriteria;
    }

    public void setCompletionCriteria(CompletionCriteria completionCriteria) {
        this.completionCriteria = completionCriteria;
    }

    public int getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(int courseCode) {
        this.courseCode = courseCode;
    }

    public int getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(int maxScore) {
        this.maxScore = maxScore;
    }

    public Date getLastUpdatedAt() {
        return lastUpdatedAt;
    }

    public void setLastUpdatedAt(Date lastUpdatedAt) {
        this.lastUpdatedAt = lastUpdatedAt;
    }

    public int getUserScore() {
        return userScore;
    }

    public void setUserScore(int userScore) {
        this.userScore = userScore;
    }

    public boolean isEnrolled() {
        return isEnrolled;
    }

    public void setIsEnrolled(boolean isEnrolled) {
        this.isEnrolled = isEnrolled;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }
}
