package com.fujitsu.fnst.fmooc.android.app.presenter;

import com.fujitsu.fnst.fmooc.android.app.view.ReportHelpViewInterface;

/**
 * Created by lijl.fnst on 2016/02/05.
 */
public class ReportHelpPresenter extends BasePresenter{
    private ReportHelpViewInterface view;
    public ReportHelpPresenter(ReportHelpViewInterface reportHelpViewInterface){
        super();
        view = reportHelpViewInterface;
    }
}
