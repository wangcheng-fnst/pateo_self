package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.PaintDrawable;
import android.util.Log;
import android.view.*;
import android.widget.*;

import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.data.model.ListHeadModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Content;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.network.model.CourseClip;
import com.fujitsu.fnst.fmooc.android.app.network.model.PlayList;
import com.fujitsu.fnst.fmooc.android.app.presenter.CoursePlayPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.CoursePlayViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.ExpandableAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.stickylistheaders.ExpandableStickyListHeadersListView;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.VideoPlayFragment;
import com.fujitsu.fnst.fmooc.android.app.view.listener.OnHeaderClickListener;
import com.google.android.youtube.player.YouTubePlayer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/22.
 */
public class CoursePlayActivity extends BaseActivity<CoursePlayPresenter> implements CoursePlayViewInterface,YouTubePlayer.OnFullscreenListener,VideoPlayFragment.SuccessPlayerInitListener {


    @Bind(R.id.id_play_layout)
    FrameLayout playLayout;
    @Bind(R.id.id_title_layout)
    LinearLayout topLayout;
    @Bind(R.id.id_course_list)
    ExpandableStickyListHeadersListView expandableCourseList;
    @Bind(R.id.id_title_right_layout)
    LinearLayout rightLayout;
    private ExpandableAdapter expandableAdapter;
    @Bind(R.id.id_course_txt)
    TextView courseTxt;
    @Bind(R.id.id_line)
    View line;
    @Bind(R.id.id_play_list_layout)
    FrameLayout playListLayout;
    //while course unavailable this layout will visible otherwise gone
    @Bind(R.id.id_no_playlist_layout)
    LinearLayout noPlaylistLayout;



    private List<CourseModel> datas = new ArrayList<CourseModel>();
    private List<ListHeadModel> headers = new ArrayList<ListHeadModel>();
    VideoPlayFragment playFragment;
    private boolean fullscreen;
    private boolean isFirst = true;
    private boolean isFirst2 = true;
    private int height;

    PopupWindow popupWindow;
    private String courseId;
    private Course course;
    @Override
    protected int getLayout() {
        return R.layout.course_play_activity_layout;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return true;
    }

    /**
     * 受講中コース詳細
     * @return
     */
    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.play_title);
    }


    @Override
    protected void onCreateView() {
        super.onCreateView();
        courseId = getIntent().getStringExtra(Constants.EXTRA_COURSE_ID);
        playFragment = (VideoPlayFragment) getFragmentManager().findFragmentById(R.id.video_fragment_container);
        playFragment.setSuccessPlayerInitListener(this);
        presenter = new CoursePlayPresenter(courseId,this, datas, playFragment,headers);
    }

    @Override
    protected void onResume() {
        Log.e("CoursePlayActivity", "onResume");
        super.onResume();
        if (popupWindow!= null && popupWindow.isShowing()){
            popupWindow.dismiss();
        }
    }


    public void showPlayList(){
        expandableCourseList.setVisibility(View.VISIBLE);
        noPlaylistLayout.setVisibility(View.GONE);
    }
    //while course unavailable
    public void showNoPlayList(){
        expandableCourseList.setVisibility(View.GONE);
        noPlaylistLayout.setVisibility(View.VISIBLE);
    }

    private void newCreate() {
        datas = new ArrayList<CourseModel>();
        headers = new ArrayList<ListHeadModel>();
        if (course != null) {
            if (course.getStatus().equals(Course.COURSE_STATUS_UNAVAILABLE)){
                showNoPlayList();
                return;
            }else {
                showPlayList();
            }
            for (int i = 0; i < course.getPlaylists().size();i++){
                PlayList playList = course.getPlaylists().get(i);
                ListHeadModel headModel = new ListHeadModel();
                headModel.setAuthor(playList.getAuthor());
                headModel.setDescription(playList.getDescription());
                headModel.setName(playList.getName());
                headModel.setPlaylistId(playList.getPlaylistId());
                headModel.setId(i);
                headModel.setIcon(R.drawable.arrow_down);
                for (int j =0; j < playList.getContents().size();j++){
                    Content content = playList.getContents().get(j);
                    CourseModel courseModel = new CourseModel();
                    courseModel.setAuthorId(content.getAuthorId());
                    courseModel.setContentId(content.getContentId());
                    courseModel.setCourseId(content.getCourseId());
                    courseModel.setDescription(content.getDescription());
                    courseModel.setLengthInSeconds(content.getLengthInSeconds());
                    courseModel.setName(content.getName());
                    courseModel.setPlaylistId(content.getPlaylistId());
                    courseModel.setPercentageViewed(content.getPercentageViewed());
//                    if (content.getPercentageViewed() > 0){
//                        courseModel.setState(CourseClip.STATE_VIEWED);
//                    }else {
//                        courseModel.setState(CourseClip.STATE_CANVIEW);
//                    }
                    if (content.getState() != null){
                        courseModel.setState(content.getState());
                    }else {
                        courseModel.setState(CourseClip.STATE_CANVIEW);
                    }
//                    if (content.getPercentageViewed() > 0 && content.getPercentageViewed() < 100){
//                        courseModel.setState(CourseClip.STATE_CANVIEW);
//                    }

                    courseModel.setYoutubeId(content.getYoutubeId());
                    courseModel.setpId(i);
                    if (content.getContentType() != null){
                        courseModel.setContentType(content.getContentType());
                    }else {
                        courseModel.setContentType(CourseClip.TYPE_COURSECLIP);
                    }
                    courseModel.setReportTitle(content.getReportTitle());
                    courseModel.setReportLabel(content.getReportLabel());
//                    courseModel.setContentType(content.getContentType());
                    datas.add(courseModel);
                }
                headers.add(headModel);

            }
            if (course.getStatus() != null
                    && course.getStatus().equals(Course.COURSE_STATUS_OPEN)
                    && course.getUserStatus() != null
                    && course.getUserStatus().equals(Course.USER_STATUS_ENROLLED)) {
                //while course open and user enrolled
                ListHeadModel enFellow = new ListHeadModel();
                enFellow.setId(course.getPlaylists().size());
                enFellow.setType("btn");
                CourseModel dismissModel = new CourseModel();
                dismissModel.setpId(course.getPlaylists().size());
                dismissModel.setState(CourseClip.STATE_CANNOTVIEW);
                dismissModel.setContentType(CourseClip.TYPE_REMOVE);
                datas.add(dismissModel);
                headers.add(enFellow);
            }

        }
    }





    /**
     * when meue btn click show popupWindow
     * @param v
     */
    private void showMore(View v){
        if (course != null) {
            View popupWindow_view = getLayoutInflater().inflate(R.layout.course_popupindow, null, false);
            popupWindow = new PopupWindow(popupWindow_view, ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.WRAP_CONTENT, true);
            popupWindow.setFocusable(true);
            popupWindow.setBackgroundDrawable(new BitmapDrawable());
            popupWindow.showAsDropDown(v, 0, 0, Gravity.RIGHT | Gravity.TOP);
            Button courseDetailBtn = (Button) popupWindow_view.findViewById(R.id.id_course_btn);
            Button scoreBtn = (Button) popupWindow_view.findViewById(R.id.id_score_btn);
            Button credentialsBtn = (Button) popupWindow_view.findViewById(R.id.id_credentials_btn);
            Button discussBtn = (Button) popupWindow_view.findViewById(R.id.id_discuss_btn);
            Button dismissBtn = (Button) popupWindow_view.findViewById(R.id.id_dismiss_btn);

            discussBtn.setOnClickListener(this);
            courseDetailBtn.setOnClickListener(this);
            scoreBtn.setOnClickListener(this);
            credentialsBtn.setOnClickListener(this);
            if (Course.USER_STATUS_ENROLLED.equals(course.getUserStatus())) {
                credentialsBtn.setVisibility(View.GONE);
            } else {
                courseDetailBtn.setVisibility(View.VISIBLE);
            }
            if (Course.COURSE_STATUS_UNAVAILABLE.equals(course.getStatus())) {
                discussBtn.setVisibility(View.GONE);
            } else {
                discussBtn.setVisibility(View.VISIBLE);
            }
            popupWindow.setOutsideTouchable(true);

            popupWindow_view.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (popupWindow != null && popupWindow.isShowing()) {
                        popupWindow.dismiss();
                        popupWindow = null;
                    }
                    return false;
                }
            });
        }else {
            showToast("server error");
        }

    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_down_img){
        }else if (v.getId() == R.id.id_title_right_layout) {
            showMore(v);
        } else if (v.getId() == R.id.id_discuss_btn){
            popupWindow.dismiss();
            popupWindow = null;
            Intent intent = new Intent(this,DiscussionActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(Constants.EXTRA_COURSE_ID,course.getCourseId());
            intent.putExtra(Constants.EXTRA_STATUS,course.getStatus());
            intent.putExtra(Constants.EXTRA_USER_STATUS,course.getUserStatus());
            startActivity(intent);
        } else if (v.getId() == R.id.id_course_btn){
            popupWindow.dismiss();
            popupWindow = null;
            //to course detail activity
            Intent intent = new Intent(this,CourseDetailNewActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(Constants.EXTRA_COURSE_ID,course.getCourseId());
            startActivity(intent);

        } else if (v.getId() == R.id.id_score_btn){
            //to score activity
            popupWindow.dismiss();
            popupWindow = null;
            Intent intent = new Intent(this,ScoreActivity.class);
            intent.putExtra("playlist", course);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else if (v.getId() == R.id.id_credentials_btn){
            //to credentials activity
            popupWindow.dismiss();
            popupWindow = null;
            presenter.goCredentials();
        }
    }

    @Override
    public void setSelection(int position) {
        expandableAdapter.getHeadItem(position).setIcon(R.drawable.arrow_up);
        expandableCourseList.expand(expandableAdapter.getHeaderId(position));
        expandableCourseList.setSelection(position);
        presenter.setPlayIngPosition(position);

    }

    @Override
    public ExpandableStickyListHeadersListView getListView() {
        return expandableCourseList;
    }

    @Override
    public void back() {
        super.onBackPressed();
    }

    @Override
    public void setData(Course course) {
        this.course = course;
        newCreate();
        presenter.setListView(expandableCourseList);
        presenter.setPlaylist(datas);
        presenter.setHeadModels(headers);
        courseTxt.getPaint().setFakeBoldText(true);
        courseTxt.setText(course.getName());
        expandableAdapter = new ExpandableAdapter(datas, this);
        expandableAdapter.setmHeaders(headers);
        expandableAdapter.setListener(presenter);
        expandableCourseList.setAdapter(expandableAdapter);
        expandableCourseList.setCollapse(true);
        expandableCourseList.setOnHeaderClickListener(new OnHeaderClickListener(expandableCourseList, expandableAdapter, presenter));
        presenter.setAdapter(expandableAdapter);
        expandableCourseList.setOnItemClickListener(presenter);
        rightLayout.setOnClickListener(this);
        playLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (isFirst) {
                    isFirst = false;
                    height = playLayout.getLayoutParams().height;

                }

            }
        });
        expandableCourseList.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (isFirst2) {
                    isFirst2 = false;
                    int j =-1;
                    for (int i = 0; i < datas.size() - 1; i++) {
                        if (datas.get(i).getContentType().equals(CourseClip.TYPE_COURSECLIP)
                        && datas.get(i).getState().equals(CourseClip.STATE_VIEWED)) {
                            j = i;
                        }
                    }
                    //TODO:play the last video
                    Log.e("j------",j+"");
                    if (j > -1) {
                        setSelection(j+1);
                    }else {
                        setSelection(0);
                    }
                }
            }
        });

    }

    @Override
    public void showDialog(Dialog dialog) {
        dialog.show();
    }


    @Override
    public void onFullscreen(boolean b) {
        fullscreen = b;
        doLayout();
    }
    private void doLayout(){
        LinearLayout.LayoutParams playerParams =
                (LinearLayout.LayoutParams) playLayout.getLayoutParams();
        if (fullscreen){
            playerParams.width = LinearLayout.LayoutParams.MATCH_PARENT;
            playerParams.height = LinearLayout.LayoutParams.MATCH_PARENT;
            topLayout.setVisibility(View.GONE);
            playListLayout.setVisibility(View.GONE);
            line.setVisibility(View.GONE);
            courseTxt.setVisibility(View.GONE);
        }else{
            playerParams.width = LinearLayout.LayoutParams.MATCH_PARENT;
            playerParams.height = height;
            topLayout.setVisibility(View.VISIBLE);
            playListLayout.setVisibility(View.VISIBLE);
            line.setVisibility(View.VISIBLE);
            courseTxt.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBackPressed() {

        if (fullscreen){
            playFragment.setFullscreen(!fullscreen);
        }else {
            if (popupWindow != null && popupWindow.isShowing()){
                popupWindow.dismiss();
            }else {
                super.onBackPressed();
            }
        }
    }

    @Override
    public void onSuccessInit(boolean isOnResume) {
        if (!isOnResume) {
            playFragment.setOnFullscreenListener(this);
            presenter.init();
            presenter.setChangeListener();
        }else {
            presenter.resumePlayer();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data != null) {
            switch (resultCode) {
                case Constants.PROFILE_SETTING_FIRSTNAME:
                    break;
            }
        }
    }
}
