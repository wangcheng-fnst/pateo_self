package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import butterknife.Bind;
import cn.pedant.SweetAlert.SweetAlertDialog;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.CourseDetailPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.view.CourseDetailViewInterface;
import com.fujitsu.fnst.videoplayer.app2.model.Video;
import com.fujitsu.fnst.videoplayer.app2.util.DensityUtil;
import com.fujitsu.fnst.videoplayer.app2.view.MediaController;
import com.fujitsu.fnst.videoplayer.app2.view.SuperVideoPlayer;

import java.util.ArrayList;

/**
 * Created by wangc.fnst on 2015/12/21.
 */
public class CourseDetailActivity extends BaseActivity<CourseDetailPresenter> implements CourseDetailViewInterface {

    @Bind(R.id.id_play_btn)
    ImageView playBtn;
    @Bind(R.id.id_video_view)
    SuperVideoPlayer videoPlayer;
    @Bind(R.id.id_title_layout)
    View titleView;
    @Bind(R.id.id_introduce_layout)
    LinearLayout introduceLayout;
    private SweetAlertDialog dialog;


    @Override
    protected int getLayout() {
        return R.layout.course_detail_activity_layout_old;
    }

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new CourseDetailPresenter(this);
        playBtn.setOnClickListener(this);

    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.detail_title);
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_play_btn) {
            dismissPlayBtn();
            showVideoPlayer();
            videoPlayer.setAutoHideController(false);
            presenter.loadVideo();
        }
    }

    @Override
    public void onBackPressed() {
        if (getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            setPageType(MediaController.PageType.SHRINK);
            showIntroduce();
            showTitleBar();
        }else{
            super.onBackPressed();
        }
    }

    @Override
    public void showWaitingDialog() {
        if (dialog == null) {
            dialog = new SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        }
        dialog.getProgressHelper().setBarColor(getResources().getColor(R.color.blue));
        dialog.setTitleText("Wait.....");
        dialog.setCancelable(true);
        dialog.show();
    }

    @Override
    public void dismissWaitingDialog() {
        if (dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    @Override
    public void loadVideo(ArrayList<Video> videos) {
        videoPlayer.loadMultipleVideo(videos, 0, 0, 0);
    }

    @Override
    public void setVideoPlayCallback(SuperVideoPlayer.VideoPlayCallbackImpl callback) {
        videoPlayer.setVideoPlayCallback(callback);

    }

    /**
     * 恢复屏幕至竖屏
     */
    @Override
    public void resetPageToPortrait() {
        if (getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            videoPlayer.setPageType(MediaController.PageType.SHRINK);
        }
    }

    @Override
    public void showPlayBtn() {
        playBtn.setVisibility(View.VISIBLE);
    }

    @Override
    public void dismissPlayBtn() {
        playBtn.setVisibility(View.GONE);

    }

    @Override
    public void showVideoPlayer() {
        videoPlayer.setVisibility(View.VISIBLE);
    }

    @Override
    public void dismissVideoPlayer() {
        videoPlayer.setVisibility(View.INVISIBLE);
    }

    @Override
    public void videoClose() {
        videoPlayer.close();
    }

    @Override
    public void setPageType(MediaController.PageType pageType) {
        videoPlayer.setPageType(pageType);
    }

    @Override
    public void showTitleBar() {
        titleView.setVisibility(View.VISIBLE);
    }

    @Override
    public void dismissTitleBar() {
        titleView.setVisibility(View.GONE);
    }

    @Override
    public void showIntroduce() {
        introduceLayout.setVisibility(View.VISIBLE);

    }

    @Override
    public void dismissIntroduce() {
        introduceLayout.setVisibility(View.GONE);

    }

    /**
     * 旋转屏幕之后回调
     *
     * @param newConfig newConfig
     */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (null == videoPlayer) return;
        /***
         * 根据屏幕方向重新设置播放器的大小
         */
        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().getDecorView().invalidate();
            float height = DensityUtil.getWidthInPx(this);
            float width = DensityUtil.getHeightInPx(this);
            videoPlayer.getLayoutParams().height = (int) width;
            videoPlayer.getLayoutParams().width = (int) height;
        } else if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            final WindowManager.LayoutParams attrs = getWindow().getAttributes();
            attrs.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().setAttributes(attrs);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            float width = DensityUtil.getWidthInPx(this);
            float height = DensityUtil.dip2px(this, 200.f);
            videoPlayer.getLayoutParams().height = (int) height;
            videoPlayer.getLayoutParams().width = (int) width;
        }
    }
}
