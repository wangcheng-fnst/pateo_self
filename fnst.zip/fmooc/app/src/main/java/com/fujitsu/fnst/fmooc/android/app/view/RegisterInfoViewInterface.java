package com.fujitsu.fnst.fmooc.android.app.view;

/**
 * Created by lijl.fnst on 2015/12/14.
 */
public interface RegisterInfoViewInterface extends BaseViewInterface{

}
