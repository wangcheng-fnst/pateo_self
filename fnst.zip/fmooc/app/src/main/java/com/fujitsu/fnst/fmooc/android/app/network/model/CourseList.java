package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/13.
 */
public class CourseList implements Serializable {
    private List<Course> courses;
    private Course course;

    public CourseList() {
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses){
        this.courses=courses;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
}
