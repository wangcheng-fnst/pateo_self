package com.fujitsu.fnst.fmooc.android.app.presenter;

import com.fujitsu.fnst.fmooc.android.app.view.AppAboutViewInterface;

/**
 * Created by lijl.fnst on 2015/12/15.
 */
public class AppAboutPresenter extends BasePresenter {
    private AppAboutViewInterface view;

    public AppAboutPresenter(AppAboutViewInterface viewInterface){
        super();
        view = viewInterface;
    }
}
