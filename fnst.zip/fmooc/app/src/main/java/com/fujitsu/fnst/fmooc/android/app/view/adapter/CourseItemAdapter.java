package com.fujitsu.fnst.fmooc.android.app.view.adapter;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.activity.CourseDetailActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.CourseDetailNewActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.CoursePlayActivity;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.List;
import java.util.Objects;

/**
 * Created by wangc.fnst on 2015/12/16.
 */
public class CourseItemAdapter extends BaseListViewAdapter<Course> {

    private int from;

    public CourseItemAdapter(List<Course> mData, int from) {
        super(mData);
        this.from = from;
    }

    @Override
    protected ViewHolder getViewHolder(View contentView) {
        return new ViewHolder(contentView);
    }

    @Override
    protected int getItemLayout() {
        return R.layout.top_item_layout;
    }


    @Override
    protected void setItemData(BaseViewHolder viewHolder, int position) {
        Course item = (Course) getItem(position);
        ViewHolder holder = (ViewHolder) viewHolder;
        String url = Constants.HOST_NAME+"images/"+item.getThumbnailImageFile();
        ImageLoader.getInstance().displayImage(url, holder.img);
        holder.nameTxt.setText(item.getName());
        if (item.getAuthor() != null) {
            holder.teaTxt.setText(item.getAuthor().getDisplayName());
        }
//        if(from == 0){
//            Log.e("getUserStatus",item.getName()+":"+item.getUserStatus());
//            if(item.getUserStatus()!=null &&item.getUserStatus().equals(Course.USER_STATUS_ENROLLED)){
//                holder.statusTxt.setVisibility(View.VISIBLE);
//                holder.statusTxt.setText(FmoocApplication.getInstance().getApplicationContext().getResources().getString(R.string.course_doing));
//            } else {
//                holder.statusTxt.setVisibility(View.GONE);
//            }
//        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        super.onItemClick(parent, view, position, id);
        Course course = (Course) getItem(position - 1);
        Intent intent = null;
        if (course.getUserStatus()!= null
                && (course.getUserStatus().equals(Course.USER_STATUS_ENROLLED)
                || course.getUserStatus().equals(Course.USER_STATUS_COMPLETED))) {
            intent = new Intent(FmoocApplication.getInstance().getApplicationContext(), CoursePlayActivity.class);
        } else {
            intent = new Intent(FmoocApplication.getInstance().getApplicationContext(), CourseDetailNewActivity.class);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(Constants.EXTRA_COURSE_ID, ((Course) getItem(position - 1)).getCourseId());
        FmoocApplication.getInstance().getApplicationContext().startActivity(intent);
    }

    class ViewHolder implements BaseViewHolder {
        @Bind(R.id.id_content_img)
        ImageView img;
        @Bind(R.id.id_name_txt)
        TextView nameTxt;
        @Bind(R.id.id_tea_txt)
        TextView teaTxt;
        @Bind(R.id.id_status_txt)
        TextView statusTxt;

        public ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
