package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.SendPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.view.SendViewInterface;

/**
 * Created by wangc.fnst on 2015/12/11.
 */
public class SendActivity extends BaseActivity<SendPresenter> implements SendViewInterface {

    @Bind(R.id.id_send_btn)
    Button sendBtn;
    @Bind(R.id.id_email_edit)
    EditText emailEdit;


    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new SendPresenter(this);
        sendBtn.setClickable(false);

    }

    @Override
    protected int getLayout() {
        return R.layout.send_activity_layout;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.login_forget_password);
    }

    @Override
    public void enableBtn() {
        sendBtn.setClickable(true);
        sendBtn.setOnClickListener(this);
        sendBtn.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public void disableBtn() {
        sendBtn.setClickable(false);
        sendBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }

    @Override
    public void setChangeListener(TextWatcher watcher) {
        emailEdit.addTextChangedListener(watcher);
    }

    @Override
    public String getEmail() {
        return emailEdit.getText().toString();
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (R.id.id_send_btn == v.getId()){
            presenter.sendEmail();
        }
    }
}
