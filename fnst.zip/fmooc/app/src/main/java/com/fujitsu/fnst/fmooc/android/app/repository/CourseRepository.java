package com.fujitsu.fnst.fmooc.android.app.repository;

import android.util.Log;

import com.fujitsu.fnst.fmooc.android.app.data.OnGetModelFinishImpl;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.network.NetCallback;
import com.fujitsu.fnst.fmooc.android.app.network.model.*;
import com.fujitsu.fnst.fmooc.android.app.network.service.CourseService;
import com.fujitsu.fnst.fmooc.android.app.network.service.UserService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit.Call;
import retrofit.Response;
import rx.Subscriber;
import rx.Subscription;

/**
 * Created by lijl.fnst on 2016/01/06.
 */
public class CourseRepository {
    private String TAG_LOG = CourseRepository.class.getName();

    public static final String GET_MYCOURSES_LIST_RESPONSE = "get_mycourses_list_response";
    public static final String GET_COURSES_DETAIL_RESPONSE = "get_courses_detail_response";

    private Map<String, OnGetModelFinishImpl> listeners;

    private static CourseRepository instance;

    public static CourseRepository getInstance() {
        if (instance == null) {
            instance = new CourseRepository();
        }
        return instance;
    }

    public CourseRepository() {
        listeners = new HashMap<String, OnGetModelFinishImpl>();
    }


    /**
     * update the course state
     *
     * @param id
     * @param data
     * @param subscriber
     * @return
     */
    public Subscription updateCourse(String id, Integer data, Subscriber<EmptyModel> subscriber) {
        return CourseService.getService().updateCourse(id, data, subscriber);
    }

    /**
     * getMyCoursesList
     *
     * @param id
     * @param page
     * @param subscriber
     * @return
     */
    public Subscription getMyCoursesList(String id, Integer page, Subscriber<List<Course>> subscriber) {
        return CourseService.getService().getMyCoursesList(id, page, subscriber);
    }

    public Subscription getMyCourses(String id, Map<String, Object> map, Subscriber<List<Course>> subscriber) {
        return CourseService.getService().getMyCourses(map, id, subscriber);
    }

    public Subscription getCourseInformation(String id, Boolean data, Subscriber<CourseDetailModel> subscriber) {
        return CourseService.getService().getCourseInformation(id, data, subscriber);
    }

    public Subscription enrollCourse(String id, Subscriber<EmptyModel> subscriber) {
        return CourseService.getService().enrollCourse(id, subscriber);
    }

    public Subscription getReportDetail(String id, Boolean data, Subscriber<ReportDetailModel> subscriber) {
        return CourseService.getService().getReportDetail(id, data, subscriber);
    }

    public Subscription getPDF(String id, Subscriber<FilenameModel> subscriber) {
        return CourseService.getService().getPDF(id, subscriber);
    }

    public Subscription getMadePDF(String id, Subscriber<FilenameModel> subscriber) {
        return CourseService.getService().getMadePDF(id, subscriber);
    }

    public void getCoursesDetail(String id, Integer page, Subscriber<List<Course>> subscriber) {


    }

    public Subscription addCourses(String id, Subscriber<EmptyModel> subscriber) {
        return CourseService.getService().addCourses(id, subscriber);

    }

    public Subscription deleteCourse(String id, Subscriber<EmptyModel> subscriber) {
        return CourseService.getService().deleteCourse(id, subscriber);
    }

    public Subscription getCourseById(String id, Subscriber<Course> subscriber) {
        return CourseService.getService().getCoursesDetail(id, true, true, subscriber);
    }


    private OnGetModelFinishImpl getListener(String type) {

        for (String key : listeners.keySet()) {
            if (key.equals(type)) {
                return listeners.get(key);
            }
        }
        OnGetModelFinishImpl listener = new OnGetModelFinishImpl() {
            @Override
            public void onSuccess(String type, Object result) {

            }

            @Override
            public void onFailed(String type, String message) {

            }
        };
        return listener;
    }

    public void register(String type, OnGetModelFinishImpl listener) {
        listeners.put(type, listener);
    }

    public void unRegister(String type) {
        listeners.remove(type);
    }
}
