package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.*;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.MainPresenter;
import com.fujitsu.fnst.fmooc.android.app.repository.RssRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.MainViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.MainAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.ProgressDialog;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.*;
import rx.Observable;
import rx.functions.Action1;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by wangc.fnst on 2015/12/14.
 */
public class MainFragmentActivity extends FragmentActivity implements MainViewInterface,View.OnClickListener,ViewPager.OnPageChangeListener {

    @Bind(R.id.id_title_back_btn)
    Button backImg;
    @Bind(R.id.id_title_more_img)
    ImageView moreImg;
    @Bind(R.id.id_title_content_txt)
    TextView contentText;
    @Bind(R.id.id_title_left_layout)
    LinearLayout titleLeftLayout;
    @Bind(R.id.id_title_right_layout)
    LinearLayout titleRightLayout;

    @Bind(R.id.id_right_icon)
    ImageView rightImg;
    @Bind(R.id.id_right_layout)
    RelativeLayout rightLayout;
    @Bind(R.id.id_right_txt)
    TextView rightTxt;

    @Bind(R.id.id_middle_icon)
    ImageView middleImg;
    @Bind(R.id.id_middle_layout)
    LinearLayout middleLayout;
    @Bind(R.id.id_middle_txt)
    TextView middleTxt;

    @Bind(R.id.id_left_icon)
    ImageView leftImg;
    @Bind(R.id.id_left_layout)
    LinearLayout leftLayout;
    @Bind(R.id.id_left_txt)
    TextView leftTxt;

    @Bind(R.id.id_content_pager)
    ViewPager viewPager;
    @Bind(R.id.id_dot_img)
    ImageView dot;

    private MainAdapter mainAdapter;
    private TopFragment leftFragment;
    private CourseFragment middleFragment;
    private SettingFragment rightFragment;
    private FragmentManager fragmentManager;

    private MainPresenter presenter;
    private ProgressDialog waitDialog;

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Constants.ACTION_HAS_NEW_RSS)){
                //TODO:show red dot
                Log.e("BroadcastReceiver","BroadcastReceiver");
                dot.setVisibility(View.VISIBLE);
                if (rightFragment != null){
                    rightFragment.checkHasRss();
                }
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity_layout);
        ButterKnife.bind(this);
        init();
        initReceiver();
    }

    @Override
    protected void onResume() {
        checkHasRss();
        super.onResume();
    }

    private void checkHasRss(){
        if (RssRepository.getInstance().hasNew()){
            dot.setVisibility(View.VISIBLE);
        }else {
            dot.setVisibility(View.GONE);
        }
    }
    private void initReceiver(){
        IntentFilter filter = new IntentFilter();
        filter.addAction(Constants.ACTION_HAS_NEW_RSS);
        registerReceiver(receiver,filter);
    }
    private void init(){
        backImg.setVisibility(View.INVISIBLE);
        moreImg.setVisibility(View.INVISIBLE);
        leftFragment = new TopFragment();
        middleFragment = new CourseFragment();
        rightFragment = new SettingFragment();
        fragmentManager = getSupportFragmentManager();
        List<Fragment> lists = new ArrayList<Fragment>();
        lists.add(leftFragment);
        lists.add(middleFragment);
        lists.add(rightFragment);
        mainAdapter = new MainAdapter(fragmentManager,lists);
        viewPager.setAdapter(mainAdapter);
        viewPager.addOnPageChangeListener(this);
        leftLayout.setOnClickListener(this);
        middleLayout.setOnClickListener(this);
        rightLayout.setOnClickListener(this);
        presenter = new MainPresenter(this,fragmentManager);
        leftClick();

    }


    @Override
    public void leftClick() {
        //TODO:change image src
        leftImg.setImageResource(R.drawable.left_o);
        contentText.setText(getString(R.string.top_title));
    }

    @Override
    public void middleClick() {
        //TODO:change image src
        middleImg.setImageResource(R.drawable.middle_o);
        contentText.setText(getString(R.string.middle_str));
    }

    @Override
    public void rightClick() {
        //TODO:change image src
        rightImg.setImageResource(R.drawable.right_o);
        contentText.setText(getString(R.string.right_str));

    }

    @Override
    public void resetBottom() {
//        rightLayout.setBackgroundColor(getResources().getColor(R.color.white));
//        middleLayout.setBackgroundColor(getResources().getColor(R.color.white));
//        leftLayout.setBackgroundColor(getResources().getColor(R.color.white));
//        rightTxt.setTextColor(getResources().getColor(R.color.blue));
//        middleTxt.setTextColor(getResources().getColor(R.color.blue));
//        leftTxt.setTextColor(getResources().getColor(R.color.blue));
        //TODO:change image src
        leftImg.setImageResource(R.drawable.left_n);
        middleImg.setImageResource(R.drawable.middle_n);
        rightImg.setImageResource(R.drawable.right_n);


    }
    @Override
    public void changeContent(int item){
        viewPager.setCurrentItem(item);
    }

    @Override
    public void showToast(String msg) {

    }

    @Override
    public void hideWaitingDialog(){
        if (waitDialog != null && waitDialog.isShowing()){
            waitDialog.dismiss();
        }
    }
    @Override
    public void showWaitingDialog(){
        if (waitDialog == null){
            waitDialog = new ProgressDialog(this);
        }
        waitDialog.setCancelable(false);
        waitDialog.show();
        Observable.timer(15, TimeUnit.SECONDS).subscribe(new Action1<Long>() {
            @Override
            public void call(Long aLong) {
                hideWaitingDialog();
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        if (R.id.id_left_layout == v.getId()){
            presenter.bottomClick(MainPresenter.LEFT_MODE,true);
        }else if (R.id.id_middle_layout == v.getId()){
            presenter.bottomClick(MainPresenter.MIDDLE_MODE,true);
        }else if (R.id.id_right_layout == v.getId()){
            presenter.bottomClick(MainPresenter.RIGHT_MODE,true);
        }
    }

    @Override
    public void onPageScrolled(int i, float v, int i1) {

    }

    @Override
    public void onPageSelected(int i) {
        Log.e("onPageSelected", i + "");
        if (i == 2){
            rightFragment.getDataFromNet();
        }else if (i == 1){
            middleFragment.getDataFromNet();
        }else  if (i == 0){
            leftFragment.getDataFromNet();
        }
        presenter.bottomClick(i, false);
    }

    @Override
    public void onPageScrollStateChanged(int i) {

    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(receiver);
        super.onDestroy();
    }
}
