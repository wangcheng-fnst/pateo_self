package com.fujitsu.fnst.fmooc.android.app.view.component;

import android.app.Dialog;
import android.content.Context;
import android.view.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;

/**
 * Created by wangc.fnst on 2016/1/27.
 */
public class CustomDialog extends Dialog implements View.OnClickListener{


    public interface YesOrNoClickListener{
        void yesClick();
        void noClick();
    }

    private Context mContext;

    @Bind(R.id.id_title_txt)
    TextView titleTxt;
    @Bind(R.id.id_yes_txt)
    TextView yesTxt;
    @Bind(R.id.id_no_txt)
    TextView noTxt;

    private YesOrNoClickListener listener;

    public YesOrNoClickListener getListener() {
        return listener;
    }

    private String titleStr,yesStr,noStr;

    public void setListener(YesOrNoClickListener listener) {
        this.listener = listener;
    }

    public CustomDialog(Context context) {
        super(context,R.style.style_custom_dialog);
        mContext = context;
        init();
    }

    public CustomDialog(Context context, int theme) {
        super(context, theme);
        mContext = context;
        init();
    }

    protected CustomDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
        mContext = context;
        init();
    }
    private void init(){
        int width = (int) ApplicationUtils.dp2px(mContext, 250);
        int height = (int) ApplicationUtils.dp2px(mContext, 200);
        WindowManager.LayoutParams lp = this.getWindow().getAttributes();
        lp.alpha = 1f;
        lp.gravity = Gravity.CENTER;
        this.getWindow().setAttributes(lp);
        this.setCancelable(true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                width, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        View view = LayoutInflater.from(mContext).inflate(getLayout(),null);
        setContentView(view,params);
        ButterKnife.bind(this);
        yesTxt.setOnClickListener(this);
        noTxt.setOnClickListener(this);



    }

    public int getLayout(){
        return R.layout.dialog_layout;
    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.id_yes_txt){
            if (listener != null){
                listener.yesClick();
            }
        }else if (v.getId() == R.id.id_no_txt) {
            if (listener != null){
                listener.noClick();
            }
        }
    }



    public String getTitleStr() {
        return titleStr;
    }

    public void setTitleStr(String titleStr) {
        this.titleStr = titleStr;
        titleTxt.setText(titleStr);
    }

    public String getYesStr() {
        return yesStr;
    }

    public void setYesStr(String yesStr) {
        this.yesStr = yesStr;
        yesTxt.setText(yesStr);
    }

    public String getNoStr() {
        return noStr;
    }

    public void setNoStr(String noStr) {
        this.noStr = noStr;
        noTxt.setText(noStr);
    }
}
