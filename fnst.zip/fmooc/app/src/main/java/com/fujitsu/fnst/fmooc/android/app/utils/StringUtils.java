package com.fujitsu.fnst.fmooc.android.app.utils;

import android.util.Log;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by chenjie.fnst
 */
public class StringUtils {

    public static final char SERVER_NEW_LINE_CHART = 0x1F;
    public static final String LOCAL_NEW_LINE_CHART = "\n";

    public static String replaceJsonString(String src){
        String dest = "";
        dest = src.replaceAll(SERVER_NEW_LINE_CHART+"",LOCAL_NEW_LINE_CHART);
        return dest;
    }
    public static String replacePostString(String src){
        String dest = "";
        dest = src.replaceAll(LOCAL_NEW_LINE_CHART,SERVER_NEW_LINE_CHART+"");
        return dest;
    }

    public static boolean isBlank(String str){
        if (null == str || str.trim().isEmpty()){
            return true;
        }
        return false;
    }


    /**
     * check all the characters are ascii character
     * @param str
     * @return
     */
    public static boolean isAscii(String str){
        String regEx = "[\u0000-\u007F]";
        Pattern pat = Pattern.compile(regEx);
        Matcher matcher = pat.matcher(str);
        boolean flg = false;
        int count = 0;
        while (matcher.find()){
            count++;
        }
        if (count == str.length()){
            flg = true;
        }
        return flg;
    }

    public static boolean isNumber(String str) {
        if(str == null) {
            return false;
        }
        Pattern p = Pattern
                .compile("^([0-9]+)$");
        Matcher m = p.matcher(str);
        if (m.matches()){
            return true;
        }
        return false;
    }

    public static boolean isPhoneFirstPart(String str) {
        if(str == null) {
            return false;
        }
        Pattern p = Pattern
                .compile("^0([0-9]{0,6})$");
        Matcher m = p.matcher(str);
        if (m.matches()){
            return true;
        }
        return false;
    }

    public static boolean isPhoneSecondPart(String str) {
        if(str == null) {
            return false;
        }
        Pattern p = Pattern
                .compile("^([0-9]{1,7})$");
        Matcher m = p.matcher(str);
        if (m.matches()){
            return true;
        }
        return false;
    }

    public static boolean isPhoneThirdPart(String str) {
        if(str == null) {
            return false;
        }
        Pattern p = Pattern
                .compile("^([0-9]{1,4})$");
        Matcher m = p.matcher(str);
        if (m.matches()){
            return true;
        }
        return false;
    }

    /**
     * check if the string is email
     * ・共通・・・ASCII文字であること
     「@」でローカル部とドメイン部が区切られていること
     ・ローカル部(@前) ・・・半角英数字、「-」「.」「_」「+」
     ・ドメイン部(@後) ・・・半角英数字、「-」「.」
     「.」の使用は必須
     「.」を先頭・末尾に使用不可
     「.」を2文字以上連続で使用不可
     ・全半角スペース・・・形式エラーとなる
     * @param email
     * @return
     */
    public static boolean isEmail(String email) {
        if(email == null) {
            return false;
        }
        if (!isAscii(email)){
            return false;
        }
        Pattern p = Pattern
                .compile("^([a-zA-Z0-9_\\-\\.\\+]+)@([a-zA-Z0-9\\-\\.]+)$");
        Matcher m = p.matcher(email);
        if (!m.matches()){
            return false;
        }
        if (email.contains(".") && !email.startsWith(".")
                && !email.endsWith(".") && !email.contains("..")){
            return true;
        }
        return false;
    }

    /**
     * check if all the characters are half character
     * @param str
     * @return
     */
    public static boolean isHalfString(String str){
        if (str.length() < str.getBytes().length){
            return false;
        } else {
            return true;
        }
    }

    /**
     * check password
     * パスワードは半角英数記号を使います。（半角スペースは除く）チェックポイントは下記を参照する
     ・長さが8 byte未満の場合、項目長エラーとなる
     パスワードは24文字以内
     *
     * @param password
     * @return
     */
    public static boolean isValidPassword(String password) {
        if (password == null) {
            return false;
        }
        if (password.length() < 8 || password.length() > 48){
            return false;
        }
        String pwd = password.replaceAll(" ", "");
        if (!isHalfString(pwd)){
            return false;
        }

        if (Pattern.matches("(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])[a-zA-Z0-9]{8,48}", pwd)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * check if the string is phone
     *
     * @param phone
     * @return
     */
    public static boolean isPhoneNum(String phone) {
        if (phone == null) {
            return false;
        }
        Pattern p = Pattern.compile("^\\d{11}$");
        Matcher m = p.matcher(phone);
        return m.matches();
    }

    /**
     * check userName
     * 全半角30漢字・60英文字以内
     * @param userName
     * @return
     */
    public static boolean isUserName(String userName){
        if (userName == null){
            return false;
        }
        if (userName.length() > 60){
            return false;
        }
        String pwd = userName.replaceAll(" ", "");

        if (Pattern.matches("^[a-zA-Z0-9]{1,60}$", pwd)) {
            return true;
        } else {
            return false;
        }

    }

    public static boolean isUserId(String userId){
        if (userId == null){
            return false;
        }
        if (getLength(userId) > 60){
            return false;
        }
        return true;

    }



    public static int getByteValue(byte value) {
        int result = value;
        return result & 0xff;
    }

    public static int getByteValue(byte lowValue, byte highValue){
        int low = lowValue;
        int high = highValue;
        return low & 0xff + (high & 0xff) << 4;
    }

    public static byte[] get2ByteFromInteger(int value){
        byte[] array = new byte[2];
        array[0] = Byte.parseByte(String.valueOf(value % 16));
        array[1] = Byte.parseByte(String.valueOf(value >> 4));
        return array;
    }

    public static String replaceBlank(String str) {
        String dest = "";
        if (str!=null) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(str);
            dest = m.replaceAll("");
        }
        return dest;
    }

    /**
     * ??16?��
     * @param paramString
     * @return
     */
    public static byte[] parseHexStringToBytes(String paramString)
    {
        String str = paramString.substring(2).replaceAll("[^[0-9][a-f]]", "");
        byte[] arrayOfByte = new byte[str.length() / 2];
        for (int i = 0; ; i++)
        {
            if (i >= arrayOfByte.length)
                return arrayOfByte;
            arrayOfByte[i] = Long.decode("0x" + str.substring(i * 2, 2 + i * 2)).byteValue();
        }
    }
    public static boolean isDbcCase(char c) {
        if (c >= 32 && c <= 127) {
            return true;
        }
        else if (c >= 65377 && c <= 65439) {
            return true;
        }
        return false;
    }

    public static int getLength(String str) {
        int len = 0;
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (isDbcCase(c)) {
                len = len + 1;
            } else {
                len = len + 2;
            }
        }
        return len;
    }


}
