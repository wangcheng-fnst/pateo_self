package com.fujitsu.fnst.fmooc.android.app.view.component;


import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;


public class ProgressDialog extends Dialog{

	private LinearLayout ll;
	private ImageView img;
	private Context context;
	private AnimationDrawable mAnimationDrawable;

	public static ProgressDialog instance = null;

	public ProgressDialog(Context context) {
		super(context, R.style.style_process_dialog);
		this.context = context;
		init();
	}

	public ProgressDialog(Context context, int theme) {
		super(context, R.style.style_process_dialog);
		this.context = context;
		init();
	}

	protected ProgressDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
		super(context, cancelable, cancelListener);
		this.context = context;
		init();
	}


	private void init(){

		int width = (int) ApplicationUtils.dp2px(context, 80);
		int height = width;

		WindowManager.LayoutParams lp = this.getWindow().getAttributes();
		lp.alpha = 0.8f;
		lp.gravity = Gravity.CENTER;
		this.getWindow().setAttributes(lp);
		this.setCancelable(true);

		LayoutInflater inflater = LayoutInflater.from(context);
		ll = (LinearLayout) inflater.inflate(R.layout.layout_process_dialog, null);
		img = (ImageView) ll.findViewById(R.id.id_process_img);

		img.setImageResource(R.anim.loading_old);
		mAnimationDrawable = (AnimationDrawable) img.getDrawable();
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				width, height);
		params.gravity = Gravity.CENTER;
		this.setContentView(ll, params);

	}

	public void show() {
		mAnimationDrawable.start();
		super.show();
	}

}
