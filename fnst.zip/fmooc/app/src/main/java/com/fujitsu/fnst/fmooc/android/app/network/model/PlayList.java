package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by wangc.fnst on 2016/1/13.
 */
public class PlayList implements Serializable {

    private String playlistId;
    private String courseId;
    private String name;
    private String description;
    private User author;
    private List<Content> contents;

    //local
    private int icon;

    public PlayList() {
    }

    public String getPlaylistId() {
        return playlistId;
    }

    public void setPlaylistId(String playlistId) {
        this.playlistId = playlistId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public List<Content> getContents() {
        return contents;
    }

    public void setContents(List<Content> contents) {
        this.contents = contents;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }
}
