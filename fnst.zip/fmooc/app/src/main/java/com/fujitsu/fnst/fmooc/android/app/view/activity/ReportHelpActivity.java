package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.AgreementPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.ReportHelpPresenter;
import com.fujitsu.fnst.fmooc.android.app.view.ReportHelpViewInterface;

import butterknife.Bind;

public class ReportHelpActivity extends BaseActivity<ReportHelpPresenter> implements ReportHelpViewInterface {

    @Bind(R.id.report_help_webview)
    WebView help;
    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new ReportHelpPresenter(this);
        help.loadUrl("http://www.fisdom.org/help/");
        help.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // TODO Auto-generated method stub
                view.loadUrl(url);
                return true;
            }
        });
    }
    @Override
    protected int getLayout() {
        return R.layout.activity_report_help;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.about_set);
    }
}
