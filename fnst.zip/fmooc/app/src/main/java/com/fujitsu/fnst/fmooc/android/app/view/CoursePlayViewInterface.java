package com.fujitsu.fnst.fmooc.android.app.view;

import android.app.Dialog;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.view.component.stickylistheaders.ExpandableStickyListHeadersListView;

/**
 * Created by wangc.fnst on 2015/12/22.
 */
public interface CoursePlayViewInterface extends BaseViewInterface {
    void setSelection(int position);
    ExpandableStickyListHeadersListView getListView();
    void back();
    void setData(Course course);
    void showDialog(Dialog dialog);
}
