package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.ActionBar;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.Content;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.network.model.PlayList;
import com.fujitsu.fnst.fmooc.android.app.presenter.LoginPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.ScorePresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ScoreViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.component.ProcessbarView;

import java.util.List;
import java.util.concurrent.TimeoutException;

import butterknife.Bind;

public class ScoreActivity extends BaseActivity<ScorePresenter> implements ScoreViewInterface {
    @Bind(R.id.id_total_view)
    ProcessbarView totalView;
    @Bind(R.id.score_layout)
    LinearLayout scorelayout;
    @Bind(R.id.score_title)
    TextView scoreTitle;

    private List<PlayList> playlist;
    private Course course;

    @Override
    protected int getLayout() {
        return R.layout.activity_score;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.score_title);
    }

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new ScorePresenter(this);
        Intent intent = getIntent();
        course = (Course) intent.getSerializableExtra("playlist");
        playlist = course.getPlaylists();
        if (course.getUserScore() != 0){
            totalView.setmTitleText(Integer.toString((course.getUserScore())));
            totalView.setScoreValue( (course.getUserScore()));
            totalView.startDraw();
        }

        for (PlayList list:playlist){
            for (Content content:list.getContents()){
                if (content.getContentType().equals(Constants.CONTENT_TYPE_REPORT)){
                    if (content.getScore() != null){
                        scorelayout.addView(createTextview(content.getReportTitle()));
                        ProcessbarView bar = creatProcessbar(content.getScore());
                        scorelayout.addView(bar);
                        bar.startDraw();

                    }

                }
            }
        }



    }

    private TextView createTextview(String title){
        TextView textView = new TextView(this);
        textView.setText(title);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimensionPixelSize(R.dimen.sp_16));
        textView.setTextColor(Color.BLACK);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(getResources().getDimensionPixelSize(R.dimen.dp_20), getResources().getDimensionPixelSize(R.dimen.dp_20), getResources().getDimensionPixelSize(R.dimen.dp_20), 0);
        textView.setLayoutParams(layoutParams);
        return textView;
    }

    private ProcessbarView creatProcessbar(int score){
        ProcessbarView processbarView = new ProcessbarView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelSize(R.dimen.dp_28));
        layoutParams.setMargins(getResources().getDimensionPixelSize(R.dimen.dp_20), getResources().getDimensionPixelSize(R.dimen.dp_10), getResources().getDimensionPixelSize(R.dimen.dp_20), 0);
        processbarView.setLayoutParams(layoutParams);
        processbarView.setmTitleTextSize(getResources().getDimensionPixelSize(R.dimen.sp_16));
        processbarView.setmTitleTextColor(Color.BLACK);
        processbarView.setmTitleText(Integer.toString(score));
        processbarView.setScoreValue(score);
        processbarView.setTextMarginLeft(getResources().getDimensionPixelSize(R.dimen.dp_6));
        processbarView.setTextMarginRight(getResources().getDimensionPixelSize(R.dimen.dp_6));
        processbarView.setLineSize(getResources().getDimensionPixelSize(R.dimen.dp_1));
        return processbarView;
    }

    @Override
    public void setScoreTitle(String name){
        scoreTitle.setText(name + getResources().getString(R.string.score_title_user));
    }

}
