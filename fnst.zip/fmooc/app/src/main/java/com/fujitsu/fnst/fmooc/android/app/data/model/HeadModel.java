package com.fujitsu.fnst.fmooc.android.app.data.model;

import com.fujitsu.fnst.fmooc.android.app.data.BaseModel;

/**
 * Created by wangc.fnst on 2015/12/25.
 */
public class HeadModel extends BaseModel{

    private int id;
    private int resId;

    public HeadModel(int id, int resId) {
        this.id = id;
        this.resId = resId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }
}
