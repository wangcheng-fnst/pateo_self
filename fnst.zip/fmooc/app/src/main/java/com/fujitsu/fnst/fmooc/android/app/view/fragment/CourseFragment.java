package com.fujitsu.fnst.fmooc.android.app.view.fragment;

import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.presenter.CoursePresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.CourseViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.CourseItemAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/18.
 */
public class CourseFragment extends BaseFragment<CoursePresenter> implements CourseViewInterface {

    @Bind(R.id.id_course_ing_txt)
    TextView courseIngTxt;
    @Bind(R.id.id_course_ing_layout)
    LinearLayout courseIngLayout;

    @Bind(R.id.id_course_end_txt)
    TextView courseEndTxt;
    @Bind(R.id.id_course_end_layout)
    LinearLayout courseEndLayout;

    @Bind(R.id.id_course_list)
    PullRefleashListView listView;

    @Bind(R.id.id_course_layout)
    LinearLayout courseLayout;
    @Bind(R.id.id_course_error_layout)
    LinearLayout courseErrorLayout;
    @Bind(R.id.refresh_btn)
    Button refreshBtn;
    @Bind(R.id.id_course_null_layout)
    LinearLayout nullLayout;

    private CourseItemAdapter adapter;
    private List<Course> mData = new ArrayList<Course>();
    private int currentMode = Constants.COURSE_ING_MODE;
    private int page = 1;


    @Override
    protected int getLayout() {
        return R.layout.course_fragment_layout;
    }

    @Override
    protected void init() {
        listView.setPullLoadEnable(true);
        listView.setPullRefreshEnable(true);
        presenter = new CoursePresenter(this,page);
        adapter = new CourseItemAdapter(mData, 1);
        listView.setAdapter(adapter);
        listView.setRefleashListener(presenter);
        listView.setOnItemClickListener(adapter);
        courseIngLayout.setOnClickListener(this);
        courseEndLayout.setOnClickListener(this);
        refreshBtn.setOnClickListener(this);
    }

    @Override
    public void addItems(List<Course> data) {
        mData.addAll(mData.size()-1 < 0?0:mData.size() -1,data);
    }

    @Override
    public void onLoad() {
        listView.stopLoadMore();
        listView.stopRefresh();
        listView.setRefreshTime("");
    }

    @Override
    public void notify(boolean isRefresh) {
        adapter.notifyDataSetChanged();

    }

    @Override
    public void changeMode(int mode) {
        if (mode == Constants.COURSE_ING_MODE){
            courseIngLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_left_o));
            courseEndLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_right_n));
            courseIngTxt.setTextColor(getResources().getColor(R.color.white));
            courseEndTxt.setTextColor(getResources().getColor(R.color.orange));
        } else {
            courseIngLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_left_n));
            courseEndLayout.setBackground(getResources().getDrawable(R.drawable.tab_bar_right_o));
            courseIngTxt.setTextColor(getResources().getColor(R.color.orange));
            courseEndTxt.setTextColor(getResources().getColor(R.color.white));
        }
    }

    @Override
    public void resetData() {
        mData.clear();
    }

    @Override
    public LinearLayout getCourseLayout() {
        return courseLayout;
    }

    @Override
    public LinearLayout getCourseErrorLayout() {
        return courseErrorLayout;
    }

    @Override
    public LinearLayout getNullLayout() {
        return nullLayout;
    }

    @Override
    public PullRefleashListView getList() {
        return listView;
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (v.getId() == R.id.id_course_ing_layout){
            if (currentMode != Constants.COURSE_ING_MODE) {
                currentMode = Constants.COURSE_ING_MODE;
                presenter.changeMode(Constants.COURSE_ING_MODE);
            }
        }else if (v.getId() == R.id.id_course_end_layout){
            if (currentMode != Constants.COURSE_END_MODE) {
                currentMode = Constants.COURSE_END_MODE;
                presenter.changeMode(Constants.COURSE_END_MODE);
            }
        }else if(v.getId() == R.id.refresh_btn){
            getDataFromNet();
        }
    }

    public void getDataFromNet(){
        page = 1;
        presenter.setPage(page);
        presenter.setCheckNet(true);
        presenter.getDataFromNet();
    }
}
