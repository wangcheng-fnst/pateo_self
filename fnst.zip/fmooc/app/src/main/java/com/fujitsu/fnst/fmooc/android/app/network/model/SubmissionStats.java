package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by lijl.fnst on 2016/02/15.
 */
public class SubmissionStats implements Serializable{
    private User student;
    private String courseId;
    private String reportId;
    private String submissionId;
    private String state;
    private Integer numberOfAssignedEvaluationsRequired;
    private Integer numberOfAssignedEvaluationsSubmitted;
    private Integer numberOfEvaluationsRequiredForNotations;
    private Integer numberOfEvaluationsReceived;
    private Integer maximumScore;
    private Integer scoresRecievedMiddleValue;
    private Integer score;

    public User getStudent() {
        return student;
    }

    public void setStudent(User student) {
        this.student = student;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getNumberOfAssignedEvaluationsRequired() {

        return numberOfAssignedEvaluationsRequired;
    }

    public void setNumberOfAssignedEvaluationsRequired(Integer numberOfAssignedEvaluationsRequired) {
        this.numberOfAssignedEvaluationsRequired = numberOfAssignedEvaluationsRequired;
    }

    public Integer getNumberOfAssignedEvaluationsSubmitted() {
        return numberOfAssignedEvaluationsSubmitted;
    }

    public void setNumberOfAssignedEvaluationsSubmitted(Integer numberOfAssignedEvaluationsSubmitted) {
        this.numberOfAssignedEvaluationsSubmitted = numberOfAssignedEvaluationsSubmitted;
    }

    public Integer getNumberOfEvaluationsRequiredForNotations() {
        return numberOfEvaluationsRequiredForNotations;
    }

    public void setNumberOfEvaluationsRequiredForNotations(Integer numberOfEvaluationsRequiredForNotations) {
        this.numberOfEvaluationsRequiredForNotations = numberOfEvaluationsRequiredForNotations;
    }

    public Integer getNumberOfEvaluationsReceived() {
        return numberOfEvaluationsReceived;
    }

    public void setNumberOfEvaluationsReceived(Integer numberOfEvaluationsReceived) {
        this.numberOfEvaluationsReceived = numberOfEvaluationsReceived;
    }

    public Integer getMaximumScore() {
        return maximumScore;
    }

    public void setMaximumScore(Integer maximumScore) {
        this.maximumScore = maximumScore;
    }

    public Integer getScoresRecievedMiddleValue() {
        return scoresRecievedMiddleValue;
    }

    public void setScoresRecievedMiddleValue(Integer scoresRecievedMiddleValue) {
        this.scoresRecievedMiddleValue = scoresRecievedMiddleValue;
    }

    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public String getSubmissionId() {
        return submissionId;
    }

    public void setSubmissionId(String submissionId) {
        this.submissionId = submissionId;
    }
}
