package com.fujitsu.fnst.fmooc.android.app.rss;

import android.util.Log;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

/**
 * Created by wangc.fnst on 2016/1/12.
 */
public class TestRss {
    public static void  main(String[] args) throws Exception{
        try {
//            URL url = new URL("http://m.cn.engadget.com/rss.xml");
            URL url = new URL("https://www.baidu.com");
            URLConnection connection = url.openConnection();
            RssFeed feed = RssReader.read(connection.getInputStream());

            ArrayList<RssItem> rssItems = feed.getRssItems();
            for(RssItem rssItem : rssItems) {
                Log.i("RSS Reader", rssItem.getTitle());
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
