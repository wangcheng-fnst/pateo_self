package com.fujitsu.fnst.fmooc.android.app.view.adapter;

import android.graphics.Paint;
import android.text.TextUtils;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.*;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.DiscussionModel;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.component.CollapsibleTextView;
import com.fujitsu.fnst.fmooc.android.app.view.component.ExpandableTextView;

import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public class DiscussionAdapter extends BaseListViewAdapter<DiscussionModel> {

    private View.OnClickListener onClickListener;
    private boolean readOnly = false;
    private final SparseBooleanArray mCollapsedStatus = new SparseBooleanArray();
    public DiscussionAdapter(List<DiscussionModel> mData) {
        super(mData);
    }

    public View.OnClickListener getOnClickListener() {
        return onClickListener;
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public void setReadOnly(boolean readOnly){
        this.readOnly = readOnly;
    }

    @Override
    protected BaseViewHolder getViewHolder(View contentView) {
        return new ViewHolder(contentView);
    }

    @Override
    protected int getItemLayout() {
        return R.layout.discussion_item_layout;
    }

    @Override
    protected void setItemData(BaseViewHolder viewHolder, int position) {
        final DiscussionModel model = (DiscussionModel)getItem(position);
        final ViewHolder holder = (ViewHolder) viewHolder;
        holder.headImg.setImageResource(Constants.getImageResId_30(model.getHeadId()+""));
        if (!StringUtils.isBlank(model.getReplyOf())){
            if (model.getReplyOf() != null) {
                holder.replyLayout.setVisibility(View.VISIBLE);
//                holder.replyLayout.setOnClickListener(onClickListener);
//                holder.replyLayout.setTag(R.id.position,position);
                holder.replyTxt.setOnClickListener(onClickListener);
                holder.replyTxt.setTag(R.id.position,position);
                holder.replyTxt.setText("No." +model.getReplyOfNumber());
                holder.replyTxt.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
            }else {
                holder.replyLayout.setVisibility(View.GONE);
            }
        }else {
            holder.replyLayout.setVisibility(View.GONE);

        }
        holder.orderTxt.setText("No."+model.getOrder());
        holder.timeTxt1.setText(model.getTime().substring(0, 10));
        holder.timeTxt2.setText(model.getTime().substring(11, 16));
//        holder.headImg.setImageResource(Constants.getImageResId_30(model.getHeadId()+""));
        holder.nameTxt.setText(model.getUserName());
        holder.contentTxt.setmMaxCollapsedLines(5);
//        if (!StringUtils.isBlank(model.getReplyOf())){
//            if (model.getReplyOf() != null) {
//                holder.contentTxt.setmMaxCollapsedLines(4);
//            }else {
//                holder.contentTxt.setmMaxCollapsedLines(5);
//            }
//        }else {
//            holder.contentTxt.setmMaxCollapsedLines(5);
//        }
        holder.contentTxt.setText(model.getContent(),mCollapsedStatus,position);
        holder.replyBtn.setTag(R.id.position,position);
        holder.moreTxt.setTag(R.id.position,position);
        holder.moreTxt.setOnClickListener(onClickListener);
        holder.moreTxt.setTag(holder.contentTxt);
        holder.moreTxt.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        holder.expandCollapse.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        if(readOnly){
            holder.replyBtn.setClickable(false);
            holder.replyBtn.setAlpha(0.5f);
            holder.replyBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
        }else{
            holder.replyBtn.setOnClickListener(onClickListener);
        }
    }


    class ViewHolder implements BaseViewHolder{
        @Bind(R.id.id_item_order_txt)
        TextView orderTxt;
        @Bind(R.id.id_item_time1_txt)
        TextView timeTxt1;
        @Bind(R.id.id_item_time2_txt)
        TextView timeTxt2;
        @Bind(R.id.id_item_name_txt)
        TextView nameTxt;
        @Bind(R.id.id_item_head_img)
        ImageView headImg;
        @Bind(R.id.id_item_content_txt)
        ExpandableTextView contentTxt;
        @Bind(R.id.id_item_more_txt)
        TextView moreTxt;
        @Bind(R.id.id_reply_btn)
        Button replyBtn;
        @Bind(R.id.id_reply_layout)
        LinearLayout replyLayout;
        @Bind(R.id.id_reply_txt)
        TextView replyTxt;
        @Bind(R.id.expand_collapse)
        TextView expandCollapse;

        public ViewHolder(View view) {
            ButterKnife.bind(this,view);
        }
    }


}
