package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by zhaod.fnst on 2016/2/19.
 */
public class FilenameModel implements Serializable {

    private String filename;

    public FilenameModel() {
    }

    public FilenameModel(String filename) {
        this.filename = filename;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }
}
