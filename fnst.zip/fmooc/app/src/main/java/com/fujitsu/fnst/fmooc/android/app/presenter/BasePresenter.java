package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Context;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.view.BaseViewInterface;

/**
 * Created by wangc.fnst on 2015/12/10.
 */
public abstract class BasePresenter {
    protected Context context;



    public  void onCreate(){};
    public  void onResume(){};
    public  void onPause() {};
    public  void onStop() {};
    public  void onStart() {};
    public  void onDestroy() {};

    public BasePresenter() {
        this.context = FmoocApplication.getInstance().getApplicationContext();
    }
}
