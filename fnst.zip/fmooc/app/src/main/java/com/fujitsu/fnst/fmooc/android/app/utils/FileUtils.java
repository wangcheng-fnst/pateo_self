package com.fujitsu.fnst.fmooc.android.app.utils;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.util.Date;

/**
 * Created by wangc.fnst
 */
public class FileUtils {

    public static final String ROOT_DIR = Environment.getExternalStorageDirectory() + "/fmooc/";



    public static String getImagePath() {
        File dirFile = new File(ROOT_DIR, "image");
        if (!dirFile.exists()) {
            dirFile.mkdirs();
        }
        return dirFile.getAbsolutePath();
    }

    public static File getNewPicFile() {
       return new File(getImagePath(), new Date().getTime() + ".jpg");
    }


    public static String getPathByUri(Context context, Uri uri) {
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            String uriPath = uri.getPath();
            int index = uriPath.indexOf("content://media/");
            if (index != -1) {
                uriPath = uriPath.substring(index).replace("/ACTUAL", "");
                uri = Uri.parse(uriPath);
            }
            String[] projection = {MediaStore.Images.Media.DATA};
            Cursor cursor = null;
            try {
                cursor = context.getContentResolver().query(uri, projection, null, null, null);
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                if (cursor.moveToFirst()) {
                    return cursor.getString(column_index);
                }
            } catch (Exception e) {
            } finally {
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
            }
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

}
