package com.fujitsu.fnst.fmooc.android.app.network;

/**
 * Created by wangc.fnst on 2015/12/24.
 */
public class ErrorCode {
    public static final int ERROR_PARAMETER = 400;//
    public static final int ERROR_AUTH = 401;//
    public static final int ERROR_PERMISSION = 403;//
    public static final int ERROR_NOT_FONT = 404;//
    public static final int ERROR_TOO_LARGE = 413;//
    public static final int ERROR_URI = 414;//
    public static final int ERROR_OTHER = 0;//

}
