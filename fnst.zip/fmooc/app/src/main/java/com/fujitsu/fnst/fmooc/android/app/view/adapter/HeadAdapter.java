package com.fujitsu.fnst.fmooc.android.app.view.adapter;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.HeadModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.ProfileImage;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/25.
 */
public class HeadAdapter extends RecyclerView.Adapter<HeadAdapter.ViewHolder> {

    private List<ProfileImage> mData = new ArrayList<ProfileImage>();
    private int itemCount;
    private int selectPosition = 1;

    public HeadAdapter(List<ProfileImage> mData) {
        this.mData = mData;
        itemCount = mData.size();
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

    public int getSelectPosition() {
        return selectPosition;
    }

    public void setSelectPosition(int selectPosition) {
        this.selectPosition = selectPosition;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int position) {
        ViewHolder holder = new ViewHolder(LayoutInflater.from(FmoocApplication.getInstance().getBaseContext()).inflate(R.layout.head_item,viewGroup,false));
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int position) {
        ProfileImage item = getItem(position);
        Log.e("header",item.getImageId());
        viewHolder.headImg.setImageResource(Constants.getImageResId_120(item.getImageId()));
    }

    public ProfileImage getItem(int position){
        return mData.get(position % (mData.size()));
    }

    @Override
    public int getItemCount() {
        return Integer.MAX_VALUE;
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        @Bind(R.id.id_head_img)
        ImageView headImg;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
