package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.app.Activity;
import android.content.Intent;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportDetailModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.SubmittedReport;
import com.fujitsu.fnst.fmooc.android.app.repository.ReportRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.utils.StringUtils;
import com.fujitsu.fnst.fmooc.android.app.view.ReportSendViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ProfileSelectActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ReportMainActivity;
import com.fujitsu.fnst.fmooc.android.app.view.activity.ReportSendActivity;
import com.fujitsu.fnst.fmooc.android.app.view.component.CustomDialog;
import com.fujitsu.fnst.fmooc.android.app.view.listener.EditChangeListener;
import rx.Subscriber;
import rx.Subscription;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by lijl.fnst on 2016/01/07.
 */
public class ReportSendPresenter extends BasePresenter implements EditChangeListener.TextChangeCallback{
    private ReportSendViewInterface view;
    private String contentId,userAnswer;
    private int maxNumberOfCharacters;
    private CustomDialog dialog;

    public ReportSendPresenter(ReportSendViewInterface loginViewInterface){
        super();
        view = loginViewInterface;
        init();
    }

    public void init(){
        EditChangeListener answerWatcher = new EditChangeListener();
        answerWatcher.setCallback(this);
        view.setAnswerListener(answerWatcher);
    }

    public CustomDialog getMessageDialog(){
        if (dialog == null){
            dialog = new CustomDialog((Activity) view);
            dialog.setNoStr(context.getResources().getString(R.string.no));
            dialog.setYesStr(context.getResources().getString(R.string.report_submit));
            dialog.setTitleStr(context.getResources().getString(R.string.report_submit_dialog));
            dialog.setListener(new CustomDialog.YesOrNoClickListener() {
                @Override
                public void yesClick() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    submit();
                }

                @Override
                public void noClick() {
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                }
            });
        }
        return dialog;
    }

    public void submit(){
        contentId = view.getContentId();
        userAnswer = view.getUserAnswer();
        maxNumberOfCharacters = view.getMaxNumberOfCharacters();
        if(userAnswer.length() > maxNumberOfCharacters){
            view.showToast(String.valueOf(maxNumberOfCharacters) + context.getResources().getString(R.string.report_answer_too_long));
        }else{
            Map<String, Object> data= new HashMap<String, Object>();
            data.put("answerText",userAnswer);
            ReportRepository.getInstance().addReportAnswer(contentId, data, getSubscriber());
        }
    }

    private Subscriber getSubscriber(){
        return new Subscriber<SubmittedReport>() {
            @Override
            public void onCompleted() {
                //view.showToast("onCompleted");
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable e) {
                view.showToast(e.getMessage());
                view.hideWaitingDialog();
            }
            @Override
            public void onNext(SubmittedReport report) {
                //view.showToast("onNext");
                view.hideWaitingDialog();
//                Intent intent = new Intent(context,ReportMainActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                intent.putExtra(Constants.EXTRA_CONTENTID, view.getContentId());
//                context.startActivity(intent);

                Intent intent = new Intent();
                intent.putExtra(Constants.EXTRA_CONTENTID, view.getContentId());
                ((ReportSendActivity)view).setResult(Constants.REPORT_STEP1, intent);
                ((ReportSendActivity)view).finish();
            }
        };
    }

    @Override
    public void formatRight() {
        if (checkValue()){
            view.enableBtn();
        }else{
            view.disableBtn();
        }
    }

    private boolean checkValue(){
        userAnswer = view.getUserAnswer();
        if (!StringUtils.isBlank(userAnswer)){
            return true;
        }
        return false;
    }

}
