package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.os.Handler;
import android.view.View;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.CourseModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.repository.CourseRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.view.CourseViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;
import com.fujitsu.fnst.fmooc.android.app.view.fragment.CourseFragment;
import rx.Subscriber;
import rx.Subscription;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangc.fnst on 2015/12/18.
 */
public class CoursePresenter extends BasePresenter implements PullRefleashListView.OnRefleashListener {

    private CourseViewInterface view;
    private Handler mHandler;
    private int mode = Constants.COURSE_ING_MODE;
    private int page;
    private Subscription subscription;
    private String id;
    private String status="";
    private boolean checkNet=true;

    public CoursePresenter(CourseViewInterface view,int page) {
        this.view = view;
        this.page=page;
        mHandler = new Handler();
        checkNet=false;
        getDataFromNet();
    }


    public void changeMode(int mode){
        this.mode = mode;
        view.changeMode(mode);
        if(mode==Constants.COURSE_ING_MODE){
            status=Course.USER_STATUS_ENROLLED;
        }else if(mode == Constants.COURSE_END_MODE){
            status=Course.USER_STATUS_COMPLETED;
        }
        page=1;
        checkNet=true;
        getDataFromNet();
    }

    @Override
    public void onRefresh() {
        page=1;
        checkNet=false;
        getDataFromNet();
    }

    public void getDataFromNet(){
        id = ShareReferencesManager.getInstance(context).getStringValue(Constants.SP_USER_ID);
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("page",page);
        map.put("getPlaylistsInformation",Boolean.valueOf(false));
        map.put("getContentsInformation",Boolean.valueOf(false));
        map.put("sort","newFirst");
        if (status.equals(Course.USER_STATUS_ENROLLED)){
            map.put("forUserState",status);
        }

        subscription = CourseRepository.getInstance().getMyCourses(id, map, getCourseSubscriber());
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public void setCheckNet(boolean checkNet){
        this.checkNet=checkNet;
    }

    @Override
    public void onLoadMore() {
        page++;
        checkNet=false;
        getDataFromNet();
    }

    private Subscriber getCourseSubscriber(){
        return new Subscriber<List<Course>>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable throwable) {
                if(checkNet){
                    view.showToast(throwable.getMessage());
                    view.getCourseLayout().setVisibility(View.GONE);
                    view.getCourseErrorLayout().setVisibility(View.VISIBLE);
                }else{
                    view.showToast(context.getResources().getString(R.string.network_error));
                }
                view.onLoad();
            }

            @Override
            public void onNext(final List<Course> courseModels) {
                view.getCourseLayout().setVisibility(View.VISIBLE);
                view.getCourseErrorLayout().setVisibility(View.GONE);
                view.getNullLayout().setVisibility(View.GONE);
                view.getList().setVisibility(View.VISIBLE);
                if (page == 1){
                    view.resetData();
                    if(courseModels == null || courseModels.size() < 1){
                        view.getNullLayout().setVisibility(View.VISIBLE);
                        view.getCourseLayout().setVisibility(View.VISIBLE);
                        view.getList().setVisibility(View.GONE);
                        view.getCourseErrorLayout().setVisibility(View.GONE);
                    }
                }
                view.addItems(courseModels);
                view.notify(true);
                view.onLoad();
            }
        };
    }
}
