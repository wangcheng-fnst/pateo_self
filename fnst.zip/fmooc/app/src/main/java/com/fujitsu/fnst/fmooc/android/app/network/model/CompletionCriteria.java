package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by wangc.fnst on 2016/2/15.
 */
public class CompletionCriteria implements Serializable {
    private boolean shouldViewAllCourseClips;
    private boolean shouldSubmitAllReports;
    private int minimalScoreAsAbsoluteValue;
    private int minimalScoreAsPercentageOfMax;

    public boolean isShouldViewAllCourseClips() {
        return shouldViewAllCourseClips;
    }

    public void setShouldViewAllCourseClips(boolean shouldViewAllCourseClips) {
        this.shouldViewAllCourseClips = shouldViewAllCourseClips;
    }

    public boolean isShouldSubmitAllReports() {
        return shouldSubmitAllReports;
    }

    public void setShouldSubmitAllReports(boolean shouldSubmitAllReports) {
        this.shouldSubmitAllReports = shouldSubmitAllReports;
    }

    public int getMinimalScoreAsAbsoluteValue() {
        return minimalScoreAsAbsoluteValue;
    }

    public void setMinimalScoreAsAbsoluteValue(int minimalScoreAsAbsoluteValue) {
        this.minimalScoreAsAbsoluteValue = minimalScoreAsAbsoluteValue;
    }

    public int getMinimalScoreAsPercentageOfMax() {
        return minimalScoreAsPercentageOfMax;
    }

    public void setMinimalScoreAsPercentageOfMax(int minimalScoreAsPercentageOfMax) {
        this.minimalScoreAsPercentageOfMax = minimalScoreAsPercentageOfMax;
    }
}
