package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.view.View;
import com.fujitsu.fnst.fmooc.android.app.network.model.Course;
import com.fujitsu.fnst.fmooc.android.app.repository.CourseRepository;
import com.fujitsu.fnst.fmooc.android.app.view.TopViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;
import rx.Subscriber;
import rx.Subscription;

import java.util.List;

/**
 * Created by wangc.fnst on 2015/12/16.
 */
public class TopPresenter extends BasePresenter implements PullRefleashListView.OnRefleashListener {

    private TopViewInterface view;
    private android.os.Handler mHandler;
    private Subscription subscription;

    private int page;
    private boolean checkNet=true;
    public TopPresenter(TopViewInterface view,int page) {
        this.view = view;
        this.page = page;
        mHandler = new android.os.Handler();
    }

    public void getDataFromNet(){
        subscription = CourseRepository.getInstance().getMyCoursesList("newFirst", page, getCourseSubscriber());

    }
    @Override
    public void onRefresh() {
        page=1;
        checkNet=false;
        getDataFromNet();
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public void setCheckNet(boolean checkNet){
        this.checkNet=checkNet;
    }

    @Override
    public void onLoadMore() {
        page++;
        checkNet=false;
        getDataFromNet();
    }

    private Subscriber getCourseSubscriber(){
        return new Subscriber<List<Course>>() {
            @Override
            public void onCompleted() {
                view.hideWaitingDialog();
            }

            @Override
            public void onError(Throwable throwable) {
                view.showToast(throwable.getMessage());
                view.hideWaitingDialog();
                if(checkNet){
                    view.getCourseLayout().setVisibility(View.GONE);
                    view.getCourseErrorLayout().setVisibility(View.VISIBLE);
                }
//                else{
//                    view.showToast("network wrong");
//                }
                view.onLoad();
            }

            @Override
            public void onNext(final List<Course> courseModels) {
                view.hideWaitingDialog();
                view.getCourseLayout().setVisibility(View.VISIBLE);
                view.getCourseErrorLayout().setVisibility(View.GONE);
                if (page == 1){
                    view.resetData();
                }
                if (courseModels.size() < 1){
                    view.hideFoot();
                    view.onLoad();
                    return;
                }
                view.addItems(courseModels);
                view.notify(true);
                view.onLoad();
            }
        };
    }
}
