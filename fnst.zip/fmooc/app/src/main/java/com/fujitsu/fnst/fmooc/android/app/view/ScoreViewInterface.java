package com.fujitsu.fnst.fmooc.android.app.view;

/**
 * Created by lijl.fnst on 2016/01/29.
 */
public interface ScoreViewInterface extends BaseViewInterface{
    void setScoreTitle(String name);
}
