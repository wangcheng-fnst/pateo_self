package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;

import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.data.model.DiscussionModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.*;
import com.fujitsu.fnst.fmooc.android.app.presenter.ReportMainPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.ReportSelfPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ReportSelfViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.adapter.QuestionAdapter;
import com.fujitsu.fnst.fmooc.android.app.view.component.CustomDialog;
import com.fujitsu.fnst.fmooc.android.app.view.component.NoScrollListview;
import com.fujitsu.fnst.fmooc.android.app.view.component.PullRefleashListView;

import java.util.ArrayList;
import java.util.List;

public class ReportSelfActivity extends BaseActivity<ReportSelfPresenter> implements ReportSelfViewInterface {

    @Bind(R.id.id_question_list)
    NoScrollListview questionList;
    @Bind(R.id.id_report_self_btn)
    Button submit;
    @Bind(R.id.id_score)
    TextView myScore;
    @Bind(R.id.id_score_total)
    TextView totalScore;
    @Bind(R.id.id_report_your)
    TextView reportContent;
    @Bind(R.id.id_quesiton)
    TextView question;
    @Bind(R.id.id_report_comment)
    EditText reportComment;
    @Bind(R.id.id_report_pass_comment)
    TextView reportPassComment;

    private QuestionAdapter adapter;
    private List<ReportEvaluationActivity> mData = new ArrayList<ReportEvaluationActivity>();
    int[] scores = null;
    int[] selectedChoices = null;
    private ReportDetailModel reportModel;
    private String contentId;
    private View.OnTouchListener onTouchListener;
    private CustomDialog dialog;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        Intent intent = getIntent();
        reportModel =((ReportDetailModel)intent.getSerializableExtra(Constants.EXTRA_REPORT));
        mData = reportModel.getSubmission().getEvaluationWording().getActivities();
        contentId = reportModel.getContent().getContentId();
        question.setFocusable(true);
        question.setFocusableInTouchMode(true);
        question.requestFocus();
        reportContent.setMovementMethod(ScrollingMovementMethod.getInstance());
        reportContent.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        reportContent.setText(reportModel.getSubmission().getMySubmission().getSubmittedAnswerText());

        onTouchListener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if(event.getAction()==MotionEvent.ACTION_MOVE){
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if(event.getAction()==MotionEvent.ACTION_UP){
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                }
                return false;
            }
        };

        String state = reportModel.getContent().getState();
        List<Integer> passChoices = null;
        scores = new int[mData.size()];
        selectedChoices = new int[mData.size()];
        int maxScore = 0;
        int initScore = 0;
        for(int i=0;i<mData.size();i++){
            List<ReportEvaluationActivityChoice> choices=mData.get(i).getChoices();
            initScore += choices.get(0).getScore();
            scores[i] = choices.get(0).getScore();
            selectedChoices[i] = 0;
            int score=0;
            for(int k=0;k<choices.size();k++){
                if(choices.get(k).getScore()>score){
                    score = choices.get(k).getScore();
                }
            }
            maxScore += score;
        }
        totalScore.setText("/"+maxScore+getResources().getString(R.string.report_score));
        if(!state.equals(Report.CANNOT_SUBMIT) && !state.equals(Report.WAITING_FOR_REPORT_ANSWER)
                && !state.equals(Report.WAITING_FOR_SELF_EVALUATION_PERIOD_TO_START)
                && !state.equals(Report.WAITING_FOR_SELF_EVALUATION)){
            disableBtn();
            reportPassComment.setVisibility(View.VISIBLE);
            reportPassComment.setText(reportModel.getSubmission().getSelfEvaluation().getComments());
            reportPassComment.setMovementMethod(ScrollingMovementMethod.getInstance());
            reportPassComment.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);

            reportPassComment.setOnTouchListener(onTouchListener);

            reportComment.setVisibility(View.GONE);
            passChoices = reportModel.getSubmission().getSelfEvaluation().getSelectedChoices();
            List<Integer> scores = reportModel.getSubmission().getSelfEvaluation().getSelectedScores();
            Integer getScore = 0;
            for(int k=0;k<scores.size();k++){
                getScore += scores.get(k);
            }
            myScore.setText(String.valueOf(getScore));
            submit.setText(getResources().getString(R.string.report_sent));
            disableBtn();
        }else{
            reportPassComment.setVisibility(View.GONE);
            reportComment.setVisibility(View.VISIBLE);
            reportComment.setMovementMethod(ScrollingMovementMethod.getInstance());
            reportComment.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
            reportComment.setOnTouchListener(onTouchListener);
            myScore.setText(String.valueOf(initScore));
            disableBtn();
        }
        presenter = new ReportSelfPresenter(this);

        adapter = new QuestionAdapter(mData,passChoices,this);
        questionList.setAdapter(adapter);
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton button = (RadioButton)v;
                if(button!=null){
                    int position = (int)button.getTag(R.id.position);
                    int score = (int)button.getTag(R.id.score);
                    int radioPosition = (int)button.getTag(R.id.radio_position);
                    scores[position]=score;
                    selectedChoices[position] = radioPosition;
                    int total = 0;
                    for(int i=0;i<scores.length;i++){
                        total += scores[i];
                    }
                    myScore.setText(String.valueOf(total));
                }
            }
        });
//        adapter.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                RadioButton button = (RadioButton)group.findViewById(checkedId);
//                if(button!=null){
//                    int position = (int)button.getTag(R.id.position);
//                    int score = (int)button.getTag(R.id.score);
//                    int radioPosition = (int)button.getTag(R.id.radio_position);
//                    scores[position]=score;
//                    selectedChoices[position] = radioPosition;
//                    int total = 0;
//                    for(int i=0;i<scores.length;i++){
//                        total += scores[i];
//                    }
//                    myScore.setText(String.valueOf(total));
//                }
//            }
//        });
    }

    @Override
    public void disableBtn() {
        submit.setClickable(false);
        submit.setAlpha(0.5f);
        submit.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }

    @Override
    public String getContentId() {
        return contentId;
    }

    @Override
    public void enableBtn() {
        submit.setClickable(true);
        submit.setAlpha(1);
        submit.setOnClickListener(this);
        submit.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public String getUserComment() {
        return reportComment.getText().toString();
    }

    @Override
    public void setCommentListener(TextWatcher watcher) {
        reportComment.addTextChangedListener(watcher);
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_report_self_btn) {

            if (dialog == null){
                dialog = new CustomDialog(this);
                dialog.setNoStr(getResources().getString(R.string.no));
                dialog.setYesStr(getResources().getString(R.string.sign_up_btn));
                dialog.setTitleStr(getResources().getString(R.string.report_self_dialog));
                dialog.setListener(new CustomDialog.YesOrNoClickListener() {
                    @Override
                    public void yesClick() {
                        if (dialog.isShowing()) {
                            dialog.dismiss();
                        }

                        String selected = "";
                        for(int i=0;i<selectedChoices.length;i++){
                            if(i == selectedChoices.length-1)
                                selected += String.valueOf(selectedChoices[i]);
                            else
                                selected += String.valueOf(selectedChoices[i])+",";
                        }
                        String comments = reportComment.getText().toString();
                        presenter.submit(contentId, selected, comments);
                    }

                    @Override
                    public void noClick() {
                        if (dialog.isShowing()) {
                            dialog.dismiss();
                        }
                    }
                });
            }
            dialog.show();
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_report_self;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.report_self_title);
    }
}
