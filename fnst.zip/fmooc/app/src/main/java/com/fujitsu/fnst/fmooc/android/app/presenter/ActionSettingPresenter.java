package com.fujitsu.fnst.fmooc.android.app.presenter;

import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.utils.ShareReferencesManager;
import com.fujitsu.fnst.fmooc.android.app.view.ActionSettingViewInterface;

/**
 * Created by lijl.fnst on 2015/12/16.
 */
public class ActionSettingPresenter extends BasePresenter{
    private ActionSettingViewInterface view;
    private Boolean inWifiStatus;
    public ActionSettingPresenter(ActionSettingViewInterface viewInterface){
        super();
        view = viewInterface;
        init();
    }
    public void init(){
        inWifiStatus = ShareReferencesManager.getInstance(context).getBoolean(Constants.SETTING_INWIFI_PLAY);
        if (inWifiStatus){
            view.setSwitchOn();
        } else {
            view.setSwitchOff();
        }

    }
    public void setInWifiOn(){
        ShareReferencesManager.getInstance(context).setValue(Constants.SETTING_INWIFI_PLAY,true);
        view.setSwitchOn();
    }
    public void setInWifiOff(){
        ShareReferencesManager.getInstance(context).setValue(Constants.SETTING_INWIFI_PLAY,false);
        view.setSwitchOff();
    }
}
