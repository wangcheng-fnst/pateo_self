package com.fujitsu.fnst.fmooc.android.app;

import android.app.Application;
import android.os.Environment;
import com.fujitsu.fnst.fmooc.android.app.utils.RequestWithHeadImageDownloader;
import com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

/**
 * Created by wangc.fnst on 2015/12/7.
 */
public class FmoocApplication extends Application {

    private static FmoocApplication instance;
    private String LOG_TAG = FmoocApplication.class.getName();
    public static String staticDataPath = Environment
            .getExternalStorageDirectory()
            + "/Android/data/"
            + "android.fmooc" + "/datas/";


    public static FmoocApplication getInstance(){
        return  instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        initImageLoader();
    }


    private void initImageLoader(){
        if (ImageLoader.getInstance().isInited()){
            ImageLoader.getInstance().destroy();
        }
        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                .showImageForEmptyUri(R.drawable.pic_loading)
                .showImageOnFail(R.drawable.pic_loading)
                .showImageOnLoading(R.drawable.pic_loading)
//                .extraForDownloader(header)
                .cacheInMemory(true)
                .cacheOnDisk(true)
                .build();
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(this)
                .defaultDisplayImageOptions(defaultOptions)
                .imageDownloader(new RequestWithHeadImageDownloader(this))
                .diskCacheSize(100 * 1024 * 1024) // 100 Mb
                .memoryCache(new LruMemoryCache(100 * 1024 * 1024))
                .build();
        // Initialize ImageLoader with configuration.
        ImageLoader.getInstance().init(config);


    }
    private static boolean isRssOK = false;
    private static boolean hasNewRss = false;

    public static boolean isRssOK() {
        return isRssOK;
    }

    public static void setIsRssOK(boolean isRssOK) {
        FmoocApplication.isRssOK = isRssOK;
    }

    public static boolean isHasNewRss() {
        return hasNewRss;
    }

    public static void setHasNewRss(boolean hasNewRss) {
        FmoocApplication.hasNewRss = hasNewRss;
    }
}
