package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by lijl.fnst on 2016/01/19.
 */
public class ReportSubmission implements Serializable {
    private String contentId;
    private String state;
    private SubmittedReport mySubmission;
    private ReportEvaluationWording evaluationWording;
    private SubmittedReportEvaluation selfEvaluation;
    private List<SubmittedReport> assignedSubmissions;
    private List<SubmittedReportEvaluation> evaluationsForAssignedSubmission;
    private List<SubmittedReportEvaluation> evaluationsForMySubmission;
    private Reflection myReflection;

    public SubmittedReport getMySubmission() {
        return mySubmission;
    }

    public void setMySubmission(SubmittedReport mySubmission) {
        this.mySubmission = mySubmission;
    }

    public SubmittedReportEvaluation getSelfEvaluation() {
        return selfEvaluation;
    }

    public void setSelfEvaluation(SubmittedReportEvaluation selfEvaluation) {
        this.selfEvaluation = selfEvaluation;
    }

    public ReportEvaluationWording getEvaluationWording() {
        return evaluationWording;
    }

    public void setEvaluationWording(ReportEvaluationWording evaluationWording) {
        this.evaluationWording = evaluationWording;
    }

    public List<SubmittedReport> getAssignedSubmissions() {
        return assignedSubmissions;
    }

    public void setAssignedSubmissions(List<SubmittedReport> assignedSubmissions) {
        this.assignedSubmissions = assignedSubmissions;
    }

    public List<SubmittedReportEvaluation> getEvaluationsForAssignedSubmission() {
        return evaluationsForAssignedSubmission;
    }

    public void setEvaluationsForAssignedSubmission(List<SubmittedReportEvaluation> evaluationsForAssignedSubmission) {
        this.evaluationsForAssignedSubmission = evaluationsForAssignedSubmission;
    }

    public List<SubmittedReportEvaluation> getEvaluationsForMySubmission() {
        return evaluationsForMySubmission;
    }

    public void setEvaluationsForMySubmission(List<SubmittedReportEvaluation> evaluationsForMySubmission) {
        this.evaluationsForMySubmission = evaluationsForMySubmission;
    }

    public Reflection getMyReflection() {
        return myReflection;
    }

    public void setMyReflection(Reflection myReflection) {
        this.myReflection = myReflection;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }
}
