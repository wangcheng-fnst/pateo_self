package com.fujitsu.fnst.fmooc.android.app.view;

import android.text.TextWatcher;

/**
 * Created by lijl.fnst on 2015/12/11.
 */
public interface RegisterViewInterface extends BaseViewInterface{
    void enableBtn();
    void setNameListener(TextWatcher watcher);
    void setPasswordListener(TextWatcher watcher);
    String getUserName();
    String getPwd();
    void disableBtn();
    void showPassword();
    void hidePassword();
    String getEmail();
    void setEmailText(String email);
}
