package com.fujitsu.fnst.fmooc.android.app.data.model;


import java.io.Serializable;

/**
 * Created by wangc.fnst on 2015/12/16.
 */
public class CourseModel implements Serializable {
    private int pId;
    private int id;
    private String contentId;
    private String playlistId;
    private String courseId;
    private String authorId;
    private String contentType;
    private String name;
    private String description;
    private String youtubeId;
    private int lengthInSeconds;
    private int percentageViewed;
    private String state;
    private String reportTitle;
    private String reportLabel;

    /**
     * local
     * @return
     */
    private boolean isSendOk = false;

    public boolean isSendOk() {
        return isSendOk;
    }

    public void setIsSendOk(boolean isSendOk) {
        this.isSendOk = isSendOk;
    }

    public int getpId() {
        return pId;
    }

    public void setpId(int pId) {
        this.pId = pId;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    public String getPlaylistId() {
        return playlistId;
    }

    public void setPlaylistId(String playlistId) {
        this.playlistId = playlistId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getAuthorId() {
        return authorId;
    }

    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getYoutubeId() {
        return youtubeId;
    }

    public void setYoutubeId(String youtubeId) {
        this.youtubeId = youtubeId;
    }

    public int getLengthInSeconds() {
        return lengthInSeconds;
    }

    public void setLengthInSeconds(int lengthInSeconds) {
        this.lengthInSeconds = lengthInSeconds;
    }

    public int getPercentageViewed() {
        return percentageViewed;
    }

    public void setPercentageViewed(int percentageViewed) {
        this.percentageViewed = percentageViewed;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getReportTitle() {
        return reportTitle;
    }

    public void setReportTitle(String reportTitle) {
        this.reportTitle = reportTitle;
    }

    public String getReportLabel() {
        return reportLabel;
    }

    public void setReportLabel(String reportLabel) {
        this.reportLabel = reportLabel;
    }
}
