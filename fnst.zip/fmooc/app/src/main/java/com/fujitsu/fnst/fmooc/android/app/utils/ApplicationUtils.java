package com.fujitsu.fnst.fmooc.android.app.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import com.fujitsu.fnst.fmooc.android.app.FmoocApplication;
import com.fujitsu.fnst.fmooc.android.app.network.model.User;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;

import java.io.File;

/**
 * アプリのツール
 *
 */
public class ApplicationUtils {

    private static String tmpFilePath;

    public static void setTmpFilePath(String path){
        tmpFilePath = path;
    }
    public static String getTmpFilePath(){
        return tmpFilePath;
    }

    public static String token;

    public static float dp2px(Context context, float dp){
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }

    public static float sp2px(Context context, float sp){
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, context.getResources().getDisplayMetrics());
    }

    public static int getDeviceDp(Context context) {
        DisplayMetrics dm = FmoocApplication.getInstance().getResources().getDisplayMetrics();
        Log.e("window:", "width:" + dm.widthPixels + " height:" + dm.heightPixels + " dentisy:" + dm.density + " dentisyDpi:" + dm.densityDpi);

        return 160 * dm.widthPixels / dm.densityDpi;
    }


    /**
     * プログラムのバージョンを取得する
     * @return プログラムのバージョン:取得できないときに、"-1"を返る
     */
    public static int getPackageVersion() {
        int version = -1;
        try {
            PackageManager pm = FmoocApplication.getInstance().getPackageManager();
            PackageInfo pi = pm.getPackageInfo(FmoocApplication.getInstance().getPackageName(), 0);
            version = pi.versionCode;
        } catch (PackageManager.NameNotFoundException ex) {
            ex.printStackTrace();
        }
        return version;
    }

    /**
     * プログラムのバージョン名を取得する
     * @return プログラムのバージョン名:取得できないときに、nullを返る
     */
    public static String getPackageVersionName() {
        String versionName = null;
        try {
            PackageManager pm = FmoocApplication.getInstance().getPackageManager();
            PackageInfo pi = pm.getPackageInfo(FmoocApplication.getInstance().getPackageName(), 0);
            versionName = pi.versionName;
        } catch (PackageManager.NameNotFoundException ex) {
            ex.printStackTrace();
        }
        return versionName;
    }

    /**
     * ネットワークが利用可能かどうか確認する
     * @return ネットワークが利用可能かどうか
     */
    public static boolean isOpenNetwork() {
        ConnectivityManager connManager = (ConnectivityManager) FmoocApplication.getInstance().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connManager.getActiveNetworkInfo() != null) {
            return connManager.getActiveNetworkInfo().isAvailable();
        }
        return false;
    }

    public static boolean isAgreeWithoutWifi(){
        boolean result = ShareReferencesManager.getInstance(FmoocApplication.getInstance()).getBoolean(Constants.SETTING_INWIFI_PLAY);
        return result;
    }


    /**
     * キャッシュファイルのパスを取得する
     *
     * @return キャッシュファイルのパス(書き込むことができなければnull)
     */
    public static File getCacheFileDir() {
        File file = null;
        //SDカードをmountの時に
        if (Environment.getExternalStorageState()
                .equals(Environment.MEDIA_MOUNTED)) {
            file = FmoocApplication.getInstance().getExternalCacheDir();
        }
        //デバイスは、SDカードでない場合
        else if (Environment.getExternalStorageState()
                .equals(Environment.MEDIA_REMOVED)) {
            file = FmoocApplication.getInstance().getCacheDir();
        }
        if (file != null && file.canWrite()) {
            return file;
        } else {
        return null;
        }
    }

    /**
     * キャッシュファイルのパスを取得する
     *
     * @return キャッシュファイルのパス（デフォルトは空の文字列を返す）
     */
    public static String getCacheFileDirPath() {
        //SDカードをmountの時に
        if (Environment.getExternalStorageState()
                .equals(Environment.MEDIA_MOUNTED)) {
            return FmoocApplication.getInstance().getExternalCacheDir().getPath();
        }
        //デバイスは、SDカードでない場合
        else if (Environment.getExternalStorageState()
                .equals(Environment.MEDIA_REMOVED)) {
            return FmoocApplication.getInstance().getCacheDir().getPath();
        }
        return "";
    }


    /**
     * avoid double click
     */
    private static long lastClickTime;
    public synchronized static boolean isFastClick() {
        long time = System.currentTimeMillis();
        if ( time - lastClickTime < 500) {
            return true;
        }
        lastClickTime = time;
        return false;
    }
    public static void setToken(String token1){
        token = token1;
    }
    public static String getToken(){
        return token;
    }

    public static  boolean isOver = true;



    public static UserInfoModel userInfoModel;

    public static boolean isSetting = false;







}
