package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.util.List;

/**
 * Created by zhaod.fnst on 2016/1/26.
 */
public class MessageDetailModel {
    private Message message;

    public MessageDetailModel() {
    }

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }
}
