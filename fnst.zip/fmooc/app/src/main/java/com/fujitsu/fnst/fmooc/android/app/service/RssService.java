package com.fujitsu.fnst.fmooc.android.app.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import com.fujitsu.fnst.fmooc.android.app.repository.RssRepository;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import rx.Subscription;

/**
 * Created by wangc.fnst on 2016/1/19.
 */
public class RssService extends Service implements RssRepository.GetFromNetFinishListener{

    private Subscription subscription;
    private RssBinder rssBinder = new RssBinder();

    @Override
    public void finish() {
        RssRepository.getInstance().setListener(null);
        Intent intent = new Intent();
        intent.setAction(Constants.ACTION_HAS_NEW_RSS);
        sendBroadcast(intent);
    }

    class RssBinder extends Binder{
        public RssService getService(){
            return RssService.this;
        }
    }
    @Override
    public IBinder onBind(Intent intent) {
        return rssBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null){
            String action = intent.getAction();
            if (action.equals(Constants.ACTION_GET_RSS)){
                RssRepository.getInstance().setListener(this);
                RssRepository.getInstance().getRss();
            }
        }
        return super.onStartCommand(intent, flags, startId);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
