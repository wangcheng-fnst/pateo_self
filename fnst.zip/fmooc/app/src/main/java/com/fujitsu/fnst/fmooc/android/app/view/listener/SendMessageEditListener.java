package com.fujitsu.fnst.fmooc.android.app.view.listener;

import android.content.Context;
import android.text.*;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.widget.EditText;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.view.DiscussionViewInterface;

/**
 * Created by wangc.fnst on 2016/1/5.
 */
public class SendMessageEditListener implements TextWatcher {
    private EditText editText;
    private boolean isWatch;
    private String watchStr;
    private Context mContext;

    private String oldStr = "";
    private boolean isNeedWatch = true;

    public SendMessageEditListener(Context mContext) {

        this.mContext = mContext;

    }

    public boolean isWatch() {
        return isWatch;
    }

    public void setIsWatch(boolean isWatch) {
        this.isWatch = isWatch;
//        ss = new SpannableString(watchStr);
        }

    public String getWatchStr() {
        return watchStr;
    }

    public void setWatchStr(String watchStr) {
        this.watchStr = watchStr;
        oldStr = watchStr;
    }

    public EditText getEditText() {
        return editText;
    }

    public void setEditText(EditText editText) {
        this.editText = editText;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        Log.e("TextChange","onTextChanged:"+s.toString()+" start:"+start+"before:"+before+" count:"+count);
    }

    @Override
    public void afterTextChanged(Editable s) {
        Log.e("TextChange","afterTextChanged:"+s.toString());
        String currentStr = s.toString();
        Object[] spannable = s.getSpans(0, s.length(), Object.class);
        for (Object o : spannable) {
            // when input keyboard observer this edittext, return
            if (o instanceof android.text.style.UnderlineSpan){
                return;
            }
        }

        if (isWatch && !oldStr.equals(currentStr)){
             SpannableString ss = new SpannableString(currentStr);
            if (currentStr.indexOf(watchStr) == 0) {
                oldStr = currentStr;
                ss.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.font_dark_gray)), 0, watchStr.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                ss.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.black)), watchStr.length(), currentStr.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                editText.setText(ss);
                editText.setSelection(ss.length());
            }else if (currentStr.indexOf(watchStr) < 0){
                if (currentStr.length() < watchStr.length()) {
                    oldStr = "";
                    editText.setText("");
                    isWatch = false;
                    ((DiscussionViewInterface) (mContext)).removeEditListener();
                    editText.setTextColor(mContext.getResources().getColor(R.color.black));
                }else {
                    ss = new SpannableString(oldStr);
                    ss.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.font_dark_gray)), 0, watchStr.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                    ss.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.black)), watchStr.length(), oldStr.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                    editText.setText(ss);
                    editText.setSelection(oldStr.length());
                    return;
                }
            }else if (currentStr.indexOf(watchStr) > 0){
                ss = new SpannableString(oldStr);
                ss.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.font_dark_gray)), 0, watchStr.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                ss.setSpan(new ForegroundColorSpan(mContext.getResources().getColor(R.color.black)), watchStr.length(), oldStr.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                editText.setText(ss);
                editText.setSelection(oldStr.length());
                return;
            }


        }

    }
}
