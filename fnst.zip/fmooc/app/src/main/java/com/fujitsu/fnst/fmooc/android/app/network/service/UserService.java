package com.fujitsu.fnst.fmooc.android.app.network.service;

import android.util.AndroidRuntimeException;
import com.fujitsu.fnst.fmooc.android.app.network.ObserverConvert;
import com.fujitsu.fnst.fmooc.android.app.network.ServiceBuilder;
import com.fujitsu.fnst.fmooc.android.app.network.model.*;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import retrofit.Call;
import retrofit.Response;
import retrofit.http.*;
import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by wangc.fnst on 2015/12/24.
 */
public class UserService {

    private static UserService service;
    private LoginInterface loginInterface;

    public UserService() {
        loginInterface = ServiceBuilder.getInstance().build(LoginInterface.class);
    }

    public static UserService getService() {
        if (service == null) {
            service = new UserService();
        }
        return service;
    }

    public Call<EmptyModel> dummyCode(String code){
        Map<String, String> body = new HashMap<String, String>();
        body.put("code", code);

        return loginInterface.dummyCode(code);
    }

    public Call<LoginModel> login(String mail, String pwd) {
        Map<String, String> body = new HashMap<String, String>();
        body.put("email", mail);
        body.put("password", pwd);
        Call<LoginModel> call = loginInterface.login(mail,pwd);
        return call;
    }

    public Call<LoginModel> newUser(String name,String email,String pwd){
        Map<String, String> body = new HashMap<String, String>();
        body.put("email", email);
        body.put("password", pwd);
        body.put("name",name);
        return loginInterface.newUser(email, pwd, name);
    }

    public Call<EmptyModel> sendCode(String email, String codeFor){
        Map<String, String> body = new HashMap<String, String>();
        body.put("email", email);

        return loginInterface.sendCode(email, codeFor);
    }

//    public Call<EmptyModel> resetPwd(String id, String oldPassword, String newPassword){
//        Map<String, String> body = new HashMap<String, String>();
//        body.put("oldPassword", oldPassword);
//        body.put("newPassword", newPassword);
//
//        return loginInterface.resetPwd(id, oldPassword, newPassword);
//    }

    public Call<EmptyModel> forgetPwd(String email, String newPasswrod){
        Map<String, String> body = new HashMap<String, String>();
        body.put("email", email);
        body.put("newPasswrod", newPasswrod);

        return loginInterface.forgetPwd(email, newPasswrod);
    }

    public Call<EmptyModel> getUserInfo(String id, String data){
        return loginInterface.getUserInfo(id, data);
    }



    public Subscription getUserInformation(String id,String data, Subscriber<UserInfoModel> subscriber){
        Observable<Response<UserInfoModel>> observable = loginInterface.getUserInformation(ApplicationUtils.getToken(), Constants.CONTENT_REFERER,id,data);
        return observable.flatMap(new ObserverConvert<UserInfoModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public Subscription setUserInformation(String id,Map<String, Object> data, Subscriber<UserInfoModel> subscriber){
        Observable<Response<UserInfoModel>> observable = loginInterface.setUserInformation(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id, data);
        return observable.flatMap(new ObserverConvert<UserInfoModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public Subscription resetPwd(String id, String oldPassword, String newPassword,Subscriber<EmptyModel> subscriber){
        Observable<Response<EmptyModel>> observable = loginInterface.resetPwd(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id, oldPassword, newPassword);
        return observable.flatMap(new ObserverConvert<EmptyModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
    public Subscription changeHeadImage(String id,String imageId,Subscriber<EmptyModel> subscriber){
        Observable<Response<EmptyModel>> observable = loginInterface.changeHeadImage(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, id, imageId);
        return observable.flatMap(new ObserverConvert<EmptyModel>())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    public Subscription getImages(Subscriber<Image> subscriber){
        Observable<Response<Image>> observable = loginInterface.getImages(ApplicationUtils.getToken(), Constants.CONTENT_REFERER);
        return  observable.flatMap(new ObserverConvert<Image>())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(subscriber);
    }

    public Subscription userLogout(Subscriber<EmptyModel> subscriber){
        Observable<Response<EmptyModel>> observable = loginInterface.userLogout(ApplicationUtils.getToken(), Constants.CONTENT_REFERER);
        return  observable.flatMap(new ObserverConvert<EmptyModel>())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(subscriber);
    }

    public Subscription confirmCode(Subscriber<CodeEmail> subscriber, String code){
        Observable<Response<CodeEmail>> observable = loginInterface.confirmCode(ApplicationUtils.getToken(), Constants.CONTENT_REFERER, code);
        return  observable.flatMap(new ObserverConvert<CodeEmail>())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(subscriber);
    }
    public interface LoginInterface {
        @GET("security/confirmation-code")
        Call<EmptyModel> dummyCode(@Query("code") String code);

        @FormUrlEncoded
        @POST("security/new-user-token")
        Call<LoginModel> login(@Field("email") String email,@Field("password") String pwd);

        @FormUrlEncoded
        @POST("users/new-user")
        Call<LoginModel> newUser(@Field("email") String email,@Field("password") String pwd,@Field("displayName") String name);

        @FormUrlEncoded
        @POST("security/new-email-confirmation-code")
        Call<EmptyModel> sendCode(@Field("email") String email, @Field("for") String codeFor);

        @FormUrlEncoded
        @POST("users/{id}/password")
        Observable<Response<EmptyModel>> resetPwd(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@Field("oldPassword") String oldPassword,@Field("newPassword") String newPassword);

        @FormUrlEncoded
        @POST("security/new-password")
        Call<EmptyModel> forgetPwd(@Field("email") String email,@Field("newPassword") String newPassword);

        @GET("users/{id}")
        Call<EmptyModel> getUserInfo(@Path("id") String id, @Query("data") String data);

        @GET("users/{id}")
        Observable<Response<UserInfoModel>> getUserInformation(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@Query("data") String data);
        @GET("users/{id}")
        Observable<UserInfoModel> getUserInformationNew(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@Query("data") String data);

        @FormUrlEncoded
        @POST("users/{id}")
        Observable<Response<UserInfoModel>> setUserInformation(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@FieldMap Map<String, Object> data);

        @FormUrlEncoded
        @POST("users/{id}/image")
        Observable<Response<EmptyModel>> changeHeadImage(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer,@Path("id") String id,@Field("imageId") String imageId);

        @GET("users/profile-images")
        Observable<Response<Image>> getImages(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer);

        @DELETE("security/new-user-token")
        Observable<Response<EmptyModel>> userLogout(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer);

        @GET("security/confirmation-code")
        Observable<Response<CodeEmail>> confirmCode(@Header("Fisdom-User-Token") String token,@Header("Referer") String referer, @Query("code") String code);

    }
}
