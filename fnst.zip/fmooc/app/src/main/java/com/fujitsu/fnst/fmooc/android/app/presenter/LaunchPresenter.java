package com.fujitsu.fnst.fmooc.android.app.presenter;

import android.content.Intent;
import android.widget.Toast;
import com.fujitsu.fnst.fmooc.android.app.view.LaunchViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.activity.LoginActivity;

/**
 * Created by wangc.fnst on 2015/12/10.
 */
public class LaunchPresenter extends BasePresenter{
    private LaunchViewInterface view;


    public LaunchPresenter(LaunchViewInterface loginViewInterface){
        super();
        view = loginViewInterface;
    }


    public void login(){
        Toast.makeText(context,"login btn click",Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(context, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public void register(){
        Toast.makeText(context,"login register click",Toast.LENGTH_SHORT).show();
    }
    public void facebookLink(){
        Toast.makeText(context,"login facebook click",Toast.LENGTH_SHORT).show();
    }
    public void googleLink(){
        Toast.makeText(context,"login google click",Toast.LENGTH_SHORT).show();
    }
}
