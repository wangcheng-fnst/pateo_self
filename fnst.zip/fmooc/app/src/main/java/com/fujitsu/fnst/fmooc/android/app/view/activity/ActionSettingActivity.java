package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.ActionSettingPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.HelpPresenter;
import com.fujitsu.fnst.fmooc.android.app.view.ActionSettingViewInterface;

import butterknife.Bind;

public class ActionSettingActivity extends BaseActivity<ActionSettingPresenter> implements ActionSettingViewInterface {

    @Bind(R.id.setting_inwifi_sw)
    Switch inWifiSw;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new ActionSettingPresenter(this);
        inWifiSw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                if (isChecked){
                    presenter.setInWifiOn();
                }else {
                    presenter.setInWifiOff();
                }
            }
        });
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_action_setting;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.action_setting_title);
    }

    @Override
    public void setSwitchOn(){
        inWifiSw.setChecked(true);
    }

    @Override
    public void setSwitchOff(){
        inWifiSw.setChecked(false);
    }

}
