package com.fujitsu.fnst.fmooc.android.app.view;

import android.text.TextWatcher;

/**
 * Created by wangc.fnst on 2015/12/11.
 */
public interface SendViewInterface extends BaseViewInterface {

    void enableBtn();
    void disableBtn();
    void setChangeListener(TextWatcher watcher);
    String getEmail();

}
