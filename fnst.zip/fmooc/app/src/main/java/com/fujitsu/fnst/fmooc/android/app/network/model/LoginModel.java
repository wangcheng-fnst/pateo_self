package com.fujitsu.fnst.fmooc.android.app.network.model;

import java.io.Serializable;

/**
 * Created by wangc.fnst on 2015/12/24.
 */
public class LoginModel implements Serializable {

    private String userId;

    public LoginModel() {
    }

    public LoginModel(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
