package com.fujitsu.fnst.fmooc.android.app.presenter;

import com.fujitsu.fnst.fmooc.android.app.view.SendSuccessViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.SignUpViewInterface;

/**
 * Created by lijl.fnst on 2015/12/29.
 */
public class SendSuccessPresenter extends BasePresenter {
    private SendSuccessViewInterface view;
    public SendSuccessPresenter(SendSuccessViewInterface sendSuccessViewInterface){
        super();
        view = sendSuccessViewInterface;
    }
}
