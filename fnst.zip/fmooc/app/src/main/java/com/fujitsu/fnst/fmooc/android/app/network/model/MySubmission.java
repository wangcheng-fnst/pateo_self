package com.fujitsu.fnst.fmooc.android.app.network.model;

/**
 * Created by lijl.fnst on 2016/01/19.
 */
public class MySubmission {
    private String submissionId;
    private String submittedAnswerText;
    private String submissionDateTime;

    public String getSubmissionId() {
        return submissionId;
    }

    public void setSubmissionId(String submissionId) {
        this.submissionId = submissionId;
    }

    public String getSubmittedAnswerText() {
        return submittedAnswerText;
    }

    public void setSubmittedAnswerText(String submittedAnswerText) {
        this.submittedAnswerText = submittedAnswerText;
    }

    public String getSubmissionDateTime() {
        return submissionDateTime;
    }

    public void setSubmissionDateTime(String submissionDateTime) {
        this.submissionDateTime = submissionDateTime;
    }
}
