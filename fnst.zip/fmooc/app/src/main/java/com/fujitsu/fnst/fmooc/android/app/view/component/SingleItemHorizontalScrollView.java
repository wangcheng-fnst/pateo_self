package com.fujitsu.fnst.fmooc.android.app.view.component;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;

/**
 * Created by wangc.fnst on 2015/12/28.
 */
public class SingleItemHorizontalScrollView extends HorizontalScrollView {

    private Adapter mAdapter;
    private int mScreenWidth;
    private int mItemWidth;
    private ViewGroup mContainer;

    private int mItemCount;
    private boolean flag;
    public SingleItemHorizontalScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        mScreenWidth = outMetrics.widthPixels;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (!flag){
            mContainer = (ViewGroup) getChildAt(0);
            if (mAdapter != null){
                mItemCount = mAdapter.getCount();
                mItemWidth = mScreenWidth / mItemCount;
                mContainer.removeAllViews();
                for (int i = 0; i< mAdapter.getCount();i++){
                    addChildView(i);
                }
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /**
     * 在容器末尾添加一个Item
     * @param i
     */
    private void addChildView(int i)
    {
        View item = mAdapter.getView(this, i);
        //设置参数
        android.view.ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(
                mItemWidth, android.view.ViewGroup.LayoutParams.MATCH_PARENT);
        item.setLayoutParams(lp);
        //设置Tag
        item.setTag(i);
        //添加事件
//        item.setOnClickListener(this);
        mContainer.addView(item);
    }
    /**
     * 在容器指定位置添加一个Item
     * @param i
     */
    private void addChildView(int i, int index)
    {
        View item = mAdapter.getView(this, i);
        android.view.ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(
                mItemWidth, android.view.ViewGroup.LayoutParams.MATCH_PARENT);
        item.setLayoutParams(lp);
        item.setTag(i);
//        item.setOnClickListener(this);
        mContainer.addView(item, index);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        flag = true;
        int action = ev.getAction();
        int scrollX = getScrollX();
        switch (action){
            case MotionEvent.ACTION_MOVE:
                if (scrollX == 0){
                    addChildToFirst();
                }
                if (Math.abs(scrollX - mItemWidth ) <= mItemCount){
                    addChildToLast();
                }
                break;
            case MotionEvent.ACTION_UP:
                checkForReset();
                break;
        }
        return super.onTouchEvent(ev);
    }
    /**
     * 在底部添加一个View，并移除第一个View
     */
    private void addChildToLast()
    {
        int pos = (Integer) mContainer.getChildAt(1).getTag();
        addChildView(pos);
        mContainer.removeViewAt(0);
        this.scrollTo(0, 0);
    }

    /**
     * 在顶部添加一个View，并移除最后一个View
     */
    protected void addChildToFirst()
    {
        int pos = (Integer) mContainer.getChildAt(mItemCount - 1).getTag();
        addChildView(pos, 0);
        mContainer.removeViewAt(mContainer.getChildCount() - 1);
        this.scrollTo(mItemWidth, 0);
    }

    /**
     * 检查当前getScrollY,显示完成Item，或者收缩此Item
     */
    private void checkForReset()
    {
        int val = getScrollX() % mItemWidth;
        if (val >= mItemWidth / 2)
        {
            smoothScrollTo(mItemWidth, 0);
        } else
        {
            smoothScrollTo(0, 0);
        }

    }


    public static abstract class Adapter{
        public abstract View getView(SingleItemHorizontalScrollView parent,int pos);
        public abstract int getCount();
    }
}
