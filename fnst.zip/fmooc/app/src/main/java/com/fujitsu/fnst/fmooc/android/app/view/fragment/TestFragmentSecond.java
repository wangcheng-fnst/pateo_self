package com.fujitsu.fnst.fmooc.android.app.view.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.fujitsu.fnst.fmooc.android.app.R;

/**
 * Created by wangc.fnst on 2015/12/14.
 */
public class TestFragmentSecond extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.test_second, container, false);
        return v;
    }
}
