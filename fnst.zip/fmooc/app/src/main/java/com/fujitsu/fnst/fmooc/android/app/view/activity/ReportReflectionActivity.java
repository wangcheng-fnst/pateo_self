package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportDetailModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportEvaluationActivity;
import com.fujitsu.fnst.fmooc.android.app.network.model.SubmittedReport;
import com.fujitsu.fnst.fmooc.android.app.network.model.SubmittedReportEvaluation;
import com.fujitsu.fnst.fmooc.android.app.presenter.ReportReflectionPresenter;
import com.fujitsu.fnst.fmooc.android.app.presenter.ReportSelfPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ReportReflectionViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.ReportSelfViewInterface;
import com.fujitsu.fnst.fmooc.android.app.view.component.CustomDialog;

import java.util.List;

public class ReportReflectionActivity extends BaseActivity<ReportReflectionPresenter> implements ReportReflectionViewInterface {
    @Bind(R.id.id_report_your)
    TextView reportYour;
    @Bind(R.id.report_comment1)
    TextView reportComment1;
    @Bind(R.id.report_comment2)
    TextView reportComment2;
    @Bind(R.id.report_comment3)
    TextView reportComment3;
    @Bind(R.id.id_report_reflection)
    EditText reportReflection;
    @Bind(R.id.reflection_table)
    TableLayout tableLayout;
    @Bind(R.id.id_submit_report_btn)
    Button submit;

    @Bind(R.id.reflection_score1)
    TextView score1;
    @Bind(R.id.reflection_score2)
    TextView score2;
    @Bind(R.id.reflection_score3)
    TextView score3;
    @Bind(R.id.reflection_score4)
    TextView score4;

    private View.OnTouchListener onTouchListener;
    private ReportDetailModel reportModel;
    List<ReportEvaluationActivity> activities;
    private SubmittedReportEvaluation selfData;
    private List<SubmittedReportEvaluation> otherData;
    private SubmittedReport myReport;
    private String contentId;
    private CustomDialog dialog;
    private int scoreNum1 = 0;
    private int scoreNum2 = 0;
    private int scoreNum3 = 0;
    private int scoreNum4 = 0;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new ReportReflectionPresenter(this);
        Intent intent = getIntent();
        reportModel =((ReportDetailModel)intent.getSerializableExtra(Constants.EXTRA_REPORT));
        contentId = reportModel.getContent().getContentId();
        myReport = reportModel.getSubmission().getMySubmission();
        selfData = reportModel.getSubmission().getSelfEvaluation();
        otherData = reportModel.getSubmission().getEvaluationsForMySubmission();
        reportYour.setMovementMethod(ScrollingMovementMethod.getInstance());
        reportYour.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        reportComment1.setMovementMethod(ScrollingMovementMethod.getInstance());
        reportComment1.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        reportComment2.setMovementMethod(ScrollingMovementMethod.getInstance());
        reportComment2.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        reportComment3.setMovementMethod(ScrollingMovementMethod.getInstance());
        reportComment3.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        reportReflection.setMovementMethod(ScrollingMovementMethod.getInstance());
        reportReflection.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);

        onTouchListener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if(event.getAction()==MotionEvent.ACTION_MOVE){
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if(event.getAction()==MotionEvent.ACTION_UP){
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                }
                return false;
            }
        };

        reportYour.setOnTouchListener(onTouchListener);
        reportComment1.setOnTouchListener(onTouchListener);
        reportComment2.setOnTouchListener(onTouchListener);
        reportComment3.setOnTouchListener(onTouchListener);
        reportReflection.setOnTouchListener(onTouchListener);

        submit.setOnClickListener(this);
        //createTablerow(tableLayout);
        setMyReport(myReport.getSubmittedAnswerText());
        setOtherComment(reportComment1, otherData.get(0).getComments());
        setOtherComment(reportComment2, otherData.get(1).getComments());
        setOtherComment(reportComment3, otherData.get(2).getComments());
        disableBtn();
        activities = reportModel.getSubmission().getEvaluationWording().getActivities();
        for (int i = 0; i < activities.size();i++){
            createTableRow(tableLayout, activities.get(i).getLabel(), Integer.toString(selfData.getSelectedScores().get(i)), Integer.toString(otherData.get(0).getSelectedScores().get(i)), Integer.toString(otherData.get(1).getSelectedScores().get(i)), Integer.toString(otherData.get(2).getSelectedScores().get(i)));
            scoreNum1 += selfData.getSelectedScores().get(i);
            scoreNum2 += otherData.get(0).getSelectedScores().get(i);
            scoreNum3 += otherData.get(1).getSelectedScores().get(i);
            scoreNum4 += otherData.get(2).getSelectedScores().get(i);
        }

        score1.setText(Integer.toString(scoreNum1));
        score2.setText(Integer.toString(scoreNum2));
        score3.setText(Integer.toString(scoreNum3));
        score4.setText(Integer.toString(scoreNum4));

        if (reportModel.getSubmission().getMyReflection() != null){
            reportReflection.setText(reportModel.getSubmission().getMyReflection().getSubmittedReflectionText());
            reportReflection.setFocusable(false);
            submit.setText(getResources().getString(R.string.report_sent));
            disableBtn();
        }

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_report_reflection;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.report_result_title);
    }

    private void createTableRow(TableLayout tableLayout, String title, String scoreAll,String score1,String score2, String score3){
        TableRow tableRow = new TableRow(this);
        tableRow.setBackground(getResources().getDrawable(R.drawable.table_bg_top));
        TextView view1 = new TextView(this);
        view1.setWidth(getResources().getDimensionPixelSize(R.dimen.dp_156));
        view1.setText(title);
        view1.setGravity(Gravity.LEFT);
        view1.setPadding(getResources().getDimensionPixelSize(R.dimen.dp_10), 0, 0, 0);
        view1.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimensionPixelSize(R.dimen.sp_14));
        view1.setTextColor(getResources().getColor(R.color.black));
        view1.getPaint().setFakeBoldText(true);
        tableRow.addView(view1);
        TextView view2 = new TextView(this);
        view2.setWidth(getResources().getDimensionPixelSize(R.dimen.dp_67));
        view2.setText(scoreAll);
        view2.setGravity(Gravity.CENTER);
        view2.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimensionPixelSize(R.dimen.sp_16));
        view2.setTextColor(getResources().getColor(R.color.black));
        view2.setBackground(getResources().getDrawable(R.drawable.table_bg_middle));
        tableRow.addView(view2);
        TextView view3 = new TextView(this);
        view3.setWidth(getResources().getDimensionPixelSize(R.dimen.dp_30));
        view3.setText(score1);
        view3.setGravity(Gravity.CENTER);
        view3.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimensionPixelSize(R.dimen.sp_16));
        view3.setTextColor(getResources().getColor(R.color.black));
        tableRow.addView(view3);
        TextView view4 = new TextView(this);
        view4.setWidth(getResources().getDimensionPixelSize(R.dimen.dp_32));
        view4.setText(score2);
        view4.setGravity(Gravity.CENTER);
        view4.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimensionPixelSize(R.dimen.sp_16));
        view4.setTextColor(getResources().getColor(R.color.black));
        view4.setBackground(getResources().getDrawable(R.drawable.table_bg_right));
        tableRow.addView(view4);
        TextView view5 = new TextView(this);
        view5.setWidth(getResources().getDimensionPixelSize(R.dimen.dp_25));
        view5.setText(score3);
        view5.setGravity(Gravity.CENTER);
        view5.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimensionPixelSize(R.dimen.sp_16));
        view5.setTextColor(getResources().getColor(R.color.black));
        tableRow.addView(view5);
        tableLayout.addView(tableRow);

    }

    public void setMyReport(String report){
        reportYour.setText(report);
    }

    public void setOtherComment(TextView reportComment, String comment){
        reportComment.setText(comment);
    }

    public void setMyReflection(String reflection){
        reportReflection.setText(reflection);
    }

    @Override
    public void enableBtn() {
        submit.setClickable(true);
        submit.setAlpha(1);
        submit.setOnClickListener(this);
        submit.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public void disableBtn() {
        submit.setClickable(false);
        submit.setAlpha(0.5f);
        submit.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }

    @Override
    public String getContentId() {
        return contentId;
    }

    @Override
    public String getComment() {
        return reportReflection.getText().toString();
    }

    @Override
    public void setCommentListener(TextWatcher watcher) {
        reportReflection.addTextChangedListener(watcher);
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_submit_report_btn) {

            if (dialog == null){
                dialog = new CustomDialog(this);
                dialog.setNoStr(getResources().getString(R.string.no));
                dialog.setYesStr(getResources().getString(R.string.sign_up_btn));
                dialog.setTitleStr(getResources().getString(R.string.report_reflection_dialog));
                dialog.setListener(new CustomDialog.YesOrNoClickListener() {
                    @Override
                    public void yesClick() {
                        if (dialog.isShowing()) {
                            dialog.dismiss();
                        }
                        String submissionId = myReport.getSubmissionId();
                        String comments = reportReflection.getText().toString();
                        presenter.submit(contentId, submissionId, comments);
                    }

                    @Override
                    public void noClick() {
                        if (dialog.isShowing()) {
                            dialog.dismiss();
                        }
                    }
                });
            }
            dialog.show();
        }
    }
}
