package com.fujitsu.fnst.fmooc.android.app.view;

import com.fujitsu.fnst.fmooc.android.app.data.model.UserModel;

/**
 * Created by lijl.fnst on 2015/12/21.
 */
public interface ProfileSettingViewInterface extends BaseViewInterface{

}
