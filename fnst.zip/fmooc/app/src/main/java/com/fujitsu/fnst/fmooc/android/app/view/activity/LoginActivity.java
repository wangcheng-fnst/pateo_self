package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import butterknife.Bind;
import butterknife.OnCheckedChanged;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.presenter.LoginPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.ApplicationUtils;
import com.fujitsu.fnst.fmooc.android.app.view.LoginViewInterface;

/**
 * Created by wangc.fnst on 2015/12/10.
 */
public class LoginActivity extends BaseActivity<LoginPresenter> implements LoginViewInterface {
    @Bind(R.id.id_login_tip_txt)
    TextView tipTxt;
    @Bind(R.id.id_name_edit)
    EditText nameEdit;
    @Bind(R.id.id_password_edit)
    EditText passwordEdit;
    @Bind(R.id.id_remember_box)
    CheckBox rememberBox;
    @Bind(R.id.id_login_btn)
    Button loginBtn;
    @Bind(R.id.id_forget_txt)
    TextView forgetTxt;
    @Bind(R.id.id_register_btn)
    Button registerBtn;


    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new LoginPresenter(this);
        loginBtn.setClickable(false);
        disableBtn();
        forgetTxt.setOnClickListener(this);
        registerBtn.setOnClickListener(this);
        rememberBox.setOnCheckedChangeListener(checkedChangeListener);
    }

    @Override
    protected int getLayout() {
        return R.layout.login_activity_layout;
    }

    @Override
    public boolean showBackImg() {
        return false;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.login_main_title);
    }

    @Override
    public void enableBtn() {
        loginBtn.setClickable(true);
        loginBtn.setOnClickListener(this);
        loginBtn.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public void disableBtn() {
        loginBtn.setClickable(false);
        loginBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }

    @Override
    public void setNameListener(TextWatcher watcher) {
        nameEdit.addTextChangedListener(watcher);
    }

    @Override
    public void setPasswordListener(TextWatcher watcher) {
        passwordEdit.addTextChangedListener(watcher);
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        super.onClick(v);
        if (v.getId() == R.id.id_login_btn){
            presenter.login();
        } else if (v.getId() == R.id.id_forget_txt){
            presenter.forgetPwdClick();
        } else if (v.getId() == R.id.id_register_btn){
            presenter.register();
        }

    }
    private CompoundButton.OnCheckedChangeListener checkedChangeListener = new CompoundButton.OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            presenter.setSaveUserInfo(isChecked);
        }
    };
    @Override
    public void setValue(String name,String pwd) {
        nameEdit.setText(name);
        passwordEdit.setText(pwd);
        rememberBox.setChecked(true);
    }

    @Override
    public String getName() {
        return nameEdit.getText().toString();
    }

    @Override
    public String getPwd() {
        return passwordEdit.getText().toString();
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
