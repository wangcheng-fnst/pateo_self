package com.fujitsu.fnst.fmooc.android.app.view.activity;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;

import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import butterknife.Bind;
import cn.pedant.SweetAlert.SweetAlertDialog;
import com.fujitsu.fnst.fmooc.android.app.R;
import com.fujitsu.fnst.fmooc.android.app.network.model.Report;
import com.fujitsu.fnst.fmooc.android.app.network.model.ReportDetailModel;
import com.fujitsu.fnst.fmooc.android.app.network.model.UserInfoModel;
import com.fujitsu.fnst.fmooc.android.app.presenter.ReportSendPresenter;
import com.fujitsu.fnst.fmooc.android.app.utils.Constants;
import com.fujitsu.fnst.fmooc.android.app.view.ReportSendViewInterface;

public class ReportSendActivity extends BaseActivity<ReportSendPresenter> implements ReportSendViewInterface {
    @Bind(R.id.id_report_title)
    TextView reportTitle;
    @Bind(R.id.id_content_edit)
    EditText contentEdit;
    @Bind(R.id.id_submit_report_btn)
    Button submitBtn;
//    private SweetAlertDialog dialog;
    private ReportDetailModel reportDetailModel;
    private String contentId;
    private int maxNumberOfCharacters;

    @Override
    protected void onCreateView() {
        super.onCreateView();
        presenter = new ReportSendPresenter(this);
        Intent intent = getIntent();
        reportDetailModel =((ReportDetailModel)intent.getSerializableExtra(Constants.EXTRA_REPORT));
        contentId=reportDetailModel.getContent().getContentId();
        reportTitle.setText(reportDetailModel.getContent().getReportLabel());
        maxNumberOfCharacters =reportDetailModel.getContent().getMaxNumberOfCharacters();
        String state = reportDetailModel.getContent().getState();
        if(!state.equals(Report.CANNOT_SUBMIT) && !state.equals(Report.WAITING_FOR_REPORT_ANSWER)){
            contentEdit.setText(reportDetailModel.getSubmission().getMySubmission().getSubmittedAnswerText());
            contentEdit.setFocusable(false);
            submitBtn.setText(getResources().getString(R.string.report_submitted));
            disableBtn();
        }else{
            disableBtn();
        }
    }

    @Override
    protected int getLayout() {
        return R.layout.activity_report_send;
    }

    @Override
    public boolean showBackImg() {
        return true;
    }

    @Override
    public boolean showMoreImg() {
        return false;
    }

    @Override
    public String getTitleContent() {
        return getResources().getString(R.string.report_send_title);
    }

    @Override
    public void showDialog(Dialog dialog) {
        dialog.show();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (R.id.id_submit_report_btn == v.getId()){
            showDialog(presenter.getMessageDialog());
        }
    }

    @Override
    public void enableBtn() {
        submitBtn.setClickable(true);
        submitBtn.setAlpha(1);
        submitBtn.setOnClickListener(this);
        submitBtn.setBackgroundResource(R.drawable.login_btn_bg);
    }

    @Override
    public void disableBtn() {
        submitBtn.setClickable(false);
        submitBtn.setAlpha(0.5f);
        submitBtn.setBackgroundResource(R.drawable.login_unable_btn_bg);
    }

    @Override
    public String getContentId() {
        return contentId;
    }

    @Override
    public String getUserAnswer() {
        return contentEdit.getText().toString();
    }

    @Override
    public int getMaxNumberOfCharacters() {
        return maxNumberOfCharacters;
    }

    @Override
    public EditText getEditText() {
        return contentEdit;
    }

    @Override
    public void setAnswerListener(TextWatcher watcher) {
        contentEdit.addTextChangedListener(watcher);
    }
}
