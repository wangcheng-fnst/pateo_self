package com.example;

import de.greenrobot.daogenerator.DaoGenerator;
import de.greenrobot.daogenerator.Entity;
import de.greenrobot.daogenerator.Schema;

import java.util.Date;

public class DaoGen {

    public static void main(String[] args) throws Exception {
        Schema schema = new Schema(1, "com.fujitsu.android.fmooc.data.database");
//        addEmail(schema);
//        addNotificationModel(schema);
        addRssItem(schema);
        new DaoGenerator().generateAll(schema, ".");
    }

    private static void addEmail(Schema schema) {
        Entity email = schema.addEntity("EmailModel");
        email.addIdProperty().autoincrement();
        email.addIntProperty("user_alert_mail_id");
        email.addIntProperty("user_id");
        email.addIntProperty("verification_status");
        email.addIntProperty("enabled");
        email.addStringProperty("alert_mail");
        email.addLongProperty("updated_at");
    }

    private static void addNotificationModel(Schema schema) {
        Entity entity = schema.addEntity("NotificationModel");
        entity.addIdProperty().autoincrement();

        entity.addStringProperty("recipientId");
        entity.addStringProperty("notificationId");
        entity.addStringProperty("senderId");
        entity.addStringProperty("senderType");
        entity.addStringProperty("status");
        entity.addStringProperty("text");
        entity.addDateProperty("dateTime");


    }
    private static void addRssItem(Schema schema){
        Entity entity = schema.addEntity("RssItemModel");
        entity.addIdProperty();
        entity.addStringProperty("title");
        entity.addStringProperty("link");
        entity.addDateProperty("pubDate");
        entity.addStringProperty("description");
        entity.addStringProperty("content");
        entity.addIntProperty("status");

    }
}
