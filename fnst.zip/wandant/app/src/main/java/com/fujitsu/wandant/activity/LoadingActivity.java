package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.WandantApplication;
import com.fujitsu.wandant.net.model.UserFromNet;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.UserUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chenjie.fnst on 2015/10/21.
 */
public class LoadingActivity extends NewBaseActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                UserFromNet user = UserUtils.getInstance().loadUser();
                if (null != user && !StringUtils.isBlank(user.getToken())){
                    Map<String,String> header = new HashMap<>();
                    header.put("X-Auth-Token", user.getToken());
                    WandantApplication.getInstance().initImageLoader(header);
                    startActivity(new Intent(LoadingActivity.this, MainActivity.class));
                } else {
                    Intent intent = new Intent(LoadingActivity.this, LoginActivity.class);
                    startActivity(intent);

                }
                LoadingActivity.this.finish();
            }

        }, 1500);
    }
}
