//******************************************************************
//* わんダント2システム
//******************************************************************
/*
 *	わんダント2Android
 *	AgreementWithoutAccountActivity.java
 *
 *	変更日			変更者				障害No／仕様変更No
 *	15/12/21 		FNST)Chenjie 	    新規作成
 *
 */
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************

package com.fujitsu.wandant.activity;

import android.content.Intent;

import android.graphics.Bitmap;

import android.net.Uri;

import android.os.Bundle;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;

import android.view.View;

import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import android.widget.Button;
import android.widget.TextView;

import butterknife.Bind;

import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;

import com.github.lzyzsd.jsbridge.BridgeWebView;
import com.github.lzyzsd.jsbridge.DefaultHandler;

/**
 * AgreementWithoutAccountActivity
 */
public class AgreementWithoutAccountActivity extends BaseActivity {

    /** WebViewClient for account agreement */
    private BridgeWebView.BridgeWebViewClient accountAgreeClient = null;

    /** WebViewClient for user agreement */
    private BridgeWebView.BridgeWebViewClient userAgreeClient = null;

    /** webview for acount agreement loading flag */
    private boolean isAccountLoadFinished = false;

    /** webview for user agreement loading flag */
    private boolean isUserLoadFinished = false;

    /** agreement info textview */
    @Bind(R.id.id_agree_info_tv)
    TextView agreeInfoTxt;

    /** webview to show account agreement */
    @Bind(R.id.id_account_agree_web)
    BridgeWebView accountAgreeWeb;

    /** webview to show user agreement */
    @Bind(R.id.id_user_agree_web)
    BridgeWebView userAgreeWeb;

    /** agree button */
    @Bind(R.id.id_agree_btn)
    Button agreeBtn;

    /**
     * title's text
     * @return title's text
     */
    @Override
    public String getTitleName() {
        return getString(R.string.agreement_title);
    }

    /**
     * title's url
     * @return title's url
     */
    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    /**
     * onCreateView
     * @param savedInstanceState
     */
    @Override
    public void onCreateView(Bundle savedInstanceState) {
        String          infoPart1     = getString(R.string.account_agreement_info1);
        String          infoPart2     = getString(R.string.account_agreement_info2);
        SpannableString agreementInfo = new SpannableString(infoPart1 + infoPart2);

        agreementInfo.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.font_dark_gray)), 0,
                              infoPart1.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        agreementInfo.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.font_green)), infoPart1.length(),
                              (infoPart1.length() + infoPart2.length()), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        agreeInfoTxt.setText(agreementInfo);
        agreeBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        agreeBtn.setOnClickListener(this);
        agreeBtn.setEnabled(true);
        initClient();
        showWaitingDialog();
        accountAgreeWeb.setVerticalScrollBarEnabled(false);
        accountAgreeWeb.setHorizontalScrollBarEnabled(false);
        accountAgreeWeb.getSettings().setTextZoom(100);
        accountAgreeWeb.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        accountAgreeWeb.setDefaultHandler(new DefaultHandler());
        accountAgreeWeb.setWebChromeClient(new WebChromeClient());
        accountAgreeWeb.setWebViewClient(accountAgreeClient);
        accountAgreeWeb.loadUrl(ApplicationUtils.getUserAgreementUrl());
        userAgreeWeb.setVerticalScrollBarEnabled(false);
        userAgreeWeb.setHorizontalScrollBarEnabled(false);
        userAgreeWeb.getSettings().setTextZoom(100);
        userAgreeWeb.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        userAgreeWeb.setDefaultHandler(new DefaultHandler());
        userAgreeWeb.setWebChromeClient(new WebChromeClient());
        userAgreeWeb.setWebViewClient(userAgreeClient);
        userAgreeWeb.loadUrl(ApplicationUtils.getUserAgreementUrl());
        findViewById(R.id.id_agree_info_tv).setOnClickListener(this);
    }

    /**
     * layout of activity
     * @return layout of activity
     */
    @Override
    public int getLayout() {
        return R.layout.activity_agreement;
    }

    /**
     * view click event
     * @param view
     */
    @Override
    public void onClick(View view) {
        super.onClick(view);
        if (view.getId() == R.id.id_agree_btn) {
            switch (activityFromFlag) {
            case Constants.ACTIVITY_FROM_REGISTER :
                Intent intent = new Intent();
                intent.putExtra(Constants.EXTRA_REGISTER_URL, ApplicationUtils.getRegisterUrlWithoutAccount());
                intent.setClass(this, UserRegisterWebViewActivity.class);
                startActivity(intent);
                break;
            default :
                finish();
                break;
            }
        }
    }

    /**
     * check if need to hide waiting dailaog
     *
     */
    public void checkHideLoadingDialog() {
        if (isAccountLoadFinished && isUserLoadFinished) {
            hideWaitingDialog();
        }
    }

    /**
     * init webview client
     *
     */
    public void initClient() {
        accountAgreeClient = accountAgreeWeb.new BridgeWebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (ApplicationUtils.getUserAgreementUrl().equals(url)
                        || url.contains(ApplicationUtils.getErrorUrl())) {
                    return false;
                } else {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.VIEW");
                    Uri uri = Uri.parse(url);
                    intent.setData(uri);
                    startActivity(intent);
                    return true;
                }
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                isAccountLoadFinished = true;
                checkHideLoadingDialog();
            }
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
            }
        };
        userAgreeClient = userAgreeWeb.new BridgeWebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (ApplicationUtils.getUserAgreementUrl().equals(url)
                        || url.contains(ApplicationUtils.getErrorUrl())) {
                    return false;
                } else {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.VIEW");
                    Uri uri = Uri.parse(url);
                    intent.setData(uri);
                    startActivity(intent);
                    return true;
                }
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                isUserLoadFinished = true;
                checkHideLoadingDialog();
            }
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
            }
        };
    }
}

