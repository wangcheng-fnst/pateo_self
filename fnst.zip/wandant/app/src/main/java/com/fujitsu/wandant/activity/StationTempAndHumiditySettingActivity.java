package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Station;
import com.fujitsu.wandant.net.model.UserFromNet;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ToastManager;
import com.fujitsu.wandant.view.datepicker.WheelView;
import com.fujitsu.wandant.view.datepicker.adapter.ArrayWheelAdapter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenjie.fnst on 2015/10/08.
 */
public class StationTempAndHumiditySettingActivity extends BaseActivity implements OnModelFinishedListener {

    @Bind(R.id.id_sure_btn)
    Button button;
    @Bind(R.id.id_temp_max_wv)
    WheelView tempWheelView;
    @Bind(R.id.id_humi_min_wv)
    WheelView humiWheelView;

    private List<String> tempList = new ArrayList<>();
    private List<String> humiList = new ArrayList<>();


    private String tempUnit;
    private String humiUnit;
    private String hyphen;

    private Station station = null;

    private int[] SHADOWS_COLORS = new int[] { 0xefffffff, 0xcfffffff, 0x3fffffff };

    @Override
    public String getTitleName() {
        return getString(R.string.station_setting);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        Serializable serializable = getIntent().getSerializableExtra(Constants.EXTRA_STATION);
        if (null != serializable){
            station = (Station) serializable;
        } else {
            station = new Station();
            station.setTemperature(Constants.STATION_TEMP_DEFAULT);
            station.setHumidity_down(Constants.STATION_HUMI_DEFAULT);
            UserFromNet user = UserUtils.getInstance().loadUser();
            if (null != user){
                station.setUser_id(user.getUser_id());
            }
        }
//        switch (activityFromFlag){
//            case Constants.ACTIVITY_FROM_SETTING_STATION_DETAIL:
//            case Constants.ACTIVITY_FROM_SETTING_ALERT_LIST:
//                button.setText(getResources().getString(R.string.setting_sure));
//                break;
//            default:
//                break;
//        }
        tempUnit = getResources().getString(R.string.temperature_unit);
        humiUnit = getResources().getString(R.string.percent_unit);
        hyphen = getResources().getString(R.string.hyphen);
        bindViews();
    }

    private void bindViews() {
        button.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        button.setOnClickListener(this);

        for (int index = Constants.STATION_TEMP_MIN; index < Constants.STATION_TEMP_MAX + 1; index++ ){
            tempList.add(String.valueOf(index) + tempUnit);
        }
        String[] tempItems = new String[Constants.STATION_TEMP_MAX - Constants.STATION_TEMP_MIN + 1];
        tempItems = tempList.toArray(tempItems);
        ArrayWheelAdapter<String> tempAdapter = new ArrayWheelAdapter<String>(this,tempItems);
        tempWheelView.setViewAdapter(tempAdapter);
        tempWheelView.setCyclic(false);
        tempWheelView.setVisibleItems(5);
        tempWheelView.setShadowColor(SHADOWS_COLORS[0],SHADOWS_COLORS[1],SHADOWS_COLORS[2]);
        if (null == station.getTemperature()){
            tempWheelView.setCurrentItem(Constants.STATION_TEMP_DEFAULT - Constants.STATION_TEMP_MIN);
        } else {
            tempWheelView.setCurrentItem(station.getTemperature() - Constants.STATION_TEMP_MIN);
        }

        for (int index = Constants.STATION_HUMI_MIN; index < Constants.STATION_HUMI_MAX + 1; index++ ){
            humiList.add(String.valueOf(index) + humiUnit);
        }
        String[] humiItems = new String[Constants.STATION_TEMP_MAX - Constants.STATION_TEMP_MIN + 1];
        humiItems = humiList.toArray(humiItems);
        ArrayWheelAdapter<String> humiAdapter = new ArrayWheelAdapter<String>(this,humiItems);
        humiWheelView.setViewAdapter(humiAdapter);
        humiWheelView.setCyclic(false);
        humiWheelView.setVisibleItems(5);
        humiWheelView.setShadowColor(SHADOWS_COLORS[0], SHADOWS_COLORS[1], SHADOWS_COLORS[2]);
        if (null == station.getHumidity_down()){
            humiWheelView.setCurrentItem(Constants.STATION_HUMI_DEFAULT - Constants.STATION_HUMI_MIN);
        } else {
            humiWheelView.setCurrentItem(station.getHumidity_down() - Constants.STATION_HUMI_MIN);
        }

    }

    @Override
    public int getLayout() {
        return R.layout.activity_station_setting;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_sure_btn:
                uploadStationToNet();
                break;
            default:
                break;
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_STATION_TEMP_HUMI_SETTING, this);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_STATION_TEMP_HUMI_SETTING);
    }

    private void uploadStationToNet() {
        Integer temp = tempWheelView.getCurrentItem() + Constants.STATION_TEMP_MIN;
        station.setTemperature(temp);
        Integer humi = humiWheelView.getCurrentItem() + Constants.STATION_HUMI_MIN;
        station.setHumidity_down(humi);
        DogDeviceStationRepository.getInstance().modifyStationFromNet(DogDeviceStationRepository.REQUEST_FROM_STATION_TEMP_HUMI_SETTING, station, true);

//        switch (activityFromFlag){
//            case Constants.ACTIVITY_FROM_SETTING_STATION_ADD:
//            case Constants.ACTIVITY_FROM_REGISTER:
//            case Constants.ACTIVITY_FROM_MAIN:
//                DogDeviceStationRepository.getInstance().addStationFromNet(DogDeviceStationRepository.REQUEST_FROM_STATION_TEMP_HUMI_SETTING, station, true);
//                break;
//            case Constants.ACTIVITY_FROM_SETTING_STATION_DETAIL:
//            case Constants.ACTIVITY_FROM_SETTING_ALERT_LIST:
//                DogDeviceStationRepository.getInstance().modifyStationFromNet(DogDeviceStationRepository.REQUEST_FROM_STATION_TEMP_HUMI_SETTING, station, true);
//                break;
//            default:
//                break;
//        }
    }

    @Override
    public void success(Object station, int type) {
//        switch (activityFromFlag){
//            case Constants.ACTIVITY_FROM_SETTING_STATION_ADD:
//                this.station = (Station) station;
//                Intent intentAdd = new Intent();
//                intentAdd.setClass(this,SettingActivity.class);
//                startActivity(intentAdd);
//                break;
//            case Constants.ACTIVITY_FROM_SETTING_STATION_DETAIL:
//            case Constants.ACTIVITY_FROM_SETTING_ALERT_LIST:
                Intent intent = new Intent();
                intent.putExtra(Constants.EXTRA_STATION,this.station);
                setResult(RESULT_OK, intent);
                finish();
//                break;
//            case Constants.ACTIVITY_FROM_REGISTER:
//                this.station = (Station) station;
//                Intent topIntent = new Intent();
//                topIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                topIntent.setClass(this, MainActivity.class);
//                startActivity(topIntent);
//            case Constants.ACTIVITY_FROM_MAIN:
//                Intent mainIntent = new Intent();
//                mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                mainIntent.setClass(this, MainActivity.class);
//                startActivity(mainIntent);
//            default:
//                break;
//        }
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
//        Toast.makeText(this,errorMsg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this,errorMsg,Toast.LENGTH_SHORT).show();
    }
}
