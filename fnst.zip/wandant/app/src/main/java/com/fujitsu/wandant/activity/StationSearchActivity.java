package com.fujitsu.wandant.activity;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.*;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelUuid;
import android.view.View;
import android.widget.Button;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.net.model.Station;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ToastManager;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by chenjie.fnst on 2015/10/14.
 */
@TargetApi(Build.VERSION_CODES.LOLLIPOP)
public class StationSearchActivity extends BaseActivity {

    private BluetoothLeScanner  mLEScanner;
    private ScanSettings settings;
    private List<ScanFilter>    filters;
    private ScanCallback mScanCallback;
    private static final long SCAN_PERIOD = 5000;
    private BluetoothAdapter bluetoothAdapter;
    private Thread scanThread;
    private static final int OPEN_BLUETOOTH_REQUEST = 1;

    private Context context;

    @Bind(R.id.id_progress_flag)
    View progressView;
    @Bind(R.id.id_sure_btn)
    Button sureBtn;

    private BluetoothDevice stationDevice = null;

    private Station station = null;

    @Override
    public String getTitleName() {
        return getResources().getString(R.string.station_setting);
    }

    @Override
    public int getLayout() {
        return R.layout.activity_station_search;
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }


    @Override
    public void onCreateView(Bundle savedInstanceState) {
        initStation();
        bindView();
        initBluetooth();
    }

    private void initStation() {
        station = new Station();
        station.setUser_id(UserUtils.getInstance().loadUser().getUser_id());
        station.setTemperature(Constants.STATION_TEMP_DEFAULT);
        station.setHumidity_down(Constants.STATION_HUMI_DEFAULT);
    }

    private void bindView() {
        context = this;
        sureBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        sureBtn.setOnClickListener(this);
        if (activityFromFlag == Constants.ACTIVITY_FROM_REGISTER){
            progressView.setVisibility(View.VISIBLE);
        } else {
            progressView.setVisibility(View.GONE);
        }
        if (activityFromFlag == Constants.ACTIVITY_FROM_REGISTER || activityFromFlag == Constants.ACTIVITY_FROM_MAIN){
            isBackable = false;
        } else {
            isBackable = true;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    private void setBtnStates(boolean isEnable){
        if (isEnable){
            sureBtn.setEnabled(true);
            sureBtn.setBackgroundResource(R.drawable.btn_sure);
        } else {
            sureBtn.setEnabled(false);
            sureBtn.setBackgroundResource(R.drawable.btn_sure_disable);
        }
    }

    private void goToNextActivity() {
        Intent wifiIntent = new Intent();
        wifiIntent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,activityFromFlag);
        wifiIntent.putExtra(Constants.EXTRA_STATION,station);
        wifiIntent.setClass(StationSearchActivity.this,StationWifiEditActivity.class);
        startActivity(wifiIntent);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopScanThread();
    }

    private void initBluetooth(){
        /*  Get a   Bluetooth   Adapter Object  */
        BluetoothManager manager = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = manager.getAdapter();
        if (null == bluetoothAdapter) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.bluetooth_error));
        } else {
            toApi21();
            scanLeDevice();
        }
    }

    /**
     *  API < 21
     */
    private BluetoothAdapter.LeScanCallback leScanCallback = new BluetoothAdapter.LeScanCallback() {

        @Override
        public void onLeScan(final BluetoothDevice device, int rssi, final byte[] scanRecord) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    stationDevice = device;
                    station.setBdid(stationDevice.getAddress());
//                    station = StationUtil.parserFirmInfo(station, scanRecord);
                    setBtnStates(true);
                    stopScanThread();
                }
            });
        }
    };


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == OPEN_BLUETOOTH_REQUEST) {
            if (resultCode == RESULT_OK) {
                scanLeDevice();
            } else if (resultCode == RESULT_CANCELED) {
                //Bluetooth not enabled.
                finish();
                return;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void scanLeDevice() {
        setBtnStates(false);
        if (!bluetoothAdapter.isEnabled()){
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, OPEN_BLUETOOTH_REQUEST);
        } else {
            scanThread = new Thread(){
                @Override
                public void run() {
                    //todo change the code

                    // mod by wangcy for bug on 2016-2-9 start

                    if  (Build.VERSION.SDK_INT  <   21)
                    {
                        UUID[] serviceUuids = new UUID[1];
                        serviceUuids[0] = Constants.STATION_IOT_SERVICE;
                        bluetoothAdapter.startLeScan(serviceUuids,leScanCallback);
                    }
                    else
                    {
                        if(mScanCallback!=null){
                            mLEScanner.startScan(filters, settings, mScanCallback);
                        }

                    }

                    // mod by wangcy for bug on 2016-2-9 end

//                    bluetoothAdapter.startLeScan(leScanCallback);
//                    try{
//                        Thread.sleep(SCAN_PERIOD);
//                        stopScanThread();
//                    } catch (InterruptedException e){
//                        e.printStackTrace();
//                    }
                }
            };
            scanThread.start();
        }
    }

    /**
     *
     */
    private void toApi21() {
        if  (Build.VERSION.SDK_INT  >=  21)
        {
            mScanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
            /*  Connect to  device  found   */
                   // Log.i("callbackType", String.valueOf(callbackType));

                    BluetoothDevice device = result.getDevice();

                    stationDevice = device;
                    station.setBdid(stationDevice.getAddress());
                    setBtnStates(true);
                    stopScanThread();
                }

                @Override
                public void onBatchScanResults(List<ScanResult> results) {
            /*  Process a   batch   scan    results */
                    for (ScanResult sr : results) {
                     //   Log.i("Scan Item:   ", sr.toString());
                    }
                }
            };

            mLEScanner = bluetoothAdapter.getBluetoothLeScanner();
            ScanFilter deviceFilter = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(Constants.STATION_IOT_SERVICE)).build();
           // settings = new ScanSettings.Builder().setScanMode(ScanSettings.CALLBACK_TYPE_ALL_MATCHES).build();
            settings = new ScanSettings.Builder().build();
            filters = new ArrayList<ScanFilter>();
            filters.add(deviceFilter);
        }
    }

    /**
     * 停止扫描
     */
    private void stopScanThread() {
        if(scanThread != null) {
            scanThread.interrupt();

           // mod by wangcy for bug on 2016-2-9 start
           // bluetoothAdapter.stopLeScan(leScanCallback);
            if  (Build.VERSION.SDK_INT  <   21)
            {
                if (bluetoothAdapter != null && leScanCallback != null) {
                    bluetoothAdapter.stopLeScan(leScanCallback);
                }

            } else
            {
                if (mLEScanner != null && mScanCallback != null) {
                    mLEScanner.stopScan(mScanCallback);
                }

            }
            // mod by wangcy for bug on 2016-2-9 end
            scanThread = null;
        }
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_sure_btn:
                goToNextActivity();
                break;
            default:
                break;
        }
    }



}
