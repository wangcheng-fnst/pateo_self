//******************************************************************
//* わんダント2システム
//******************************************************************
/*
 *	わんダント2Android
 *	UserAddressEditActivity.java
 *
 *	変更日			変更者				障害No／仕様変更No
 *	2015/11/04 		FNST)Chenjie  	新規作成
 *
 */
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************

package com.fujitsu.wandant.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.model.ProvinceModel;
import com.fujitsu.wandant.net.AccountService;
import com.fujitsu.wandant.net.NetCallback;
import com.fujitsu.wandant.net.model.UserFromNet;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ToastManager;
import com.fujitsu.wandant.view.datepicker.DatePickView;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * UserAddressEditActivity
 */
public class UserAddressEditActivity extends BaseActivity {

    /** log tag */
    private static final String LOG_TAG = UserAddressEditActivity.class.getName();

    /** user info */
    private UserFromNet user = null;

    /** pick view for province */
    private DatePickView provincePickView = null;

    /** province info */
    private ProvinceModel province = null;

    /** spit string */
    private String spit = null;

    /** edittext to input post code */
    @Bind(R.id.id_post_code_et)
    EditText postCodeEt;

    /** textview for showing province */
    @Bind(R.id.id_province_tv)
    TextView provinceTv;

    /** edittext to input address 1 */
    @Bind(R.id.id_address1_et)
    EditText address1Et;

    /** edittext to input address 2 */
    @Bind(R.id.id_address2_et)
    EditText address2Et;

    /** textwatch for listening postcode input */
    private TextWatcher textWatcher;

    /** textwatch for address input */
    private TextWatcher addressTextWatcher;

    /**
     * title
     * @return
     */
    @Override
    public String getTitleName() {
        return getResources().getString(R.string.user_address);
    }

    /**
     * head url
     * @return
     */
    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    /**
     * return layout id of activity
     * @return
     */
    @Override
    public int getLayout() {
        return R.layout.activity_user_address_edit;
    }

    /**
     * onCreateView
     * @param savedInstanceState
     */
    @Override
    public void onCreateView(Bundle savedInstanceState) {
        isShowRight = true;
        user        = UserUtils.getInstance().loadUser();
        this.spit   = getResources().getString(R.string.spit);
        showAddress();
        bindViews();
    }

    /**
     * bindViews
     *
     */
    private void bindViews() {
        textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                String postCode = s.toString();

                if (postCode.length() == 3) {
                    province = null;
                    province = ApplicationUtils.getProvinceById(postCode);
                    postCodeEt.setText(postCode + spit);
                    showProvince(postCode.replaceAll(spit, ""));
                } else if (postCode.length() == 4) {
                    postCodeEt.removeTextChangedListener(textWatcher);

                    if (postCode.endsWith(spit)) {
                        postCodeEt.setText(postCode.replaceAll(spit, ""));
                    } else {
                        String finalCode = postCode.substring(0, 3);

                        finalCode += spit;
                        finalCode += postCode.substring(3, 4);
                        postCodeEt.setText(finalCode);
                    }

                    postCodeEt.setSelection(postCodeEt.getText().toString().length());
                    postCodeEt.addTextChangedListener(textWatcher);
                } else if (postCode.length() == 8){
                    showProvince(postCode.replaceAll(spit, ""));
                } else if (postCode.length() < 3) {
                    province = null;
                }

//                showProvince(postCode.replaceAll(spit, ""));
            }
        };
        provinceTv.setOnClickListener(this);
        postCodeEt.addTextChangedListener(textWatcher);
        addressTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                setRightButtonStatus();
            }
        };
        postCodeEt.addTextChangedListener(addressTextWatcher);
        provinceTv.addTextChangedListener(addressTextWatcher);
        address1Et.addTextChangedListener(addressTextWatcher);
        address2Et.addTextChangedListener(addressTextWatcher);

        InputFilter[] filter1 = new InputFilter[] {
                new InputFilter.LengthFilter(Constants.USER_ADDRESS1_MAX)
        };
        address1Et.setFilters(filter1);
        InputFilter[] filter2 = new InputFilter[] {
                new InputFilter.LengthFilter(Constants.USER_ADDRESS2_MAX)
        };
        address2Et.setFilters(filter2);
    }

    private void setRightButtonStatus() {
        if (StringUtils.isBlank(postCodeEt.getText().toString())
                || StringUtils.isBlank(provinceTv.getText().toString())
                || StringUtils.isBlank(address1Et.getText().toString())
                || StringUtils.isBlank(address2Et.getText().toString())){
            rightTxt.setEnabled(false);
        } else {
            rightTxt.setEnabled(true);
        }
    }

    /**
     * show address
     *
     */
    private void showAddress() {
        if (null == user) {
            return;
        }

        postCodeEt.setSelection(postCodeEt.length());
        postCodeEt.setText(user.getPostcode());
        provinceTv.setText(user.getAddress0());
        address1Et.setText(user.getAddress1());
        address2Et.setText(user.getAddress2());
        setRightButtonStatus();
    }

    /**
     * show province
     *
     * @param postCode
     */
    private void showProvince(String postCode) {
        if (null == province) {
//            provinceTv.setText("");
//            address1Et.setText("");

            return;
        }

        provinceTv.setText(province.getProvince());

        Map<String, String> map = province.getMap();

        if ((null != map) && map.containsKey(postCode)) {
            address1Et.setText(map.get(postCode));
        } else {
            address1Et.setText("");
        }
    }

    /**
     * get dialog to edit province
     *
     * @return
     */
    private Dialog getProvinceDialog() {
        if (null != provincePickView) {
            return provincePickView;
        }

        Map<Integer, String> provinceMap = new LinkedHashMap<>();
        Integer[]            array       = Constants.PROVINCE_ARRAY;

        for (int index = 0; index < array.length; index++) {
            provinceMap.put(index, getResources().getString(array[index]));
        }

        provincePickView = new DatePickView(this, DatePickView.DIALOG_THEME_ARRAY, provinceMap);
        provincePickView.setTargetView(provinceTv);

        Window window = provincePickView.getWindow();

        window.setGravity(Gravity.BOTTOM);

        return provincePickView;
    }

    /**
     * on click event
     * @param v
     */
    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()) {
        case R.id.id_province_tv :
            getProvinceDialog().show();

            break;

        case R.id.id_right_tv :
            updateAddressInfo();
        default :
            break;
        }
    }

    /**
     * update address info
     */
    private void updateAddressInfo() {
        boolean isLegal = false;
        String postCode = postCodeEt.getText().toString().trim();
        String province = provinceTv.getText().toString().trim();
        String address1 = address1Et.getText().toString().trim();
        String address2 = address2Et.getText().toString().trim();

        if (StringUtils.isBlank(postCode) || postCode.length() != Constants.USER_POSTCODE ||
                !StringUtils.isPostCode(postCode)){
            ToastManager.getInstance().showFail(getResources().getString(R.string.error_wrong_user_postcode));
        } else if (StringUtils.isBlank(address1) || address1.length() > Constants.USER_ADDRESS1_MAX || !StringUtils
                .isAddress1(address1)) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.error_wrong_user_address1));
        } else if (StringUtils.isBlank(address2) || address2.length() > Constants.USER_ADDRESS2_MAX || !StringUtils
                .isAddress2(address2)){
            ToastManager.getInstance().showFail(getResources().getString(R.string.error_wrong_user_address2));
        } else {
            isLegal = true;
            user.setPostcode(postCode);
            user.setAddress0(province);
            user.setAddress1(address1);
            user.setAddress2(address2);
        }
        if (!isLegal){
            return;
        }
        showWaitingDialog();
        AccountService.getInstance().modifyUser(user, new NetCallback<UserFromNet>() {
            @Override
            public void success(UserFromNet responseData) {
                hideWaitingDialog();
                if (null == responseData) {
                    return;
                }

                Logger.i(LOG_TAG, "save token = " + token);
                user.setToken(token);
                user.setPostcode(responseData.getPostcode());
                user.setAddress0(responseData.getAddress0());
                user.setAddress1(responseData.getAddress1());
                user.setAddress2(responseData.getAddress2());
                UserUtils.getInstance().saveUser(user);
                setResult(RESULT_OK);
                finish();
            }

            @Override
            public void failure(String errorCode, String errorMsg) {
                showErrorMessage(errorCode);
                hideWaitingDialog();
            }

            @Override
            public void internalFailure(String errorMsg) {
                hideWaitingDialog();
                ToastManager.getInstance().showFail(errorMsg);
//                Toast.makeText(WandantApplication.getInstance().getApplicationContext(), errorMsg,
//                        Toast.LENGTH_SHORT).show();
            }
        });
    }

}
