package com.fujitsu.wandant.ble;

import android.bluetooth.*;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.utils.Constants;
import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.functions.Func1;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class BleDeviceAndroid extends BleDevice {

	private static final long TIME_OUT = 15;
	private static final String LOG_TAG = BleDeviceAndroid.class.getName();
	private BluetoothGatt mGatt;
	private Context mContext;
	
//	private final static int BLE_ERR = 133;
	
	private boolean needAutoConnect = true;
	
	private final static int MSG_AUTO_CONNECT_DELAYED = 1;
	private final static int MSG_AUTO_CMD_EXECUTE = 2;
	
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MSG_AUTO_CONNECT_DELAYED:
				if(null != mGatt && null != mDevice){
                    mGatt.disconnect();
                    mGatt.close();
					mGatt = null;
                    if(mGattCallback!=null){
                          mGatt = mDevice.connectGatt(mContext, false, mGattCallback);
                       // connectToGatt(mDevice,mContext,false,mGattCallback);
                    }

				}
				break;
			case MSG_AUTO_CMD_EXECUTE:
				if(null!=mDevice){
					processNextRequest();
				}
				break;
			default:
				break;
			}
		}
	};

	public static final int CONNECT_CHANGED = 1;
	public static final int WRITE_COMPLETE = 2;
	public static final int READ_COMPLETE = 3;
	public static final int CHARACTERISTIC_CHANGED = 4;
	public static final int NOTIFICATION_REGISTERED = 5;
	public static final int READ_RSSI = 6;

//	private BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
//	private BluetoothGattCallback mGattCallback = null;

	private ConnectionChangedCallBack connectChangedCallBack = null;
	private OnSubscribe connectChangedObservable = new OnSubscribe<ResponseData>() {
		@Override
		public void call(final Subscriber<? super ResponseData> subscriber) {
			connectChangedCallBack = new ConnectionChangedCallBack(){
				@Override
				public void onConnectionChanged(boolean is_connected) {
					ResponseData data = new ResponseData(CONNECT_CHANGED,true,
							null, null, null, Constants.NUMBER_INVALID);
					subscriber.onNext(data);
				}
			};
		}
	};


	private WriteCompleteCallBack writeCompleteCallBack = null;
	private OnSubscribe writeCompleteObservable = new OnSubscribe<ResponseData>() {
		@Override
		public void call(final Subscriber<? super ResponseData> subscriber) {
			writeCompleteCallBack = new WriteCompleteCallBack() {
				@Override
				public void onWriteComplete(UUID srv_uuid, UUID ch_uuid, boolean is_ok) {
//					if (is_ok){
						ResponseData data = new ResponseData(WRITE_COMPLETE,is_ok,
								srv_uuid, ch_uuid, null, Constants.NUMBER_INVALID);
						subscriber.onNext(data);
//					}
				}
			};
		}
	};

	private ReadCompleteCallBack readCompleteCallBack = null;
	private OnSubscribe readCompleteObservable = new OnSubscribe<ResponseData>() {
		@Override
		public void call(final Subscriber<? super ResponseData> subscriber) {
			readCompleteCallBack = new ReadCompleteCallBack() {
				@Override
				public void onReadComplete(UUID srv_uuid, UUID ch_uuid, byte[] val, boolean is_ok) {
//					if (is_ok){
						ResponseData data = new ResponseData(READ_COMPLETE,is_ok,
								srv_uuid, ch_uuid, val, Constants.NUMBER_INVALID);
						subscriber.onNext(data);
//					}

				}
			};
		}

	};

	private NotificationRegisteredCallBack notifyRegisteredCallBack = null;
	private OnSubscribe notifyRegisteredObservable = new OnSubscribe<ResponseData>() {
		@Override
		public void call(final Subscriber<? super ResponseData> subscriber) {
			notifyRegisteredCallBack = new NotificationRegisteredCallBack() {
				@Override
				public void onNotificationRegistered(UUID srv_uuid, UUID ch_uuid, boolean is_ok) {
					ResponseData data = new ResponseData(NOTIFICATION_REGISTERED,true,
							srv_uuid, ch_uuid, null, Constants.NUMBER_INVALID);
					subscriber.onNext(data);
				}
			};
		}

	};


	private CharacteristicChangeCallBack chChangedcallBack = null;
	private OnSubscribe chChangedObservable = new OnSubscribe<ResponseData>() {
		@Override
		public void call(final Subscriber<? super ResponseData> subscriber) {
			chChangedcallBack = new CharacteristicChangeCallBack() {
				@Override
				public void onCharacteristicChange(UUID srv_uuid, UUID ch_uuid, byte[] val) {
					ResponseData data = new ResponseData(CHARACTERISTIC_CHANGED, true,
							srv_uuid,ch_uuid,val, Constants.NUMBER_INVALID);
					subscriber.onNext(data);
				}
			};
		}
	};

	private ReadRssiCallBack readRssiCallBack = null;
	private OnSubscribe readRemoteRssiObservable = new OnSubscribe<ResponseData>() {
		@Override
		public void call(final Subscriber<? super ResponseData> subscriber) {
			readRssiCallBack = new ReadRssiCallBack() {
				@Override
				public void onReadRssi(int rssi, boolean is_ok) {
					ResponseData data = new ResponseData(READ_RSSI, is_ok,
							null,null,null, rssi);
					subscriber.onNext(data);
				}
			};
		}
	};

	private BluetoothGattCallback mGattCallback  = new BluetoothGattCallback() {
			@Override
			public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic ch) {
               // Log.e("onCharacteristicChanged",ch.getValue().length+"");
                mDevCallback.onCharacteristicChange(ch.getService().getUuid(), ch.getUuid(), ch.getValue());
				if (null != chChangedcallBack) {
					chChangedcallBack.onCharacteristicChange(ch.getService().getUuid(), ch.getUuid(), ch.getValue());
				}
				if (null != ch.getValue()){
					Logger.d(LOG_TAG, "serveruuid " + ch.getService().getUuid().toString() + " childuuid " + ch.getUuid().toString() + " read data " + Arrays.toString(ch.getValue()));
				}
			}

			@Override
			public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic ch, int status) {
				mDevCallback.onReadComplete(ch.getService().getUuid(), ch.getUuid(), ch.getValue(), status == BluetoothGatt.GATT_SUCCESS);
				if (null != readCompleteCallBack){
					readCompleteCallBack.onReadComplete(ch.getService().getUuid(), ch.getUuid(), ch.getValue(), status == BluetoothGatt.GATT_SUCCESS);

				}
				mHandler.sendEmptyMessage(MSG_AUTO_CMD_EXECUTE);
			}

			@Override
			public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic ch, int status) {
				mDevCallback.onWriteComplete(ch.getService().getUuid(), ch.getUuid(), status == BluetoothGatt.GATT_SUCCESS);
				if (null != writeCompleteCallBack){
					writeCompleteCallBack.onWriteComplete(ch.getService().getUuid(), ch.getUuid(), status == BluetoothGatt.GATT_SUCCESS);

				}
				mHandler.sendEmptyMessage(MSG_AUTO_CMD_EXECUTE);
			}

			@Override
			public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {

//                if(status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
//                    mGatt = gatt;
//                    //FPT edit MTU size
//                    if (Build.VERSION.SDK_INT >= 21) {
//                        Method m;
//                        try {
//                            m = mGatt.getClass().getDeclaredMethod("requestMtu", int.class);
//                            boolean requestMTU = (boolean) m.invoke(mGatt, 512);
//                            Log.e("BluetoothGattCallback-onConnectionStateChange","requestMtu"+requestMTU);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }

                boolean connected = (newState == BluetoothProfile.STATE_CONNECTED) && (status == BluetoothGatt.GATT_SUCCESS);
				modifyConnectionState(connected);
				if (!connected) {
					clearRequest();
					if (!needAutoConnect) {
						mDevice = null;
					} else {
						mDeviceState = DISCONNECTED;
						mHandler.sendEmptyMessageDelayed(MSG_AUTO_CONNECT_DELAYED, 4000);
					}
				}
			}


			@Override
			public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor desc, int status) {
				BluetoothGattCharacteristic ch = desc.getCharacteristic();
				mGatt.setCharacteristicNotification(ch, true);
				mDevCallback.onNotificationRegistered(ch.getService().getUuid(), ch.getUuid(), status == BluetoothGatt.GATT_SUCCESS);
				if (null != notifyRegisteredCallBack){
					notifyRegisteredCallBack.onNotificationRegistered(ch.getService().getUuid(), ch.getUuid(), status == BluetoothGatt.GATT_SUCCESS);
				}
			}

			@Override
			public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
				mDevCallback.onReadRssi(rssi, status == BluetoothGatt.GATT_SUCCESS);
				if (null != readRssiCallBack){
					readRssiCallBack.onReadRssi(rssi, status == BluetoothGatt.GATT_SUCCESS);
				}
			}

			@Override
			public void onServicesDiscovered(BluetoothGatt gatt, int status) {
				if (status == BluetoothGatt.GATT_SUCCESS) {
					mDeviceState = SERVICE_DISCOVERED;
					mDevCallback.onConnectionChanged(true);
					if (null != connectChangedCallBack){
						connectChangedCallBack.onConnectionChanged(true);
					}

				}
			}

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            /* compiled code */
            if (status == BluetoothGatt.GATT_SUCCESS) {

            }

        }


		};



	@Override
	public Observable<ResponseData> getNotification(final UUID serverUuid, final UUID childUUid){
		return Observable.create(chChangedObservable).timeout(TIME_OUT, TimeUnit.SECONDS)
				.filter(new Func1<ResponseData, Boolean>() {
					@Override
					public Boolean call(ResponseData responseData) {
						return (responseData.getType() == CHARACTERISTIC_CHANGED
								&& responseData.getSrvUuid().toString().equals(serverUuid.toString())
								&& responseData.getChUuid().toString().equals(childUUid.toString()));
					}
				});
	}

    public void reConnect() {
        if (null != mGatt) {
            mGatt.disconnect();
            mGatt.close();
            mGatt = null;
        }
        if (null != mDevice && null != mGattCallback) {
             mGatt = mDevice.connectGatt(mContext, false, mGattCallback);
            //connectToGatt(mDevice,mContext,false,mGattCallback);
        }
    }

    private BleDeviceAndroid(Context cntx, BluetoothDevice device, BleDeviceCallback cb, boolean needConnect) {
		needAutoConnect = true;
		mContext = cntx;
		mDevice = device;
		mDevCallback = cb;
		if(needAutoConnect){
		   mGatt = device.connectGatt(cntx, false, mGattCallback);
          // connectToGatt(device,cntx,false,mGattCallback);
		}
	}


    public void connectToGatt(BluetoothDevice device, Context context, boolean auto, BluetoothGattCallback gattCallback) {
        if(Build.VERSION.SDK_INT > 19){
            Method m;
            try {
                m = device.getClass().getDeclaredMethod("connectGatt", Context.class, boolean.class, BluetoothGattCallback.class, int.class);
                int transport = device.getClass().getDeclaredField("TRANSPORT_LE").getInt(null);    // LE = 2, BREDR = 1, AUTO = 0
                mGatt = (BluetoothGatt) m.invoke(device, context, auto, gattCallback, transport);
            } catch (Exception e) {
                mGatt =device.connectGatt(context, auto, gattCallback);
                e.printStackTrace();
            }
        }else{
                mGatt =device.connectGatt(context, auto, gattCallback);
        }
    }
	
	public static BleDeviceAndroid connectBleDevice(Context cntx, BluetoothDevice device, BleDeviceCallback cb) {
		return new BleDeviceAndroid(cntx, device, cb, true);
	}
	
	public static BleDeviceAndroid createBleDevice(Context cntx, BluetoothDevice device, BleDeviceCallback cb) {
		return new BleDeviceAndroid(cntx, device, cb, false);
	}

	@Override
	protected boolean discoverServices() {
		return mGatt.discoverServices();
	}

	@Override
	public void disconnect() {
		mHandler.removeMessages(MSG_AUTO_CONNECT_DELAYED);	
		needAutoConnect = false;
		Logger.d(LOG_TAG, "manager disconnect " + mGatt);
		if(null != mGatt){
			mGatt.disconnect();
			mGatt.close();
		}
//		mDevice = null;
		mGatt = null;
	}

	@Override
	public boolean readRssi() {
		if(null == mGatt){
			return false;
		}
		return mGatt.readRemoteRssi();
	}

	@Override
	public boolean registerNotification(UUID srv_uuid, UUID ch_uuid) {
		Logger.d(LOG_TAG, "registerNotification serveruuid " + srv_uuid.toString() + "childuuid " + ch_uuid.toString());
		BluetoothGattService service = mGatt.getService(srv_uuid);
		if (null == service){
			Logger.e(LOG_TAG, "no serviceuuid " + srv_uuid.toString());
			return false;
		}
		BluetoothGattCharacteristic ch = service.getCharacteristic(ch_uuid);
		if (null == ch){
			Logger.e(LOG_TAG, "no childuuid " + ch_uuid.toString());
			return false;
		}
        mGatt.setCharacteristicNotification(ch,true);

		BluetoothGattDescriptor desc = ch.getDescriptor(CLIENT_CHAR_CONFIG_UUID);
		if (null == desc){
			return false;
		}
		desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        return mGatt.writeDescriptor(desc);
//        try {
//            for (BluetoothGattDescriptor descriptor : ch.getDescriptors()) {
//                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
//                mGatt.writeDescriptor(descriptor);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return false;
//        }
  //      return true;
	}

	@Override
	public boolean read(UUID srv_uuid, UUID ch_uuid) {
		Logger.d(LOG_TAG, "read serveruuid " + srv_uuid.toString() + "childuuid " + ch_uuid.toString());
		BluetoothGattService service = mGatt.getService(srv_uuid);
		if (null == service){
			Logger.e(LOG_TAG, "no serviceuuid " + srv_uuid.toString());
			return false;
		}
		BluetoothGattCharacteristic ch = service.getCharacteristic(ch_uuid);
		if (null == ch){
			Logger.e(LOG_TAG, "no childuuid " + ch_uuid.toString());
			return false;
		}
		return mGatt.readCharacteristic(ch);
	}

	@Override
	public boolean write(UUID srv_uuid, UUID ch_uuid, byte[] data) {
		if (null != data){
			Logger.d(LOG_TAG, "write data " + Arrays.toString(data) + " serveruuid " + srv_uuid.toString() + " childuuid " + ch_uuid.toString());
		}
		BluetoothGattService service = mGatt.getService(srv_uuid);
		if (null == service){
			Logger.e(LOG_TAG, "no serviceuuid " + srv_uuid.toString());
			return false;
		}
		BluetoothGattCharacteristic ch = service.getCharacteristic(ch_uuid);
		if (null == ch){
			Logger.e(LOG_TAG, "no childuuid " + ch_uuid.toString());
			return false;
		}


		ch.setValue(data);
		return mGatt.writeCharacteristic(ch);
	}

	@Override
	public Observable<ResponseData> checkConnected() {
		if (mDeviceState == SERVICE_DISCOVERED){
			ResponseData data = new ResponseData(CONNECT_CHANGED,true,
					null, null, null, Constants.NUMBER_INVALID);
			return Observable.just(data);
		} else {
			return Observable.create(connectChangedObservable)
					.timeout(TIME_OUT, TimeUnit.SECONDS).filter(new Func1<ResponseData, Boolean>() {
						@Override
						public Boolean call(ResponseData responseData) {
							return (responseData.getType() == CONNECT_CHANGED);
						}
					});
		}
	}

	@Override
	public void disableBT() {
		if(null!=mGatt){
			Logger.i(LOG_TAG, "disableBT-----");
			modifyConnectionState(false);
			clearRequest();
            mGatt.disconnect();
            mGatt.close();
			mGatt = null;
		}
	}

	@Override
	public boolean isServiceDiscoveryed(UUID srv_uuid, UUID ch_uuid) {
		try{
			BluetoothGattCharacteristic ch = mGatt.getService(srv_uuid).getCharacteristic(ch_uuid);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public Observable<ResponseData> registerNotificationObs(final UUID srv_uuid, final UUID ch_uuid) {
		registerNotification(srv_uuid, ch_uuid);
		return Observable.create(notifyRegisteredObservable).timeout(TIME_OUT, TimeUnit.SECONDS).filter(new Func1<BleDevice.ResponseData, Boolean>() {
			@Override
			public Boolean call(BleDevice.ResponseData responseData) {
				return responseData.getType() == BleDeviceAndroid.NOTIFICATION_REGISTERED
						&& responseData.getSrvUuid().equals(srv_uuid)
						&& responseData.getChUuid().equals(ch_uuid);
			}
		});
//		return notifyRegisteredObservable;
	}

	@Override
	public Observable<ResponseData> readObs(final UUID srv_uuid, final UUID ch_uuid) {
		read(srv_uuid, ch_uuid);
		return Observable.create(readCompleteObservable).timeout(TIME_OUT, TimeUnit.SECONDS).filter(new Func1<BleDevice.ResponseData, Boolean>() {
			@Override
			public Boolean call(BleDevice.ResponseData responseData) {
				return responseData.getType() == BleDeviceAndroid.READ_COMPLETE
						&& responseData.getSrvUuid().equals(srv_uuid)
						&& responseData.getChUuid().equals(ch_uuid);
			}
		});
	}

	@Override
	public Observable<ResponseData> writeObs(final UUID srv_uuid, final UUID ch_uuid, byte[] data) {
		write(srv_uuid, ch_uuid, data);
		return Observable.create(writeCompleteObservable).timeout(TIME_OUT, TimeUnit.SECONDS).filter(new Func1<BleDevice.ResponseData, Boolean>() {
			@Override
			public Boolean call(BleDevice.ResponseData responseData) {
				return responseData.getType() == BleDeviceAndroid.WRITE_COMPLETE
						&& responseData.getSrvUuid().equals(srv_uuid)
						&& responseData.getChUuid().equals(ch_uuid);
			}
		});
	}

	@Override
	public Observable<ResponseData> readRssiObs() {
		readRssi();
		return Observable.create(readRemoteRssiObservable).timeout(TIME_OUT, TimeUnit.SECONDS).filter(new Func1<BleDevice.ResponseData, Boolean>() {
			@Override
			public Boolean call(BleDevice.ResponseData responseData) {
				return responseData.getType() == BleDeviceAndroid.READ_RSSI;
			}
		});
	}


}
