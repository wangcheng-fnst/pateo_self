//******************************************************************
//* わんダント2システム
//******************************************************************
/*
 *	わんダント2Android
 *	UserInfoActivity.java
 *
 *	変更日			変更者				障害No／仕様変更No
 *	2015/10/16 		FNST)wangc.fnst 	新規作成
 *
 */
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************

package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.model.ValueEditModel;
import com.fujitsu.wandant.net.model.UserFromNet;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.TimeUtils;
import com.fujitsu.wandant.utils.UserUtils;

import java.util.Date;
import java.util.Map;

/**
 * UserInfoActivity
 */
public class UserInfoActivity extends BaseActivity {

    /** email request flag */
    private static final int EMAIL_REQUEST = 0;

    /** name request flag */
    private static final int NAME_REQUEST = 1;

    /** phonetic request flag */
    private static final int PHONETIC_REQUEST = 2;

    /** phone request flag */
    private static final int PHONE_REQUEST = 3;

    /** twitter request flag */
    private static final int TWITTER_REQUEST = 4;

    /** birthday request flag */
    private static final int BIRTHDAY_REQUEST = 5;

    /** sex request flag */
    private static final int SEX_REQUEST = 6;

    /** family request flag */
    private static final int FAMILY_REQUEST = 7;

    /** job request flag */
    private static final int JOB_REQUEST = 8;

    /** address request flag */
    private static final int ADDRESS_REQUEST = 9;

    /** withdrawal button */
    @Bind(R.id.id_withdrawal_btn)
    Button withDrawalBtn;

    /** textview for email */
    @Bind(R.id.id_email_txt)
    TextView emailTv;

    /** textview for name*/
    @Bind(R.id.id_full_name_txt)
    TextView nameTv;

    /** textview for phonetic */
    @Bind(R.id.id_phonetic_txt)
    TextView phoneticTv;

    /** textview for sex */
    @Bind(R.id.id_sex_txt)
    TextView sexTv;

    /** textview for phone */
    @Bind(R.id.id_phone_txt)
    TextView phoneTv;

    /** textview for twitter */
    @Bind(R.id.id_twitter_txt)
    TextView twitterTv;

    /** textview for family */
    @Bind(R.id.id_family_txt)
    TextView familyTv;

    /** textview for address number */
    @Bind(R.id.id_address_num_txt)
    TextView addressNumTv;

    /** textview for address area */
    @Bind(R.id.id_address_area_txt)
    TextView addressAreaTv;

    /** textview for address 1 */
    @Bind(R.id.id_address1_txt)
    TextView address1Tv;

    /** textview for address 2 */
    @Bind(R.id.id_address2_txt)
    TextView address2Tv;

    /** textview for birthday */
    @Bind(R.id.id_birthday_txt)
    TextView birthdayTv;

    /** textview for job */
    @Bind(R.id.id_job_txt)
    TextView jobTv;

    /** user information */
    private UserFromNet userInfo;

    /**
     * title
     *
     * @return
     */
    @Override
    public String getTitleName() {
        return getString(R.string.account_detail);
    }

    /**
     * head
     * @return
     */
    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    /**
     * onCreateView
     * @param savedInstanceState
     */
    @Override
    public void onCreateView(Bundle savedInstanceState) {
        initView();
        getUserInfo();
    }

    /**
     * init views of activity
     *
     */
    private void initView() {
        withDrawalBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_white_sure_pressed,
                R.drawable.btn_white_sure));
        withDrawalBtn.setOnClickListener(this);

//      findViewById(R.id.id_user_email_layout).setOnClickListener(this);
        findViewById(R.id.id_full_name_layout).setOnClickListener(this);
        findViewById(R.id.id_phonetic_layout).setOnClickListener(this);
        findViewById(R.id.id_sex_layout).setOnClickListener(this);
        findViewById(R.id.id_phone_layout).setOnClickListener(this);
        findViewById(R.id.id_twitter_layout).setOnClickListener(this);
        findViewById(R.id.id_family_layout).setOnClickListener(this);
        findViewById(R.id.id_birthday_layout).setOnClickListener(this);
        findViewById(R.id.id_job_layout).setOnClickListener(this);
        findViewById(R.id.id_address_layout).setOnClickListener(this);
    }

    /**
     * get user information
     */
    public void getUserInfo() {
        userInfo = UserUtils.getInstance().loadUser();
        showUser();
    }

    /**
     * show user information
     *
     */
    private void showUser() {
        if (null == userInfo) {
            return;
        }

        emailTv.setText(userInfo.getEmail());

        String name = "";

        if (!StringUtils.isBlank(userInfo.getFamilyname())) {
            name += userInfo.getFamilyname();
        }

        if (!StringUtils.isBlank(userInfo.getFirstname())) {
            name += " " + userInfo.getFirstname();
        }

        nameTv.setText(name);

        String namek = "";

        if (!StringUtils.isBlank(userInfo.getFamilynamek())) {
            namek += userInfo.getFamilynamek();
        }

        if (!StringUtils.isBlank(userInfo.getFirstnamek())) {
            namek += " " + userInfo.getFirstnamek();
        }

        phoneticTv.setText(namek);

        Integer sex = userInfo.getSex();

        if ((null != sex) && Constants.USER_GENDER_MAP.containsKey(sex)) {
            sexTv.setText(Constants.USER_GENDER_MAP.get(sex));
        }

        phoneTv.setText(userInfo.getTelephonenumber());
        twitterTv.setText(userInfo.getTwitter_account());

        String familyStr = getFamilyStr();

        familyTv.setText(familyStr);
        addressNumTv.setText(userInfo.getPostcode());
        addressAreaTv.setText(userInfo.getAddress0());
        address1Tv.setText(userInfo.getAddress1());
        address2Tv.setText(userInfo.getAddress2());

        String birth = userInfo.getBirthday();

        if (null != birth) {
            Date date = TimeUtils.parseYYYYMMDDDate(birth);
            if (null != date) {
                String dateStr = TimeUtils.formatWithYearMonthDay(date);
                birthdayTv.setText(dateStr);
            }
        }

        if (!StringUtils.isBlank(userInfo.getJob())) {
            Integer key   = Integer.parseInt(userInfo.getJob());
            Integer value = Constants.USER_JOB_MAP.get(key);

            if (null != value) {
                jobTv.setText(getResources().getString(value));
            } else {
                jobTv.setText("");
            }
        } else {
            jobTv.setText("");
        }
    }

    /**
     * get family string
     * @return
     */
    private String getFamilyStr() {
        Integer[] family    = userInfo.getFamily();
        String    familyStr = "";

        if ((null == family) || (0 == family.length)) {
            return familyStr;
        }

        for (Integer integer : family) {
            if (Constants.USER_FAMILY_MAP.containsKey(integer)) {
                familyStr += getResources().getString(Constants.USER_FAMILY_MAP.get(integer)) + "\n";
            }
        }

        if (familyStr.endsWith("\n")) {
            familyStr = familyStr.substring(0, familyStr.length() - 1);
        }

        return familyStr;
    }

    /**
     * get layout id of activity
     * @return
     */
    @Override
    public int getLayout() {
        return R.layout.user_info;
    }

    /**
     * go to ValueEditActivity to edit value
     *
     * @param title
     * @param showType
     * @param valueType
     * @param requestCode
     */
    private void gotoValueEditActivity(String title, int showType, int valueType, int requestCode) {
        Intent         intent = new Intent();
        ValueEditModel model  = new ValueEditModel();

        model.setTitle(title);
        model.setShowType(showType);
        model.setValueType(valueType);
        model.setUser(userInfo);
        intent.putExtra(Constants.EXTRA_VALUE, model);
        intent.setClass(this, ValueEditActivity.class);
        startActivityForResult(intent, requestCode);
    }

    /**
     * go to ValueEditActivity to select value
     * @param title
     * @param showType
     * @param valueType
     * @param map
     * @param requestCode
     */
    private void gotoValueSelectActivity(String title, int showType, int valueType, Map<Integer, Integer> map,
            int requestCode) {
        Intent         intent = new Intent();
        ValueEditModel model  = new ValueEditModel();

        model.setTitle(title);
        model.setShowType(showType);
        model.setValueType(valueType);
        model.setMap(map);
        model.setUser(userInfo);
        intent.putExtra(Constants.EXTRA_VALUE, model);
        intent.setClass(this, ValueEditActivity.class);
        startActivityForResult(intent, requestCode);
    }

    /**
     * on click event
     * @param v
     */
    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()) {

//      case R.id.id_user_email_layout:
//          gotoValueEditActivity(getResources().getString(R.string.user_email),
//                  ValueEditActivity.SINGLE_TEXT_TYPE, ValueEditActivity.USER_EMAIL, EMAIL_REQUEST);
//          break;
        case R.id.id_full_name_layout :
            gotoValueEditActivity(getResources().getString(R.string.user_full_name), ValueEditActivity.MULTI_TEXT_TYPE,
                                  ValueEditActivity.USER_NAME, NAME_REQUEST);

            break;

        case R.id.id_phonetic_layout :
            gotoValueEditActivity(getResources().getString(R.string.user_phonetic), ValueEditActivity.MULTI_TEXT_TYPE,
                                  ValueEditActivity.USER_PHONETIC, PHONETIC_REQUEST);

            break;

        case R.id.id_sex_layout :
            gotoValueSelectActivity(getResources().getString(R.string.user_sex), ValueEditActivity.SINGLE_SELECT_TYPE,
                                    ValueEditActivity.USER_SEX, Constants.USER_GENDER_MAP, SEX_REQUEST);

            break;

        case R.id.id_phone_layout :
            gotoValueEditActivity(getResources().getString(R.string.user_phone), ValueEditActivity.MULTI_TEXT_TYPE,
                                  ValueEditActivity.USER_PHONE, PHONE_REQUEST);

            break;

        case R.id.id_twitter_layout :
            gotoValueEditActivity(getResources().getString(R.string.user_twitter), ValueEditActivity.SINGLE_TEXT_TYPE,
                                  ValueEditActivity.USER_TWITTER, TWITTER_REQUEST);

            break;

        case R.id.id_family_layout :
            gotoValueSelectActivity(getResources().getString(R.string.user_family),
                                    ValueEditActivity.MULTI_SELECT_TYPE, ValueEditActivity.USER_FAMILY,
                                    Constants.USER_FAMILY_MAP, FAMILY_REQUEST);

            break;

        case R.id.id_birthday_layout :
            gotoValueEditActivity(getResources().getString(R.string.user_birthday), ValueEditActivity.DATE_TYPE,
                                  ValueEditActivity.USER_BIRTHDAY, BIRTHDAY_REQUEST);

            break;

        case R.id.id_job_layout :
            gotoValueSelectActivity(getResources().getString(R.string.user_job), ValueEditActivity.SINGLE_SELECT_TYPE,
                                    ValueEditActivity.USER_JOB, Constants.USER_JOB_MAP, JOB_REQUEST);

            break;

        case R.id.id_withdrawal_btn :
            Intent intent = new Intent();

            intent.setClass(this, UserWithdrawalActivity.class);
            startActivity(intent);

            break;

        case R.id.id_address_layout :
            Intent addressIntent = new Intent();

            addressIntent.setClass(this, UserAddressEditActivity.class);
            startActivityForResult(addressIntent, ADDRESS_REQUEST);
        default :
            break;
        }
    }

    /**
     * onActivityResult
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (RESULT_OK != resultCode) {
            return;
        }

        if (requestCode == ADDRESS_REQUEST) {
            userInfo = UserUtils.getInstance().loadUser();
            addressNumTv.setText(userInfo.getPostcode());
            addressAreaTv.setText(userInfo.getAddress0());
            address1Tv.setText(userInfo.getAddress1());
            address2Tv.setText(userInfo.getAddress2());

            return;
        }

        ValueEditModel model = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);

        if (!model.isConnectNetSuccess()) {
            return;
        }

        UserFromNet user = model.getUser();

        if (null == user) {
            return;
        }
        userInfo = user;
        switch (requestCode) {
        case EMAIL_REQUEST :
            userInfo.setEmail(user.getEmail());
            emailTv.setText(user.getEmail());

            break;

        case NAME_REQUEST :
            userInfo.setFamilyname(user.getFamilyname());
            userInfo.setFirstname(user.getFirstname());
            nameTv.setText(user.getFamilyname() + " " + user.getFirstname());

            break;

        case PHONETIC_REQUEST :
            userInfo.setFamilynamek(user.getFamilynamek());
            userInfo.setFirstnamek(user.getFirstnamek());
            phoneticTv.setText(user.getFamilynamek() + " " + user.getFirstnamek());

            break;

        case PHONE_REQUEST :
            userInfo.setTelephonenumber(user.getTelephonenumber());
            phoneTv.setText(user.getTelephonenumber());

            break;

        case TWITTER_REQUEST :
            userInfo.setTwitter_account(user.getTwitter_account());
            twitterTv.setText(user.getTwitter_account());

            break;

        case BIRTHDAY_REQUEST :
            String birth = user.getBirthday();

            if (null != birth) {
                Date date = TimeUtils.parseYYYYMMDDDate(birth);

                if (null != date) {
                    String dateStr = TimeUtils.formatWithYearMonthDay(date);

                    birthdayTv.setText(dateStr);
                }

//              birthdayTv.setText(TimeUtils.formatWithYearMonthDay(birth));
            }

            break;

        case SEX_REQUEST :
            userInfo.setSex(user.getSex());
            sexTv.setText(Constants.USER_GENDER_MAP.get(user.getSex()));

            break;

        case FAMILY_REQUEST :
            userInfo.setFamily(user.getFamily());

            String familyStr = getFamilyStr();

            familyTv.setText(familyStr);

            break;

        case JOB_REQUEST :
            userInfo.setJob(user.getJob());

            if (!StringUtils.isBlank(user.getJob())) {
                Integer key = Integer.parseInt(user.getJob());

                jobTv.setText(Constants.USER_JOB_MAP.get(key));
            } else {

//              jobTv.setText("");
            }

            break;

        default :
            break;
        }
    }
}

