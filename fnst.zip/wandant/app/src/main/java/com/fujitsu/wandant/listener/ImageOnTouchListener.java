package com.fujitsu.wandant.listener;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by chenjie.fnst on 2015/11/23.
 */
public class ImageOnTouchListener implements View.OnTouchListener {

    private float positionX;
    private float positionY;
    private float CLICK_DISTANCE_MAX = 20f;
    private float PAGE_DISTANCE_MIN = 80f;
    private OnTopTouchListener listener;
    private String LOG_TAG = ImageOnTouchListener.class.getName();
    private boolean isPageConsumed = false;

    public interface OnTopTouchListener{
        void onClicked();
        void onPrevious();
        void onNext();
    }

    public ImageOnTouchListener(OnTopTouchListener listener){
        this.listener = listener;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        float currentX = event.getX();
        float currentY = event.getY();
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                positionX = currentX;
                positionY = currentY;
                isPageConsumed = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (isPageConsumed){
                    return true;
                }
                if (Math.abs(currentX - positionX) < Math.abs(currentY - positionY)
                        || Math.abs(currentX - positionX) < PAGE_DISTANCE_MIN){
                    return true;
                }
                isPageConsumed = true;
                if(currentX - positionX > 0){
                    listener.onPrevious();
                    Log.d(LOG_TAG,"ACTION_MOVE onPrevious");
                } else {
                    listener.onNext();
                    Log.d(LOG_TAG, "ACTION_MOVE onNext");
                }
                break;
            case MotionEvent.ACTION_UP:
                if (Math.abs(currentX - positionX) < CLICK_DISTANCE_MAX
                        && Math.abs(currentY - positionY) < CLICK_DISTANCE_MAX ){
                    listener.onClicked();
                    Log.d(LOG_TAG, "ACTION_UP onClicked");
                } else if (isPageConsumed){
                    return true;
                }
                isPageConsumed = true;
                if (Math.abs(currentX - positionX) >= Math.abs(currentY - positionY)
                        && currentX - positionX > PAGE_DISTANCE_MIN){
                    listener.onPrevious();
                    Log.d(LOG_TAG, "ACTION_UP onPrevious");
                } else if (Math.abs(currentX - positionX) >= Math.abs(currentY - positionY)
                        && positionX - currentX > PAGE_DISTANCE_MIN){
                    listener.onNext();
                    Log.d(LOG_TAG, "ACTION_UP onNext");
                }
                break;
        }
        return true;
    }
}
