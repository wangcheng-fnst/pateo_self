package com.fujitsu.wandant.activity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.ble.BleHandler;
import com.fujitsu.wandant.ble.DeviceHandler;
import com.fujitsu.wandant.db.DataBaseManager;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.model.DeviceModel;
import com.fujitsu.wandant.model.FirmDetailModel;
import com.fujitsu.wandant.model.dao.FirmDetailModelDao;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.StatusRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.*;
import com.fujitsu.wandant.view.PopViewHelper;
import com.fujitsu.wandant.view.ToastManager;
import me.grantland.widget.AutofitTextView;
import rx.Observable;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func1;

import java.io.Serializable;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by wangc.fnst on 2015/10/16.
 */
public class DeviceDetailActivity extends BaseActivity implements OnModelFinishedListener {


    @Bind(R.id.id_name_txt)
    TextView nameTxt;
    @Bind(R.id.id_bdid_txt)
    AutofitTextView bdidTxt;
    @Bind(R.id.id_power_txt)
    TextView powerTxt;
    @Bind(R.id.id_update_flag_iv)
    View updateFlagView;
    @Bind(R.id.id_firm_txt)
    TextView firmTxt;
    @Bind(R.id.id_temp_tv)
    TextView tempTxt;
    @Bind(R.id.id_humi_tv)
    TextView humiTxt;
    @Bind(R.id.id_device_info_layer)
    View layer;
    @Bind(R.id.id_device_remove_btn)
    Button removeBtn;
    private Dog dog;
    private DeviceModel device;
    private DeviceHandler deviceHandler;
    private FirmDetailModelDao firmDao;
    private String hyphen;
    private String percent;
    private FirmDetailModel firmInfo;
    private Subscription subscription = null;
    /** bluetooth adapter */
    private BluetoothAdapter bluetoothAdapter;
    private static final int REQUEST_DEVICE_DETAIL = 1;
    /** request flag to open bluetooth function in the phone */
    private static final int REQUEST_OPEN_BLUETOOTH = 2;
    private static final int REQUEST_DEVICE_SETTING = 3;

    private String str4BDID =null ;

    @Override
    public String getTitleName() {
        return getString(R.string.device_detail);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public int getLayout() {
        return R.layout.device_detail;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_DEVICE_DETAIL, this);
        dog = (Dog) getIntent().getSerializableExtra(Constants.EXTRA_DOG);
        device = (DeviceModel)DogDeviceStationRepository.getInstance().searchDeviceByDogId(dog.getDog_id(), true);
        str4BDID=BDIDUtils.addMark4BDID(device.getBdid());
        deviceHandler = new DeviceHandler();
        firmDao = DataBaseManager.getInstance().getDaoSession().getFirmDetailModelDao();
        hyphen = getResources().getString(R.string.hyphen);
        percent = getResources().getString(R.string.percent_unit);
        initView();
        initBluetooth();
    }

    /**
     * initBluetooth
     *
     */
    private void initBluetooth() {
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);

        bluetoothAdapter = manager.getAdapter();

        if (null == bluetoothAdapter) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.bluetooth_error));
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

                startActivityForResult(intent, REQUEST_OPEN_BLUETOOTH);
            } else {
                getData();
            }
        }
    }

    private void getData() {
        new Handler().postDelayed(new Runnable() {
            public void run() {
                //execute the task
                getDataFromBle();
            }
        }, 1000);
    }

    /**
     * onActivityResult
     *
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_CANCELED){
            return;
        }
        switch (requestCode){
            case REQUEST_OPEN_BLUETOOTH:
                getData();
                break;
            case REQUEST_DEVICE_SETTING:
                refreshDeviceInfo(data);
                break;
            default:
                break;
        }
    }

    private void refreshDeviceInfo(Intent data) {
        Serializable serializable = data.getSerializableExtra(Constants.EXTRA_DEVICE_MODEL);
        if (null != serializable){
            DeviceModel deviceModel = (DeviceModel) serializable;
            device.setTemperature(deviceModel.getTemperature());
            device.setHumidity_down(deviceModel.getHumidity_down());
            tempTxt.setText((device.getTemperature() == null ? hyphen:
                    device.getTemperature())+getResources().getString(R.string.temperature_unit));
            humiTxt.setText((device.getHumidity_down() ==null? hyphen:
                    device.getHumidity_down())+getResources().getString(R.string.percent_unit));
        }
    }

    private void initView() {
        nameTxt.setText(dog.getName());
        removeBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_white_sure_pressed, R.drawable.btn_white_sure));
        removeBtn.setOnClickListener(this);
        if (null != device) {
            bdidTxt.setText(str4BDID);
            tempTxt.setText((device.getTemperature() == null ? hyphen:
                    device.getTemperature())+getResources().getString(R.string.temperature_unit));
            humiTxt.setText((device.getHumidity_down() ==null? hyphen:
                    device.getHumidity_down())+getResources().getString(R.string.percent_unit));
            if (null == device.getBattery()){
                powerTxt.setText(hyphen);
            } else {
                powerTxt.setText(String.valueOf(device.getBattery()) + percent);
            }
            firmInfo = StatusRepository.getInstance().getFirmDbByBdid(device.getBdid());
            if (null != firmInfo && null != firmInfo.getMajor()){
                firmTxt.setText(firmInfo.getMajor());
            } else {
                firmTxt.setText(hyphen);
            }
        }
        findViewById(R.id.id_firm_rl).setOnClickListener(this);
        findViewById(R.id.id_temp_rl).setOnClickListener(this);
        findViewById(R.id.id_humi_rl).setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpdateFlag();
    }

    private void setUpdateFlag(){
        boolean needUpdate = isNeedUpdate();
        if (needUpdate){
            updateFlagView.setVisibility(View.VISIBLE);
            updateFlagView.setOnClickListener(this);
        } else {
            updateFlagView.setVisibility(View.GONE);
            updateFlagView.setOnClickListener(null);
        }
    }

    private boolean isNeedUpdate() {
        boolean needUpdate = false;
        if (null == device || StringUtils.isBlank(device.getBdid())){
            needUpdate = false;
            return needUpdate;
        }
        List list = firmDao.queryBuilder()
                .where(FirmDetailModelDao.Properties.Needupdate.eq(true))
                .where(FirmDetailModelDao.Properties.Bdid.eq(device.getBdid())).list();
        if (null == list || list.isEmpty()){
            needUpdate = false;
        } else {
            needUpdate = true;
        }
        return needUpdate;
    }

    private void getDataFromBle() {
        if (!BluetoothAdapter.checkBluetoothAddress(str4BDID)){
            return;
        }
        subscription = deviceHandler.connectDeviceAndSetTime(str4BDID).timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return aBoolean == true;
            }
        }).first().flatMap(new Func1<Boolean, Observable<DeviceUtil.FirmSetting>>() {
            @Override
            public Observable<DeviceUtil.FirmSetting> call(Boolean aBoolean) {
                return deviceHandler.getFirm().timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS);
            }
        }).timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<DeviceUtil.FirmSetting, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(DeviceUtil.FirmSetting firmSetting) {
                setFirmSetting(firmSetting);
                return Observable.just(true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                return deviceHandler.registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<DeviceUtil.DeviceSetting>>() {
            @Override
            public Observable<DeviceUtil.DeviceSetting> call(Boolean aBoolean) {
                return deviceHandler.getDeviceSetting().timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS);
            }
        }).first().timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<DeviceUtil.DeviceSetting, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(DeviceUtil.DeviceSetting deviceSetting) {
                setDeviceSetting(deviceSetting);
                return Observable.just(true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Integer>>() {
            @Override
            public Observable<Integer> call(Boolean aBoolean) {
                return deviceHandler.getBattery().timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS);
            }
        }).subscribe(new Action1<Integer>() {
            @Override
            public void call(Integer integer) {
                setBattery(integer);
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
    }

//    public Observable<DeviceUtil.DeviceSetting> getDeviceSettingFromBle(String address){
//        return connectDeviceAndSetTime(address).filter(new Func1<Boolean, Boolean>() {
//            @Override
//            public Boolean call(Boolean aBoolean) {
//                return aBoolean == true;
//            }
//        }).first().timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<Boolean, Observable<Boolean>>() {
//            @Override
//            public Observable<Boolean> call(Boolean aBoolean) {
//                return registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID);
//            }
//        }).filter(new Func1<Boolean, Boolean>() {
//            @Override
//            public Boolean call(Boolean aBoolean) {
//                return (aBoolean == true);
//            }
//        }).first().timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<Boolean, Observable<DeviceUtil.DeviceSetting>>() {
//            @Override
//            public Observable<DeviceUtil.DeviceSetting> call(Boolean aBoolean) {
//                return getDeviceSetting();
//            }
//        });
//    }


    private void setDeviceSetting(final DeviceUtil.DeviceSetting setting) {
        if (null != setting) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    device.setTemperature(setting.getTemp());
                    device.setHumidity_down(setting.getHumi());
                    DogDeviceStationRepository.getInstance().updateDevice(device);
                    tempTxt.setText(setting.getTemp() + getResources().getString(R.string.temperature_unit));
                    humiTxt.setText(setting.getHumi() + getResources().getString(R.string.percent_unit));
                }
            });

        }
    }

    private void setBattery(final Integer integer) {
        if (null != integer){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    device.setBattery(integer);
                    DogDeviceStationRepository.getInstance().updateDevice(device);
                    powerTxt.setText(integer + percent);
                }
            });

        }
    }

    private void setFirmSetting(final DeviceUtil.FirmSetting firmSetting) {
        if (null != firmSetting) {
//                            firmInfo.setMajor();
//                            FirmDetailModel model = StatusRepository.getInstance().getFirmDbByBdid(device.getBdid());
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (null == firmInfo){
                        firmInfo = new FirmDetailModel(UserUtils.getInstance().loadUser().getUser_id(),
                                FirmDetailModel.DEVICE_TYPE,false, device.getBdid());
                        firmInfo.setVersion(firmSetting.getFirmVersion());
                        StatusRepository.getInstance().insertFirm(firmInfo);
                    } else {
                        firmInfo.setVersion(firmSetting.getFirmVersion());
                        StatusRepository.getInstance().updateFirm(firmInfo);
                    }
                    firmTxt.setText("" + firmSetting.getFirmVersion());
                }
            });

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != deviceHandler){
            deviceHandler.disconnect();
        }
        if (null != subscription){
            subscription.unsubscribe();;
            subscription = null;
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        Intent intent = new Intent();
        int id = v.getId();
        if (id == R.id.id_firm_rl) {
            if (updateFlagView.getVisibility() == View.VISIBLE){
                intent.putExtra(Constants.EXTRA_FIRM_FLAG,FirmUpdateActivity.DEVICE_FIRM_UPDATE_FLAG);
                intent.putExtra(Constants.EXTRA_FIRM_INFO, firmInfo);
                intent.setClass(this,FirmUpdateActivity.class);
                startActivity(intent);
            }

        } else if (id == R.id.id_temp_rl) {
            intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,activityFromFlag);
            intent.putExtra(Constants.EXTRA_DOG,dog);
            intent.putExtra(Constants.EXTRA_DEVICE_MODEL, device);
            intent.setClass(this, DeviceSettingActivity.class);
            startActivityForResult(intent, REQUEST_DEVICE_SETTING);
        } else if (id == R.id.id_humi_rl) {
            intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,activityFromFlag);
            intent.putExtra(Constants.EXTRA_DOG,dog);
            intent.putExtra(Constants.EXTRA_DEVICE_MODEL, device);
            intent.setClass(this, DeviceSettingActivity.class);
            startActivityForResult(intent, REQUEST_DEVICE_SETTING);
        } else if (id == R.id.id_device_remove_btn){
            PopViewHelper.getInstance().showDeletePop(this, layer,
                    getResources().getString(R.string.device_delete_title), getResources().getString(R.string.release));
        } else  if (id == R.id.id_pop_sure_txt){
            PopViewHelper.getInstance().dismissPop();
            showWaitingDialog();
            DogDeviceStationRepository.getInstance().deleteDeviceFromNet(DogDeviceStationRepository.REQUEST_FROM_DEVICE_DETAIL,dog.getDog_id());
        }else if (id == R.id.id_pop_cancel_txt){;
            PopViewHelper.getInstance().dismissPop();
        }

    }

    @Override
    public void success(Object dogId, int mode) {
        hideWaitingDialog();
        if (mode == DogDeviceStationRepository.DELETE_DEVICE_FROM_NET_MODE){
            if (null != device && null != device.getBdid()){
                DogDeviceStationRepository.getInstance().deleteDevice(device);
            }
            Intent intent = new Intent();
            intent.putExtra(Constants.EXTRA_VALUE,dog.getDog_id());
            setResult(REQUEST_DEVICE_DETAIL,intent);
            finish();
        }
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
        hideWaitingDialog();
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
        hideWaitingDialog();
    }

}
