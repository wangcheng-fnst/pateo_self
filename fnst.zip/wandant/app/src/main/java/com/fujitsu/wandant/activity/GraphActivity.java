package com.fujitsu.wandant.activity;


import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSmoothScroller;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnChildAttachStateChangeListener;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.WandantApplication;
import com.fujitsu.wandant.adapter.BarDataAdapter;
import com.fujitsu.wandant.adapter.ListStepsAndShakeAdapter;
import com.fujitsu.wandant.model.GraphInfoModel;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.presenter.GraphInterface;
import com.fujitsu.wandant.presenter.GraphPresenter;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.TimeUtils;
import com.fujitsu.wandant.view.ListViewNoScroll;
import com.fujitsu.wandant.view.NumberView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/9/25.
 */
public class GraphActivity extends BaseActivity implements GraphInterface {

    /**
     * data count
     */
//    private int dataCount = 20;
    /**
     * the max count of shakes or steps
     */
    private static final float maxStepCount = 20000;
    private static final float maxShakeCount = 10000;
    private static final String LOG_TAG = GraphActivity.class.getName();
    private float lastAverageCount;
    /**
     * bar view (RecyclerView)
     */
    RecyclerView mRecyclerView;
    /**
     * show data with listView
     */
    ListViewNoScroll mListViewNoScroll;
    /**
     * for bar View
     */
    float downX, downY, moveX;
    /**
     * for listView
     */
    float listDownX, listDownY, listMoveY;
    /**
     * LinearLayoutManager for bar View to slow the speed of scrolling
     */
    LinearLayoutManager manager;
    /**
     * first:the first position for bar View
     * last: the last position for bar View
     */
//    int first = dataCount - 10;
//    int last = dataCount - 2;
//    int first = 0;
//    int last = 0;
    public int firstCompleteVisiblePosition;
    /**
     * width : the width of device
     * height:the height of device
     */
    public int width, height;
    /**
     * width : the width of bar
     * barWidth:the height of blank
     */
    public float blankWidth, barWidth;
    /**
     * to judge if the first time complete to draw view
     */
    private boolean isFirst = true;

    /**
     * adapter for bar View
     */
    private BarDataAdapter barViewDataAdapter;
    /**
     * data from net
     */
    private List<GraphInfoModel> mStepDataFromNet = new ArrayList<GraphInfoModel>();
//    private List<GraphInfoModel> mShakeData = new ArrayList<GraphInfoModel>();

    /**
     * adapter for listView
     */
    private ListStepsAndShakeAdapter listViewDataAdapter;
    /**
     * the flag of scrolling if over
     */
    private boolean isOver = true;
    /**
     * the height of listView
     */
    private int listHeight;


    private Handler mHandler;

    /**
     * listFirst: first position of listView
     * listLast; last position of listView
     */
//    private int listFirst, listLast;

    /**
     * some normal view of the activity
     */
    private TextView nameTxt;
    private ImageView dateImg;
    private TextView dateTxt;
    private NumberView countTxt;
    private LinearLayout averageLayout;
    private TextView averageTxt;
    private NumberView averageCountTxt;
    private TextView averageTypeTxt;
    private TextView averageNameTxt;
    private LinearLayout mListLayout;
    private RelativeLayout mTitleBar4Step;
    private RelativeLayout mTitleBar4Shack;
    private int barTxtWidth;

    private ImageView tabBgImg;

    /**
     * mode to differ Shake or Step
     */
    private int currentMode = BarDataAdapter.STEP_MODE;

    private Dog dog;
    private GraphPresenter graphPresenter;
    private ScrollCallBack scrollCallBack;
    private ScrollCallBackRunnable scrollCallBackRunnable;
    private String hyphen;
    private String comma;

    @Override
    public String getTitleName() {
        if (null != dog){
            return dog.getName();
        }
        return "";
    }

    @Override
    public String getTitleHeadUrl() {
        if (null != dog){
            return ApplicationUtils.getHeadIconUrl(dog.getAvatar_url());
        }
        return "";
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        super.isShowHead = true;
        super.isShowName = true;
        dog = (Dog) getIntent().getSerializableExtra(Constants.EXTRA_DOG);
        graphPresenter = new GraphPresenter(this,dog, mStepDataFromNet);
        hyphen = getResources().getString(R.string.hyphen);
        comma = getResources().getString(R.string.comma);
        setScrollCallBack(graphPresenter);
        graphPresenter.onCreate();
        mHandler = new Handler();
        scrollCallBackRunnable = new ScrollCallBackRunnable();
    }


    /**
     * init all view
     */
    @Override
    public void initView() {
        findViewById(R.id.id_title_layout).setBackgroundResource(0);
        findViewById(R.id.id_title_layout).setBackgroundColor(getResources().getColor(R.color.white));
        width = WandantApplication.getInstance().getWidth();
        height = WandantApplication.getInstance().getHeight();
        //for cover view
        RelativeLayout frameLayout = (RelativeLayout) findViewById(R.id.id_blank);
        View viewLeft = findViewById(R.id.left);
        View viewRight = findViewById(R.id.right);
        blankWidth = width / 49.4f;
        barWidth = (blankWidth * 4.6f);
        barTxtWidth = (int) (barWidth - 28) + 1;
        final LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(frameLayout.getLayoutParams());
        lp1.height = (int) (2 * barTxtWidth + 10) + 1;
        lp1.width = (int) (width + blankWidth) + 1;
        lp1.setMargins((int) (0 - blankWidth / 2.0), 0 - lp1.height, 0, 0);
        frameLayout.setLayoutParams(lp1);
        RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(viewLeft.getLayoutParams());
        lp2.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        lp2.height = (int) (2 * (barTxtWidth) + 10);
        lp2.width = (int) (barWidth + blankWidth) + 1;
        viewLeft.setLayoutParams(lp2);
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(viewRight.getLayoutParams());
        lp.height = (int) (2 * barTxtWidth + 10);
        lp.width = (int) (barWidth + blankWidth) + 1;
        viewRight.setLayoutParams(lp);
        //for bar view
        mRecyclerView = (RecyclerView) findViewById(R.id.id_bar_view);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(mRecyclerView.getLayoutParams());
        barLp.width = (int) (width + blankWidth) + 1;
        barLp.setMargins((int) (0 - blankWidth / 2.0), 0, 0, 0);
        mRecyclerView.setLayoutParams(barLp);
        barViewDataAdapter = new BarDataAdapter(this);
        barViewDataAdapter.setMode(BarDataAdapter.STEP_MODE);
        manager = new CustomLayoutManager(this, LinearLayoutManager.HORIZONTAL, true);
        barViewDataAdapter.setManager(manager);
        mRecyclerView.addOnChildAttachStateChangeListener(new OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(View view) {

            }

            @Override
            public void onChildViewDetachedFromWindow(View view) {

            }
        });

        mRecyclerView.setRecyclerListener(new RecyclerView.RecyclerListener() {
            @Override
            public void onViewRecycled(RecyclerView.ViewHolder holder) {
                barViewDataAdapter.removeHolder((BarDataAdapter.BarHolder) holder);
            }
        });
        mRecyclerView.setLayoutManager(manager);
        mRecyclerView.setAdapter(barViewDataAdapter);
        mRecyclerView.addOnScrollListener(scrollListener);
        ViewTreeObserver.OnGlobalLayoutListener globalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (isFirst) {
                    int barHeight = mRecyclerView.getHeight();
                    listHeight = mListViewNoScroll.getHeight();
                    if (0 != barHeight && 0 != listHeight){
                        barViewDataAdapter.setWidthAndHeight(barWidth, blankWidth, barHeight, barTxtWidth);
                        barViewDataAdapter.setMaxCount(maxStepCount, maxShakeCount);
                        listViewDataAdapter.setHeight(listHeight);
                        mListViewNoScroll.setAdapter(listViewDataAdapter);
                        isFirst = false;
                        //First loading the step data from DB
                        graphPresenter.getData();
                    }
                }
            }
        };
        mRecyclerView.getViewTreeObserver().addOnGlobalLayoutListener(globalLayoutListener);


        //for log list view
        mListViewNoScroll = (ListViewNoScroll) findViewById(R.id.id_data_list);
        mListViewNoScroll.getViewTreeObserver().addOnGlobalLayoutListener(globalLayoutListener);
        listViewDataAdapter = new ListStepsAndShakeAdapter(this);


        //for count show
        nameTxt = (TextView) findViewById(R.id.id_name_txt);
        if (null != dog){
            nameTxt.setText(dog.getName());
        }
        dateImg = (ImageView) findViewById(R.id.id_date_img);
        dateTxt = (TextView) findViewById(R.id.id_date_tv);
        countTxt = (NumberView) findViewById(R.id.id_count_txt);
        countTxt.setFontColor(Constants.DARK_GRAY);
        //for average view
        averageLayout = (LinearLayout) findViewById(R.id.id_average_layout);
        averageTxt = (TextView) findViewById(R.id.id_average_txt);
        mListLayout = (LinearLayout) findViewById(R.id.id_list_layout);
        averageLayout.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        tabBgImg = (ImageView) findViewById(R.id.id_tab_bg);
        RelativeLayout.LayoutParams tabLp = new RelativeLayout.LayoutParams(tabBgImg.getLayoutParams());
        tabLp.width = width / 2;
        tabBgImg.setLayoutParams(tabLp);
        findViewById(R.id.id_steps_layout).setOnClickListener(this);
        findViewById(R.id.id_shakes_layout).setOnClickListener(this);

        averageCountTxt = (NumberView) findViewById(R.id.id_average_count_txt);
        averageNameTxt = (TextView) findViewById(R.id.id_average_name_txt);
        averageTypeTxt = (TextView) findViewById(R.id.id_average_type_txt);
        averageCountTxt.setFontColor(Constants.LIGHT_GRAY);
        //Title Bar 4 List
        mTitleBar4Step = (RelativeLayout) findViewById(R.id.id_title_bar_4_step);
        mTitleBar4Shack = (RelativeLayout) findViewById(R.id.id_title_bar_4_shack);
//        averageCountTxt.setValue(getFormatCount(getAverageCount()) + "");
        averageTypeTxt.setText(getResources().getString(R.string.step));


    }

    @Override
    public int getMode() {
        return currentMode;
    }

    @Override
    public void refreshStepsAndShakeList() {
        Log.e("huangc","#### refreshStepsAndShakeList  ####");
        int position = manager.findFirstVisibleItemPosition();
        boolean isToday = false;
        Log.e("huangc", "#### refreshStepsAndShakeList position= " + position + "  isToday= " + isToday);
        if (0 == position || RecyclerView.NO_POSITION == position){
            position = 0;
            isToday = true;
        }
        List<GraphInfoModel> data = new ArrayList<>();
        for (int index = 0; index < 7 && (index + position + 1) < mStepDataFromNet.size(); index++){
            data.add(mStepDataFromNet.get(index + position + 1));
        }
        listViewDataAdapter.refreshData(currentMode, isToday, data);

    }

    @Override
    public void refreshData(List<GraphInfoModel> stepList, Integer firstIndex, Integer lastIndex) {
//        if (null == firstIndex || null == lastIndex){
//            return;
//        }
//        Log.e("huangc","#### Activity refreshData ####");
//        Log.e("huangc","#### Activity refreshData size= "+stepList.size());
            barViewDataAdapter.refreshData(stepList, firstIndex, lastIndex);
        changeData(firstCompleteVisiblePosition);
    }

    @Override
    public void refreshZoomDataNow(int firstVisiblePosition, int lastVisiblePosition) {
        barViewDataAdapter.refreshZoomData(firstVisiblePosition, lastVisiblePosition);
    }


    /**
     * get layout xml
     *
     * @return
     */
    @Override
    public int getLayout() {
        return R.layout.activity_step_records;
    }

    @Override
    protected void onResume() {
        super.onResume();
        graphPresenter.onResume();
    }

    /**
     * change mode from step to shake or shake to step
     *
     * @param mode
     */
    public void changeMode(int mode) {
        if (mode == BarDataAdapter.SHAKE_MODE) {
            mTitleBar4Shack.setVisibility(View.VISIBLE);
            mTitleBar4Step.setVisibility(View.GONE);
            manager.removeAllViews();
            barViewDataAdapter.setMode(mode);
            ((TextView) findViewById(R.id.id_step_str)).setText(getResources().getString(R.string.times));
            averageNameTxt.setText(getResources().getString(R.string.shake_average_str));
            averageTypeTxt.setText(getResources().getString(R.string.times));
        } else {
            mTitleBar4Shack.setVisibility(View.GONE);
            mTitleBar4Step.setVisibility(View.VISIBLE);
            manager.removeAllViews();
            barViewDataAdapter.setMode(BarDataAdapter.STEP_MODE);
            ((TextView) findViewById(R.id.id_step_str)).setText(getResources().getString(R.string.step));
            averageNameTxt.setText(getResources().getString(R.string.step_average_str));
            averageTypeTxt.setText(getResources().getString(R.string.step));
        }
        if (!mStepDataFromNet.isEmpty()){
            changeData(1);
        }
        refreshStepsAndShakeList();

    }

    /**
     * click event
     *
     * @param v
     */
    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (v.getId() == R.id.id_steps_layout) {
            if (currentMode != BarDataAdapter.STEP_MODE) {
                currentMode = BarDataAdapter.STEP_MODE;
                averageLayout.setVisibility(View.VISIBLE);
                float currentTranslationX = tabBgImg.getTranslationX();
                ObjectAnimator.ofFloat(tabBgImg, "translationX", currentTranslationX, 0)
                        .setDuration(300)
                        .start();
                ((TextView) findViewById(R.id.id_step_txt)).setTextColor(getResources().getColor(R.color.font_black));
                ((TextView) findViewById(R.id.id_shake_txt)).setTextColor(getResources().getColor(R.color.font_light_gray));
                ((ImageView) findViewById(R.id.id_step_img)).setImageResource(R.drawable.step_pressed);
                ((ImageView) findViewById(R.id.id_shake_img)).setImageResource(R.drawable.shake_normal);
                changeMode(currentMode);
            }

        } else if (v.getId() == R.id.id_shakes_layout) {
            if (currentMode != BarDataAdapter.SHAKE_MODE) {
                currentMode = BarDataAdapter.SHAKE_MODE;
                averageLayout.setVisibility(View.GONE);
                float currentTranslationX = tabBgImg.getTranslationX();
                ObjectAnimator.ofFloat(tabBgImg, "translationX", currentTranslationX, width / 2 +4)
                        .setDuration(300)
                        .start();
                ((TextView) findViewById(R.id.id_step_txt)).setTextColor(getResources().getColor(R.color.font_light_gray));
                ((TextView) findViewById(R.id.id_shake_txt)).setTextColor(getResources().getColor(R.color.font_black));
                ((ImageView) findViewById(R.id.id_step_img)).setImageResource(R.drawable.step_normal);
                ((ImageView) findViewById(R.id.id_shake_img)).setImageResource(R.drawable.shake_pressed);
                changeMode(currentMode);
            }
        }

    }

    @Override
    public void initData(List<GraphInfoModel> data) {
        barViewDataAdapter.setData(data);
        changeData(1);
    }

    @Override
    public void refreshData(List<GraphInfoModel> data) {
        barViewDataAdapter.setData(data);
    }


    @Override
    public void refreshDataNow() {
        barViewDataAdapter.refreshDataNow();
    }

    private void changeData(int position){
        if (0 == position){
            position = 1;
        }
        if (position < 0 || position >= mStepDataFromNet.size()){
            return;
        }
        countTxt.setFontColor(Constants.DARK_GRAY);
        Integer count;
        if (currentMode == BarDataAdapter.STEP_MODE) {
            count = mStepDataFromNet.get(position).getWdSteps();
        }else{
            count = mStepDataFromNet.get(position).getWdBuruburu();
        }
            countTxt.setText(StringUtils.getFormatCount(count) + "");

        if (1 == position) {
            dateImg.setVisibility(View.VISIBLE);
            dateTxt.setVisibility(View.GONE);
        } else {
            if (dateImg.getVisibility() == View.VISIBLE){
                dateImg.setVisibility(View.GONE);
                dateTxt.setVisibility(View.VISIBLE);
            }
            List<GraphInfoModel> list = barViewDataAdapter.getData();
            if (null != list && position < list.size() ){
                dateTxt.setText(TimeUtils.geMonthDay(list.get(position).getSensedAt()) + "");
            } else {
                dateTxt.setText("");
            }

        }
    }



    @Override
    public void initAverage(Integer count) {
        if (currentMode == BarDataAdapter.STEP_MODE){
            if (count==null){
                averageLayout.setVisibility(View.GONE);
                return;
            }
            averageLayout.setVisibility(View.VISIBLE);
            LinearLayout.LayoutParams averageLayoutLp = new LinearLayout.LayoutParams(averageLayout.getLayoutParams());
            LinearLayout.LayoutParams averageTxtLp = new LinearLayout.LayoutParams(averageTxt.getLayoutParams());
            averageTxtLp.height = (int) (barWidth * 1.2f);
            averageTxtLp.width = (int) (barWidth * 1.2f);
            averageTxt.setLayoutParams(averageTxtLp);
            int averageCount = count;
//            lastAverageCount = averageCount;
            int marginTop = (int) ((int) (2 * barTxtWidth + 10) + 1 + averageTxtLp.height / 2.0 + (averageCount / maxStepCount) * (mRecyclerView.getMeasuredHeight() - 2 * barTxtWidth - 10));
            averageLayoutLp.setMargins(10, 0 - marginTop, 0, 0);
            averageLayout.setLayoutParams(averageLayoutLp);

            float yOffset = ((lastAverageCount - averageCount) / maxStepCount * (mRecyclerView.getMeasuredHeight() - 2 * barTxtWidth - 10));
            float currentTranslationY = averageLayout.getTranslationY();
            if(currentTranslationY == 0){
                currentTranslationY = yOffset ;
                yOffset = 0;
            }
            ObjectAnimator.ofFloat(averageLayout, "translationY", currentTranslationY, yOffset)
                .setDuration(500)
                .start();
            averageCountTxt.setValue(StringUtils.getFormatCount(averageCount));

            lastAverageCount = averageCount;

        } else {
            averageLayout.setVisibility(View.GONE);
        }
    }



    OnScrollListener scrollListener = new RecyclerView.OnScrollListener(){
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            Log.e("huangc","====> onScrollStateChanged ");
            if(newState == RecyclerView.SCROLL_STATE_DRAGGING){
                Log.d(LOG_TAG, "cancel");
//                mHandler.removeCallbacks(scrollCallBackRunnable);
            }else if(newState == RecyclerView.SCROLL_STATE_IDLE) {
                mHandler.post(scrollCallBackRunnable);
                View view = GraphActivity.this.mRecyclerView.getChildAt(8);
                if (null == view){
                    return;
                }
                int left = GraphActivity.this.mRecyclerView.getChildAt(8).getLeft();
                if (left <= 0){
                } else if (left > (barWidth / 2 + blankWidth + 1)){
                    int x1 = (int) (left - (barWidth + blankWidth + 1));
                    GraphActivity.this.mRecyclerView.smoothScrollBy(x1, 0);
                } else {
                    int x2 = left;
                    GraphActivity.this.mRecyclerView.smoothScrollBy(x2, 0);
                }
            }
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            Log.e("huangc", "====> onScrolled    ");
            super.onScrolled(recyclerView, dx, dy);
            LinearLayoutManager manager = (LinearLayoutManager) recyclerView.getLayoutManager();
            int firstCompletePosition = manager.findFirstCompletelyVisibleItemPosition();
            int firstVisiblePosition = manager.findFirstVisibleItemPosition();
            int lastVisiblePosition = manager.findLastVisibleItemPosition();
            if (firstCompleteVisiblePosition != firstCompletePosition){
                changeData(firstCompletePosition);
                firstCompleteVisiblePosition = firstCompletePosition;
            }
//            if (currentMode == BarDataAdapter.STEP_MODE){
                barViewDataAdapter.setFirstCompleteVisiblePosition(firstVisiblePosition, lastVisiblePosition);
            //TODO
                refreshDataNow();
//            refreshZoomDataNow(firstVisiblePosition, lastVisiblePosition);
//            }
        }
    };


    public class ScrollCallBackRunnable implements Runnable{
        @Override
        public void run() {
            scrollCallBack.scrollToPosition(firstCompleteVisiblePosition);
        }
    }

    public void setScrollCallBack(ScrollCallBack scrollCallBack) {
        this.scrollCallBack = scrollCallBack;
    }

    public ScrollCallBack getScrollCallBack() {
        return scrollCallBack;
    }


    public interface ScrollCallBack{
        void scrollToPosition(int position);
    }

    private class CustomLayoutManager extends LinearLayoutManager {
        public CustomLayoutManager(Context context, int orientation, boolean reverseLayout) {
            super(context, orientation, reverseLayout);
        }

        @Override
        public void smoothScrollToPosition(RecyclerView recyclerView, RecyclerView.State state, int position) {
            super.smoothScrollToPosition(recyclerView, state, position);
            LinearSmoothScroller smoothScroller = new LinearSmoothScroller(recyclerView.getContext()) {
                public PointF computeScrollVectorForPosition(int targetPosition) {
                    return CustomLayoutManager.this.computeScrollVectorForPosition(targetPosition);
                }

                @Override
                protected float calculateSpeedPerPixel(DisplayMetrics displayMetrics) {
                    return 200 / TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 100, displayMetrics);
                }
            };
            smoothScroller.setTargetPosition(position);
            this.startSmoothScroll(smoothScroller);
        }
    }


}
