package com.fujitsu.wandant.ble;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import com.fujitsu.wandant.log.Logger;

public abstract class BleManager {

	public BleDevice getDevice() {
		return bleDevice;
	}

	public interface BleCallback {
		void onFoundDevice(BluetoothDevice device, int rssi, byte[] record);
	}

	protected Context mContext;
	protected BleCallback mBleCallback;
	protected boolean mBtEnable = true;
	protected BleDevice bleDevice = null;	

	protected BleManager(Context cntx, BleCallback cb) {
//	protected BleManager(Context cntx) {
		mBleCallback = cb;
		mContext = cntx;

		IntentFilter filter = new IntentFilter();
		filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
		cntx.registerReceiver(mReceiver, filter);

		mBtEnable = BluetoothAdapter.getDefaultAdapter().isEnabled();
		if(mBtEnable) {
			enableBle(cntx);
		} else {
			Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
			enableBtIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			mContext.startActivity(enableBtIntent);
		}
	}

	public static BleManager createBleManager(Context cntx, BleCallback cb) {
		if (Build.VERSION.SDK_INT >= 18) {
			return new BleManagerAndroid(cntx, cb);
//			return new BleManagerAndroid(cntx);
		}
		return null;
	}

	private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
				int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.STATE_OFF);
				Logger.i("yyy", "bt status changed " + (state == BluetoothAdapter.STATE_ON));
				mBtEnable = (state == BluetoothAdapter.STATE_ON);
				if (mBtEnable) {
					enableBle(mContext);
				}else{
					disableBle();
				}
			}
		}
	};

	protected abstract void enableBle(Context cntx);
	protected abstract void disableBle();

	public abstract void scanBleDevice();
	public abstract void stopScan();
	public abstract BleDevice connectBleDevice(String deviceAddress, BleDevice.BleDeviceCallback cb);
	public abstract BleDevice connectBleDevice(BluetoothDevice device, BleDevice.BleDeviceCallback cb);
	public abstract void disconnect();

}
