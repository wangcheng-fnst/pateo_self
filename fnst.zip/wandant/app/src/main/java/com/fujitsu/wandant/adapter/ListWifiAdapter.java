package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.utils.Constants;

import java.util.List;

/**
 * Created by chenjie.fnst on 2015/10/14.
 */
public class ListWifiAdapter extends BaseAdapter {

    private Context context;
    private List<ScanResult> wifiList;
    private int selectPosition = Constants.NUMBER_INVALID;

    public ListWifiAdapter(Context context, List<ScanResult> list){
        this.context = context;
        this.wifiList = list;

    }

    private int[] signalArray = new int[]{R.drawable.wifi_signal_0, R.drawable.wifi_signal_1,
                                            R.drawable.wifi_signal_2, R.drawable.wifi_signal_3};

    @Override
    public int getCount() {
        return wifiList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void setSelectPosition(int selectPosition) {
        this.selectPosition = selectPosition;
        notifyDataSetChanged();
    }

    class ViewHolder{
        private ImageView tvSignal;
        private TextView tvName;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (null == convertView){
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.listview_wifi_item,parent,false);
            viewHolder.tvSignal = (ImageView) convertView.findViewById(R.id.tvSignal);
            viewHolder.tvName = (TextView)convertView.findViewById(R.id.tvName);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder)convertView.getTag();
        }
        if (position == selectPosition) {
            if (position == 0){
                convertView.setBackground(context.getResources().getDrawable(R.drawable.table_top_pressed_bg));
            } else {
                convertView.setBackground(context.getResources().getDrawable(R.drawable.table_middle_pressed_bg));
            }
        } else {
            convertView.setBackgroundColor(context.getResources().getColor(R.color.transparent));
        }
        ScanResult scanResult = wifiList.get(position);
        int drawableId = signalArray[WifiManager.calculateSignalLevel(scanResult.level,4)];
        viewHolder.tvSignal.setImageDrawable(context.getResources().getDrawable(drawableId));
        viewHolder.tvName.setText(scanResult.SSID + " " + scanResult.BSSID);
        return convertView;
    }
}
