package com.fujitsu.wandant.activity;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.FileUtils;
import com.fujitsu.wandant.utils.MediaFile;
import com.fujitsu.wandant.view.CircleImageView;
import com.fujitsu.wandant.view.ToastManager;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.io.File;

/**
 * Created by wangc.fnst on 2015/10/15.
 */
public class ImageCatActivity extends BaseActivity implements OnModelFinishedListener {
    public static final int CAREMA_CODE = 0x001;
    public static final int IMAGE_SELECT_CODE = 0x02;
    public static final int IMAGE_COMPLETE = 0x03;
    public static final int START_FOR_ADD_TYPE = 0x100;
    public static final int START_FOR_EDIT_TYPE = 0x101;

    CircleImageView photoAddImg;
    Button okBtn;
    private PopupWindow mWindow;
    private File tmpImageFile;
    private File targetImageFile;
    private View layer;
    private Dog dog;
//    private int currentType;


    @Override
    public String getTitleName() {
        return getResources().getString(R.string.dog_register_title);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        super.isShowHead = false;
        super.isShowName = true;
        dog = (Dog) (getIntent().getSerializableExtra(Constants.EXTRA_DOG));
//        currentType = getIntent().getIntExtra(Constants.EXTRA_DOG_TYPE,START_FOR_ADD_TYPE);
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_IMAGE_CAT, this);
        initView();
    }

    private void initView() {
        photoAddImg = (CircleImageView) findViewById(R.id.id_photo_add_img);
        okBtn = (Button) findViewById(R.id.id_sure_btn);
        okBtn.setOnClickListener(this);
        photoAddImg.setOnClickListener(this);
        okBtn.setOnClickListener(this);
        okBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        layer = findViewById(R.id.id_layer);
    }

    @Override
    public int getLayout() {
        return R.layout.photo_crop_index;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        int id = v.getId();
        if (id == R.id.id_photo_add_img) {
            showPicPop();
        } else if (id == R.id.id_sure_btn) {
            switch (activityFromFlag){
                case Constants.ACTIVITY_FROM_SETTING_DOG_DETAIL:
                    showWaitingDialog();
                    DogDeviceStationRepository.getInstance().modifyDogHeadFromNet(DogDeviceStationRepository.REQUEST_FROM_IMAGE_CAT,
                            dog.getDog_id(),new File(dog.getAvatar_url()));
                    break;
                case Constants.ACTIVITY_FROM_SETTING_DOG_ADD:
                case Constants.ACTIVITY_FROM_REGISTER:
                    Intent intent = new Intent(this, DogSureActivity.class);
                    intent.putExtra(Constants.EXTRA_DOG, dog);
                    intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG, activityFromFlag);
                    startActivity(intent);
                    break;
                default:
                    break;

            }
//            if (currentType == START_FOR_ADD_TYPE) {
//                DogDeviceStationRepository.getInstance().addDogFromNet(DogDeviceStationRepository.REQUEST_FROM_IMAGE_CAT, dog);
//            }else{
//                DogDeviceStationRepository.getInstance().modifyDogHeadFromNet(DogDeviceStationRepository.REQUEST_FROM_IMAGE_CAT,
//                        dog.getDog_id(),new File(dog.getAvatar_url()));
//            }
        } else if (id == R.id.id_photo_take_txt) {
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // decide image path
            tmpImageFile = FileUtils.getNewPicFile();
            ApplicationUtils.setTmpFilePath(tmpImageFile.getAbsolutePath());
            Uri uri = Uri.fromFile(new File(tmpImageFile.getAbsolutePath()));
            camera.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            startActivityForResult(camera, CAREMA_CODE);
            dismissPicPopup();

        } else if (id == R.id.id_photo_select_txt) {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent.setType("image/*");
            startActivityForResult(intent, IMAGE_SELECT_CODE);
            dismissPicPopup();
        } else if (id == R.id.id_photo_cancel_txt) {
            dismissPicPopup();
        }
    }

    @Override
    protected void onDestroy() {
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_IMAGE_CAT);
        super.onDestroy();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Uri uri = null;
        switch (requestCode) {
            case CAREMA_CODE:
                File file = new File(ApplicationUtils.getTmpFilePath());
                if (resultCode == RESULT_OK && file.exists()) {
                    targetImageFile = FileUtils.getNewPicFile();
                    Intent intent = new Intent(this, ClipActivity.class);
                    intent.putExtra(Constants.EXTRA_SRC_PATH, file.getAbsolutePath());
                    intent.putExtra(Constants.EXTRA_DEST_PATH, targetImageFile.getAbsolutePath());
                    startActivityForResult(intent, IMAGE_COMPLETE);
                }
                break;
            case IMAGE_SELECT_CODE:
                if (resultCode == RESULT_OK) {
                    uri = data.getData();
                    String path = FileUtils.getPathByUri(this, uri);
                    if (MediaFile.isSupportImageType(path)) {
                        targetImageFile = FileUtils.getNewPicFile();
                        Intent intent = new Intent(this, ClipActivity.class);
                        intent.putExtra(Constants.EXTRA_SRC_PATH, path);
                        intent.putExtra(Constants.EXTRA_DEST_PATH, targetImageFile.getAbsolutePath());
                        startActivityForResult(intent, IMAGE_COMPLETE);
                    } else {
//                        ToastManager.getInstance().showFail(getString(R.string.image_format_error));
                    }
                }
                break;
            case IMAGE_COMPLETE:
                if (resultCode == RESULT_OK) {
                    String path = data.getStringExtra(Constants.EXTRA_TARGET_PATH);
                    ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconPath(path), photoAddImg);
                    dog.setAvatar_url(path);
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void showPicPop() {
        if (mWindow == null) {
            View view = LayoutInflater.from(this).inflate(R.layout.photo_pick_layout, null);
            mWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//            view.setBackgroundColor(getResources().getColor(R.color.half_transparent_black));
            view.findViewById(R.id.id_photo_take_txt).setOnClickListener(this);
            view.findViewById(R.id.id_photo_select_txt).setOnClickListener(this);
            view.findViewById(R.id.id_photo_cancel_txt).setOnClickListener(this);
            mWindow.setBackgroundDrawable(new BitmapDrawable());
            mWindow.setOutsideTouchable(true);
            mWindow.setFocusable(true);
            mWindow.setOnDismissListener(onDismissListener);
        }
        mWindow.setAnimationStyle(R.style.bottom_dialog);
        mWindow.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM, 0, 0);
        float currentAlpha = layer.getAlpha();
        ObjectAnimator.ofFloat(layer, "alpha", currentAlpha, 1f).setDuration(500).start();

    }

    private void dismissPicPopup() {
        if (mWindow != null && mWindow.isShowing()) {
            mWindow.dismiss();
        }
    }

    private PopupWindow.OnDismissListener onDismissListener = new PopupWindow.OnDismissListener() {
        @Override
        public void onDismiss() {
            float currentAlpha = layer.getAlpha();
            ObjectAnimator.ofFloat(layer, "alpha", currentAlpha, 0f).setDuration(500).start();
        }
    };

    @Override
    public void success(Object dog, int type) {
        hideWaitingDialog();
        switch (type){
//            case DogDeviceStationRepository.ADD_DOG_FROM_NET_MODE:
//                Intent intent = new Intent(this, BleSelectionActivity.class);
//                intent.putExtra(Constants.EXTRA_DOG_INFO, (Dog) dog);
//                intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG, activityFromFlag);
//                startActivity(intent);
//                break;
            case DogDeviceStationRepository.MODIFY_HEAD_FROM_NET_MODE:
                Intent intent = new Intent();
                intent.putExtra(Constants.EXTRA_DOG_HEAD,((Dog)dog).getAvatar_url());
                setResult(RESULT_OK, intent);
                finish();
                break;
            default:
                break;
        }
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
        hideWaitingDialog();
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
        hideWaitingDialog();
    }




}
