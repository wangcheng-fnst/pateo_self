package com.fujitsu.wandant.db;

import android.database.sqlite.SQLiteDatabase;
import com.fujitsu.wandant.WandantApplication;


public class DataBaseManager {
    /**
     * データベース名
     */
    public static final String DB_NAME = "wandant-db";

    public static DataBaseManager INSTANCE = null;

    private DaoSession daoSession;

    /**
     * データベース接続を初期化する
     */
    private DataBaseManager() {
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(WandantApplication.getInstance().getApplicationContext(), DB_NAME, null);
        SQLiteDatabase db = helper.getWritableDatabase();
        DaoMaster daoMaster = new DaoMaster(db);
        daoSession = daoMaster.newSession();
    }

    /**
     * singletonパターン
     * @return
     */
    public synchronized static DataBaseManager getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DataBaseManager();
        }
        return INSTANCE;
    }

    public DaoSession getDaoSession() {
        return daoSession;
    }
}
