package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.utils.BitmapUtil;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.view.ToastManager;
import com.fujitsu.wandant.view.clip.ClipImageLayout;

import java.io.File;

/**
 * Created by wangc.fnst on 2015/10/15.
 */
public class ClipActivity extends BaseActivity {
    private String srcPath,destPath;
    private ClipImageLayout mClipImageLayout;
    private TextView cancelTxt,okTxt;
    @Override
    public String getTitleName() {
        return getResources().getString(R.string.move_change);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        super.isShowHead = false;
        super.isShowName = true;
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        srcPath = getIntent().getStringExtra(Constants.EXTRA_SRC_PATH);
        destPath = getIntent().getStringExtra(Constants.EXTRA_DEST_PATH);
        if(TextUtils.isEmpty(srcPath)||!(new File(srcPath).exists())){
            ToastManager.getInstance().showFail(getResources().getString(R.string.image_load_failed));
//            Toast.makeText(this, getResources().getString(R.string.image_load_failed), Toast.LENGTH_SHORT).show();
            return;
        }
        Bitmap bitmap = BitmapUtil.convertToBitmap(srcPath, 420, 420);
        if(bitmap == null){
            ToastManager.getInstance().showFail(getResources().getString(R.string.image_load_failed));
//            Toast.makeText(this,getResources().getString(R.string.image_load_failed),Toast.LENGTH_SHORT).show();
            return;
        }
        mClipImageLayout = (ClipImageLayout) findViewById(R.id.id_clip_layout);
        mClipImageLayout.setBitmap(bitmap);
        cancelTxt = (TextView) findViewById(R.id.id_photo_cancel_txt);
        okTxt = (TextView) findViewById(R.id.id_ok_txt);
        cancelTxt.setOnClickListener(this);
        okTxt.setOnClickListener(this);



    }

    @Override
    public int getLayout() {
        return R.layout.clip_image_layout;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        int id  = v.getId();
        if (id == R.id.id_photo_cancel_txt){
            setResult(RESULT_CANCELED);
            finish();
        }else if(id == R.id.id_ok_txt){
            showWaitingDialog();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Bitmap bitmap = mClipImageLayout.clip();
                    BitmapUtil.savePhotoToSDCard(bitmap,destPath);
                    hideWaitingDialog();
                    Intent intent = new Intent();
                    intent.putExtra(Constants.EXTRA_TARGET_PATH,destPath);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }).start();
        }
    }
}
