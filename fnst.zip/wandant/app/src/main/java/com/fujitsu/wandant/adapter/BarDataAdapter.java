package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.fujitsu.wandant.R;
import com.fujitsu.wandant.model.GraphInfoModel;
import com.fujitsu.wandant.utils.TimeUtils;
import com.fujitsu.wandant.view.LinePointView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import rx.Observable;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * Created by wangc.fnst on 2015/9/25.
 */
public class BarDataAdapter extends RecyclerView.Adapter<BarDataAdapter.BarHolder> {

    public static final int STEP_MODE = 1;
    public static final int SHAKE_MODE = 2;
    public static final int NORMAL_STYLE = 1;
    public static final int UNSIGHT_STYLE = 0;
    public static final int PRESSED_STYLE = 2;
    private static final String LOG_TAG = BarDataAdapter.class.getName();


    private Context mContext;
    private List<GraphInfoModel> mData = new ArrayList<GraphInfoModel>();
    private int mode;
    private float maxStepCount;
    private float maxShakeCount;
    private float height;
    private float blankWidth, barWidth, barTxtHeight;
    private LinearLayoutManager manager;
    private int firstVisiblePosition = 0;
    private int lastVisiblePosition = 8;

    private Map<Integer, BarHolder> mMapPositionHolder = new HashMap<>();
    private Map<BarHolder, Integer> mMapHolderPosition = new HashMap<>();
//    public static int lastHeight = 0;


    public BarDataAdapter(Context context) {
        this.mContext = context;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
        if (mode == SHAKE_MODE) {
            notifyDataSetChanged();
        } else {
            refreshData(mData, 0, 10);
            notifyDataSetChanged();
        }
    }

    public void setData(List<GraphInfoModel> data) {
        this.mData = data;
        notifyDataSetChanged();
    }

    public List<GraphInfoModel> getData() {
        return mData;
    }

    public void setMaxCount(float maxStepCount, float maxShakeCount) {
        this.maxStepCount = maxStepCount;
        this.maxShakeCount = maxShakeCount;
    }

    public void setWidthAndHeight(float barWidth, float blankWidth, float height, float barTxtHeight) {
        this.height = height;
        this.barWidth = barWidth;
        this.blankWidth = blankWidth;
        this.barTxtHeight = barTxtHeight;
    }

    @Override
    public BarHolder onCreateViewHolder(ViewGroup viewGroup, int position) {
        Log.e(LOG_TAG, "onCreateViewHolder " + position);
        BarHolder holder = new BarHolder(LayoutInflater.from(mContext).inflate(R.layout.bar_text_item, viewGroup, false));
        return holder;
    }
    @Override
    public void onBindViewHolder(final BarHolder holder, int position) {
        Log.d(LOG_TAG, "onBindViewHolder position: " + position);
        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(holder.itemLayout.getLayoutParams());
        itemLp.width = (int) (barWidth + blankWidth) + 1;
        holder.itemLayout.setLayoutParams(itemLp);
        GraphInfoModel model = mData.get(position);
        if (mode == STEP_MODE) {

            if (mMapPositionHolder.get(position) != null) {
                mMapHolderPosition.remove(mMapPositionHolder.remove(position));
            }
            mMapPositionHolder.put(position, holder);
            mMapHolderPosition.put(holder, position);
            model.setPosition(position);
            holder.position = position;
            holder.linePoint.setVisibility(View.GONE);
            if (1 == position) {
                holder.textWeek.setBackgroundResource(R.drawable.week_day_bg_pressed);
            } else {
                holder.textWeek.setBackgroundResource(R.drawable.week_day_bg);
            }
        } else {
            holder.imageNormal.setAlpha(0f);
            holder.imagePressed.setAlpha(0f);
            holder.imageUnSight.setAlpha(0f);
            holder.linePoint.setVisibility(View.VISIBLE);
            RelativeLayout.LayoutParams pointLp = new RelativeLayout.LayoutParams(holder.linePoint.getLayoutParams());
            pointLp.width = (int) (barWidth + blankWidth) + 1;
            pointLp.height = (int) (height - 2 * barTxtHeight - 10);
            int currentCount = parseInteger(model.getWdBuruburu());
            int countHeight = (int) (((currentCount / maxShakeCount)) * (height - 2 * barTxtHeight - 10));
            holder.linePoint.setCountHeight(countHeight);
            if (position < mData.size() - 2 && position > 1) {
                int preCount = parseInteger(mData.get(position - 1).getWdBuruburu());
                int nextCount = parseInteger(mData.get(position + 1).getWdBuruburu());
                float leftY = (currentCount + preCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
                float rightY = (currentCount + nextCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
                holder.linePoint.setEndY(rightY, leftY);
            } else if (position == mData.size() - 2 && position > 1) {
                try {
                    int preCount = parseInteger(mData.get(position - 1).getWdBuruburu());
                    float leftY = (model.getWdBuruburu() + preCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
                    holder.linePoint.setEndY(0f, leftY);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (position == 1) {
                int nextCount = parseInteger(mData.get(position + 1).getWdBuruburu());
                float rightY = (currentCount + nextCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
                holder.linePoint.setEndY(rightY, 0f);
            } else {
                holder.linePoint.setEndY(0f, 0f);
            }
            if (1 == position) {
                holder.linePoint.setPointBitmap(R.drawable.line_point_pressed);
                holder.textWeek.setBackgroundResource(R.drawable.week_day_bg_pressed);
            } else {
                holder.linePoint.setPointBitmap(R.drawable.line_point_normal);
                holder.textWeek.setBackgroundResource(R.drawable.week_day_bg);
            }
            holder.linePoint.setLayoutParams(pointLp);
        }

        /*set day and week day**/
        LinearLayout.LayoutParams dayLp = new LinearLayout.LayoutParams(holder.textDay.getLayoutParams());
        dayLp.width = (int) (barTxtHeight);
        dayLp.height = (int) (barTxtHeight);
        dayLp.setMargins((int) (blankWidth / 2.0) + 14, 0, 0, 0);
        holder.textDay.setLayoutParams(dayLp);

        LinearLayout.LayoutParams weekLp = new LinearLayout.LayoutParams(holder.textWeek.getLayoutParams());
        weekLp.width = (int) (barTxtHeight);
        weekLp.height = (int) (barTxtHeight);
        weekLp.setMargins((int) (blankWidth / 2.0) + 14, 10, 0, 0);
        holder.textWeek.setLayoutParams(weekLp);
        String day = TimeUtils.getToday(model.getSensedAt()) + "";
        String dayOfWeek = TimeUtils.getWeekDay(model.getSensedAt()) + "";
        holder.textDay.setText(day);
        holder.textWeek.setText(dayOfWeek);

    }

    @Override
    public int getItemViewType(int position) {
        return 1;
    }

    public void refreshData(List<GraphInfoModel> data, final Integer firstIndex, final Integer lastIndex) {
        Log.e("huangc", "-----------BarDataAdapter  refreshData ------------------ ");
        Log.e("huangc", "#### refreshData data.size()=  " + data.size());
        Log.e("huangc", "#### refreshData firstIndex =  " + firstIndex);
        Log.e("huangc", "#### refreshData lastIndex =  " + lastIndex);
        Log.e("huangc", "-----------BarDataAdapter  refreshData ------------------ ");
        if (!data.isEmpty() && null != data) {
            setBaseDataList(data, firstIndex, lastIndex);
        }
        whichPartNeed2Update();
    }

    public void refreshDataNow() {
        whichPartNeed2Update();
    }

    public void refreshZoomData(int start, int end) {
        Log.e("huangc", "#### refreshZoomData start = " + start + " end= " + end);
        for (int index = start; index < end; index++) {
            GraphInfoModel tempModel = mData.get(index);
            Log.e("huangc", "#### refreshZoomData tempModel.height = " + tempModel.getStepHeight());

        }
    }

    private void setBaseDataList(List<GraphInfoModel> data, Integer firstIndex, Integer lastIndex) {
        for (int index = firstIndex; index < mData.size() && index < data.size() && index <= lastIndex; index++) {
            GraphInfoModel model = data.get(index);
            this.mData.get(index).setSensedAt(model.getSensedAt());
            this.mData.get(index).setWdBuruburu(model.getWdBuruburu());
            this.mData.get(index).setWdSteps(model.getWdSteps());
            this.mData.get(index).setDog_id(model.getDog_id());
            this.mData.get(index).setId(model.getId());
            int stepHeight = getStepHeight(model);
            this.mData.get(index).setStepHeight(stepHeight);
            this.mData.get(index).setPosition(index);
            //set buruburu
            int shakeCount = parseInteger(model.getWdBuruburu());
            int shakeHeight = (int) (((shakeCount / maxShakeCount)) * (height - 2 * barTxtHeight - 10));
            float leftY = 0;
            float rightY = 0;
//            int countHeight = (int) (((currentCount / maxShakeCount)) * (height - 2 * barTxtHeight - 10));
//            holder.linePoint.setCountHeight(countHeight);
            if (index < mData.size() - 2 && index > 1) {
                int preCount = parseInteger(mData.get(index - 1).getWdBuruburu());
                int nextCount = parseInteger(mData.get(index + 1).getWdBuruburu());
                rightY = (shakeCount + preCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
                leftY = (shakeCount + nextCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
            } else if (index == mData.size() - 2 && index > 1) {
                int preCount = parseInteger(mData.get(index - 1).getWdBuruburu());
                int currentCount = parseInteger(model.getWdBuruburu());
                rightY = (currentCount + preCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
            } else if (index == 1) {
                int nextCount = parseInteger(mData.get(index + 1).getWdBuruburu());
                leftY = (shakeCount + nextCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
            }
            this.mData.get(index).setShakeHeight(shakeHeight);
            this.mData.get(index).setLeftY(leftY);
            this.mData.get(index).setRightY(rightY);
        }
    }



    /**
     *  哪些部分数据落在可视区间里面，这样就需要被局部刷新
     *  这里是一个一个的去刷新
     */
    private void whichPartNeed2Update() {
        Observable.from(mData).filter(new Func1<GraphInfoModel, Boolean>() {
            @Override
            public Boolean call(GraphInfoModel graphInfoModel) {
                if (graphInfoModel.getPosition() >= firstVisiblePosition && graphInfoModel.getPosition() <= lastVisiblePosition) {
                    return true;
                }
                return false;
            }
        }).subscribeOn(Schedulers.computation())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<GraphInfoModel>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onNext(final GraphInfoModel graphInfoModel) {
                        updateView(graphInfoModel);
                    }
                });
    }

    /**
     *  将数据源的数据进行加工成可以用来显示用的数据
     */
    private void makeDateNew() {
        for (int index = 0; index < mData.size(); index++) {
            GraphInfoModel model = this.mData.get(index);
            this.mData.get(index).setSensedAt(model.getSensedAt());
            this.mData.get(index).setWdBuruburu(model.getWdBuruburu());
            this.mData.get(index).setWdSteps(model.getWdSteps());
            this.mData.get(index).setDog_id(model.getDog_id());
            this.mData.get(index).setId(model.getId());
            int stepHeight = getStepHeight(model);
            this.mData.get(index).setStepHeight(stepHeight);
            this.mData.get(index).setPosition(index);
            //set buruburu
            int shakeCount = parseInteger(model.getWdBuruburu());
            int shakeHeight = (int) (((shakeCount / maxShakeCount)) * (height - 2 * barTxtHeight - 10));
            float leftY = 0;
            float rightY = 0;
            if (index < mData.size() - 2 && index > 1) {
                int preCount = parseInteger(mData.get(index - 1).getWdBuruburu());
                int nextCount = parseInteger(mData.get(index + 1).getWdBuruburu());
                rightY = (shakeCount + preCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
                leftY = (shakeCount + nextCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
            } else if (index == mData.size() - 2 && index > 1) {
                int preCount = parseInteger(mData.get(index - 1).getWdBuruburu());
                int currentCount = parseInteger(model.getWdBuruburu());
                rightY = (currentCount + preCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
            } else if (index == 1) {
                int nextCount = parseInteger(mData.get(index + 1).getWdBuruburu());
                leftY = (shakeCount + nextCount) / 2f / maxShakeCount * (height - 2 * barTxtHeight - 10);
            }
            this.mData.get(index).setShakeHeight(shakeHeight);
            this.mData.get(index).setLeftY(leftY);
            this.mData.get(index).setRightY(rightY);
        }
    }

    /**
     * @param model
     * @return
     * 计算柱状图的高度Value
     */
    private int getStepHeight(GraphInfoModel model) {
        int stepHeight = -1;
        if (null == model.getWdSteps()) {
            stepHeight = 0;
        } else {
            stepHeight = (int) (((model.getWdSteps() / maxStepCount)) * (height - 2 * barTxtHeight - 10));
        }
        return stepHeight;
    }


    public void updateLayoutParams(BarHolder holder, int height) {
        RelativeLayout.LayoutParams normalLp = new RelativeLayout.LayoutParams(holder.imageNormal.getLayoutParams());
        normalLp.width = (int) (barWidth);
        normalLp.height = height;
        normalLp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        normalLp.setMargins((int) (blankWidth / 2.0), 0, 0, 0);
        holder.imageNormal.setLayoutParams(normalLp);
        holder.imagePressed.setLayoutParams(normalLp);
        holder.imageUnSight.setLayoutParams(normalLp);
    }



    public void removeHolder(BarHolder holder) {
        Integer position = mMapHolderPosition.remove(holder);
        if (null != holder) {
            mMapPositionHolder.remove(position);
        }
    }

    private int parseInteger(Integer integer) {
        if (null == integer) {
            return 0;
        } else {
            return integer;
        }
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void setManager(LinearLayoutManager manager) {
        this.manager = manager;
    }

    public class BarHolder extends RecyclerView.ViewHolder {

        public ImageView imageNormal;
        public ImageView imageUnSight;
        public ImageView imagePressed;

        public TextView textWeek;
        public TextView textDay;
        public LinearLayout itemLayout;

        public LinePointView linePoint;

        public int position = -1;
        public int height = 0;

        public float leftY;
        public float rightY;

        public BarHolder(View itemView) {
            super(itemView);
            imageNormal = (ImageView) itemView.findViewById(R.id.id_img_normal);
            imagePressed = (ImageView) itemView.findViewById(R.id.id_img_pressed);
            imageUnSight = (ImageView) itemView.findViewById(R.id.id_img_unsight);
            textWeek = (TextView) itemView.findViewById(R.id.id_txt_week);
            textDay = (TextView) itemView.findViewById(R.id.id_txt_day);
            itemLayout = (LinearLayout) itemView.findViewById(R.id.id_item_layout);
            linePoint = (LinePointView) itemView.findViewById(R.id.id_line_point);
        }
    }


    /**
     * @param firstVisiblePosition
     * @param lastVisiblePosition
     *
     */
    public void setFirstCompleteVisiblePosition(int firstVisiblePosition, int lastVisiblePosition) {

        Log.d(LOG_TAG, "firstVisiblePosition: " + firstVisiblePosition);
        boolean firstChanged = false;
        boolean lastChanged = false;
        if (this.firstVisiblePosition != firstVisiblePosition) {
            firstChanged = true;
        }
        if (this.lastVisiblePosition != lastVisiblePosition) {
            lastChanged = true;
        }

        this.firstVisiblePosition = firstVisiblePosition;
        this.lastVisiblePosition = lastVisiblePosition;
        if (mode == SHAKE_MODE) {
            return;
        }
        if (lastVisiblePosition > firstVisiblePosition) {
            for (int i = firstVisiblePosition; i <= lastVisiblePosition; i++) {
                BarHolder holder = mMapPositionHolder.get(i);
                GraphInfoModel model = null;
                if (i < mData.size()) {
                    model = mData.get(i);
                }
                if (i != firstVisiblePosition && i != lastVisiblePosition) {
                    if (holder != null) {
                        holder.imageNormal.setAlpha(1f);
                        holder.imagePressed.setAlpha(0f);
                        holder.imageUnSight.setAlpha(0f);
                    }
                    if (null != model) {
                        model.setMode(NORMAL_STYLE);
                    }
                } else {
                    if (holder != null) {
                        holder.imageNormal.setAlpha(0f);
                        holder.imagePressed.setAlpha(0f);
                        holder.imageUnSight.setAlpha(1f);
                    }
                    if (null != model) {
                        model.setMode(UNSIGHT_STYLE);
                    }
                }
            }
//            GraphInfoModel graphInfoModelFirst = mData.get(firstVisiblePosition);
//            if (firstChanged) {
//                if (graphInfoModelFirst.getWdSteps() != null) {
//                    updateView(graphInfoModelFirst);
//                }
//            }
//            GraphInfoModel graphInfoModelLast = mData.get(lastVisiblePosition);
//            if (lastChanged) {
//                if (graphInfoModelLast.getWdSteps() != null) {
//                    updateView(graphInfoModelLast);
//                }
//            }

        }
    }


    /**
     * @param graphInfoModel
     * 刷新页面（柱状 线性）
     */
    public void updateView(GraphInfoModel graphInfoModel) {
        Log.e("huangc", "####   updateView #### ");
        int position = graphInfoModel.getPosition();
        final BarHolder holder = mMapPositionHolder.get(position);

        if (null == holder) {
            Log.e("huangc","####  if (null == holder)  return");
            return;
        }
        if (mode == STEP_MODE) {

//            if (holder.height == 0) {
//                //不带动画的效果
//                Log.e("huangc","------------------------------");
//            drawHeightView(graphInfoModel, holder);
//            } else {
                //带动画的效果
                Log.e("huangc","++++++++++++++++++++++++++++++");
                updateStepModeView(graphInfoModel, position, holder);
//            }

        } else {
            updateLineModeView(graphInfoModel, position, holder);
        }

    }

    /**
     * @param graphInfoModel
     * @param position
     * @param holder
     * 刷新线性视图页面
     */
    private void updateLineModeView(GraphInfoModel graphInfoModel, int position, BarHolder holder) {
        holder.imageNormal.setAlpha(0f);
        holder.imagePressed.setAlpha(0f);
        holder.imageUnSight.setAlpha(0f);
        holder.linePoint.setVisibility(View.VISIBLE);
        RelativeLayout.LayoutParams pointLp = new RelativeLayout.LayoutParams(holder.linePoint.getLayoutParams());
        pointLp.width = (int) (barWidth + blankWidth) + 1;
        pointLp.height = (int) (height - 2 * barTxtHeight - 10);
        holder.linePoint.setCountHeight(graphInfoModel.getShakeHeight());
        holder.linePoint.setEndY(graphInfoModel.getLeftY(), graphInfoModel.getRightY());
        if (1 == position) {
            holder.linePoint.setPointBitmap(R.drawable.line_point_pressed);
            holder.textWeek.setBackgroundResource(R.drawable.week_day_bg_pressed);
        } else {
            holder.linePoint.setPointBitmap(R.drawable.line_point_normal);
            holder.textWeek.setBackgroundResource(R.drawable.week_day_bg);
        }
        holder.linePoint.setLayoutParams(pointLp);
    }

    /**
     * @param graphInfoModel
     * @param holder
     * 绘制柱状图没有动画效果
     */
    private void drawHeightView(GraphInfoModel graphInfoModel, BarHolder holder) {
        holder.linePoint.setVisibility(View.GONE);
        RelativeLayout.LayoutParams normalLp = new RelativeLayout.LayoutParams(holder.imageNormal.getLayoutParams());
        normalLp.width = (int) (barWidth);
        normalLp.height = getStepHeight(graphInfoModel);
        normalLp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        normalLp.setMargins((int) (blankWidth / 2.0), 0, 0, 0);
        holder.imageNormal.setLayoutParams(normalLp);
        holder.imagePressed.setLayoutParams(normalLp);
        holder.imageUnSight.setLayoutParams(normalLp);
    }

    /**
     * @param graphInfoModel
     * @param position
     * @param holder
     * 刷新 柱状视图页面
     */
    private void updateStepModeView(GraphInfoModel graphInfoModel, int position, BarHolder holder) {
        Log.e("huangc","++++++++  updateStepModeView  +++++++");
        Log.e("huangc","++++++++  updateStepModeView   mData.get(position).getStepHeight() = "+ mData.get(position).getStepHeight());
        if (holder.height == graphInfoModel.getStepHeight() && holder.height !=0) {
            return;
        }
        if (-1 == mData.get(position).getStepHeight()) {
            Log.e("huangc", "+++++++++++++++");
            Log.e("huangc", "mData.get(position) date= " + mData.get(position).getSensedAt());
            holder.height = 0;
        }
        if (holder.height > 0) {
            int oldHeight = holder.height;
            float scaleYRate = 0.0f;
            if (graphInfoModel.getStepHeight() > 0) {
                scaleYRate = (float) oldHeight / graphInfoModel.getStepHeight();
                updateLayoutParams(holder, graphInfoModel.getStepHeight());
                ScaleAnimation scaleAnimation = new ScaleAnimation(1.0f, 1.0f, scaleYRate, 1f, Animation.RELATIVE_TO_SELF, 1f, Animation.RELATIVE_TO_SELF, 1f);
                scaleAnimation.setFillAfter(true);
                scaleAnimation.setDuration(500);
                if (position == firstVisiblePosition || position == lastVisiblePosition) {
                    holder.imageUnSight.startAnimation(scaleAnimation);
                } else {
                    holder.imageNormal.startAnimation(scaleAnimation);
                }
            } else {
                ScaleAnimation scaleAnimation = new ScaleAnimation(1.0f, 1.0f, 1f, 0f, Animation.RELATIVE_TO_SELF, 1f, Animation.RELATIVE_TO_SELF, 1f);
                scaleAnimation.setFillAfter(true);
                scaleAnimation.setDuration(500);
                scaleAnimation.setAnimationListener(new MyAnimationListener(holder, 0));
                if (position == firstVisiblePosition || position == lastVisiblePosition) {
                    holder.imageUnSight.startAnimation(scaleAnimation);
                } else {
                    holder.imageNormal.startAnimation(scaleAnimation);
                }
            }
            Log.d(LOG_TAG, "oldHeight: " + oldHeight + " newHeight: " + graphInfoModel.getStepHeight() + " scaleYRate: " + scaleYRate + " data" + graphInfoModel.getSensedAt());
        } else {
            updateLayoutParams(holder, graphInfoModel.getStepHeight());
            ScaleAnimation scaleAnimation = new ScaleAnimation(1.0f, 1.0f, 0f, 1f, Animation.RELATIVE_TO_SELF, 1f, Animation.RELATIVE_TO_SELF, 1f);
            scaleAnimation.setFillAfter(true);
            scaleAnimation.setDuration(500);
            if (position == firstVisiblePosition || position == lastVisiblePosition) {
                holder.imageUnSight.startAnimation(scaleAnimation);
            } else {
                holder.imageNormal.startAnimation(scaleAnimation);
            }
        }
        holder.height = graphInfoModel.getStepHeight();
    }

    public class MyAnimationListener implements Animation.AnimationListener {

        public int myHeight;
        public BarHolder myHolder;

        public MyAnimationListener(BarHolder holder, int height) {
            this.myHeight = height;
            this.myHolder = holder;
        }

        @Override
        public void onAnimationStart(Animation animation) {

        }

        @Override
        public void onAnimationEnd(Animation animation) {
            myHolder.linePoint.setVisibility(View.GONE);
            RelativeLayout.LayoutParams normalLp = new RelativeLayout.LayoutParams(myHolder.imageNormal.getLayoutParams());
            normalLp.width = (int) (barWidth);
            normalLp.height = myHeight;
            normalLp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            normalLp.setMargins((int) (blankWidth / 2.0), 0, 0, 0);
            myHolder.imageNormal.setLayoutParams(normalLp);
            myHolder.imagePressed.setLayoutParams(normalLp);
            myHolder.imageUnSight.setLayoutParams(normalLp);
        }

        @Override
        public void onAnimationRepeat(Animation animation) {

        }
    }
}
