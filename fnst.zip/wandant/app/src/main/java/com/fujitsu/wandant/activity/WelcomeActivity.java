//******************************************************************
//* わんダント2システム
//******************************************************************
/*
 *	わんダント2Android
 *	WelcomeActivity.java
 *
 *	変更日			変更者				障害No／仕様変更No
 *	16/01/19 		FNST)chenjie	    新規作成
 *
 */
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************

package com.fujitsu.wandant.activity;


import android.content.Intent;

import android.os.Bundle;

import android.view.View;

import butterknife.Bind;

import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;

/**
 * Created by chenjie.fnst on 2016/01/19.
 */
public class WelcomeActivity extends BaseActivity {

    /** sure button */
    @Bind(R.id.id_sure_btn)
    View sureBtn;

    /**
     * getTitleName
     * @return
     */
    @Override
    public String getTitleName() {
        return getResources().getString(R.string.register_finished_title);
    }

    /**
     * getTitleHeadUrl
     * @return
     */
    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    /**
     * onCreateView
     * @param savedInstanceState
     */
    @Override
    public void onCreateView(Bundle savedInstanceState) {
        isBackable = false;
        sureBtn.setOnClickListener(this);
        sureBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
    }

    /**
     * return layout of activity
     * @return
     */
    @Override
    public int getLayout() {
        return R.layout.activity_welcome;
    }

    /**
     * onclick event
     * @param v
     */
    @Override
    public void onClick(View v) {
        super.onClick(v);

        if (v.getId() == R.id.id_sure_btn) {
            Intent topIntent = new Intent();
            topIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            topIntent.setClass(this, MainActivity.class);
            startActivity(topIntent);
        }
    }
}
