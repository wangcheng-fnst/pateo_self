package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.WandantApplication;
import com.fujitsu.wandant.adapter.ListValueSelectAdapter;
import com.fujitsu.wandant.model.ValueEditModel;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.presenter.ValueEditPresenter;
import com.fujitsu.wandant.presenter.ValueEditViewInterface;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.TimeUtils;
import com.fujitsu.wandant.view.CheckView;
import com.fujitsu.wandant.view.ListViewNoScroll;
import com.fujitsu.wandant.view.datepicker.DatePickView;
import com.fujitsu.wandant.view.datepicker.OnWheelScrollListener;
import com.fujitsu.wandant.view.datepicker.WheelView;
import com.fujitsu.wandant.view.datepicker.adapter.NumericWheelAdapter;

import java.util.*;

/**
 * Created by chenjie.fnst on 2015/10/26.
 */
public class ValueEditActivity extends BaseActivity implements ValueEditViewInterface, AdapterView.OnItemClickListener, CheckView.OnCheckListener {


    public static final int SINGLE_TEXT_TYPE = 0;
    public static final int MULTI_TEXT_TYPE = 1;
    public static final int DATE_TYPE = 2;
    public static final int TWO_MONTH_TYPE = 3;
    public static final int SINGLE_SELECT_TYPE = 4;
    public static final int MULTI_SELECT_TYPE = 5;

    //text
    public static final int DOG_NAME = 4;
    public static final int DOG_MICROCHIP = 5;
    public static final int DOG_WATCH = 6;

    //date
    public static final int DOG_BIRTH = 7;
    public static final int DOG_ADOPT_DATE = 8;
    //two month
    public static final int DOG_FILARIAL_MONTH = 9;
    public static final int DOG_FLEA_MONTH = 10;
    //selecter
    public static final int DOG_GENDER = 11;
    public static final int DOG_LEG_SIZE = 25;
    public static final int DOG_COLOR = 12;
    public static final int DOG_INJECTION = 13;
    public static final int DOG_RABIS = 14;
    public static final int DOG_DIAG = 15;

    public static final int USER_EMAIL = 16;
    public static final int USER_NAME = 17;
    public static final int USER_PHONETIC = 18;
    public static final int USER_PHONE = 19;
    public static final int USER_TWITTER = 20;
    public static final int USER_BIRTHDAY = 21;

    public static final int USER_SEX = 22;
    public static final int USER_FAMILY = 23;
    public static final int USER_JOB = 24;
    private static final String LOG_TAG = ValueEditActivity.class.getName();


    private ValueEditModel model;
    private ValueEditPresenter presenter;

    @Bind(R.id.id_single_value_ll)
    View singleValueLayout;
    @Bind(R.id.id_single_value_et)
    EditText singleValueEt;
    @Bind(R.id.id_single_delete_iv)
    View singleDeleteView;
    @Bind(R.id.id_two_month_label)
    View towMonthLabel;
    @Bind(R.id.id_multi_value_ll)
    View twoValueLayout;

    @Bind(R.id.id_multi_value1_layout)
    View Value1Layout;
    @Bind(R.id.id_multi_value1_et)
    EditText multiValue1Et;
    @Bind(R.id.id_multi_value1_delete_iv)
    View multiDelete1View;

    @Bind(R.id.id_multi_value2_layout)
    View Value2Layout;
    @Bind(R.id.id_multi_value2_et)
    EditText multiValue2Et;
    @Bind(R.id.id_multi_value2_delete_iv)
    View multiDelete2View;

    @Bind(R.id.id_multi_value3_layout)
    View Value3Layout;
    @Bind(R.id.id_multi_value3_et)
    EditText multiValue3Et;
    @Bind(R.id.id_multi_value3_delete_iv)
    View multiDelete3View;


    @Bind(R.id.id_wheel_ll)
    View wheelLayout;
    @Bind(R.id.id_year_wv)
    WheelView yearWv;
    @Bind(R.id.id_month_mv)
    WheelView monthWv;
    @Bind(R.id.id_day_mv)
    WheelView dayWv;
    @Bind(R.id.id_dog_birth_unknown)
    CheckView dogBirthUnknownCv;

    @Bind(R.id.id_right_tv)
    TextView sureTv;

//    private int yearLength = 100;
    private int startYear = 1890;
    int curYear;
    int curMonth;
    int curDay;
    private NumericWheelAdapter monthAdapter;
    private NumericWheelAdapter dayAdapter;
    private DatePickView.ChooseListener listener;


    @Bind(R.id.id_select_lv)
    ListViewNoScroll listView;
    private ListValueSelectAdapter adapter;
    private List<ListValueSelectAdapter.ContentClass> selectedList = new ArrayList<>();

    @Override
    public void onCheckedChanged(boolean isChecked) {
        presenter.onDogBirthCheckedChanged(isChecked);
    }

//    @Bind(R.id.id_sure_btn)
//    Button btnSure;

    public class FocusListener implements View.OnFocusChangeListener{

        private View deleteView;

        public FocusListener(View view){
            deleteView = view;
        }

        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if (hasFocus){
                deleteView.setVisibility(View.VISIBLE);
            } else {
                deleteView.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        presenter.onItemClick(position,true);
    }


    @Override
    public String getTitleName() {
        return model.getTitle();
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        presenter = new ValueEditPresenter(this);
        Intent intent = getIntent();
        model = (ValueEditModel) intent.getSerializableExtra(Constants.EXTRA_VALUE);
        initListener();
        presenter.createView();
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_VALUE,presenter);
    }

    private void initListener() {
        singleValueEt.setOnFocusChangeListener(new FocusListener(singleDeleteView));
        singleDeleteView.setOnClickListener(this);

        multiValue1Et.setOnFocusChangeListener(new FocusListener(multiDelete1View));
        multiDelete1View.setOnClickListener(this);
        multiValue2Et.setOnFocusChangeListener(new FocusListener(multiDelete2View));
        multiDelete2View.setOnClickListener(this);
        multiDelete2View.setVisibility(View.GONE);
        multiValue3Et.setOnFocusChangeListener(new FocusListener(multiDelete3View));
        multiDelete3View.setOnClickListener(this);
        multiDelete3View.setVisibility(View.GONE);

        dogBirthUnknownCv.setOnCheckedChangedListener(this);
    }


    @Override
    public int getLayout() {
        return R.layout.activity_value_edit;
    }

    @Override
    public void setModel(ValueEditModel model) {
        this.model = model;
    }

    @Override
    public ValueEditModel getModel() {
        return model;
    }

    @Override
    public void setKey(List<Integer> key) {
        this.model.setKey(key);
    }

    @Override
    public void setValue(List<String> value) {
        this.model.setValue(value);
    }

    @Override
    public void createSingleTextView(){
        isShowRight = true;
        sureTv.setEnabled(false);
        singleValueLayout.setVisibility(View.VISIBLE);
        singleValueEt.setEnabled(true);
        twoValueLayout.setVisibility(View.GONE);
        wheelLayout.setVisibility(View.GONE);
        listView.setVisibility(View.GONE);
        towMonthLabel.setVisibility(View.GONE);
//        btnSure.setVisibility(View.VISIBLE);
        if (null != model.getValue() && !model.getValue().isEmpty()){
            singleValueEt.setText(model.getValue().get(0));
        } else {
            singleValueEt.setText("");
        }
        singleValueEt.setSelection(singleValueEt.length());
    }

    @Override
    public void createMultiTextView() {
        isShowRight = true;
        sureTv.setEnabled(false);
        singleValueLayout.setVisibility(View.GONE);
        twoValueLayout.setVisibility(View.VISIBLE);
        wheelLayout.setVisibility(View.GONE);
        listView.setVisibility(View.GONE);
        towMonthLabel.setVisibility(View.GONE);
//        btnSure.setVisibility(View.VISIBLE);
        if (null == model.getValue() || model.getValue().isEmpty()) {
            multiValue1Et.setText("");
            multiValue2Et.setText("");
        }

        if (model.getValue().size() == 1){
            Value1Layout.setVisibility(View.VISIBLE);
            Value2Layout.setVisibility(View.VISIBLE);
            Value3Layout.setVisibility(View.GONE);
            multiValue1Et.setText(model.getValue().get(0));
            multiValue2Et.setText("");
        } else if (model.getValue().size() == 2){
            Value1Layout.setVisibility(View.VISIBLE);
            Value2Layout.setVisibility(View.VISIBLE);
            Value3Layout.setVisibility(View.GONE);
            multiValue1Et.setText(model.getValue().get(0));
            multiValue2Et.setText(model.getValue().get(1));
        } else {
            Value1Layout.setVisibility(View.VISIBLE);
            Value2Layout.setVisibility(View.VISIBLE);
            Value3Layout.setVisibility(View.VISIBLE);
            multiValue1Et.setText(model.getValue().get(0));
            multiValue2Et.setText(model.getValue().get(1));
            multiValue3Et.setText(model.getValue().get(2));
        }
        multiValue1Et.setSelection(multiValue1Et.length());
    }

    private void refreshDayNum(int year, int month, int day) {
        int maxMonth;
        if (year == curYear){
            maxMonth = curMonth;
        } else {
            maxMonth = 12;
        }
        if (month > maxMonth){
            monthWv.setCurrentItem(maxMonth - 1);
            monthWv.invalidateWheel(true);
        }
        if (null == monthAdapter || monthAdapter.getItemsCount() != maxMonth) {
            monthAdapter = new NumericWheelAdapter(this, 1, maxMonth, "%d");
            monthAdapter.setLabel(getResources().getString(R.string.month));
            monthWv.setViewAdapter(monthAdapter);
        }
        int monthDay;
        if (year == curYear && maxMonth == curMonth){
            monthDay = curDay;
        } else {
            monthDay = TimeUtils.getDaysByYearMonth(year, month);
        }
        if (null == dayAdapter || dayAdapter.getItemsCount() != monthDay){
            dayAdapter = new NumericWheelAdapter(this,1, monthDay, "%d");
            dayAdapter.setLabel(getResources().getString(R.string.day));
            dayWv.setViewAdapter(dayAdapter);
        }
        if (day > monthDay){
            dayWv.setCurrentItem(monthDay - 1);
            dayWv.invalidateWheel(true);
        }

    }


    @Override
    public void createDateView(){
        isShowRight = true;
        sureTv.setEnabled(true);
        singleValueLayout.setVisibility(View.VISIBLE);
        singleValueEt.setEnabled(false);
        twoValueLayout.setVisibility(View.GONE);
        wheelLayout.setVisibility(View.VISIBLE);
        yearWv.setVisibility(View.VISIBLE);
        monthWv.setVisibility(View.VISIBLE);
        dayWv.setVisibility(View.VISIBLE);
        listView.setVisibility(View.GONE);
        towMonthLabel.setVisibility(View.GONE);
//        btnSure.setVisibility(View.VISIBLE);


        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = WandantApplication.getInstance().getWidth();
        getWindow().setAttributes(lp);

        Calendar c = Calendar.getInstance();
        curYear = c.get(Calendar.YEAR);
        curMonth = c.get(Calendar.MONTH) + 1;
        curDay = c.get(Calendar.DAY_OF_MONTH);

        yearWv.addScrollingListener(scrollListener);
        monthWv.addScrollingListener(scrollListener);
        dayWv.addScrollingListener(scrollListener);

        NumericWheelAdapter numericWheelAdapter1=new NumericWheelAdapter(this, startYear, curYear);
        numericWheelAdapter1.setLabel(getString(R.string.year));
        yearWv.setViewAdapter(numericWheelAdapter1);
        yearWv.setCyclic(false);

        monthAdapter = new NumericWheelAdapter(this,1, curMonth, "%d");
        monthAdapter.setLabel(getString(R.string.month));
        monthWv.setViewAdapter(monthAdapter);

        monthWv.setCyclic(false);

        dayWv.setCyclic(false);
        yearWv.setVisibleItems(7);
        monthWv.setVisibleItems(7);
        dayWv.setVisibleItems(7);

        // set default value
        if (null != model.getValue() && !model.getValue().isEmpty()){
            singleValueEt.setText(model.getValue().get(0));
            int[] array = TimeUtils.getArrayFromDateStr(model.getValue().get(0));
            if (null != array && 3 == array.length){
                refreshDayNum(array[0], array[1], array[2]);
                yearWv.setCurrentItem(array[0] - startYear);
                monthWv.setCurrentItem(array[1] - 1);
                dayWv.setCurrentItem(array[2] - 1);
                return;
            }
        } else {
            singleValueEt.setText("");
        }
        refreshDayNum(curYear, curMonth, curDay);
        yearWv.setCurrentItem(curYear - startYear);
        monthWv.setCurrentItem(curMonth - 1);
        dayWv.setCurrentItem(curDay - 1);
    }

    @Override
    public void createTwoMonthView(){
        isShowRight = true;
        sureTv.setEnabled(true);
        singleValueLayout.setVisibility(View.VISIBLE);
        singleValueEt.setEnabled(false);
        twoValueLayout.setVisibility(View.GONE);
        towMonthLabel.setVisibility(View.VISIBLE);
        wheelLayout.setVisibility(View.VISIBLE);
        yearWv.setVisibility(View.VISIBLE);
        monthWv.setVisibility(View.VISIBLE);
        dayWv.setVisibility(View.GONE);
        listView.setVisibility(View.GONE);

//        btnSure.setVisibility(View.VISIBLE);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = WandantApplication.getInstance().getWidth();
        getWindow().setAttributes(lp);
        yearWv.addScrollingListener(scrollListener);
        monthWv.addScrollingListener(scrollListener);

        NumericWheelAdapter numericWheelAdapter1=new NumericWheelAdapter(this,1, 12, "%d");
        numericWheelAdapter1.setLabel(getString(R.string.month));
        yearWv.setViewAdapter(numericWheelAdapter1);
        yearWv.setCyclic(false);

        NumericWheelAdapter numericWheelAdapter2=new NumericWheelAdapter(this,1, 12, "%d");
        numericWheelAdapter2.setLabel(getString(R.string.month));
        monthWv.setViewAdapter(numericWheelAdapter2);
        monthWv.setCyclic(false);

        dayWv.setCyclic(false);

        // set default value
        if (null != model.getValue() && !model.getValue().isEmpty()){
            singleValueEt.setText(model.getValue().get(0));
            int[] array = TimeUtils.getArrayFromTwoMonthStr(model.getValue().get(0));
            if (null != array && 2 == array.length){
                yearWv.setCurrentItem(array[0] - 1);
                monthWv.setCurrentItem(array[1] - 1);
                return;
            }
        } else {
            singleValueEt.setText("");
        }

    }

    @Override
    public void createSelectView() {
        singleValueLayout.setVisibility(View.GONE);
        twoValueLayout.setVisibility(View.GONE);
        wheelLayout.setVisibility(View.GONE);
        listView.setVisibility(View.VISIBLE);
        towMonthLabel.setVisibility(View.GONE);
//        btnSure.setVisibility(View.GONE);
        if (null != model.getMap()){
            for (Map.Entry entry:model.getMap().entrySet()){
                ListValueSelectAdapter.ContentClass content = new ListValueSelectAdapter.ContentClass();
                content.key = (Integer) entry.getKey();
                content.value = (Integer) entry.getValue();
                content.isSelected = (null != model.getKey() && model.getKey().contains(content.key));
                selectedList.add(content);
            }
            adapter = new ListValueSelectAdapter(this,selectedList);
            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(this);
    }

    @Override
    public void setEditTextValue(String value) {
        singleValueEt.setText(value);
    }

    @Override
    public String getSingleTextValue() {
        return singleValueEt.getText().toString();
    }

    @Override
    public List<String> getMultiTextValue() {
        List<String> list = new ArrayList<>();
        if (Value1Layout.getVisibility() == View.VISIBLE){
            list.add(multiValue1Et.getText().toString());
        }
        if (Value2Layout.getVisibility() == View.VISIBLE){
            list.add(multiValue2Et.getText().toString());
        }
        if (Value3Layout.getVisibility() == View.VISIBLE){
            list.add(multiValue3Et.getText().toString());
        }
        return list;
    }

    @Override
    public Date getDateValue() {
        int nor_year = yearWv.getCurrentItem() + startYear;
        int nor_month = monthWv.getCurrentItem() + 1;
        int nor_day = dayWv.getCurrentItem() + 1;
        String dateStr = TimeUtils.format(nor_year, nor_month, nor_day);
        return TimeUtils.parseWithYearMonthDay(dateStr);
    }

    @Override
    public int[] getTwoMonthValue() {
        int[] array = new int[2];
        int nor_year = yearWv.getCurrentItem() + 1;
        int nor_month = monthWv.getCurrentItem() + 1;
        array[0] = nor_year;
        array[1] = nor_month;
        return array;
    }

    @Override
    public void setEditTextEditable(boolean isEnable) {
        singleValueEt.setEnabled(isEnable);
    }

    @Override
    public void setSuccess(boolean isSuccess) {
        model.setIsConnectNetSuccess(isSuccess);
    }

    @Override
    public void showProcessDialog() {
        showWaitingDialog();
    }

    @Override
    public void hideProcessDialog() {
        hideWaitingDialog();
    }

    @Override
    public void finishActivity() {
        Intent intent = new Intent();
        intent.putExtra(Constants.EXTRA_VALUE,model);
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public List<ListValueSelectAdapter.ContentClass> getSelectList() {
        return selectedList;
    }

    @Override
    public ListValueSelectAdapter getAdapter() {
        return adapter;
    }

    @Override
    public View getSureButton() {
        return this.sureTv;
    }

    @Override
    public void setTextWatcher(ValueEditPresenter.InputTextWatch textWatch) {
        singleValueEt.addTextChangedListener(textWatch);
        multiValue1Et.addTextChangedListener(textWatch);
        multiValue2Et.addTextChangedListener(textWatch);
        multiValue3Et.addTextChangedListener(textWatch);
    }

    @Override
    public void setEditTextInputType(int typeClassNumber) {
        singleValueEt.setInputType(typeClassNumber);
        multiValue1Et.setInputType(typeClassNumber);
        multiValue2Et.setInputType(typeClassNumber);
        multiValue3Et.setInputType(typeClassNumber);
    }

    @Override
    public void setSureButtonVisible(boolean isVisible) {
        isShowRight = isVisible;
    }

    @Override
    public void setMaxLength(int length) {
        InputFilter[] filter = new InputFilter[] {
            new InputFilter.LengthFilter(length)
        };
        singleValueEt.setFilters(filter);
        multiValue1Et.setFilters(filter);
        multiValue2Et.setFilters(filter);
        multiValue3Et.setFilters(filter);
    }

    @Override
    public void setMinDate(int year, int month, int day) {
        startYear = year;
    }

    @Override
    public void showDogAgeUnknownView(boolean isSelected) {
        dogBirthUnknownCv.setVisibility(View.VISIBLE);
        dogBirthUnknownCv.setChecked(isSelected);
    }

//    @Override
//    public void setDogBirthUnknowChecked(boolean isChecked) {
//
//    }

    OnWheelScrollListener scrollListener = new OnWheelScrollListener() {
        @Override
        public void onScrollingStarted(WheelView wheel) {

        }

        @Override
        public void onScrollingFinished(WheelView wheel) {
            if (yearWv != null) {
                if (model.getShowType() == DATE_TYPE){
                    int nor_year = yearWv.getCurrentItem() + startYear;
                    int nor_month = monthWv.getCurrentItem() + 1;
                    int nor_day = dayWv.getCurrentItem() + 1;
                    refreshDayNum(nor_year, nor_month, nor_day);
                    if (getListener() != null) {
                        getListener().setDate(nor_year, nor_month, nor_day);
                    }
                }
                presenter.updateUIValue();
            }
        }
    };

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_single_delete_iv:
                singleValueEt.setText("");
                presenter.clearValue();
                break;
            case R.id.id_multi_value1_delete_iv:
                multiValue1Et.setText("");
                break;
            case R.id.id_multi_value2_delete_iv:
                multiValue2Et.setText("");
                break;
            case R.id.id_multi_value3_delete_iv:
                multiValue3Et.setText("");
                break;
            case R.id.id_right_tv:
                presenter.onSureButtonClicked(true);
                break;
            default:
                break;
        }
    }

    public DatePickView.ChooseListener getListener() {
        return listener;
    }

    @Override
    protected void onDestroy() {
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_VALUE);
        super.onDestroy();
    }
}
