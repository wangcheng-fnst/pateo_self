package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.net.*;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ToastManager;

/**
 * Created by chenjie.fnst on 2015/10/30.
 */
public class UserWithdrawalActivity extends BaseActivity {

    @Bind(R.id.id_yes_btn)
    Button yesBtn;
    @Bind(R.id.id_no_btn)
    Button noBtn;

    @Override
    public String getTitleName() {
        return getResources().getString(R.string.user_withdrawal_title);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        bindViews();
    }

    private void bindViews() {
        ButtonOnTouchListener listener = new ButtonOnTouchListener(this,R.drawable.btn_sure_pressed,R.drawable.btn_sure);
        yesBtn.setOnTouchListener(listener);
        noBtn.setOnTouchListener(listener);
        yesBtn.setOnClickListener(this);
        noBtn.setOnClickListener(this);
    }

    @Override
    public int getLayout() {
        return R.layout.activity_user_withdrawal;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_yes_btn:
                //1.call the interface of server
                AccountService.getInstance().withdrawal(new NetCallback<Void>() {
                    @Override
                    public void success(Void responseData) {

                    }

                    @Override
                    public void failure(String errorCode, String errorMsg) {
                        showErrorMessage(errorCode);
                    }

                    @Override
                    public void internalFailure(String errorMsg) {
                        ToastManager.getInstance().showFail(errorMsg);
//                        Toast.makeText(WandantApplication.getInstance().getApplicationContext(), errorMsg, Toast.LENGTH_SHORT).show();
                    }
                });
                //4. clear all the date in the phone
                DogDeviceStationRepository.getInstance().deleteAllDogsFromDb();
                DogDeviceStationRepository.getInstance().deleteAllDeviceFromDb();
                DogDeviceStationRepository.getInstance().deleteAllStationsFromDb();
                MutterRepository.getInstance().deleteAllMuttersFromMutterAllDb();
                MutterRepository.getInstance().deleteAllMuttersFromMutterDb();
                StatusRepository.getInstance().deleteAllDeviceFirmDetailsFromDb();
                UserUtils.getInstance().logout();
                // todo 3. go to login activity
                Intent intent = new Intent();
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.setClass(this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;
            case R.id.id_no_btn:
                finish();
                break;
        }
    }
}
