package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.adapter.EmailListAdapter;
import com.fujitsu.wandant.net.EmailRepository;
import com.fujitsu.wandant.net.model.UserAlertMail;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ListViewInScrollView;
import com.fujitsu.wandant.view.PopViewHelper;
import com.fujitsu.wandant.view.ToastManager;
import com.kyleduo.switchbutton.SwitchButton;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/10/20.
 */
public class EmailListActivity extends BaseActivity implements View.OnLongClickListener,OnModelFinishedListener {

    public static final int MAX_EMAIL_SIZE = 3;
    private String LOG_TAG = EmailListActivity.class.getName();

    @Bind(R.id.id_email_list)
    ListViewInScrollView listView;
    @Bind(R.id.id_add_layout)
    LinearLayout addLayout;
    @Bind(R.id.id_email_layer)
    View layer;

    private EmailListAdapter adapter;
    private List<UserAlertMail> items = new ArrayList<UserAlertMail>();

    public final static int ADD_EMAIL_REQUEST = 0;
    public final static int EDIT_EMAIL_REQUEST = 1;

    private int currentPosition ;

    @Override
    public String getTitleName() {
        return getResources().getString(R.string.mail);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        EmailRepository.getInstance().register(this, EmailRepository.REQUEST_TYPE_FROM_EMAIL_LIST);
        createData();
        addLayout.setOnClickListener(this);
    }
    private void loadData(){
        if (adapter != null) {
            adapter.setmData(items);
            adapter.notifyDataSetChanged();
        }else{
            adapter = new EmailListAdapter(items,this);
            adapter.setmListener(this);
            listView.setAdapter(adapter);
        }
        if (items.size() >= MAX_EMAIL_SIZE){
            addLayout.setVisibility(View.GONE);
        }else{
            addLayout.setVisibility(View.VISIBLE);
        }
    }
    private void createData(){
        EmailRepository.getInstance().loadInDb();
        EmailRepository.getInstance().getAllEmails();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_add_layout:
                addEmail();
                break;
            case R.id.id_email_layout:
                int position = (int) v.getTag(R.id.position);
                if (position < items.size() && items.get(position).getVerification_status() == UserAlertMail.EMAIL_ENABLE){
                    modifyEmail(v);
                } else {
                    ToastManager.getInstance().showFail(getResources().getString(R.string.email_edit_disable_info));
                }
                break;
            case R.id.id_email_switch:
                changeEmailStatus((SwitchButton)v);
                break;
            case R.id.id_pop_sure_txt:
                PopViewHelper.getInstance().dismissPop();
                showWaitingDialog();
                EmailRepository.getInstance().remove(items.get(currentPosition));
                break;
            case R.id.id_pop_cancel_txt:
                PopViewHelper.getInstance().dismissPop();
                break;
        }
    }

    private void modifyEmail(View v) {
        int position = (Integer) v.getTag(R.id.position);
        currentPosition = position;
        Intent intent = new Intent();
        intent.putExtra(Constants.EXTRA_EMAIL_MODE,false);
        intent.putExtra(Constants.EXTRA_VALUE, items.get(position));
        intent.setClass(this, EmailAddActivity.class);
        startActivityForResult(intent, EDIT_EMAIL_REQUEST);
    }

    private void changeEmailStatus(SwitchButton switchButton) {
        int position = (Integer) switchButton.getTag(R.id.position);
        showWaitingDialog();
        int allowFlg = UserAlertMail.EMAIL_DISABLE;
        currentPosition = position;
        if (switchButton.isChecked()){
            allowFlg = UserAlertMail.EMAIL_ENABLE;
        }else {
            allowFlg = UserAlertMail.EMAIL_DISABLE;
        }
        EmailRepository.getInstance().changePermission(switchButton, items.get(currentPosition),allowFlg);
    }

    public void addEmail(){
        Intent intent = new Intent();
        intent.putExtra(Constants.EXTRA_EMAIL_MODE,true);
        intent.setClass(this, EmailAddActivity.class);
        startActivityForResult(intent, ADD_EMAIL_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK){
            return;
        }
        switch (requestCode){
            case ADD_EMAIL_REQUEST:
                UserAlertMail newMail = (UserAlertMail)data.getSerializableExtra(Constants.EXTRA_EMAIL_INFO);
                newMail.setVerification_status(UserAlertMail.EMAIL_NOT_VERIFIED);
                newMail.setEnabled(UserAlertMail.EMAIL_ENABLE);
                newMail.setUser_id(UserUtils.getInstance().loadUser().getUser_id());
                items.add(newMail);
                loadData();
                break;
            case EDIT_EMAIL_REQUEST:
                String editEmail = data.getStringExtra(Constants.EXTRA_VALUE);
                ((UserAlertMail)adapter.getItem(currentPosition)).setAlert_mail(editEmail);
                ((UserAlertMail)adapter.getItem(currentPosition)).setVerification_status(UserAlertMail.EMAIL_NOT_VERIFIED);
                ((UserAlertMail)adapter.getItem(currentPosition)).setEnabled(UserAlertMail.EMAIL_ENABLE);
                loadData();
                break;
            default:
                break;
        }
    }

    @Override
    public int getLayout() {
        return R.layout.email_list;
    }

    @Override
    public boolean onLongClick(View v) {
        int position = (Integer) v.getTag(R.id.position);
        currentPosition = position;
        PopViewHelper.getInstance().showDeletePop(this, layer, getResources().getString(R.string.email_delete_title));
        return true;
    }




    @Override
    public void success(Object result, int type) {
        hideWaitingDialog();
        if (type == EmailRepository.GET_MODE){
            List<UserAlertMail> data = (List<UserAlertMail>) result;
            items.clear();
            items = data;
            loadData();
        }else if (type == EmailRepository.REMOVE_MODE){
            for (UserAlertMail mail : items){
                if (result.equals(Integer.valueOf(mail.getUser_alert_mail_id()))){
                    items.remove(mail);
                    loadData();
                    break;
                }
            }
        }else if (type == EmailRepository.PERMISSION_MODE){
            if (null != items && currentPosition < items.size() && null != result){
                items.get(currentPosition).setEnabled((Integer) result);
            }
            ((UserAlertMail)adapter.getItem(currentPosition)).setEnabled((Integer) result);
        }else if (type == EmailRepository.LOAD_FROM_DATABASE_MODE){
            List<UserAlertMail> data = (List<UserAlertMail>) result;
            items = data;
            loadData();
        }

    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
        hideWaitingDialog();
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
        hideWaitingDialog();
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        EmailRepository.getInstance().unregister(EmailRepository.REQUEST_TYPE_FROM_EMAIL_LIST);
        PopViewHelper.getInstance().dismissPop();
        super.onDestroy();
    }




}
