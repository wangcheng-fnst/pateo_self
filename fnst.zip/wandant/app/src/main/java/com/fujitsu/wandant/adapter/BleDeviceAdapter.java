package com.fujitsu.wandant.adapter;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.utils.Constants;

import java.util.List;

/**
 * Created by chenjie.fnst on 2015/10/12.
 */
public class BleDeviceAdapter extends BaseAdapter {

    private Context context;
    private List<BluetoothDevice> deviceList;
    private int selectPosition = Constants.NUMBER_INVALID;

    public BleDeviceAdapter(Context context,List<BluetoothDevice> list){
        this.context = context;
        this.deviceList = list;
    }

    @Override
    public int getCount() {
        return deviceList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void setSelectPosition(int selectPosition) {
        this.selectPosition = selectPosition;
        notifyDataSetChanged();
    }

    public int getSelectPosition() {
        return selectPosition;
    }

    class ViewHolder{
        public TextView tvBleName;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (null == convertView){
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.listview_ble_item,parent,false);
            viewHolder.tvBleName = (TextView) convertView.findViewById(R.id.tvBleName);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        if (position == selectPosition) {
            if (position == 0){
                convertView.setBackground(context.getResources().getDrawable(R.drawable.table_top_pressed_bg));
            } else {
                convertView.setBackground(context.getResources().getDrawable(R.drawable.table_middle_pressed_bg));
            }
        } else {
            convertView.setBackgroundColor(context.getResources().getColor(R.color.transparent));
        }

        viewHolder.tvBleName.setText(deviceList.get(position).getName()+" " + deviceList.get(position).getAddress());
        return convertView;
    }
}
