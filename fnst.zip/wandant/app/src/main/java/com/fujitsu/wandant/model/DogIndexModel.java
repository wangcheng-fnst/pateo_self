package com.fujitsu.wandant.model;

import java.util.List;

/**
 * Created by chenjie.fnst on 2015/10/27.
 */
public class DogIndexModel extends BaseModel {

    private String category;
    private List<DogTypeModel> data;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public List<DogTypeModel> getData() {
        return data;
    }

    public void setData(List<DogTypeModel> data) {
        this.data = data;
    }

}
