package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.activity.EmailListActivity;
import com.fujitsu.wandant.net.model.UserAlertMail;
import com.kyleduo.switchbutton.SwitchButton;
import me.grantland.widget.AutofitTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/10/20.
 */
public class EmailListAdapter extends BaseAdapter{

    private List<UserAlertMail> mData = new ArrayList<UserAlertMail>();
    private Context mContext;
    private View.OnClickListener mListener = null;

    public EmailListAdapter(List<UserAlertMail> mData, Context mContext) {
        this.mData = mData;
        this.mContext = mContext;
    }

    public void setmData(List<UserAlertMail> mData) {
        this.mData = mData;
        notifyDataSetChanged();
    }

    public void setmListener(View.OnClickListener listener){
        mListener = listener;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        EmailHolder holder = null;
        if (convertView == null){
            holder = new EmailHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.email_list_item,parent,false);
            holder.layout = (LinearLayout) convertView.findViewById(R.id.id_email_layout);
            holder.emailTxt = (AutofitTextView) convertView.findViewById(R.id.id_email_txt);
            holder.emailSwitch = (SwitchButton) convertView.findViewById(R.id.id_email_switch);
            holder.line = convertView.findViewById(R.id.email_line);
        }else{
            holder = (EmailHolder) convertView.getTag();
        }
        UserAlertMail item = mData.get(position);
        holder.emailTxt.setText(item.getAlert_mail());
        if (item.getEnabled() == UserAlertMail.EMAIL_ENABLE){
            holder.emailSwitch.setChecked(true);
        }else{
            holder.emailSwitch.setChecked(false);
        }
        if (item.getVerification_status() == UserAlertMail.EMAIL_VERIFIED){
            holder.emailSwitch.setAlpha(1f);
            holder.emailSwitch.setEnabled(true);
        } else {
            holder.emailSwitch.setAlpha(0.4f);
            holder.emailSwitch.setEnabled(false);
        }
        if (position == 2){
            holder.line.setVisibility(View.GONE);
        }else{
            holder.line.setVisibility(View.VISIBLE);
        }
        if (position == 0){
            holder.layout.setBackgroundResource(R.drawable.info_item_top_bg);
        }else if ((EmailListActivity.MAX_EMAIL_SIZE - 1 ) == position){
            holder.layout.setBackgroundResource(R.drawable.info_item_bottom_bg);
        } else {
            holder.layout.setBackgroundResource(R.drawable.info_item_middle_bg);
        }
        holder.layout.setTag(R.id.position,position);
        holder.emailSwitch.setTag(R.id.position,position);

        holder.emailSwitch.setOnClickListener(mListener);
        holder.layout.setOnClickListener(mListener);
        holder.layout.setOnLongClickListener((View.OnLongClickListener) mListener);
        convertView.setTag(holder);
        return convertView;
    }


    private class EmailHolder{
        public AutofitTextView emailTxt;
        public SwitchButton emailSwitch;
        public View line;
        public LinearLayout layout;
    }
}
