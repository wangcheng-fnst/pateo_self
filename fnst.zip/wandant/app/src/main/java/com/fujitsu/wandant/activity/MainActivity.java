package com.fujitsu.wandant.activity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.adapter.MainMsgAdapter;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.listener.ImageOnTouchListener;
import com.fujitsu.wandant.model.MutterModel;
import com.fujitsu.wandant.net.model.DeviceStatus;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.net.model.HappyData;
import com.fujitsu.wandant.net.model.StationStatus;
import com.fujitsu.wandant.presenter.MainPresenter;
import com.fujitsu.wandant.presenter.MainViewInterface;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.TimeUtils;
import com.fujitsu.wandant.view.CircleImageView;
import com.fujitsu.wandant.view.ToastManager;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ym-zhongxy on 2015/9/20.
 */
public class MainActivity extends NewBaseActivity implements View.OnClickListener,MainViewInterface, ImageOnTouchListener.OnTopTouchListener {

    private static final String LOG_TAG = MainActivity.class.getName();
    private static final int REQUEST_OPEN_BLUETOOTH = 1;
    @Bind(R.id.id_background_iv)
    ImageView stationIv;
    @Bind(R.id.id_menu_btn)
    View btnMenu;
    @Bind(R.id.id_title_tv)
    TextView tvTitle;
    @Bind(R.id.id_index_ll)
    LinearLayout llIndex;
    @Bind(R.id.id_loading_iv)
    ImageView loadingIv;
    @Bind(R.id.id_chart_btn)
    LinearLayout chartBtn;
    @Bind(R.id.ivHeadIcon)
    CircleImageView headIconIv;

    @Bind(R.id.id_device_temp)
    TextView deviceTempTv;
    @Bind(R.id.id_device_temp_unit)
    TextView deviceTempUnitTv;
    @Bind(R.id.id_device_humi_tv)
    TextView deviceHumiTv;
    @Bind(R.id.id_device_humi_unit_tv)
    TextView deviceHumiUnitTv;
    @Bind(R.id.id_battery_iv)
    ImageView deviceBatteryIv;

    @Bind(R.id.id_station_temp_tv)
    TextView stationTempTv;
    @Bind(R.id.id_station_temp_unit)
    TextView stationTempUnitTv;
    @Bind(R.id.id_station_humi_tv)
    TextView stationHumiTv;
    @Bind(R.id.id_station_humi_unit)
    TextView stationHumiUnitTv;
    @Bind(R.id.update_date_tv)
    TextView stationUpdateTv;

    @Bind(R.id.id_refresh_btn)
    Button refreshBtn;
    @Bind(R.id.viewPager)
    ViewPager viewPager;
    @Bind(R.id.id_town_btn)
    View townBtn;
    @Bind(R.id.drawer_layout)
    DrawerLayout drawerLayout;
    @Bind(R.id.id_menu_update_flag_iv)
    View menuUpdateView;
    @Bind(R.id.id_setting_update_flag_iv)
    View settingUpdateView;

    @Bind(R.id.id_heart_ll)
    View heartView;
    @Bind(R.id.id_happy_degree_tv)
    TextView happyTv;

    //Add by huangc
    //[1]
    @Bind(R.id.id_instruction_tv)
    TextView instructionTv;
    //[2]
    @Bind(R.id.id_question_most_tv)
    TextView questionMoreTv;
    //[3]
    @Bind(R.id.id_rule_tv)
    TextView ruleTv;
    //[4]
    @Bind(R.id.id_privacy_tv)
    TextView privacyTv;


    //[Version]
    @Bind(R.id.id_application_tv)
    TextView appVersionTv;

    private List<ImageView> indexViews;
    private Map<Integer,List<MutterModel>> mDogIdMuttersMap;
    private MainMsgAdapter adapter;

    private List<Dog> dogList;

    private MainPresenter presenter;
    private List<DeviceStatus> deviceStatuses;
    private List<StationStatus> stationStatuses;
    private Handler handler = new Handler();

    public static boolean refreshable = true;
    private AnimationDrawable animationDrawable = null;
    private String hyphen = null;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        initVersionInfo();
        hyphen = getResources().getString(R.string.hyphen);
        mDogIdMuttersMap = new LinkedHashMap<>();
        deviceStatuses = new ArrayList<>();
        stationStatuses = new ArrayList<>();
        dogList = new ArrayList<>();
        presenter = new MainPresenter(this,mDogIdMuttersMap,deviceStatuses,stationStatuses,handler,dogList);
        presenter.onCreate();
    }

    private void initVersionInfo() {
        String str = appVersionTv.getText().toString();
        appVersionTv.setText(str + "               " + ApplicationUtils.getPackageVersionName());
    }


    @Override
    protected void onResume() {
        super.onResume();
        presenter.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.onPause();
    }

    /**
     * init view
     */
    @Override
    public void bindViews() {
        headIconIv.setOnClickListener(this);
        stationIv.setOnTouchListener(new ImageOnTouchListener(this));
        btnMenu.setOnClickListener(this);
        chartBtn.setOnClickListener(this);
        townBtn.setOnClickListener(this);
        indexViews = new ArrayList<>();
        refreshBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_refresh_pressed, R.drawable.button_refresh));
        refreshBtn.setOnClickListener(this);
        refreshable = true;
//        findViewById(R.id.id_back_ll).setOnClickListener(this);
        findViewById(R.id.id_setting_tv).setOnClickListener(this);
        findViewById(R.id.id_instruction_tv).setOnClickListener(this);
        findViewById(R.id.id_question_most_tv).setOnClickListener(this);
        findViewById(R.id.id_rule_tv).setOnClickListener(this);
        findViewById(R.id.id_all_mutter_btn).setOnClickListener(this);
        findViewById(R.id.id_privacy_tv).setOnClickListener(this);
        //Version
        findViewById(R.id.id_application_tv).setOnClickListener(this);
    }

    /**
     * init data
     */
    @Override
    public void initData(){
        adapter = new MainMsgAdapter(this, mDogIdMuttersMap);
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(0);
        viewPager.addOnPageChangeListener(onPageChangeListener);
//        String fileUrl = "http://pic20.nipic.com/20120421/9553120_230501531156_2.jpg";
        loadStationImage();
    }

    @Override
    public ImageView getStationImageView() {
        return stationIv;
    }

    @Override
    public void setFirmNeedUpdate(boolean isFirmNeedUpdate) {
        if (isFirmNeedUpdate){
            menuUpdateView.setVisibility(View.VISIBLE);
            settingUpdateView.setVisibility(View.VISIBLE);
        } else {
            menuUpdateView.setVisibility(View.GONE);
            settingUpdateView.setVisibility(View.GONE);
        }
    }

    @Override
    public void setRefreshStatus() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (refreshable) {
                    refreshBtn.setText(getResources().getString(R.string.main_refresh));
                    refreshBtn.setAlpha(1);
                    refreshBtn.setEnabled(true);
                    if (null != animationDrawable && animationDrawable.isRunning()) {
                        animationDrawable.stop();
                    }
                    loadingIv.setVisibility(View.GONE);
                } else {
                    refreshBtn.setText(getResources().getString(R.string.main_data_reading));
                    animationDrawable = (AnimationDrawable) loadingIv.getBackground();
                    refreshBtn.setAlpha(0.4f);
                    refreshBtn.setEnabled(false);
                    if (!animationDrawable.isRunning()) {
                        animationDrawable.start();
                    }
                    loadingIv.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    /**
     * init dot image
     */
    @Override
    public void initIndexView(int count) {
        indexViews.clear();
        llIndex.removeAllViews();
        int size = (int) ApplicationUtils.dp2px(this,6);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
        lp.setMargins(size, 0, 0, 0);
        for (int i = 0; i < count && count > 1; i++) {
            ImageView index = new ImageView(this);
            index.setLayoutParams(lp);
            index.setImageResource(R.drawable.gray_dot);
            indexViews.add(index);
            llIndex.addView(index);
        }

        if (!indexViews.isEmpty()) {
            indexViews.get(0).setImageResource(R.drawable.white_dot);
        }
    }

    /**
     * change image dot
     *
     * @param page
     */
    private void changeIndex(int page) {
        for (int i = 0; i < indexViews.size(); i++) {
            ImageView index = indexViews.get(i);
            if (i != page) {
                index.setImageResource(R.drawable.gray_dot);
            } else {
                index.setImageResource(R.drawable.white_dot);
            }

        }
    }


    @Override
    public void setName(String name) {
        tvTitle.setText(name);
    }

    @Override
    public void showHeadUrl(String url) {
        ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconUrl(url), headIconIv);
    }

    @Override
    public void loadMutter() {

    }

    @Override
    public void updateHappy(HappyData happyData) {
        //todo show happy
        if (null == happyData || null == happyData.getHappy_index()){
            happyTv.setText(getResources().getString(R.string.hyphen));
            heartView.setBackground(getResources().getDrawable(R.drawable.happy_1));
            return;
        }
        Integer happyDegree = happyData.getHappy_index();
        heartView.setBackground(ApplicationUtils.getDrawableForHappy(happyDegree));
        happyTv.setText(String.valueOf(happyDegree));
    }


    @Override
    public void updateStatus(DeviceStatus deviceStatus,StationStatus stationStatus){
        if (null != deviceStatus){
            float deviceTemp = deviceStatus.getWdtemp();
            deviceTempTv.setText((deviceTemp < 0 ? hyphen : (deviceTemp + "")));
            float deviceHumi = deviceStatus.getWdhumid();
            deviceHumiTv.setText((deviceHumi < 0 ? hyphen : (deviceHumi + "")));
            deviceBatteryIv.setImageDrawable(ApplicationUtils.getDrawableForBattery(deviceStatus.getBattery()));
        } else {
            deviceTempTv.setText(hyphen);
            deviceHumiTv.setText(hyphen);
            deviceBatteryIv.setImageDrawable(getResources().getDrawable(R.drawable.battery_1));
        }
        if(null != stationStatus){
            float stationTemp = stationStatus.getTemp();
            stationTempTv.setText((stationTemp < 0 ? hyphen : (stationTemp + "")));
            float stationHumi = stationStatus.getHumid();
            stationHumiTv.setText((stationHumi < 0 ? hyphen : (stationHumi + "")));
            stationUpdateTv.setText(TimeUtils.formatDate(stationStatus.getSensedtimestamp(),"yyyy/M/d HH:mm"));
        } else {
            stationTempTv.setText(hyphen);
            stationHumiTv.setText(hyphen);
            stationUpdateTv.setText(hyphen);
        }

    }

    @Override
    public void changeDog() {

    }
    @Override
    public void updateMutters(Map<Integer, List<MutterModel>> dogIdMuttersMap){
        adapter.update(dogIdMuttersMap);
    }
    @Override
    public void goToOtherActivity(Intent intent,Class cls){
        intent.setClass(this, cls);
        intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG, Constants.ACTIVITY_FROM_MAIN);
        startActivity(intent);
    }

    /**
     * ViewPager滑动切换监听器
     */
    private ViewPager.OnPageChangeListener onPageChangeListener = new ViewPager.OnPageChangeListener(){

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        @Override
        public void onPageSelected(int position) {
            showDogInfoByIndex(position);
        }

        @Override
        public void onPageScrollStateChanged(int state) {
        }
    };

    private void showDogInfoByIndex(int position) {
        if (null != dogList && position < dogList.size()){
            presenter.setCurrentPageIndex(position);
            changeIndex(position);
            presenter.changeDogData(dogList.get(position));
            presenter.refreshDataWhenPageChanged(position);
        }

    }


    public void onClick(View v) {
        super.onClick(v);
//        if (ApplicationUtils.isFastClick()){
//            return;
//        }
        Intent intent = new Intent();
        switch (v.getId()){
            case R.id.id_refresh_btn:
                if (null != adapter){
                    adapter.hideLoadView();
                }
                presenter.onFreshButtonClicked();
                break;
            case R.id.id_chart_btn:
                int currentPage = presenter.getCurrentPageIndex();
                if (null == dogList || dogList.isEmpty() || dogList.size() < currentPage + 1){
                    return;
                }
                intent.putExtra(Constants.EXTRA_DOG,dogList.get(currentPage));
                intent.setClass(this, GraphActivity.class);
                startActivity(intent);
                break;
            case R.id.id_menu_btn:
                drawerLayout.openDrawer(Gravity.LEFT);
                break;
//            case R.id.id_back_ll:
//                drawerLayout.closeDrawer(Gravity.LEFT);
//                break;
            case R.id.id_setting_tv:
                intent.setClass(this, SettingActivity.class);
                startActivity(intent);
                drawerLayout.closeDrawer(Gravity.LEFT);
                break;

            //TODO わんダント2の使い方
            case R.id.id_instruction_tv:
                go2WebView(instructionTv.getText().toString(), Constants.URL_4_INSTRUCTION);
                drawerLayout.closeDrawer(Gravity.LEFT);
                break;
            //TODO よくある質問
            case R.id.id_question_most_tv:
                go2WebView(questionMoreTv.getText().toString(), Constants.URL_4_QUESTION_MOST);
                drawerLayout.closeDrawer(Gravity.LEFT);
                break;
            //TODO 利用規約
            case R.id.id_rule_tv:
                go2WebView(ruleTv.getText().toString(), Constants.URL_4_RULE);
                drawerLayout.closeDrawer(Gravity.LEFT);
                break;

            //TODO プライバシーポリシー
            case R.id.id_privacy_tv:
                go2WebView(privacyTv.getText().toString(), Constants.URL_4_PRIVACY);
                drawerLayout.closeDrawer(Gravity.LEFT);
                break;

            case R.id.ivHeadIcon:
                int pageIndex = presenter.getCurrentPageIndex();
                if (null == dogList || dogList.isEmpty() || dogList.size() < pageIndex + 1){
                    return;
                }
                intent.putExtra(Constants.EXTRA_DOG,dogList.get(pageIndex));
                intent.putExtra(Constants.EXTRA_DOG_COUNT,dogList.size());
                intent.setClass(this, DogInfoActivity.class);
                startActivity(intent);
                break;
//            case R.id.id_background_iv:
//                String fileUrl = (String) stationIv.getTag();
//                intent.putExtra(Constants.EXTRA_IMAGE_URL, fileUrl);
//                intent.setClass(this, ImageActivity.class);
//                startActivityForResult(intent,20);
//                break;
            case R.id.id_all_mutter_btn:
                intent.setClass(this,MutterInfoActivity.class);
                startActivity(intent);
            case R.id.id_application_tv:
                break;
            case R.id.id_town_btn:
                presenter.townClicked();
                break;
            default:
                break;
        }
    }

    @Override
    public void goToTown(String cookie) {
        Intent intent = new Intent();
        intent.putExtra(Constants.INTENT_MARK_4_WEBVIEW_COOKIE, cookie);
        intent.setClass(this, TownActivity.class);
        startActivity(intent);
    }

    private void go2WebView(String titleName, String URL) {
        Intent tempIntent = new Intent();
        tempIntent.setClass(this, WebViewActivity.class);
        tempIntent.putExtra(Constants.INTENT_MARK_4_WEBVIEW_TITLE, titleName);
        tempIntent.putExtra(Constants.INTENT_MARK_4_WEBVIEW_URL, URL);
        startActivity(tempIntent);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OPEN_BLUETOOTH) {
            if (resultCode == RESULT_OK) {
                presenter.sendDeviceDataToEventHub();
            } else if (resultCode == RESULT_CANCELED) {}
        }
    }

    @Override
    protected void onDestroy() {
        presenter.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onClicked() {
        Object object = stationIv.getTag(R.id.isStationImageLoad);
        if (null == object){
            return;
        }
        boolean isLoad = (boolean) object;
        if (!isLoad){
            return;
        }
        Intent intent = new Intent();
        String fileUrl = ApplicationUtils.getStationPhotoUrl();
        intent.putExtra(Constants.EXTRA_IMAGE_URL, fileUrl);
        intent.setClass(this, ImageActivity.class);
        startActivityForResult(intent, 20);
    }

    @Override
    public void onPrevious() {
        int currentPosition = presenter.getCurrentPageIndex();
        if (currentPosition > 0){
            currentPosition--;
            viewPager.setCurrentItem(currentPosition);
            showDogInfoByIndex(currentPosition);
        }
    }

    @Override
    public void resetCurrentItem() {
        int currentPosition = presenter.getCurrentPageIndex();
        if (currentPosition < viewPager.getChildCount()
                && currentPosition < dogList.size()){
            viewPager.setCurrentItem(currentPosition);
            showDogInfoByIndex(currentPosition);
        } else {
            presenter.setCurrentPageIndex(0);
        }
    }

    @Override
    public void loadStationImage() {
        ImageLoader.getInstance().loadImage(ApplicationUtils.getStationPhotoUrl(), new ImageLoadingListener() {
            @Override
            public void onLoadingStarted(String imageUri, View view) {
            }

            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        stationIv.setImageDrawable(context.getResources().getDrawable(R.drawable.station_default));
                        stationIv.setTag(R.id.isStationImageLoad, false);
                    }
                });

            }

            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                final Bitmap bitmap = loadedImage;
                presenter.checkRefreshStatus(0x04);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        stationIv.setImageBitmap(bitmap);
                        stationIv.setTag(R.id.isStationImageLoad, true);
                    }
                });

            }

            @Override
            public void onLoadingCancelled(String imageUri, View view) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        stationIv.setImageDrawable(context.getResources().getDrawable(R.drawable.station_default));
                        stationIv.setTag(R.id.isStationImageLoad, false);
                    }
                });
            }
        });
    }

    @Override
    public void getDataFromBle() {
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);

        BluetoothAdapter bluetoothAdapter = manager.getAdapter();

        if (null == bluetoothAdapter) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.bluetooth_error));
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

                startActivityForResult(intent, REQUEST_OPEN_BLUETOOTH);
            } else {
                presenter.sendDeviceDataToEventHub();
            }
        }
    }


    @Override
    public void onNext() {
        int currentPosition = presenter.getCurrentPageIndex();
        if (currentPosition < viewPager.getChildCount()
                && currentPosition < dogList.size()){
            currentPosition ++;
            viewPager.setCurrentItem(currentPosition);
            showDogInfoByIndex(currentPosition);
        }
    }
}
