package com.fujitsu.wandant.activity;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.view.ToastManager;
import com.github.lzyzsd.jsbridge.BridgeWebView;
import com.github.lzyzsd.jsbridge.DefaultHandler;

/**
 * Created by chenjie.fnst on 2016/02/06.
 */
public class TownActivity extends BaseActivity {

    @Bind(R.id.id_town_web)
    BridgeWebView webView;

    private Context context = null;
    private String url = "http://wandant:nxvnTRd5@town-wdtdev.azurewebsites.net/town/";
    private String cookie = null;

    @Override
    public String getTitleName() {
        return "town";
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        context = this;
        cookie = getIntent().getStringExtra(Constants.INTENT_MARK_4_WEBVIEW_COOKIE);
        webView.getSettings().setTextZoom(100);
        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setDefaultHandler(new DefaultHandler());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.setWebViewClient(webView.new BridgeWebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                hideWaitingDialog();
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                ToastManager.getInstance().showFail(context.getResources().getString(R.string.web_load_failed));
            }
        });
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.removeAllCookie();
        cookieManager.setCookie(url, cookie);
        webView.loadUrl(url);
        showWaitingDialog();
    }

    @Override
    public int getLayout() {
        return R.layout.activity_town;
    }
}
