package com.fujitsu.wandant.listener;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by wangc.fnst on 2015/10/19.
 */
public class ButtonOnTouchListener implements View.OnTouchListener {
    private Context mContext;
    private int pressedDrawable;
    private int normalDrawable;
    private String LOG_TAG = ButtonOnTouchListener.class.getName();


    public ButtonOnTouchListener(Context mContext,int pressedDrawable,int normalDrawable) {
        this.mContext = mContext;
        this.pressedDrawable = pressedDrawable;
        this.normalDrawable = normalDrawable;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (!v.isEnabled()){
            return false;
        }
        v.getParent().requestDisallowInterceptTouchEvent(true);
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                v.setBackground(mContext.getResources().getDrawable(pressedDrawable));
                v.setTranslationY(2f);
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            case MotionEvent.ACTION_UP:
                v.setBackground(mContext.getResources().getDrawable(normalDrawable));
                v.setTranslationY(-2f);
                break;
        }
        return false;
    }
}
