//******************************************************************
//* わんダント2システム
//******************************************************************
/*
 *	わんダント2Android
 *	BaseActivity.java
 *
 *	変更日			変更者				障害No／仕様変更No
 *	2015/9/19 		FNST)zhongxy	新規作成
 *
 */
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************

package com.fujitsu.wandant.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.view.CircleImageView;
import com.fujitsu.wandant.view.ToastManager;
import com.nostra13.universalimageloader.core.ImageLoader;
import me.grantland.widget.AutofitTextView;

import java.lang.reflect.Field;

/**
 * BaseActivity
 * base activity for the app
 */
public abstract class BaseActivity extends NewBaseActivity implements View.OnClickListener {

    /** if back button is clickable */
    protected boolean isBackable = true;

    /** if head image is shown */
    protected boolean isShowHead = false;

    /** if name is shown */
    protected boolean isShowName = true;

    /** if right textview is shown, defalt string is "确定" */
    protected boolean isShowRight = false;

    /** flag to mark the last activity */
    protected int activityFromFlag;

    /** back button */
    @Bind(R.id.id_title_back_img)
    View backView;

    /** textview to show name */
    @Bind(R.id.id_title_name_txt)
    AutofitTextView titleNameTxt;

    /** head imageview */
    @Bind(R.id.id_head_img)
    CircleImageView titleHeadImg;

    /** right textview */
    @Bind(R.id.id_right_tv)
    TextView rightTxt;

//    /** progress dialog to show when loading */
//    protected ProgressDialog dialog;


    /**
     * on create
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            activityFromFlag = getIntent().getIntExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,
                    Constants.ACTIVITY_FROM_REGISTER);
            setContentView(getLayout());
            ButterKnife.bind(this);
            onCreateView(savedInstanceState);

            if (isBackable) {
                backView.setVisibility(View.VISIBLE);
            } else {
                backView.setVisibility(View.GONE);
            }

            if (isShowHead) {
                titleHeadImg.setVisibility(View.VISIBLE);
                ImageLoader.getInstance().displayImage(getTitleHeadUrl(), titleHeadImg);
            } else {
                titleHeadImg.setVisibility(View.GONE);
            }

            if (isShowName) {
                titleNameTxt.setVisibility(View.VISIBLE);
                titleNameTxt.setText(getTitleName());
            } else {
                titleNameTxt.setVisibility(View.GONE);
            }

            if (isShowRight) {
                rightTxt.setVisibility(View.VISIBLE);
            } else {
                rightTxt.setVisibility(View.INVISIBLE);
            }

            backView.setOnClickListener(this);
            rightTxt.setOnClickListener(this);
        } catch (Exception e) {
            e.printStackTrace();
            Log.d("BaseActivity", e.toString());
            finish();
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            System.gc();
            System.runFinalization();
            finish();
        }
    }

    /**
     * title
     * @return title
     */
    public abstract String getTitleName();

    /**
     * head url
     * @return head url
     */
    public abstract String getTitleHeadUrl();

    /**
     * abstract method
     * @param savedInstanceState
     */
    public abstract void onCreateView(Bundle savedInstanceState);

    /**
     * layout id
     * @return layout id of the activity
     */
    public abstract int getLayout();

    /**
     * view click event
     * @param v
     */
    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()) {
            return;
        }
        if (v.getId() == R.id.id_title_back_img) {
            onBackPressed();
            return;
        }
    }

    /**
     * on destroy
     *
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

//        if (null != dialog) {
//            if (dialog.isShowing()) {
//                dialog.dismiss();
//            }
//            dialog.cancel();
//        }
    }

//    /**
//     * show waiting dialog
//     *
//     */
//    public void showWaitingDialog() {
//        if (null == dialog) {
//            dialog = new ProgressDialog(this);
//        }
//
//        dialog.setCancelable(false);
//        dialog.show();
//        Observable.timer(15, TimeUnit.SECONDS).subscribe(new Action1<Long>() {
//            @Override
//            public void call(Long aLong) {
//                hideWaitingDialog();
//            }
//        });
//    }
//
//    /**
//     * hide waiting dialog
//     *
//     */
//    public void hideWaitingDialog() {
//        if ((dialog != null) && dialog.isShowing()) {
//            dialog.dismiss();
//        }
//    }

    /**
     * rewrite method of activity to deal with the event when user click the back button of the phone
     * @param keyCode
     * @param event
     *
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) &&!isBackable) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    protected void showErrorMessage(Object code){
        ToastManager.getInstance().showFail(getErrorMessage(code));
    }

    /**
     * get errormessage by errorcode from server
     * @param code
     * @return empty string if not exist
     */
    protected String getErrorMessage(Object code){
        try{
            return getResources().getString(getErrorMessageCode(code+""));
        }catch (Exception e){
            return "";
        }
    }

    private Integer getErrorMessageCode(String code){
        Integer stringCode = null;
        try{
            Class<R.string>clazz = R.string.class;
            Field field = clazz.getDeclaredField("error_message_" + code);
            stringCode = field.getInt(null);
        }catch (Exception e){
            stringCode = null;
        }
        return stringCode;
    }


}
