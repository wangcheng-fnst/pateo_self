package com.fujitsu.wandant.activity;

import android.bluetooth.BluetoothGattService;
import android.content.*;
import android.os.Bundle;
import android.os.IBinder;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.ble.BleService;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.view.ToastManager;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by chenjie.fnst on 2015/10/15.
 */
public class StationWifiSettingActivity extends BaseActivity {


    private Context context;
    private BleService bleService;
    private BluetoothGattService iotStationGattService;

    private String wifiSSID;
    private String wifiPassword;
    private int wifiSecurity;
    private byte[] wifiByteArray = new byte[89];

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            bleService = ((BleService.BleBinder) service).getService();
            byte[] wifiArray = getWifiByteArray();
            bleService.writeData(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_CMD_W, wifiArray);
            bleService.readData(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_W);

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            bleService = null;
        }
    };

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BleService.ACTION_DATA_AVAILABLE.equals(action)) {
                //get message that station has connected the wifi
                byte[] resultArray = intent.getByteArrayExtra(BleService.EXTRA_DATA);
                String uuid = intent.getStringExtra(BleService.EXTRA_UUID);
                if (uuid.equals(Constants.STATION_IOT_RES_W.toString())){
                    if (resultArray[0] == (byte)0x01 && resultArray[1] == (byte)0x00){
                        ToastManager.getInstance().showFail(getResources().getString(R.string.setting_wifi_success));
//                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.setting_wifi_success),Toast.LENGTH_SHORT).show();
                        Intent tempAndHumiIntent = new Intent();
                        tempAndHumiIntent.setClass(StationWifiSettingActivity.this, StationTempAndHumiditySettingActivity.class);
                        startActivity(tempAndHumiIntent);
                    } else {
                        ToastManager.getInstance().showFail(getResources().getString(R.string.setting_wifi_error));
//                        Toast.makeText(getApplicationContext(),getResources().getString(R.string.setting_wifi_error),Toast.LENGTH_SHORT).show();
                    }

                }

            }
        }
    };

    @Override
    public String getTitleName() {
        return "";
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_station_wifi_setting);
        context = this;
        wifiSSID = getIntent().getStringExtra(Constants.EXTRA_WIFI_SSID);
        wifiPassword = getIntent().getStringExtra(Constants.EXTRA_WIFI_PASSWORD);
        wifiSecurity = getIntent().getIntExtra(Constants.EXTRA_WIFI_SECURITY,-1);
        Intent gattServiceIntent = new Intent(this, BleService.class);
        bindService(gattServiceIntent, serviceConnection, BIND_AUTO_CREATE);
        IntentFilter filter = new IntentFilter(BleService.ACTION_DATA_AVAILABLE);
        registerReceiver(receiver, filter);
        Timer timer= new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent();
                intent.setClass(StationWifiSettingActivity.this,StationTempAndHumiditySettingActivity.class);
                startActivity(intent);
            }
        };
        timer.schedule(task, 5000);
    }

    @Override
    public int getLayout() {
        return R.layout.activity_station_wifi_setting;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
        unregisterReceiver(receiver);
    }

    public byte[] getWifiByteArray() {
        int index = 0;
        for (index = 0; index < wifiByteArray.length;index++){
            wifiByteArray[index] = (byte)0x00;
        }

        wifiByteArray[0] = (byte)0x01;

        wifiByteArray[1] =  (byte) (wifiSecurity & 0xFF);
        wifiByteArray[2] =  (byte) ((wifiSecurity>>8) & 0xFF);
        wifiByteArray[3] =  (byte) ((wifiSecurity>>16) & 0xFF);
        wifiByteArray[4] =  (byte) ((wifiSecurity>>24) & 0xFF);

        byte[] ssidByteArray = wifiSSID.getBytes();
        int ssidSize = ssidByteArray.length;
        wifiByteArray[9] = (byte) (ssidSize & 0xFF);
        wifiByteArray[10] = (byte) ((ssidSize>>8) & 0xFF);
        wifiByteArray[11] = (byte) ((ssidSize>>16) & 0xFF);
        wifiByteArray[12] = (byte) ((ssidSize>>24) & 0xFF);

        index = 0;
        for (index = 0; index < ssidSize && index < 32;index++){
            wifiByteArray[17+index] = ssidByteArray[index];
        }

        byte[] passByteArray = wifiPassword.getBytes();
        int passSize = passByteArray.length;
        wifiByteArray[49] = (byte) (passSize & 0xFF);
        wifiByteArray[50] = (byte) ((passSize>>8) & 0xFF);
        wifiByteArray[51] = (byte) ((passSize>>16) & 0xFF);
        wifiByteArray[52] = (byte) ((passSize>>24) & 0xFF);

        index = 0;
        for (index = 0; index < passSize && index < 32;index++){
            wifiByteArray[57+index] = passByteArray[index];
        }
        return wifiByteArray;
    }
}
