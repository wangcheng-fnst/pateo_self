package com.fujitsu.wandant.activity;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.ble.BleHandler;
import com.fujitsu.wandant.ble.DeviceHandler;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.model.DeviceModel;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.utils.BDIDUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.DeviceUtil;
import com.fujitsu.wandant.view.datepicker.WheelView;
import com.fujitsu.wandant.view.datepicker.adapter.ArrayWheelAdapter;
import rx.Observable;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by chenjie.fnst on 2015/10/13.
 */
public class DeviceSettingActivity extends BaseActivity{

    @Bind(R.id.id_sure_btn)
    Button sureBtn;
    @Bind(R.id.id_temp_max_wv)
    WheelView tempWheelView;
    @Bind(R.id.id_humi_min_wv)
    WheelView humiWheelView;

    private List<String> tempList = new ArrayList<>();
    private List<String> humiList = new ArrayList<>();
    private Dog dog;
    private DeviceModel device;
    private int[] SHADOWS_COLORS = new int[] { 0xefffffff, 0xcfffffff, 0x3fffffff };

    private String tempUnit;
    private String humiUnit;

    private DeviceHandler deviceHandler;
    private Subscription subscription;
    /** bluetooth adapter */
    private BluetoothAdapter bluetoothAdapter;
    /** request flag to open bluetooth function in the phone */
    private static final int OPEN_BLUETOOTH_REQUEST = 1;
    private String str4BDID = null;

    @Override
    public String getTitleName() {
        return getResources().getString(R.string.device_ble_setting);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        dog = (Dog) getIntent().getSerializableExtra(Constants.EXTRA_DOG);
        device = (DeviceModel) getIntent().getSerializableExtra(Constants.EXTRA_DEVICE_MODEL);
        tempUnit = getResources().getString(R.string.temperature_unit);
        humiUnit = getResources().getString(R.string.percent_unit);
        deviceHandler = new DeviceHandler();
        str4BDID= BDIDUtils.addMark4BDID(device.getBdid());
        bindViews();
//        new Handler().postDelayed(new Runnable() {
//            public void run() {
//                //execute the task
//                getDataFromBle();
//            }
//        }, 1000);

    }

    private void getDataFromBle() {
        if (!BluetoothAdapter.checkBluetoothAddress(device.getBdid())){
            return;
        }
        deviceHandler.getDeviceSettingFromBle(device.getBdid()).subscribe(new Action1<DeviceUtil.DeviceSetting>() {
            @Override
            public void call(DeviceUtil.DeviceSetting setting) {
                if (null != setting) {
                    tempWheelView.setCurrentItem(setting.getTemp() - Constants.DEVICE_TEMP_MIN);
                    humiWheelView.setCurrentItem(setting.getHumi() - Constants.DEVICE_HUMI_MIN);
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {

            }
        });
    }

    private void bindViews() {
        sureBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        sureBtn.setOnClickListener(this);

        for (int index = Constants.DEVICE_TEMP_MIN; index < Constants.DEVICE_TEMP_MAX + 1; index++ ){
            tempList.add(String.valueOf(index) + tempUnit);
        }
        String[] tempItems = new String[Constants.DEVICE_TEMP_MAX - Constants.DEVICE_TEMP_MIN + 1];
        tempItems = tempList.toArray(tempItems);
        ArrayWheelAdapter<String> tempAdapter = new ArrayWheelAdapter<String>(this,tempItems);
        tempWheelView.setViewAdapter(tempAdapter);
        tempWheelView.setCyclic(false);
        tempWheelView.setVisibleItems(5);
        if(null == device.getTemperature()){
            tempWheelView.setCurrentItem(Constants.DEVICE_TEMP_DEFAULT - Constants.DEVICE_TEMP_MIN);
        } else {
            tempWheelView.setCurrentItem(device.getTemperature() - Constants.DEVICE_TEMP_MIN);
        }

        tempWheelView.setShadowColor(SHADOWS_COLORS[0], SHADOWS_COLORS[1], SHADOWS_COLORS[2]);

        for (int index = Constants.DEVICE_HUMI_MIN; index < Constants.DEVICE_HUMI_MAX + 1; index++ ){
            humiList.add(String.valueOf(index) + humiUnit);
        }
        String[] humiItems = new String[Constants.DEVICE_TEMP_MAX - Constants.DEVICE_TEMP_MIN + 1];
        humiItems = humiList.toArray(humiItems);
        ArrayWheelAdapter<String> humiAdapter = new ArrayWheelAdapter<String>(this,humiItems);
        humiWheelView.setViewAdapter(humiAdapter);
        humiWheelView.setCyclic(false);
        humiWheelView.setVisibleItems(5);
        if (null == device.getHumidity_down()){
            humiWheelView.setCurrentItem(Constants.DEVICE_HUMI_DEFAULT - Constants.DEVICE_HUMI_MIN);
        } else {
            humiWheelView.setCurrentItem(device.getHumidity_down() - Constants.DEVICE_HUMI_MIN);
        }

        humiWheelView.setShadowColor(SHADOWS_COLORS[0], SHADOWS_COLORS[1], SHADOWS_COLORS[2]);
//        humiWheelView.addScrollingListener(scrollListener);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public int getLayout() {
        return R.layout.activity_device_setting;
    }

    @Override
    protected void onDestroy() {
        if (null != deviceHandler){
            deviceHandler.disconnect();
        }
        if (null != subscription){
            subscription.unsubscribe();
            subscription = null;
        }
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_sure_btn:
                setAlert();
                break;
            default:
                break;
        }

    }

    private void setAlert() {
        showWaitingDialog();
        final int temp = tempWheelView.getCurrentItem() + Constants.DEVICE_TEMP_MIN;
        final int humi = humiWheelView.getCurrentItem() + Constants.DEVICE_HUMI_MIN;
        // set time
        if (null == device || !BluetoothAdapter.checkBluetoothAddress(str4BDID)){
            return;
        }
        subscription = deviceHandler.connectDeviceAndSetTime(str4BDID).timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS)
                .first().filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return (aBoolean == true);
                    }
                }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                        return deviceHandler.registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS);
                    }
                }).filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return (aBoolean == true);
                    }
                }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                            return deviceHandler.setAlert(temp, humi).timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS);
                    }
                }).first().subscribe(new Action1<Boolean>() {
                    @Override
                    public void call(Boolean aBoolean) {
                        deviceHandler.disconnect();
                        if (aBoolean) {
                            device.setTemperature(temp);
                            device.setHumidity_down(humi);
                            DogDeviceStationRepository.getInstance().updateSettingOfDeviceByBdid(device.getBdid(), temp, humi);
                            hideWaitingDialog();
                            Intent intent = new Intent();
                            intent.putExtra(Constants.EXTRA_DEVICE_MODEL, device);
                            setResult(RESULT_OK, intent);
                            finish();
                        }
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                        deviceHandler.disconnect();
                    }
                });
    }

}
