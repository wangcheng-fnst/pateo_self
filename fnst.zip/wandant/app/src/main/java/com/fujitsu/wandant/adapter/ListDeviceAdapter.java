package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.model.DeviceModel;
import com.fujitsu.wandant.model.FirmDetailModel;
import com.fujitsu.wandant.net.StatusRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.view.CircleImageView;
import com.nostra13.universalimageloader.core.ImageLoader;
import me.grantland.widget.AutofitTextView;

import java.util.*;

/**
 * Created by chenjie.fnst on 2015/11/09.
 */
public class ListDeviceAdapter extends BaseAdapter {

    private Context context;
    private List<Dog> dogList = new ArrayList<>();
    private Map<Integer,DeviceModel> dogIdDeviceMap = new HashMap<>();
    private List<Integer> needUpdateList = new ArrayList<>();
    private String pendant = null;
    private String nothing = null;
    private View.OnClickListener listener = null;


    public ListDeviceAdapter(Context context, List<Dog> dogs, Map<Integer,DeviceModel> deviceMap){
        this.context = context;
        this.pendant = context.getResources().getString(R.string.pendant);
        this.nothing = context.getResources().getString(R.string.nothing);
        if (null != dogs && null != deviceMap){
            this.dogList = dogs;
            this.dogIdDeviceMap = deviceMap;
            this.needUpdateList.clear();
            for (Map.Entry<Integer,DeviceModel> entry : this.dogIdDeviceMap.entrySet()){
                String bdid = entry.getValue().getBdid();
                if (!StringUtils.isBlank(bdid)){
                    FirmDetailModel model = StatusRepository.getInstance().getNeedUpdateFirmDbByBdid(bdid);
                    if (null != model){
                        this.needUpdateList.add(entry.getKey());
                    }
                }
            }
        } else {
            this.dogList.clear();
            this.dogIdDeviceMap.clear();
            this.needUpdateList.clear();;
        }

    }

    public void setOnItemListener(View.OnClickListener listener){
        this.listener = listener;
    }


    @Override
    public int getCount() {
        return dogList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void refreshList(List<Dog> dogList, Map<Integer, DeviceModel> deviceMap) {
        this.dogList = dogList;
        this.dogIdDeviceMap = deviceMap;
        notifyDataSetChanged();
    }

    class ViewHolder{
        View layout;
        CircleImageView headCiv;
        AutofitTextView nameTv;
        ImageView statusIv;
        View updateView;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (null == convertView){
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.listview_device_item, parent, false);
            viewHolder.layout = convertView.findViewById(R.id.id_device_detail_rl);
            viewHolder.headCiv = (CircleImageView) convertView.findViewById(R.id.id_head_civ);
            viewHolder.nameTv = (AutofitTextView) convertView.findViewById(R.id.id_name_tv);
            viewHolder.statusIv = (ImageView) convertView.findViewById(R.id.id_status_iv);
            viewHolder.updateView = convertView.findViewById(R.id.id_update_flag_iv);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        Dog dog = dogList.get(position);
        viewHolder.layout.setTag(position);
        viewHolder.layout.setOnClickListener(listener);
        if (!StringUtils.isBlank(dog.getAvatar_url())){
            ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconUrl(dog.getAvatar_url()),viewHolder.headCiv);
        }
        Integer dogId = dog.getDog_id();
        if (dogIdDeviceMap.containsKey(dogId)){
            viewHolder.nameTv.setText(dog.getName() + pendant);
            viewHolder.statusIv.setImageDrawable(context.getResources().getDrawable(R.drawable.arrow_right));
        } else {
            viewHolder.nameTv.setText(dog.getName() + pendant + nothing);
            viewHolder.statusIv.setImageDrawable(context.getResources().getDrawable(R.drawable.btn_add));
        }
        if (needUpdateList.contains(dogId)){
            viewHolder.updateView.setVisibility(View.VISIBLE);
        } else {
            viewHolder.updateView.setVisibility(View.GONE);
        }
        return convertView;
    }

    public void removeDeviceFromAdapterByDeviceId(Integer deviceId){
        if (deviceId!=null){
            this.dogIdDeviceMap.remove(deviceId);
            this.needUpdateList.remove(deviceId);
        }
    }

    public boolean hasDeviceUpdate(){
        return needUpdateList!=null&&needUpdateList.size()>0;
    }
}
