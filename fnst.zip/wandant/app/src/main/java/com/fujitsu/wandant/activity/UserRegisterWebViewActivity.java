package com.fujitsu.wandant.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.WandantApplication;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.net.ServerResult;
import com.fujitsu.wandant.net.model.UserFromNet;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ToastManager;
import com.github.lzyzsd.jsbridge.BridgeWebView;
import com.github.lzyzsd.jsbridge.CallBackFunction;
import com.github.lzyzsd.jsbridge.DefaultHandler;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by wangc.fnst on 2015/10/27.
 */
public class UserRegisterWebViewActivity extends BaseActivity  {

    private static final String LOG_TAG = UserRegisterWebViewActivity.class.getName();
    @Bind(R.id.id_register_web)
    BridgeWebView webView;
    @Bind(R.id.id_next_btn)
    Button nextBtn;

//    private static final String URL_WITH_ACCOUNT = Constants.SERVER_URL + "/api/register/open/index.html#/sign_up/2";
////    private static final String URL_WITH_ACCOUNT = "http://10.167.232.121:8080/register/open/#/sign_up/1";
////    private static final String URL_WITHOUT_ACCOUNT = "http://10.167.232.121:8080/register/open/#/sign_up/1";
//    private static final String URL_WITHOUT_ACCOUNT = Constants.SERVER_URL + "/api/register/open/index.html#/sign_up/1";
    private String url = null;
    private Context context = null;
    private String cookie = null;

    @Override
    public String getTitleName() {
        return getResources().getString(R.string.user_register_title);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        context = this;
        url = getIntent().getStringExtra(Constants.EXTRA_REGISTER_URL);
        if (StringUtils.isBlank(url)){
            url= ApplicationUtils.getRegisterUrlWithoutAccount();
        }
        cookie = getIntent().getStringExtra(Constants.EXTRA_VALUE);
        nextBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        nextBtn.setOnClickListener(this);
        webView.getSettings().setTextZoom(100);
        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setDefaultHandler(new DefaultHandler());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.setWebViewClient(webView.new BridgeWebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                hideWaitingDialog();
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                ToastManager.getInstance().showFail(context.getResources().getString(R.string.web_load_failed));
//                Toast.makeText(context, context.getResources().getString(R.string.web_load_failed), Toast.LENGTH_SHORT).show();
            }
        });
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.removeAllCookie();
        if (url.equals(ApplicationUtils.getRegisterUrlWithAccount())) {
//            final String cookieString = "WdUserInfo=" + GsonUtil.getInstance().toJson(UserUtils.getInstance().loadUser());
            final String cookieString = "WdUserInfo=" + cookie;
            cookieManager.setCookie(url, cookieString);
//            cookieManager.flush();
        }
        webView.loadUrl(url);
        showWaitingDialog();

    }

    @Override
    public int getLayout() {
        return R.layout.user_register;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (v.getId() == R.id.id_next_btn){
            parseData();
        }
    }

    private void parseData() {
        webView.callHandler("register", null, new CallBackFunction() {
            @Override
            public void onCallBack(String data) {
                Logger.e(LOG_TAG, "parse data is " + data);
                Gson gson = new Gson();
                Type objectType = new TypeToken<ServerResult<Object>>() {
                }.getType();
                ServerResult<Object> result =  gson.fromJson(data, objectType);
                if (result.isSuccess()){
                    Map<String,Object> map = (Map<String, Object>) result.getData();
                    String token = (String) map.get("WdToken");
                    Object userObject = map.get("userInfo");
                    String userStr = gson.toJson(userObject);
                    UserFromNet user = gson.fromJson(userStr,UserFromNet.class);
                    if (null != user){
                        user.setToken(token);
                        UserUtils.getInstance().saveUser(user);
                    }

                    Map<String,String> header = new HashMap<>();
                    header.put("X-Auth-Token", token);
                    WandantApplication.getInstance().initImageLoader(header);
                    Logger.d(LOG_TAG, "parse success");
                    Intent intent = new Intent(context,DogRegisterActivity.class);
                    intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,activityFromFlag);
                    context.startActivity(intent);
                } else {
                    String msg = (String) result.getData();
                    ToastManager.getInstance().showFail(msg);
//                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

}
