package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.net.EmailRepository;
import com.fujitsu.wandant.net.model.UserAlertMail;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ToastManager;

/**
 * Created by wangc.fnst on 2015/10/30.
 */
public class EmailAddActivity extends BaseActivity implements OnModelFinishedListener {

    private boolean isAddMode = true;
    @Bind(R.id.id_email_edit)
    EditText valueEdit;
    @Bind(R.id.id_email_img)
    ImageView cleanImg;

    private UserAlertMail mail;

    @Override
    public String getTitleName() {
        if (isAddMode){
            return getResources().getString(R.string.email_add_title);
        }else{
            return getResources().getString(R.string.email_edit_title);
        }
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        Intent intent = getIntent();
        isAddMode = intent.getBooleanExtra(Constants.EXTRA_EMAIL_MODE,true);
//        addBtn.setOnTouchListener(new ButtonOnTouchListener(this,R.mipmap.btn_sure_pressed, R.mipmap.btn_sure));
        isShowRight = true;
        rightTxt.setEnabled(false);
        if (isAddMode){
            valueEdit.setText(intent.getStringExtra(Constants.EXTRA_VALUE));
            rightTxt.setText(getResources().getString(R.string.add));
        }else {
            mail = (UserAlertMail) intent.getSerializableExtra(Constants.EXTRA_VALUE);
            valueEdit.setText(mail.getAlert_mail());
            valueEdit.setSelection(valueEdit.length());
            rightTxt.setText(getResources().getString(R.string.email_edit_save));
        }
        valueEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String address = s.toString();
                if(!StringUtils.isBlank(address)){
                    rightTxt.setEnabled(true);
                } else {
                    rightTxt.setEnabled(false);
                }
            }
        });
        rightTxt.setOnClickListener(this);
        cleanImg.setOnClickListener(this);
        EmailRepository.getInstance().register(this,EmailRepository.REQUEST_TYPE_FROM_EMAIL_ADD);
    }

    @Override
    public int getLayout() {
        return R.layout.activity_email_add;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (v.getId() == R.id.id_right_tv){
            String newAdr = valueEdit.getText().toString();
            if (!StringUtils.isEmail(newAdr)){
                ToastManager.getInstance().showFail(getResources().getString(R.string.error_wrong_email));
                return;
            }
            if (isAddMode) {
                showWaitingDialog();
                mail = new UserAlertMail();
                mail.setAlert_mail(newAdr);
                mail.setUser_id(UserUtils.getInstance().loadUser().getUser_id());
                EmailRepository.getInstance().addEmail(mail);
            }else {
                showWaitingDialog();
                mail.setAlert_mail(newAdr);
                EmailRepository.getInstance().modifyEmail(mail);
            }
        }else if (v.getId() == R.id.id_email_img){
            valueEdit.setText("");
        }
    }



    @Override
    public void success(Object result,int type) {
        if (type == EmailRepository.ADD_MODE) {
            ToastManager.getInstance().showSuc(getResources().getString(R.string.info_add_email_success));
            Integer mailId = (Integer) result;
            if (null != mailId){
                mail.setUser_alert_mail_id(mailId);
            }
            hideWaitingDialog();
            Intent intent = new Intent();
            intent.putExtra(Constants.EXTRA_EMAIL_INFO, mail);
            setResult(RESULT_OK, intent);
            finish();
        }else if (type == EmailRepository.MODIFY_MODE){
            ToastManager.getInstance().showSuc(getResources().getString(R.string.info_modify_email_success));
            hideWaitingDialog();
            Intent intent = new Intent();
            intent.putExtra(Constants.EXTRA_VALUE, mail.getAlert_mail());
            setResult(RESULT_OK, intent);
            finish();
        }
    }



    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
        hideWaitingDialog();
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
        hideWaitingDialog();
    }

    @Override
    protected void onDestroy() {
        EmailRepository.getInstance().unregister(EmailRepository.REQUEST_TYPE_FROM_EMAIL_ADD);
        super.onDestroy();
    }
}
