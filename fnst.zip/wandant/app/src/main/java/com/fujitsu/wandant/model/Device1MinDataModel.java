package com.fujitsu.wandant.model;

import java.util.UUID;

/**
 * Created by chenjie.fnst on 2015/12/15.
 */
public class Device1MinDataModel extends BaseModel {

    public static final String DATA_TYPE = "91";
    public static final String DEV_KIND = "05";

    private String gwId;
    private String devId;
    private String dataType;
    private String guid;
    private long utc;
    private String timezone;
    private String devKind;
    private String userId;


    private int wdSteps;
    private int wdMomentum;
    private int wdTrot;
    private int wdBalance;
    private int wdBuruburu;
    private float wdTemp;
    private float wdHumidity;

//    public Device1MinDataModel() {
//        this.dataType = DATA_TYPE;
//        this.guid = UUID.randomUUID().toString();
//        this.devKind = DEV_KIND;
//    }

    public Device1MinDataModel(String stationBdid, String deviceBdid) {
        this.gwId = stationBdid;
        this.devId = deviceBdid;
        this.dataType = DATA_TYPE;
        this.guid = UUID.randomUUID().toString();
        this.devKind = DEV_KIND;

    }

    public String getGwId() {
        return gwId;
    }

    public void setGwId(String gwId) {
        this.gwId = gwId;
    }

    public String getDevId() {
        return devId;
    }

    public void setDevId(String devId) {
        this.devId = devId;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public long getUtc() {
        return utc;
    }

    public void setUtc(long utc) {
        this.utc = utc;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getDevKind() {
        return devKind;
    }

    public void setDevKind(String devKind) {
        this.devKind = devKind;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getWdSteps() {
        return wdSteps;
    }

    public void setWdSteps(int wdSteps) {
        this.wdSteps = wdSteps;
    }

    public int getWdMomentum() {
        return wdMomentum;
    }

    public void setWdMomentum(int wdMomentum) {
        this.wdMomentum = wdMomentum;
    }

    public int getWdTrot() {
        return wdTrot;
    }

    public void setWdTrot(int wdTrot) {
        this.wdTrot = wdTrot;
    }

    public int getWdBalance() {
        return wdBalance;
    }

    public void setWdBalance(int wdBalance) {
        this.wdBalance = wdBalance;
    }

    public int getWdBuruburu() {
        return wdBuruburu;
    }

    public void setWdBuruburu(int wdBuruburu) {
        this.wdBuruburu = wdBuruburu;
    }

    public float getWdTemp() {
        return wdTemp;
    }

    public void setWdTemp(float wdTemp) {
        this.wdTemp = wdTemp;
    }

    public float getWdHumidity() {
        return wdHumidity;
    }

    public void setWdHumidity(float wdHumidity) {
        this.wdHumidity = wdHumidity;
    }

}
