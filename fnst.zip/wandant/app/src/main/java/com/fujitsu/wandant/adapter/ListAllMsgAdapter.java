package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.activity.AlertSettingActivity;
import com.fujitsu.wandant.model.MutterAllModel;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.TimeUtils;
import com.fujitsu.wandant.view.CircleImageView;
import com.fujitsu.wandant.view.NumberView;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ym-zhongxy on 2015/9/22.
 */
public class ListAllMsgAdapter extends BaseAdapter implements View.OnClickListener {
    private Context context;
    private List<MutterAllModel> list;
    private Map<Integer,Dog> dogIdMap;
    private boolean isShowHead = false;
    private int bigSize;
    private int smallSize;

    public ListAllMsgAdapter(Context context, List<MutterAllModel> mutterModels, Map<Integer, Dog> dogIdMap) {
        this.context = context;
        if (null == mutterModels){
            this.list = new ArrayList<>();
        } else {
            this.list = mutterModels;
        }
        if (null == dogIdMap){
            this.dogIdMap = new HashMap<>();
        } else {
            this.dogIdMap = dogIdMap;
        }
        if (this.dogIdMap.isEmpty()){
            isShowHead = false;
        } else {
            isShowHead = true;
        }
        bigSize = (int) context.getResources().getDimension(R.dimen.dp_39);
        smallSize = (int) context.getResources().getDimension(R.dimen.dp_30);
    }

    public void refreshList(List<MutterAllModel> mutterModels) {
        if (null == mutterModels){
            this.list = new ArrayList<>();
        } else {
            this.list = mutterModels;
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if(convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.listview_other_msg_item, parent,false);
            holder = new Holder();
            holder.bindViews(convertView);
            convertView.setTag(holder);
        }else{
            holder = (Holder) convertView.getTag();
        }

        MutterAllModel mutterModel = list.get(position);

        String message = mutterModel.getMsg_content();
//        message = "dsadddddddddddddddddddddddqwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnm";
//        String str = "<a href=\"http://2711082222.blog.163.com\">link</a>";
        if (StringUtils.isContainUrl(message)){
            holder.msgTv.setText(Html.fromHtml(message));
            holder.msgTv.setMovementMethod(LinkMovementMethod.getInstance());
        } else {
            holder.msgTv.setText(message);
            holder.msgTv.setMovementMethod(null);
        }
        if (ApplicationUtils.checkClickableForNavigationType(mutterModel.getNavigation_type())){
            convertView.setOnClickListener(this);
            if (0 == position){
                convertView.setBackground(context.getResources().getDrawable(R.drawable.info_item_top_bg));
            } else {
                convertView.setBackground(context.getResources().getDrawable(R.drawable.info_item_middle_bg));
            }
        } else {
            convertView.setOnClickListener(null);
            convertView.setBackgroundColor(context.getResources().getColor(R.color.white));
        }

        holder.dateTv.setValue(TimeUtils.format(mutterModel.getMsg_date()));
        Integer dogId = mutterModel.getDog_id();
        boolean haveHead = false;
        if (isShowHead){
            if (null != dogId){
                holder.headIconCiv.setVisibility(View.VISIBLE);
                Dog dog = dogIdMap.get(dogId);
                if (null != dog && !StringUtils.isBlank(dog.getAvatar_url())){
                    haveHead = true;
                    ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconUrl(dog.getAvatar_url()),holder.headIconCiv);
                }
            } else {
                holder.headIconCiv.setVisibility(View.GONE);
            }
        } else {
            holder.headIconCiv.setVisibility(View.GONE);
        }
        ViewGroup.LayoutParams params = holder.typeIconIv.getLayoutParams();
        if (haveHead){
            params.width = smallSize;
            params.height = smallSize;
        } else{
            params.width = bigSize;
            params.height = bigSize;
        }
        holder.typeIconIv.setLayoutParams(params);
        holder.typeIconIv.setImageDrawable(ApplicationUtils.getDrawableForType(mutterModel.getMsg_type()));


        return convertView;
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        Intent intent = new Intent();
        intent.setClass(context, AlertSettingActivity.class);
        context.startActivity(intent);
    }

    private class Holder{
        private ImageView typeIconIv;
        private CircleImageView headIconCiv;
        private TextView msgTv;
        private NumberView dateTv;

        private void bindViews(View view) {
            typeIconIv = (ImageView) view.findViewById(R.id.id_head_type_iv);
            headIconCiv = (CircleImageView) view.findViewById(R.id.id_head_icon_iv);
            msgTv = (TextView) view.findViewById(R.id.id_msg_tv);
            dateTv = (NumberView) view.findViewById(R.id.id_date_tv);
            dateTv.setFontColor(Constants.LIGHT_GRAY);
        }
    }
}
