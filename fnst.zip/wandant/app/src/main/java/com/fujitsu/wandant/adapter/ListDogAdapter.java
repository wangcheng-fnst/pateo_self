package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.view.CircleImageView;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenjie.fnst on 2015/10/09.
 */
public class ListDogAdapter extends BaseAdapter {

    private Context context;
    private List<Dog> dogInfoList = new ArrayList<>();

    public ListDogAdapter(Context context, List<Dog> dogInfoList){
        this.context = context;
        if (null == dogInfoList){
            this.dogInfoList.clear();
        } else {
            this.dogInfoList = dogInfoList;
        }
    }

    @Override
    public int getCount() {
        if (dogInfoList.size() > Constants.DOG_MAX_NUM){
            return Constants.DOG_MAX_NUM;
        } else {
            return dogInfoList.size();
        }
    }

    public void refreshList(List<Dog> dogList){
        if (null == dogList){
            this.dogInfoList.clear();
        } else {
            this.dogInfoList = dogList;
        }
        notifyDataSetChanged();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public class ViewHolder{
        public CircleImageView civHead;
        public TextView tvName;
        public RelativeLayout relativeLayout;
        private View lineView;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(null == convertView){
            convertView = LayoutInflater.from(context).inflate(R.layout.listview_dog_item, parent,false);
            viewHolder = new ViewHolder();
            viewHolder.civHead = (CircleImageView)convertView.findViewById(R.id.id_dog_head_civ);
            viewHolder.tvName = (TextView)convertView.findViewById(R.id.id_dog_name_tv);
            viewHolder.relativeLayout = (RelativeLayout) convertView.findViewById(R.id.id_item_layout);
            viewHolder.lineView = convertView.findViewById(R.id.id_item_line);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        if (position == 0 && position == dogInfoList.size()-1){
            viewHolder.relativeLayout.setBackgroundResource(R.drawable.info_item_top_bg);
        }else if (position == 0 && position != dogInfoList.size() -1){
            viewHolder.relativeLayout.setBackgroundResource(R.drawable.info_item_top_bg);
        }else if (position != 0 && position == dogInfoList.size() -1){
            if (dogInfoList.size() == 4) {
                viewHolder.relativeLayout.setBackgroundResource(R.drawable.info_item_bottom_bg);
            }else{
                viewHolder.relativeLayout.setBackgroundResource(R.drawable.info_item_middle_bg);
            }
        }else if (position > 0 && position < dogInfoList.size()-1){
            viewHolder.relativeLayout.setBackgroundResource(R.drawable.info_item_middle_bg);
        }
        if (position == dogInfoList.size()-1 && position == 3){
            viewHolder.lineView.setVisibility(View.GONE);
        }else{
            viewHolder.lineView.setVisibility(View.VISIBLE);
        }
        Dog dogInfo = dogInfoList.get(position);
//        ImageLoader.from(context).displayImage(viewHolder.civHead, ApplicationUtils.getHeadIconUrl(dogInfo.getAvatar_url()), R.mipmap.btn_add_pic_loading,
//                (int) ApplicationUtils.dp2px(context, 40), (int) ApplicationUtils.dp2px(context, 40));
        viewHolder.tvName.setText(dogInfo.getName());
        Dog dog = dogInfoList.get(position);
        ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconUrl(dogInfo.getAvatar_url()), viewHolder.civHead);
        viewHolder.tvName.setText(dog.getName());
        return convertView;
    }
}
