//******************************************************************
//* わんダント2システム
//******************************************************************
/*
 *	わんダント2Android
 *	DogSureActivity.java
 *
 *	変更日			変更者				障害No／仕様変更No
 *	2015/11/18 		FNST)Chenjie    	新規作成
 *
 */
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************

package com.fujitsu.wandant.activity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.fujitsu.wandant.R;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;

import com.nostra13.universalimageloader.core.ImageLoader;

/**
 * DogSureActivity
 */
public class DogSureActivity extends DogInfoActivity {

    /**
     * title
     *
     * @return
     */
    @Override
    public String getTitleName() {
        return getResources().getString(R.string.dog_register_title);
    }

    /**
     * onCreateView
     * @param savedInstanceState
     */
    @Override
    public void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        initView();
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_DOG_SURE, this);
    }

    /**
     * onDestroy
     *
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_DOG_SURE);
    }

    /**
     * show Head of dog
     *
     */
    @Override
    public void showHead() {
        if (!StringUtils.isBlank(dogInfo.getAvatar_url())) {
            ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconPath(dogInfo.getAvatar_url()),
                    headValueImg);
        } else {
            headValueImg.setImageDrawable(getResources().getDrawable(R.drawable.dog));
        }
    }

    /**
     * get server response success
     * @param dog
     * @param type
     */
    @Override
    public void success(Object dog, int type) {
        hideWaitingDialog();

        switch (type) {
        case DogDeviceStationRepository.ADD_DOG_FROM_NET_MODE :
            Intent intent = new Intent(this, BleSelectionActivity.class);

            dogInfo = (Dog) dog;
            intent.putExtra(Constants.EXTRA_DOG, dogInfo);
            intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG, activityFromFlag);
            startActivity(intent);

            break;

        default :
            break;
        }
    }

    /**
     * get server response failed
     * @param errorCode
     * @param errorMsg
     */
    @Override
    public void failed(String errorCode, String errorMsg) {
        hideWaitingDialog();
        super.failed(errorCode, errorMsg);
    }

    /**
     * get server response failed
     * @param errorMsg
     */
    @Override
    public void internalFailure(String errorMsg) {
        hideWaitingDialog();
        super.internalFailure(errorMsg);
    }

    /**
     * init View of activity
     *
     */
    private void initView() {
        findViewById(R.id.id_sex_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_color_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_kind_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_birth_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_home_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_microchip_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_watch_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_medicine_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_flea_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_injection_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_rabies_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_diagnose_more).setVisibility(View.INVISIBLE);
        findViewById(R.id.id_sex_layout).setBackground(getResources().getDrawable(R.drawable.table_middle_bg));
        findViewById(R.id.id_color_layout).setBackground(getResources().getDrawable(R.drawable.table_middle_bg));
        findViewById(R.id.id_kind_layout).setBackground(getResources().getDrawable(R.drawable.table_middle_bg));
        findViewById(R.id.id_birth_layout).setBackground(getResources().getDrawable(R.drawable.table_top_bg));
        findViewById(R.id.id_home_layout).setBackground(getResources().getDrawable(R.drawable.table_bottom_bg));
        findViewById(R.id.id_microchip_layout).setBackground(getResources().getDrawable(R.drawable.table_top_bg));
        findViewById(R.id.id_watch_layout).setBackground(getResources().getDrawable(R.drawable.table_bottom_bg));
        findViewById(R.id.id_medicine_layout).setBackground(getResources().getDrawable(R.drawable.table_top_bg));
        findViewById(R.id.id_flea_layout).setBackground(getResources().getDrawable(R.drawable.table_middle_bg));
        findViewById(R.id.id_injection_layout).setBackground(getResources().getDrawable(R.drawable.table_middle_bg));
        findViewById(R.id.id_rabies_layout).setBackground(getResources().getDrawable(R.drawable.table_middle_bg));
        findViewById(R.id.id_diagnose_layout).setBackground(getResources().getDrawable(R.drawable.table_bottom_bg));

        Button btn = (Button) findViewById(R.id.id_dog_remove_btn);

        btn.setVisibility(View.VISIBLE);
        btn.setText(getResources().getString(R.string.setting_sure));
    }

    /**
     * onclick event
     * @param v
     */
    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()) {
        case R.id.id_title_back_img :
            finish();

            break;

        case R.id.id_dog_remove_btn :
            showWaitingDialog();
            DogDeviceStationRepository.getInstance().addDogFromNet(DogDeviceStationRepository.REQUEST_FROM_DOG_SURE,
                    dogInfo);

            break;

        default :
            break;
        }
    }
}
