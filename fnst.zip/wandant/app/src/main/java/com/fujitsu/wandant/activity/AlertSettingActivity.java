package com.fujitsu.wandant.activity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.adapter.DeviceDetailAdapter;
import com.fujitsu.wandant.ble.BleHandler;
import com.fujitsu.wandant.ble.DeviceHandler;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.model.DeviceModel;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.net.model.Station;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.*;
import com.fujitsu.wandant.view.ListViewNoScroll;
import com.fujitsu.wandant.view.ToastManager;
import com.kyleduo.switchbutton.SwitchButton;
import rx.Observable;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func0;
import rx.functions.Func1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by wangc.fnst on 2015/10/16.
 */
public class AlertSettingActivity extends BaseActivity implements OnModelFinishedListener, CompoundButton.OnCheckedChangeListener {

    private static final String LOG_TAG = AlertSettingActivity.class.getName();
    @Bind(R.id.id_alert_switch)
    SwitchButton alertSwitch;
    @Bind(R.id.id_station_layout)
    LinearLayout stationLayout;
    @Bind(R.id.id_temp_value_txt)
    TextView tempTxt;
    @Bind(R.id.id_humi_value_txt)
    TextView humiTxt;
    @Bind(R.id.id_devices_list)
    ListViewNoScroll listView;

    private DeviceDetailAdapter adapter;
    private List<DeviceItem> mData;
    private List<Dog> dogs = new ArrayList<>();
    private List<DeviceModel> devices = new ArrayList<>();
    private List<Station> stations = new ArrayList<>();
    private Map<Integer,DeviceModel> dogDeviceMap = new HashMap<>();
    private String hyphen;
    private String tempUnit;
    private String percentUnit;
    private DeviceHandler handler;
    private Subscription subscription;
    /** bluetooth adapter */
    private BluetoothAdapter bluetoothAdapter;
    /** request flag to open bluetooth function in the phone */
    private static final int REQUEST_OPEN_BLUETOOTH = 2;
    private static final int REQUEST_DEVICE_SETTING = 4;

    @Override
    public String getTitleName() {
        return getString(R.string.alert_set);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        hyphen = getResources().getString(R.string.hyphen);
        tempUnit = getResources().getString(R.string.temperature_unit);
        percentUnit = getResources().getString(R.string.percent_unit);
        handler = new DeviceHandler();
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_DOG_DEVICE, this);
        initView();
    }

    @Override
    protected void onStart() {
        super.onStart();
        createData();
    }

    private void initView(){
        initAdapter();
        findViewById(R.id.id_station_humi_layout).setOnClickListener(this);
        findViewById(R.id.id_station_temp_layout).setOnClickListener(this);
        alertSwitch.setOnCheckedChangeListener(this);
        alertSwitch.setChecked(UserUtils.getInstance().isAlertEnable());
    }

    private void initAdapter() {
        mData = new ArrayList<>();
        adapter = new DeviceDetailAdapter(mData,this);
        adapter.setListener(this);
        listView.setAdapter(adapter);
    }

    private void createData(){
        DogDeviceStationRepository.getInstance().loadDogsFromDb(DogDeviceStationRepository.REQUEST_FROM_DOG_DEVICE);
        DogDeviceStationRepository.getInstance().loadStationsFromDb(DogDeviceStationRepository.REQUEST_FROM_DOG_DEVICE);
    }

    /**
     * initBluetooth
     *
     */
    private void initBluetooth() {
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);

        bluetoothAdapter = manager.getAdapter();

        if (null == bluetoothAdapter) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.bluetooth_error));
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

                startActivityForResult(intent, REQUEST_OPEN_BLUETOOTH);
            } else {
                getDataFromBle();
            }
        }
    }

    private void getDataFromBle(){
        if (null == mData || mData.isEmpty()){
            return;
        }


        Observable observable = Observable.just(true);
        for (int index = 0; index < mData.size(); index++){
            observable = getObservable(handler, index, observable);
        }
        observable.subscribe(new Action1() {
            @Override
            public void call(Object o) {
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });

//        final Integer[] itemArray = new Integer[1];
//        subscription = Observable.from(mData).flatMap(new Func1<DeviceItem, Observable<DeviceUtil.DeviceSetting>>() {
//            @Override
//            public Observable<DeviceUtil.DeviceSetting> call(DeviceItem deviceItem) {
//                itemArray[0] = mData.indexOf(deviceItem);
//                return handler.getDeviceSettingFromBle(deviceItem.bdid);
//            }
//        }).subscribe(new Action1<DeviceUtil.DeviceSetting>() {
//            @Override
//            public void call(DeviceUtil.DeviceSetting deviceSetting) {
//                if (Constants.NUMBER_INVALID != itemArray[0]) {
//                    DeviceItem item = mData.get(itemArray[0]);
//                    item.tempValue = deviceSetting.getTemp();
//                    item.humiValue = deviceSetting.getHumi();
//                    DogDeviceStationRepository.getInstance().updateSettingOfDeviceByBdid(item.bdid, item.tempValue,
//                            item.humiValue);
//                    adapter.notifyDataSetChanged();
//                }
//            }
//        }, new Action1<Throwable>() {
//            @Override
//            public void call(Throwable throwable) {
//
//            }
//        });
    }

    private Observable<Boolean> getObservable(final DeviceHandler handler,final int index, Observable<Boolean> observable) {
        return observable.flatMap(new Func1<Boolean, Observable<DeviceUtil.DeviceSetting>>() {
            @Override
            public Observable<DeviceUtil.DeviceSetting> call(Boolean isBoolean) {
//                indexArray[0] = deviceList.indexOf(device);
                String bdid = BDIDUtils.addMark4BDID(mData.get(index).bdid);
                if (!BluetoothAdapter.checkBluetoothAddress(bdid)) {
                    return Observable.just(null);
                } else {
                    return handler.getDeviceSettingFromBle(bdid).timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS);
                }
            }
        }).first().flatMap(new Func1<DeviceUtil.DeviceSetting, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(DeviceUtil.DeviceSetting deviceSetting) {
                if (Constants.NUMBER_INVALID != index && null != deviceSetting) {
                    refreshDeviceSetting(deviceSetting, index);
                }
                handler.disconnect();
                return Observable.just(true);
            }
        }, new Func1<Throwable, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Throwable throwable) {
                handler.disconnect();
                return Observable.just(true);
            }
        }, new Func0<Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call() {
                handler.disconnect();
                return Observable.just(true);
            }
        });
    }

    private void refreshDeviceSetting(final DeviceUtil.DeviceSetting deviceSetting, final int index) {
        Logger.d(LOG_TAG, "get device setting = " + GsonUtil.getInstance().toJson(deviceSetting));
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                DeviceItem item = mData.get(index);
                item.tempValue = deviceSetting.getTemp();
                item.humiValue = deviceSetting.getHumi();
                mData.set(index, item);
                DogDeviceStationRepository.getInstance().updateSettingOfDeviceByBdid(item.bdid, item.tempValue,
                        item.humiValue);
                adapter.refreshList(mData);
            }
        });
    }


    /**
     * onActivityResult
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK){
            switch (requestCode){
                case REQUEST_OPEN_BLUETOOTH:
                    getDataFromBle();
                    break;
                case REQUEST_DEVICE_SETTING:
                    refreshDeviceInfo(data);
                    break;
                default:
                    break;
            }
        }
    }

    private void refreshDeviceInfo(Intent data) {
        Serializable serializable = data.getSerializableExtra(Constants.EXTRA_DEVICE_MODEL);
        if (null != serializable){
            DeviceModel deviceModel = (DeviceModel) serializable;
            for (int index = 0; index < mData.size(); index ++){
                DeviceItem item = mData.get(index);
                if(!StringUtils.isBlank(item.bdid) && item.bdid.equals(deviceModel.getBdid())){
                    item.tempValue = deviceModel.getTemperature();
                    item.humiValue = deviceModel.getHumidity_down();
                    mData.set(index, item);
                    adapter.refreshList(mData);
                    break;
                }
            }
        }
    }


    @Override
    public int getLayout() {
        return R.layout.devices_set;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_station_humi_layout:
            case R.id.id_station_temp_layout:
                Intent intent = new Intent();
                intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,Constants.ACTIVITY_FROM_SETTING_ALERT_LIST);
                intent.putExtra(Constants.EXTRA_STATION, stations.get(0));
                intent.setClass(this,StationTempAndHumiditySettingActivity.class);
                startActivity(intent);
                break;
            case R.id.id_device_humi_layout:
            case R.id.id_device_temp_layout:
                if (null != v.getTag()){
                    //todo add login when dog doesn't have device
                    int position = (int) v.getTag();
                    if (position >= dogs.size()){
                        return;
                    }
                    Integer dogId = dogs.get(position).getDog_id();
                    if (null != dogId && dogDeviceMap.containsKey(dogId)){
                        Intent deviceIntent = new Intent();
                        deviceIntent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,Constants.ACTIVITY_FROM_SETTING_ALERT_LIST);
                        deviceIntent.putExtra(Constants.EXTRA_DOG, dogs.get(position));
                        deviceIntent.putExtra(Constants.EXTRA_DEVICE_MODEL, dogDeviceMap.get(dogId));
                        deviceIntent.setClass(this,DeviceSettingActivity.class);
                        startActivityForResult(deviceIntent, REQUEST_DEVICE_SETTING);
                    }
                }
                break;
        }
    }


    @Override
    public void success(Object result, int mode) {
        if (mode == DogDeviceStationRepository.LOAD_ALL_INFO_FROM_DB_MODE){
            dogs = (List<Dog>)result;
            if (null != dogs && dogs.size() > 0){
                for (Dog model:dogs){
                    Object device = DogDeviceStationRepository.getInstance().searchDeviceByDogId(model.getDog_id(),true);
                    if (null != device){
                        devices.add((DeviceModel)device);
                        dogDeviceMap.put(model.getDog_id(), (DeviceModel) device);
                        DeviceItem item = new DeviceItem();
                        item.name = model.getName();
                        item.bdid = ((DeviceModel)device).getBdid();
                        item.humiValue = ((DeviceModel)device).getHumidity_down() == null ? 0:((DeviceModel)device).getHumidity_down();
                        item.tempValue = ((DeviceModel)device).getTemperature() == null ? 0 :((DeviceModel)device).getTemperature();
                        mData.add(item);
                    }else{
                        DeviceItem item = new DeviceItem();
                        item.name = model.getName();
                        mData.add(item);
                    }
                }
                initBluetooth();
            }
        }else if (mode == DogDeviceStationRepository.LOAD_STATIONS_FROM_DB_MODE){
            stations = (List<Station>) result;
            if (null != stations && stations.size() > 0){
                stationLayout.setVisibility(View.VISIBLE);
                Integer temp = stations.get(0).getTemperature();
                Integer humi = stations.get(0).getHumidity_down();
                tempTxt.setText((temp== null ? hyphen :temp) + tempUnit );
                humiTxt.setText((humi== null ? hyphen :humi) + percentUnit );
            }else{
                stationLayout.setVisibility(View.GONE);
            }
        }

    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_DOG_DEVICE);
        if (null != subscription){
            subscription.unsubscribe();;
            subscription = null;
        }
        super.onDestroy();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        UserUtils.getInstance().setAlertAbility(isChecked);
        if (null != handler){
            handler.disconnect();
        }

    }

    public class DeviceItem{
        public String name;
        public String bdid;
        public int dogId;
        public int tempValue;
        public int humiValue;
    }
}
