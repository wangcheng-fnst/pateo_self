//******************************************************************
//* わんダント2システム
//******************************************************************
/*
 *	わんダント2Android
 *	BleSelectionActivity.java
 *
 *	変更日			変更者				障害No／仕様変更No
 *	2015/10/12 		FNST)Chenjie    	新規作成
 *
 */
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************

package com.fujitsu.wandant.activity;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.*;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelUuid;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.adapter.BleDeviceAdapter;
import com.fujitsu.wandant.ble.DeviceHandler;
import com.fujitsu.wandant.db.DaoSession;
import com.fujitsu.wandant.db.DataBaseManager;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.model.dao.DeviceModelDao;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Device;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ToastManager;
import rx.Subscription;
import rx.functions.Action1;

import java.util.ArrayList;
import java.util.List;

/**
 * BleSelectionActivity
 */
public class BleSelectionActivity extends BaseActivity
        implements ListView.OnItemClickListener, OnModelFinishedListener {

    /** max time to scan blurtooth */
//    private static final long SCAN_PERIOD = 30000;

    /** log tag */
    private static final String LOG_TAG = BleSelectionActivity.class.getName();

    /** request flag to open bluetooth function in the phone */
    private static final int OPEN_BLUETOOTH_REQUEST = 1;

    /** bluetooth list */
    private List<BluetoothDevice> deviceList = new ArrayList<BluetoothDevice>();



    /** callback when scan bluetooth devices*/
    private BluetoothAdapter.LeScanCallback leScanCallback = new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(final BluetoothDevice device, int rssi, final byte[] scanRecord) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
//                  try {
//                      String da = new String(scanRecord,"UTF-8");
//                      Logger.e(LOG_TAG,da);
//                  } catch (UnsupportedEncodingException e) {
//                      e.printStackTrace();
//                  }
                    if ((deviceList.indexOf(device) == -1)
                            && (0 == deviceDao.queryBuilder().where(
                                DeviceModelDao.Properties.Bdid.eq(device.getAddress())).count())) {
                        deviceList.add(device);
                        deviceAdapter.notifyDataSetChanged();
                    }
                }
            });
        }
    };


    /** listview to show bluetooth devices */
    @Bind(R.id.id_bluetooth_lv)
    ListView deviceListView;

    /** register progress view */
    @Bind(R.id.id_progress_flag)
    View progressView;

    /** sure button */
    @Bind(R.id.id_sure_btn)
    Button sureBtn;

    /** adapter to show bluetooth devices  */
    private BleDeviceAdapter deviceAdapter;

    /** bluetooth adapter */
    private BluetoothAdapter bluetoothAdapter;

    /** thread to scan bluetooth */
    private Thread scanThread;

    /** Context */
    private Context context;

    /** dog info */
    private Dog dog;

    /** device info */
    private Device device;

    /** dao to deal with info in database */
    private DeviceModelDao deviceDao;

    /** handler to connect, read and write date to wandant deivice */
    private DeviceHandler deviceHandler;

    private Subscription subscription;


    /**
     *
     * @return title
     */
    @Override
    public String getTitleName() {
        return getResources().getString(R.string.device_setting);
    }

    /**
     *
     * @return head url
     */
    @Override
    public String getTitleHeadUrl() {
        return null;
    }


    private BluetoothLeScanner mLEScanner;
    private ScanSettings settings;
    private List<ScanFilter>    filters;
    private ScanCallback mScanCallback;

    public static  String deviceVersion = null;

    /**
     * onCreate
     * @param savedInstanceState
     */
    @Override
    public void onCreateView(Bundle savedInstanceState) {
        context = this;
        dog = (Dog) getIntent().getSerializableExtra(Constants.EXTRA_DOG);
        DaoSession session = DataBaseManager.getInstance().getDaoSession();
        deviceHandler = new DeviceHandler();
        deviceDao = session.getDeviceModelDao();
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_DEVICE_ADD, this);
        initDevice();
        bindViews();
        initBluetooth();
    }

    /**
     * init device info
     *
     */
    private void initDevice() {
        device = new Device();
        device.setUser_id(UserUtils.getInstance().loadUser().getUser_id());
        device.setDog_id(dog.getDog_id());

    }

    /**
     * @return layout id of activity
     */
    @Override
    public int getLayout() {
        return R.layout.activity_ble_select;
    }

    /**
     * onStart
     *
     */
    @Override
    protected void onStart() {
        super.onStart();

    }

    /**
     * onPause
     *
     */
    @Override
    protected void onPause() {
        super.onPause();
    }

    /**
     * onDestroy
     *
     */
    @Override
    protected void onDestroy() {
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_DEVICE_ADD);
        if (null != deviceHandler){
            deviceHandler.disconnect();
        }
        stopScanThread();
        if (null != subscription){
            subscription.unsubscribe();
            subscription = null;
        }
        super.onDestroy();
    }

    /**
     * bind views of the activity
     *
     */
    private void bindViews() {
        if (activityFromFlag == Constants.ACTIVITY_FROM_REGISTER) {
            progressView.setVisibility(View.VISIBLE);
            sureBtn.setText(getResources().getString(R.string.next_step));
            isBackable = false;
        } else if (activityFromFlag == Constants.ACTIVITY_FROM_SETTING_DEVICE_LIST
                || activityFromFlag == Constants.ACTIVITY_FROM_SETTING_DOG_ADD){
            progressView.setVisibility(View.GONE);
            sureBtn.setText(getResources().getString(R.string.setting_sure));
            isBackable = true;
        } else {
            progressView.setVisibility(View.GONE);
            sureBtn.setText(getResources().getString(R.string.setting_sure));
            isBackable = false;
        }

        deviceAdapter = new BleDeviceAdapter(this, deviceList);
        deviceListView.setAdapter(deviceAdapter);
        deviceListView.setOnItemClickListener(this);
        sureBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        sureBtn.setOnClickListener(this);
    }

    /**
     * initBluetooth
     *
     */
    private void initBluetooth() {
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);

        bluetoothAdapter = manager.getAdapter();

        if (null == bluetoothAdapter) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.bluetooth_error));
        } else {
            toApi21();
            scanLeDevice();
        }
    }

    /**
     * enable or disable the sure button
     *
     * @param isEnable
     */
    private void setBtnStates(boolean isEnable) {
        if (isEnable) {
            sureBtn.setEnabled(true);
            sureBtn.setBackgroundResource(R.drawable.btn_sure);
        } else {
            sureBtn.setEnabled(false);
            sureBtn.setBackgroundResource(R.drawable.btn_sure_disable);
        }
    }

    /**
     * decide which activity to go
     *
     */
    private void goToNextActivity() {
        switch (activityFromFlag) {
            case Constants.ACTIVITY_FROM_SETTING_DEVICE_LIST :
                finish();
                break;
            case Constants.ACTIVITY_FROM_MAIN :
                finish();
                Intent mainIntent = new Intent();
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                mainIntent.setClass(this, MainActivity.class);
                startActivity(mainIntent);
                break;
            case Constants.ACTIVITY_FROM_SETTING_DOG_ADD:
                goToSettingActivity();
                break;
            case Constants.ACTIVITY_FROM_REGISTER :
                Intent deviceIntent = new Intent();
                deviceIntent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG, activityFromFlag);
                deviceIntent.setClass(this, StationSearchActivity.class);
                startActivity(deviceIntent);
                break;
            default :
                break;
        }
    }

    /**
     * scan the bluetooth devices
     *
     */
    private void scanLeDevice() {
        setBtnStates(false);

        if (!bluetoothAdapter.isEnabled()) {
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

            startActivityForResult(intent, OPEN_BLUETOOTH_REQUEST);
        } else {
            deviceList.clear();
            deviceAdapter.notifyDataSetChanged();
            scanThread = new Thread() {
                @Override
                public void run() {
                    //todo change the code


                    if  (Build.VERSION.SDK_INT  <   21)
                    {
                        bluetoothAdapter.startLeScan(leScanCallback);
                    }
                    else
                    {
                        if(mScanCallback!=null){
                           mLEScanner.startScan(mScanCallback);
                        }
                    }

//                  UUID[] array = new UUID[2];
//                  array[0] = Constants.DEVICE_IOT_SERVICE1;
//                  array[1] = Constants.DEVICE_IOT_SERVICE2;
//                  bluetoothAdapter.startLeScan(array,leScanCallback);
//                    try {
//                        Thread.sleep(SCAN_PERIOD);
//                        stopScanThread();
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
                }
            };
            scanThread.start();
        }
    }


    /**
     *
     */
    @SuppressLint("NewApi")
    private void toApi21() {
        if  (Build.VERSION.SDK_INT  >=  21)
        {
            mScanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
            /*  Connect to  device  found   */
                   // Log.i("callbackType", String.valueOf(callbackType));

                    BluetoothDevice device = result.getDevice();
                    if ((deviceList.indexOf(device) == -1)
                            && (0 == deviceDao.queryBuilder().where(
                            DeviceModelDao.Properties.Bdid.eq(device.getAddress())).count())) {
                        deviceList.add(device);
                        deviceAdapter.notifyDataSetChanged();
                    }


                }

                @Override
                public void onBatchScanResults(List<ScanResult> results) {
            /*  Process a   batch   scan    results */
                    for (ScanResult sr : results) {
                       // Log.i("Scan Item:   ", sr.toString());
                    }
                }
            };
            mLEScanner = bluetoothAdapter.getBluetoothLeScanner();
            ScanFilter deviceFilter = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(Constants.STATION_IOT_SERVICE)).build();
            // settings = new ScanSettings.Builder().setScanMode(ScanSettings.CALLBACK_TYPE_ALL_MATCHES).build();
            settings = new ScanSettings.Builder().build();
            filters = new ArrayList<ScanFilter>();
            filters.add(deviceFilter);
        }
    }

    /**
     * stop scanning the bluetooth devices
     *
     */
    private void stopScanThread() {
        if (scanThread != null) {
            scanThread.interrupt();
            if  (Build.VERSION.SDK_INT  <   21)
            {
                if (bluetoothAdapter != null && leScanCallback != null) {
                    bluetoothAdapter.stopLeScan(leScanCallback);
                }

            } else
            {
                if (mLEScanner != null && mScanCallback != null) {
                    mLEScanner.stopScan(mScanCallback);
                }

            }
            scanThread = null;
        }
    }

    /**
     * register wandant device
     *
     *
     * @param address
     */
    private void registerDevice(final String address) {
        Log.e("huangc","####  registerDevice  ####  ");
        Log.e("huangc","####  registerDevice  address=   "+address);
        device.setBdid(address);
        showAlwaysWaitingDialog();
        int leg = Constants.NUMBER_INVALID;
        if (null != dog.getLeg_size()){
            leg = dog.getLeg_size();
        }

        subscription = deviceHandler.registerDevice(address, leg, Constants.DEVICE_HUMI_DEFAULT,
                                     Constants.DEVICE_TEMP_DEFAULT).subscribe(new Action1<Boolean>() {
            @Override
            public void call(Boolean aBoolean) {
                hideWaitingDialog();
                deviceHandler.disconnect();
                //设置版本号
                if(deviceVersion!=null&&!deviceVersion.isEmpty()){
                    String major = StringUtils.getDeviceVersion(deviceVersion,0);
                    String minor = StringUtils.getDeviceVersion(deviceVersion,1);
                }else{
                    device.setMajor(0);
                    device.setMinor(0);
                }
                DogDeviceStationRepository.getInstance().addDeviceFromNet(
                    DogDeviceStationRepository.REQUEST_FROM_DEVICE_ADD, dog.getDog_id(), device);
                Logger.d(LOG_TAG, "register device address=" + address + " success");
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
                hideWaitingDialog();
                Logger.e(LOG_TAG, "register device address=" + address + " failed " + throwable.getMessage());
            }
        });

        //todo delete the code
//        DogDeviceStationRepository.getInstance().addDeviceFromNet(
//                DogDeviceStationRepository.REQUEST_FROM_DEVICE_ADD, dog.getDog_id(), device);
    }

    /**
     * onActivityResult
     *
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == OPEN_BLUETOOTH_REQUEST) {
            if (resultCode == RESULT_OK) {
                scanLeDevice();
            } else if (resultCode == RESULT_CANCELED) {}
        }
    }

    /**
     * deal with the item click event if the listview
     * @param parent
     * @param view
     * @param position
     * @param id
     */
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        deviceAdapter.setSelectPosition(position);
        setBtnStates(true);
    }

    /**
     * deal with the event of view clck event
     * @param v
     */
    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()) {
            return;
        }
        switch (v.getId()){
            case R.id.id_title_back_img:
                if (activityFromFlag == Constants.ACTIVITY_FROM_SETTING_DOG_ADD){
                    goToSettingActivity();
                } else {
                    onBackPressed();
                }
                break;
            case R.id.id_sure_btn:
                //            stopScanThread();
                if ((deviceAdapter.getSelectPosition() >= 0) && (deviceAdapter.getSelectPosition() < deviceList.size())) {
                    registerDevice(deviceList.get(deviceAdapter.getSelectPosition()).getAddress());
                }
                break;
            default:
                break;
        }
    }

    private void goToSettingActivity(){
        Intent intent = new Intent();
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setClass(this, SettingActivity.class);
        startActivity(intent);
    }

    /**
     * rewrite method of activity to deal with the event when user click the back button of the phone
     * @param keyCode
     * @param event
     *
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && !isBackable) {
            return true;
        }
        if (activityFromFlag == Constants.ACTIVITY_FROM_SETTING_DOG_ADD){
            goToSettingActivity();
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * After add a device to server,
     * get response from server success, go to the next view
     * @param result
     * @param mode
     */
    @Override
    public void success(Object result, int mode) {
        goToNextActivity();
        hideWaitingDialog();
    }

    /**
     * After add a device to server,
     * get response from server failed
     * @param errorCode
     * @param errorMsg
     */
    @Override
    public void failed(String errorCode, String errorMsg) {
        deviceAdapter.setSelectPosition(Constants.NUMBER_INVALID);
        showErrorMessage(errorCode);
        hideWaitingDialog();
    }

    /**
     * After add a device to server,
     * get the response of server internal error
     *
     */
    @Override
    public void internalFailure(String errorMsg) {
        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
        hideWaitingDialog();
    }
}

