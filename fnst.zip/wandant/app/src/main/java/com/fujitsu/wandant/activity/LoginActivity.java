package com.fujitsu.wandant.activity;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.WandantApplication;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.net.AccountRepository;
import com.fujitsu.wandant.net.model.UserFromNet;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.GsonUtil;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ProgressDialog;
import com.fujitsu.wandant.view.ToastManager;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by wangc.fnst on 2015/10/14.
 */
public class LoginActivity extends NewBaseActivity implements View.OnClickListener,OnModelFinishedListener{

    private EditText loginNameEdit;
    private View deleteView;
    private EditText loginPasswordEdit;
    private Button loginBtn;
    private TextView registerTxt;
    private View firstBgView,secondBgView,thirdBgView,forthBgView;
    private int requestType = AccountRepository.REQUEST_FROM_LOGIN_TYPE;
    protected ProgressDialog dialog;
    private int currentPage = 1;
    private android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if (currentPage == 1){
                ObjectAnimator.ofFloat(firstBgView,"alpha",1f,0f).setDuration(5000).start();
                ObjectAnimator.ofFloat(secondBgView,"alpha",0f,1f).setDuration(5000).start();
                currentPage++;
                sendEmptyMessageDelayed(1,10000);
            }else if (currentPage == 2){
                ObjectAnimator.ofFloat(secondBgView,"alpha",1f,0f).setDuration(5000).start();
                ObjectAnimator.ofFloat(thirdBgView,"alpha",0f,1f).setDuration(5000).start();
                currentPage++;
                sendEmptyMessageDelayed(1,10000);
            }else if (currentPage == 3){
                ObjectAnimator.ofFloat(thirdBgView,"alpha",1f,0f).setDuration(5000).start();
                ObjectAnimator.ofFloat(forthBgView,"alpha",0f,1f).setDuration(5000).start();
                currentPage++;
                sendEmptyMessageDelayed(1,10000);
            }else if (currentPage == 4){
                ObjectAnimator.ofFloat(forthBgView,"alpha",1f,0f).setDuration(5000).start();
                ObjectAnimator.ofFloat(firstBgView,"alpha",0f,1f).setDuration(5000).start();
                currentPage = 1;
                sendEmptyMessageDelayed(1,10000);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AccountRepository.getInstance().register(requestType,this);
        setContentView(R.layout.login_layout);
        initView();
    }

    private void initView(){
        loginNameEdit = (EditText) findViewById(R.id.id_name_edit);
        deleteView  = findViewById(R.id.id_name_delete_iv);
        loginPasswordEdit = (EditText) findViewById(R.id.id_password_edit);
        loginBtn = (Button) findViewById(R.id.id_login_btn);
        registerTxt = (TextView) findViewById(R.id.id_register_txt);
        firstBgView = findViewById(R.id.id_login_bg_first);
        secondBgView = findViewById(R.id.id_login_bg_second);
        thirdBgView = findViewById(R.id.id_login_bg_third);
        forthBgView = findViewById(R.id.id_login_bg_forth);

        loginNameEdit.setOnFocusChangeListener(new View.OnFocusChangeListener(){
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                setDeleteViewStatus(loginNameEdit.getText().toString(), loginNameEdit.hasFocus());
            }
        });

        loginPasswordEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    loginPasswordEdit.setText("");
                }
            }
        });

        loginBtn.setOnClickListener(this);
        deleteView.setOnClickListener(this);
        registerTxt.setOnClickListener(this);
        loginBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        loginNameEdit.addTextChangedListener(textWatcher);
        loginPasswordEdit.addTextChangedListener(textWatcher);

//[Test Account 4 huangc]
//        loginNameEdit.setText("Testhc@wandant.com");
//        loginPasswordEdit.setText("asdf1234");
        //Test Account 4 Graph
//        loginNameEdit.setText("a@b.cn");
//        loginPasswordEdit.setText("q111111");

//        loginNameEdit.setText("sthyouka521259@gmail.com");
//        loginPasswordEdit.setText("Hyouka521259");

//        loginNameEdit.setText("c@qq.com");
//        loginPasswordEdit.setText("q111111");
//        loginNameEdit.setText("kechang@test.com");
//        loginPasswordEdit.setText("123456asdf");


        loginNameEdit.setText("didida@cn.fujitsu.com");
        loginPasswordEdit.setText("12@qq.com");

        loginNameEdit.setSelection(loginNameEdit.length());
        handler.sendEmptyMessageDelayed(1, 5000);

    }


    private void setBtnStates(boolean isEnable){
        if (isEnable){
            loginBtn.setEnabled(true);
            loginBtn.setBackgroundResource(R.drawable.btn_sure);
        } else {
            loginBtn.setEnabled(false);
            loginBtn.setBackgroundResource(R.drawable.btn_sure_disable);
        }
    }

    private void checkIfOk(){
        String name = loginNameEdit.getText().toString();
        if (!StringUtils.isBlank(name) &&
                !StringUtils.isBlank(loginPasswordEdit.getText().toString())){
            setBtnStates(true);
        }else{
            setBtnStates(false);
        }
        setDeleteViewStatus(name, loginNameEdit.hasFocus());
    }

    private void setDeleteViewStatus(String name, boolean isFocus) {
        if (null != name && !name.equals("") && isFocus){
            deleteView.setVisibility(View.VISIBLE);
        } else {
            deleteView.setVisibility(View.GONE);
        }
    }


    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            checkIfOk();
        }
    };



    @Override
    public void onClick(View v) {
        super.onClick(v);
//        if (ApplicationUtils.isFastClick()){
//            return;
//        }
        int id  = v.getId();
        if (id == R.id.id_login_btn){
            //login
            //init token to imagelaoder
            String email = loginNameEdit.getText().toString();
            String password = loginPasswordEdit.getText().toString();
            showWaitingDialog();
            if (!StringUtils.isBlank(email) && !StringUtils.isBlank(password)){
                AccountRepository.getInstance().login(requestType,email,password);
            }
       }else if (id == R.id.id_register_txt){
            Intent intent = new Intent(this, AgreementWithoutAccountActivity.class);
            intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,Constants.ACTIVITY_FROM_REGISTER);
            startActivity(intent);
        } else if (id == R.id.id_name_delete_iv){
            loginNameEdit.setText("");
        }
    }

    @Override
    protected void onDestroy() {
        AccountRepository.getInstance().unRegister(requestType);
        super.onDestroy();
    }

    @Override
    public void success(Object result, int mode) {
        hideWaitingDialog();
        if (AccountRepository.LOGIN_MODE == mode){
            UserFromNet userFromNet = (UserFromNet) result;

            if (userFromNet.getWandant_sign_flag().equals(Integer.valueOf(1))) {
                UserUtils.getInstance().saveUser(userFromNet);
                Map<String,String> header = new HashMap<>();
                header.put("X-Auth-Token", userFromNet.getToken());
                WandantApplication.getInstance().initImageLoader(header);
                startActivity(new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
                finish();
            }else {
                Intent intent = new Intent(this, AgreementWithAccountActivity.class);
                intent.putExtra(Constants.EXTRA_VALUE, GsonUtil.getInstance().toJson(userFromNet));
                intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,Constants.ACTIVITY_FROM_REGISTER);
                startActivity(intent);
                finish();
            }
        }
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        ToastManager.getInstance().showFail(getResources().getString(R.string.error_login));
        loginPasswordEdit.setText("");
        hideWaitingDialog();
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
        loginPasswordEdit.setText("");
        hideWaitingDialog();
    }

//    public void showWaitingDialog() {
//        if (dialog == null) {
//            dialog = new ProgressDialog(this);
//        }
//        dialog.setCancelable(false);
//        dialog.show();
//        Observable.timer(15, TimeUnit.SECONDS).subscribe(new Action1<Long>() {
//            @Override
//            public void call(Long aLong) {
//                hideWaitingDialog();
//            }
//        });
//    }
//
//    public void hideWaitingDialog() {
//        if (dialog != null && dialog.isShowing()) {
//            dialog.dismiss();
//        }
//    }

}
