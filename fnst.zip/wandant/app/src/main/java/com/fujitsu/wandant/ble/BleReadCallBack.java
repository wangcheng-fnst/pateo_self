package com.fujitsu.wandant.ble;

/**
 * Created by chenjie.fnst on 2015/10/20.
 */
public abstract class BleReadCallBack {

    public String name;
    public BleReadCallBack(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
    public abstract void onCharacteristicRead(byte[] result, String uuid);

}
