//******************************************************************
//* わんダント2システム
//******************************************************************
/*
*      わんダント2Android
*      AgreementWithAccountActivity.java
*
*      変更日                     変更者                             障害No／仕様変更No
*      15/10/21                FNST)Chenjie            新規作成
*
*/
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************
package com.fujitsu.wandant.activity;

import android.content.Intent;

import android.graphics.Bitmap;

import android.net.Uri;

import android.os.Bundle;

import android.view.View;

import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import android.widget.Button;

import butterknife.Bind;

import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;

import com.github.lzyzsd.jsbridge.BridgeWebView;
import com.github.lzyzsd.jsbridge.DefaultHandler;

/**
 * AgreementWithAccountActivity
 */
public class AgreementWithAccountActivity extends BaseActivity {

    /** WebViewClient for user agreement */
    private BridgeWebView.BridgeWebViewClient userAgreeClient = null;

    /** webview loading flag */
    private boolean isUserLoadFinished = false;

    /** cookie string */
    private String cookie = null;

    /** webview of user agreement */
    @Bind(R.id.id_user_agree_web)
    BridgeWebView userAgreeWeb;

    /** agree button */
    @Bind(R.id.id_agree_btn)
    Button agreeBtn;

    /** cancel button */
    @Bind(R.id.id_cancel_btn)
    Button cancelBtn;

    /**
     * title's text
     * @return title's text
     */
    @Override
    public String getTitleName() {
        return getString(R.string.agreement_title);
    }

    /**
     * image's url
     * @return title's url
     */
    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    /**
     * onCreateView
     * @param savedInstanceState
     */
    @Override
    public void onCreateView(Bundle savedInstanceState) {
        agreeBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        agreeBtn.setOnClickListener(this);
        agreeBtn.setEnabled(true);
        cancelBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        cancelBtn.setOnClickListener(this);
        cancelBtn.setEnabled(true);
        cancelBtn.setVisibility(View.GONE);
        cookie = getIntent().getStringExtra(Constants.EXTRA_VALUE);
        initClient();
        showWaitingDialog();
        userAgreeWeb.setVerticalScrollBarEnabled(false);
        userAgreeWeb.setHorizontalScrollBarEnabled(false);
        userAgreeWeb.getSettings().setTextZoom(100);
        userAgreeWeb.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        userAgreeWeb.setDefaultHandler(new DefaultHandler());
        userAgreeWeb.setWebChromeClient(new WebChromeClient());
        userAgreeWeb.setWebViewClient(userAgreeClient);
        userAgreeWeb.loadUrl(ApplicationUtils.getUserAgreementUrl());
    }

    /**
     * layout of activity
     * @return layout of activity
     */
    @Override
    public int getLayout() {
        return R.layout.activity_agreement_with_cloud;
    }

    /**
     * view click event
     * @param v
     */
    @Override
    public void onClick(View v) {
        super.onClick(v);

        if ((v.getId() == R.id.id_agree_btn) && (activityFromFlag == Constants.ACTIVITY_FROM_REGISTER)) {
            Intent intent = new Intent();
            intent.putExtra(Constants.EXTRA_VALUE, cookie);
            intent.putExtra(Constants.EXTRA_REGISTER_URL, ApplicationUtils.getRegisterUrlWithAccount());
            intent.setClass(this, UserRegisterWebViewActivity.class);
            startActivity(intent);
        }
    }

    /**
     * check if need to hide waiting dailaog
     *
     */
    public void checkHideLoadingDialog() {
        if (isUserLoadFinished) {
            hideWaitingDialog();
        }
    }

    /**
     * init webview client
     *
     */
    public void initClient() {
        userAgreeClient = userAgreeWeb.new BridgeWebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (ApplicationUtils.getUserAgreementUrl().equals(url)
                        || url.contains(ApplicationUtils.getErrorUrl())) {
                    return false;
                } else {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.VIEW");
                    Uri uri = Uri.parse(url);
                    intent.setData(uri);
                    startActivity(intent);
                    return true;
                }
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                isUserLoadFinished = true;
                checkHideLoadingDialog();
            }
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
//              Toast.makeText(context, context.getResources().getString(R.string.web_load_failed), Toast.LENGTH_SHORT).show();
            }
        };
    }
}
