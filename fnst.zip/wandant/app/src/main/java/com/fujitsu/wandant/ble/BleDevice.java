package com.fujitsu.wandant.ble;

import android.bluetooth.BluetoothDevice;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.utils.Constants;
import rx.Observable;

import java.util.LinkedList;
import java.util.UUID;

public abstract class BleDevice {

	protected static final UUID CLIENT_CHAR_CONFIG_UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB");

	protected static final int DISCONNECTED = 0;
	protected static final int CONNECTED = 1;
	protected static final int SERVICE_DISCOVERED = 2;
	protected static final int DISCOVERED_DISCONNECTED = 3;
	private static final String LOG_TAG = BleDevice.class.getName();

	protected BluetoothDevice mDevice;
	protected int mDeviceState = DISCONNECTED;
	protected BleDeviceCallback mDevCallback;

	public abstract Observable<ResponseData> checkConnected();

	public abstract Observable getNotification(UUID serviceUuid, UUID childUUid);

	private enum BleRequestType {
		BRT_READ,
		BRT_WRITE
	}
	private class BleRequest {
		BleRequestType type;
		UUID srv_uuid;
		UUID ch_uuid;
		byte[] val;
		public BleRequest(BleRequestType t, UUID s, UUID c, byte[] v) {
			type = t;
			srv_uuid = s;
			ch_uuid = c;
			val = v;
		}
	};
	private LinkedList<BleRequest> mReqList = new LinkedList<BleRequest>();


	public class ResponseData{
		int type;
		boolean isOk;
		UUID srvUuid;
		UUID chUuid;
		byte[] val;
		int rssi;

		public ResponseData(int type, boolean isOk, UUID srvUuid, UUID chUuid, byte[] val, int rssi) {
			this.type = type;
			this.isOk = isOk;
			this.srvUuid = srvUuid;
			this.chUuid = chUuid;
			this.val = val;
			this.rssi = rssi;
		}

		public int getType() {
			return type;
		}

		public void setType(int type) {
			this.type = type;
		}

		public boolean isOk() {
			return isOk;
		}

		public void setIsOk(boolean isOk) {
			this.isOk = isOk;
		}

		public UUID getSrvUuid() {
			return srvUuid;
		}

		public void setSrvUuid(UUID srvUuid) {
			this.srvUuid = srvUuid;
		}

		public UUID getChUuid() {
			return chUuid;
		}

		public void setChUuid(UUID chUuid) {
			this.chUuid = chUuid;
		}

		public byte[] getVal() {
			return val;
		}

		public void setVal(byte[] val) {
			this.val = val;
		}

		public int getRssi() {
			return rssi;
		}

		public void setRssi(int rssi) {
			this.rssi = rssi;
		}
	}

	public interface ConnectionChangedCallBack {
		void onConnectionChanged(boolean is_connected);
	}
	public interface WriteCompleteCallBack {
		void onWriteComplete(UUID srv_uuid, UUID ch_uuid, boolean is_ok);
	}
	public interface ReadCompleteCallBack {
		void onReadComplete(UUID srv_uuid, UUID ch_uuid, byte[] val, boolean is_ok);
	}
	public interface CharacteristicChangeCallBack {
		void onCharacteristicChange(UUID srv_uuid, UUID ch_uuid, byte[] val);
	}
	public interface NotificationRegisteredCallBack {
		void onNotificationRegistered(UUID srv_uuid, UUID ch_uuid, boolean is_ok);
	}
	public interface ReadRssiCallBack {
		void onReadRssi(int rssi, boolean is_ok);
	}

	public static interface BleDeviceCallback {
		void onConnectionChanged(boolean is_connected);
		void onWriteComplete(UUID srv_uuid, UUID ch_uuid, boolean is_ok);
		void onReadComplete(UUID srv_uuid, UUID ch_uuid, byte[] val, boolean is_ok);
		void onCharacteristicChange(UUID srv_uuid, UUID ch_uuid, byte[] val);
		void onNotificationRegistered(UUID srv_uuid, UUID ch_uuid, boolean is_ok);
		void onReadRssi(int rssi, boolean is_ok);
	}

	public abstract void disableBT();
	public abstract void disconnect();
	public abstract boolean registerNotification(UUID srv_uuid, UUID ch_uuid);
	public abstract boolean read(UUID srv_uuid, UUID ch_uuid);
	public abstract boolean write(UUID srv_uuid, UUID ch_uuid, byte[] data);
	public abstract boolean readRssi();
	public abstract boolean isServiceDiscoveryed(UUID srv_uuid, UUID ch_uuid);

	public abstract Observable<ResponseData> registerNotificationObs(UUID srv_uuid, UUID ch_uuid);
	public abstract Observable<ResponseData> readObs(UUID srv_uuid, UUID ch_uuid);
	public abstract Observable<ResponseData> writeObs(UUID srv_uuid, UUID ch_uuid, byte[] data);
	public abstract Observable<ResponseData> readRssiObs();


	protected abstract boolean discoverServices();

	protected void modifyConnectionState(boolean connected) {
		Logger.i(LOG_TAG, "device connect status: " + connected + " ; mDeviceState " + mDeviceState);
		if (connected) {
			switch (mDeviceState) {
			case DISCONNECTED:
				mDeviceState = CONNECTED;
				discoverServices();
				break;
			case DISCOVERED_DISCONNECTED:
				//need redefine
				boolean serviceDiscoveryed = isServiceDiscoveryed(Constants.BLE_SERVICE_UUID, Constants.BLE_UUID_20);
				Logger.i(LOG_TAG, "serviceDiscoveryed  " + serviceDiscoveryed);
				if(serviceDiscoveryed){
					mDeviceState = SERVICE_DISCOVERED;
                    if(mDevCallback!=null){
                       mDevCallback.onConnectionChanged(true);
                    }
				}else{
					mDeviceState = CONNECTED;
					discoverServices();
				}
				break;
			}
		} else {
			switch (mDeviceState){
			case SERVICE_DISCOVERED:
				mDeviceState = DISCOVERED_DISCONNECTED;
                if(mDevCallback!=null){
                   mDevCallback.onConnectionChanged(false);
                }
				break;
			case CONNECTED:
				mDeviceState = DISCONNECTED;
                if(mDevCallback!=null){
                   mDevCallback.onConnectionChanged(false);
                }
				break;
			}
		}
	}

	public String getAddress() {
		return mDevice.getAddress();
	}

	public boolean isConnected(){
		return mDeviceState == SERVICE_DISCOVERED;
	}

	public void readCharacteristic(UUID srv_uuid, UUID ch_uuid) {
		if (mReqList.isEmpty()) {
			if (!read(srv_uuid, ch_uuid)) {
				mDevCallback.onReadComplete(srv_uuid, ch_uuid, null, false);
			}
		}
		BleRequest br = new BleRequest(BleRequestType.BRT_READ, srv_uuid, ch_uuid, null);
		mReqList.addLast(br);
	}

	public void writeCharacteristic(UUID srv_uuid, UUID ch_uuid, byte[] data) {
		Logger.i(LOG_TAG, "BleDevice mReqList " + mReqList.size());
//		for(int i=0; i<mReqList.size();i++){
//			Helper.logBytes("www", "mReqList ", mReqList.get(i).val);
//		}
		if (mReqList.isEmpty()) {
			if (!write(srv_uuid, ch_uuid, data)) {
				mDevCallback.onWriteComplete(srv_uuid, ch_uuid, false);
				return;
			}
		}
		BleRequest br = new BleRequest(BleRequestType.BRT_WRITE, srv_uuid, ch_uuid, data);
		mReqList.addLast(br);
	}

	protected void processNextRequest() {
		Logger.i(LOG_TAG, "processNextRequest ------------" + mReqList.size());
		if (null== mReqList||0 == mReqList.size()){
			return;
		}
		try {
			mReqList.removeFirst();
			while (!mReqList.isEmpty()) {
				BleRequest br = mReqList.getFirst();
				if (br.type == BleRequestType.BRT_READ) {
					if (!read(br.srv_uuid, br.ch_uuid)) {
                        if(mDevCallback!=null){
                           mDevCallback.onReadComplete(br.srv_uuid, br.ch_uuid, null, false);
                        }
					} else {
						break;
					}
				} else if (br.type == BleRequestType.BRT_WRITE) {
					if (!write(br.srv_uuid, br.ch_uuid, br.val)) {
                        if(mDevCallback!=null){
						  mDevCallback.onWriteComplete(br.srv_uuid, br.ch_uuid, false);
                        }
					} else {
						break;
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}	
	
	protected void clearRequest() {
		Logger.i(LOG_TAG, "clearRequest ------------");

        if(mReqList!=null){
           mReqList.clear();
        }
	}

}
