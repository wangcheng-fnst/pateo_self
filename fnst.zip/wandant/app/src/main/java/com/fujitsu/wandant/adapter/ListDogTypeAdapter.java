package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.model.DogIndexModel;
import com.fujitsu.wandant.model.DogTypeModel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chenjie.fnst on 2015/10/27.
 */
public class ListDogTypeAdapter extends BaseAdapter {

    private Context context;
    private List<DogIndexModel> list;
    private View.OnClickListener listener;

    public static final int GROUP_ID_KEY = 0;
    public static final int CHILD_ID_KEY = 1;

    public ListDogTypeAdapter(Context context,List<DogIndexModel> list){
        this.context =context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    public void setOnItemClickListener(View.OnClickListener listener){
        this.listener = listener;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public String[] getAlpha(){
        String[] array = new String[list.size()];
        for (int index = 0;index < list.size();index++){
            array[index] = list.get(index).getCategory();
        }
        return array;
    }

    class GroupViewHolder{
        TextView tvCategory;
        LinearLayout groupLayout;
    }

    class ChildViewHolder{
        TextView nameTV;
        ImageView isSelected;
        View divider;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        GroupViewHolder groupViewHolder = null;
        if (null == convertView){
            groupViewHolder = new GroupViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.listview_dog_type_item, parent, false);
            groupViewHolder.tvCategory = (TextView) convertView.findViewById(R.id.tvCategory);
            groupViewHolder.groupLayout = (LinearLayout) convertView.findViewById(R.id.llType);
            convertView.setTag(groupViewHolder);
        } else {
            groupViewHolder = (GroupViewHolder) convertView.getTag();
        }

        groupViewHolder.groupLayout.removeAllViews();

        DogIndexModel dogIndexModel = list.get(position);
        groupViewHolder.tvCategory.setText(dogIndexModel.getCategory());

        int length = dogIndexModel.getData().size();
        for (int index = 0; index < length;index++){
            View childView = LayoutInflater.from(context).inflate(R.layout.layout_value_select_item, parent, false);
            ChildViewHolder childViewHolder = new ChildViewHolder();
            childViewHolder.nameTV = (TextView) childView.findViewById(R.id.id_value_tv);
            childViewHolder.isSelected = (ImageView) childView.findViewById(R.id.id_select_iv);
            childViewHolder.divider = childView.findViewById(R.id.id_divider);
            Map<Integer,Integer> map = new HashMap<>();
            map.put(GROUP_ID_KEY,position);
            map.put(CHILD_ID_KEY, index);
            childView.setTag(map);

            DogTypeModel dogTypeModel = dogIndexModel.getData().get(index);
            childViewHolder.nameTV.setText(dogTypeModel.getName());
            if (dogTypeModel.isSelected()){
                childViewHolder.isSelected.setVisibility(View.VISIBLE);
            } else {
                childViewHolder.isSelected.setVisibility(View.GONE);
            }
            if (index == length - 1){
                childViewHolder.divider.setVisibility(View.GONE);
            } else {
                childViewHolder.divider.setVisibility(View.VISIBLE);
            }
            if (null != listener){
                childView.setOnClickListener(listener);
            }
            if (1 == length){
                childView.setBackground(context.getResources().getDrawable(R.drawable.info_item_bg));
            } else if (0 == index){
                childView.setBackground(context.getResources().getDrawable(R.drawable.info_item_top_bg));
            } else if (length -1 == index){
                childView.setBackground(context.getResources().getDrawable(R.drawable.info_item_bottom_bg));
            } else {
                childView.setBackground(context.getResources().getDrawable(R.drawable.info_item_middle_bg));
            }
            groupViewHolder.groupLayout.addView(childView);

        }
        return convertView;
    }


}
