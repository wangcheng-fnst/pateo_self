package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.activity.AlertSettingActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/10/16.
 */
public class DeviceDetailAdapter extends BaseAdapter {

    private List<AlertSettingActivity.DeviceItem> mData = new ArrayList<AlertSettingActivity.DeviceItem>();
    private Context mContext;
    private View.OnClickListener listener = null;

    public DeviceDetailAdapter(List<AlertSettingActivity.DeviceItem> mData, Context mContext) {
        this.mData = mData;
        this.mContext = mContext;
    }

    public void refreshList(List<AlertSettingActivity.DeviceItem> mData){
        this.mData = mData;
        this.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    public void setListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DeviceHolder holder = null;
        if (convertView == null){
            holder = new DeviceHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.device_set_item,parent,false);
            holder.nameValueTxt = (TextView)convertView.findViewById(R.id.id_name_txt);
            holder.tempValueTxt = (TextView)convertView.findViewById(R.id.id_temp_value_txt);
            holder.humiValueTxt = (TextView)convertView.findViewById(R.id.id_humi_value_txt);
            holder.tempLayout = (RelativeLayout) convertView.findViewById(R.id.id_device_temp_layout);
            holder.humiLayout = (RelativeLayout) convertView.findViewById(R.id.id_device_humi_layout);
        } else{
            holder = (DeviceHolder) convertView.getTag();
        }

        holder.tempLayout.setTag(position);
        holder.humiLayout.setTag(position);
        if (null != listener){
            holder.tempLayout.setOnClickListener(listener);
            holder.humiLayout.setOnClickListener(listener);
        }
        holder.nameValueTxt.setText(mData.get(position).name);
        holder.tempValueTxt.setText((mData.get(position).tempValue == 0 ? "-":mData.get(position).tempValue)+mContext.getResources().getString(R.string.temperature_unit));
        holder.humiValueTxt.setText((mData.get(position).humiValue == 0 ? "-":mData.get(position).humiValue)+mContext.getResources().getString(R.string.percent_unit));
        convertView.setTag(holder);
        return convertView;
    }

    public class DeviceHolder{
        public TextView tempValueTxt;
        public TextView nameValueTxt;
        public TextView humiValueTxt;
        public RelativeLayout tempLayout;
        public RelativeLayout humiLayout;

    }


}
