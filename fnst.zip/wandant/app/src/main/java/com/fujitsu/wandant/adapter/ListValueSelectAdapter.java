package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.activity.ValueEditActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenjie.fnst on 2015/10/26.
 */
public class ListValueSelectAdapter extends BaseAdapter {

    private Context context;
    private List<ContentClass> strList = new ArrayList<>();

    public static class ContentClass{
        public Integer key;
        public Integer value;
        public boolean isSelected;
    }


    public ListValueSelectAdapter(ValueEditActivity context, List<ContentClass> list) {
        this.context = context;
        this.strList = list;
    }

    @Override
    public int getCount() {
        return strList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public class ViewHolder{
        public TextView valueTv;
        public View isSelected;
        public View divider;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (null == convertView){
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.layout_value_select_item, parent, false);
            viewHolder.valueTv = (TextView) convertView.findViewById(R.id.id_value_tv);
            viewHolder.isSelected = convertView.findViewById(R.id.id_select_iv);
            viewHolder.divider = convertView.findViewById(R.id.id_divider);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        ContentClass content = strList.get(position);
        viewHolder.valueTv.setText(context.getString(content.value));
        if (content.isSelected){
            viewHolder.isSelected.setVisibility(View.VISIBLE);
        } else {
            viewHolder.isSelected.setVisibility(View.GONE);
        }
        if (position == strList.size() - 1){
            viewHolder.divider.setVisibility(View.GONE);
        } else {
            viewHolder.divider.setVisibility(View.VISIBLE);
        }
//        if (0 == position && 1 == strList.size()){
//            convertView.setBackground(context.getResources().getDrawable(R.drawable.table_white_bg));
//        } else if (0 == position){
//            convertView.setBackground(context.getResources().getDrawable(R.drawable.info_item_top_bg));
//        } else if (position == strList.size() - 1){
//            convertView.setBackground(context.getResources().getDrawable(R.drawable.info_item_bottom_bg));
//        } else {
//            convertView.setBackground(context.getResources().getDrawable(R.drawable.info_item_middle_bg));
//        }
        return convertView;
    }
}
