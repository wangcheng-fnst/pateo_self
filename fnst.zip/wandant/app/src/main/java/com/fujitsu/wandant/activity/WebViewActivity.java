package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.github.lzyzsd.jsbridge.BridgeWebView;
import com.github.lzyzsd.jsbridge.DefaultHandler;

/**
 * Created by chenjie.fnst on 2015/09/30.
 */
public class WebViewActivity extends BaseActivity {
    private static final String LOG_TAG = WebViewActivity.class.getName();
    @Bind(R.id.id_webview)
    BridgeWebView webView;

    private String currentURL = null;
    private String currentTitle = null;

    private BridgeWebView.BridgeWebViewClient client = null;


    @Override
    public String getTitleName() {
        return currentTitle;
    }

    @Override
    public String getTitleHeadUrl() {
        return currentURL;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        initData();
        initClient();
        showWaitingDialog();
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.getSettings().setTextZoom(100);
        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setDefaultHandler(new DefaultHandler());
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(client);
        webView.loadUrl(getTitleHeadUrl());
//        WebSettings wSet = webView.getSettings();
//        wSet.setJavaScriptEnabled(true);
//        webView.loadUrl("file:///android_asset/a.html");
    }

    private void initData() {
        Intent mIntent = this.getIntent();
        currentTitle = mIntent.getStringExtra(Constants.INTENT_MARK_4_WEBVIEW_TITLE);
        currentURL = mIntent.getStringExtra(Constants.INTENT_MARK_4_WEBVIEW_URL);
    }

    private void initClient(){
        client =  webView.new BridgeWebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (currentURL.equals(url)
                        || url.contains(ApplicationUtils.getErrorUrl())) {
                    return false;
                } else {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.VIEW");
                    Uri uri = Uri.parse(url);
                    intent.setData(uri);
                    startActivity(intent);
                    return true;
                }
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                hideWaitingDialog();
                super.onPageFinished(view, url);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
            }
        };
    }

    @Override
    public int getLayout() {
        return R.layout.activity_webview;
    }




}
