package com.fujitsu.wandant.activity;

import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.WandantApplication;
import com.fujitsu.wandant.adapter.ListWifiAdapter;
import com.fujitsu.wandant.ble.BleHandler;
import com.fujitsu.wandant.ble.StationHandler;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.IotPfConnectionInfo;
import com.fujitsu.wandant.net.model.Station;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.*;
import com.fujitsu.wandant.view.ScrollDisableScrollView;
import com.fujitsu.wandant.view.SwitchText;
import com.fujitsu.wandant.view.ToastManager;
import com.fujitsu.wandant.view.datepicker.DatePickView;
import rx.Observable;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by chenjie.fnst on 2015/10/14.
 */
public class StationWifiEditActivity extends BaseActivity implements Switch.OnCheckedChangeListener, ListView.OnItemClickListener, DatePickView.ChooseListener, OnModelFinishedListener {

    public static final String WPA2 = "wpa2";
    public static final String WPA = "wpa";
    public static final String WEP = "wep";
    private static final String LOG_TAG = StationWifiEditActivity.class.getName();

    private String str4BDID = null;

    @Bind(R.id.id_title_rl)
    View titleBar;
    @Bind(R.id.id_progress_flag)
    View progressView;
    @Bind(R.id.id_scroll_view)
    ScrollDisableScrollView scrollView;
    @Bind(R.id.id_all_ll)
    LinearLayout allLayout;
    @Bind(R.id.id_middle_rl)
    RelativeLayout middleLayout;
    @Bind(R.id.swManualSettingEnable)
    SwitchText swManualSettingEnable;
    @Bind(R.id.id_next_rl)
    View nextLayout;

    private List<ScanResult> wifiList = new ArrayList<ScanResult>();
    private ListView wifiListView;
    private ListWifiAdapter wifiAdapter;

    private View topLayout;
    private View bottomLayout;

    private int bottomHeight;
    private int bottomY;

    private int totalHeight = 0;
    private int statusBarHeight = 0;
    private int titleHeight = 0;
    private int btnHeight = 0;
    private int wifiSwitchHeight = 0;

    private EditText ssidEt;
    private EditText passwordEt;
    private TextView securityTv;
    private Button sureBtn;

    private DatePickView securityDpv;
    private Map<Integer,String> securityMap = new HashMap<>();
    private int securityType;


    private Context context;
    private Station station = null;
    private Subscription subscription;
    private Handler handler = new Handler();
    //wifi
    private WifiManager wifiManager;
    private BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            List<ScanResult> list = wifiManager.getScanResults();
            for (ScanResult scanResult : list){
                if (!StringUtils.isBlank(scanResult.SSID)
                        && StringUtils.isAscii(scanResult.SSID)
                        && Constants.SECURITY_OTHER != getSecurity(scanResult)){
                    wifiList.add(scanResult);
                }
            }
            if(flag){
               wifiAdapter.notifyDataSetChanged();
            }

        }
    };

    ViewTreeObserver.OnGlobalLayoutListener globalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
        @Override
        public void onGlobalLayout() {
            titleHeight = titleBar.getHeight();
            btnHeight = nextLayout.getHeight();
            wifiSwitchHeight = middleLayout.getHeight();
            if (0 != titleHeight && 0 != btnHeight && 0 != wifiSwitchHeight
                    && null == topLayout.getParent() && null == bottomLayout.getParent()){

                Rect frame = new Rect();
                getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);

                statusBarHeight = frame.top;

                titleBar.getViewTreeObserver().removeOnGlobalLayoutListener(globalLayoutListener);
                nextLayout.getViewTreeObserver().removeOnGlobalLayoutListener(globalLayoutListener);
                middleLayout.getViewTreeObserver().removeOnGlobalLayoutListener(globalLayoutListener);

                bottomHeight= totalHeight - titleHeight - btnHeight - wifiSwitchHeight - statusBarHeight;
                bottomY = bottomHeight + wifiSwitchHeight;
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        bottomHeight);
                topLayout.setLayoutParams(params);
                bottomLayout.setLayoutParams(params);
                allLayout.addView(topLayout, 0);
                allLayout.addView(bottomLayout);
            }
        }
    };



    @Override
    public String getTitleName() {
        return getResources().getString(R.string.station_setting);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    private BluetoothAdapter bluetoothAdapter;
    private  boolean flag = true;
    /**
     * 注册蓝牙搜索广播
     */
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)){
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                switch (device.getBondState()) {
                    case BluetoothDevice.BOND_BONDING:
                        break;
                    case BluetoothDevice.BOND_BONDED:  //完成配对
                        Logger.d(LOG_TAG, "BluetoothDevice.BOND_BONDED ---- success");
                        ApplicationUtils.hideKeyboard(StationWifiEditActivity.this, securityTv);
                        showAlwaysWaitingDialog();
                        registerStation();
                        break;
                    case BluetoothDevice.BOND_NONE:
                        break;
                    default:
                        break;
                }
            }else  if(BluetoothDevice.ACTION_PAIRING_REQUEST.equals(action)){
                Logger.d(LOG_TAG, "设置pin ---- success");
//               BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
//                try
//                {
//                    ClsUtils.setPin(device.getClass(), device, Constants.STATION_PSW);
//                    ClsUtils.cancelPairingUserInput(device.getClass(), device);
//                }
//                catch (Exception e)
//                {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
            }
        }

    };

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        setReceiver();
        bindViews();
        Serializable serializable = getIntent().getSerializableExtra(Constants.EXTRA_STATION);
        if (null == serializable){
            station = new Station();
        } else {
            station = (Station) serializable;
        }
        str4BDID = BDIDUtils.addMark4BDID(station.getBdid());
        securityMap.put(Constants.SECURITY_WEP, getResources().getString(R.string.security_wep));
        securityMap.put(Constants.SECURITY_WPA, getResources().getString(R.string.security_wpa));
        securityMap.put(Constants.SECURITY_WPA2,getResources().getString(R.string.security_wpa2));
        wifiManager = (WifiManager)this.getSystemService(Context.WIFI_SERVICE);
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_STATION_WIFI_SETTING, this);
       // connectStation();
    }


    /**
     * 注册广播
     */
    private void setReceiver() {
		  IntentFilter intent = new IntentFilter();
	      intent.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
          intent.addAction(BluetoothDevice.ACTION_PAIRING_REQUEST);
          intent.addAction(BluetoothDevice.ACTION_FOUND);
          registerReceiver(mReceiver, intent);
    }

    private void connectStation() {
        if (null == station || !BluetoothAdapter.checkBluetoothAddress(str4BDID)){
            return;
        }
        new Handler().postDelayed(new Runnable() {
            public void run() {
                //execute the task
                StationHandler.getInstance().connectDevice(str4BDID).timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS)
                        .first().subscribe(new Action1<Boolean>() {
                    @Override
                    public void call(Boolean aBoolean) {

                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {

                    }
                });
            }
        }, 1000);
    }

    @Override
    public int getLayout() {
        return R.layout.activity_station_wifi_edit;
    }

    private void bindViews() {
        context = this;

        if (activityFromFlag == Constants.ACTIVITY_FROM_REGISTER){
            progressView.setVisibility(View.VISIBLE);
        } else {
            progressView.setVisibility(View.GONE);
        }
        if (activityFromFlag == Constants.ACTIVITY_FROM_REGISTER || activityFromFlag == Constants.ACTIVITY_FROM_MAIN){
            isBackable = false;
        } else {
            isBackable = true;
        }
        swManualSettingEnable.setOnClickListener(this);

        totalHeight = WandantApplication.getInstance().getHeight();
        titleBar = findViewById(R.id.id_title_rl);
        titleBar.getViewTreeObserver().addOnGlobalLayoutListener(globalLayoutListener);

        nextLayout.getViewTreeObserver().addOnGlobalLayoutListener(globalLayoutListener);
        middleLayout.getViewTreeObserver().addOnGlobalLayoutListener(globalLayoutListener);

        topLayout = LayoutInflater.from(this).inflate(R.layout.layout_wifi_auto_setting, null);
        bottomLayout = LayoutInflater.from(this).inflate(R.layout.layout_wifi_manual_setting, null);

        wifiListView = (ListView) bottomLayout.findViewById(R.id.id_wifi_lv);
        wifiAdapter = new ListWifiAdapter(this,wifiList);
        wifiListView.setAdapter(wifiAdapter);
        wifiListView.setOnItemClickListener(this);

        ssidEt = (EditText) bottomLayout.findViewById(R.id.id_ssid_et);
        passwordEt = (EditText) bottomLayout.findViewById(R.id.id_password_et);
        securityTv = (TextView) bottomLayout.findViewById(R.id.id_security_tv);
        securityTv.setOnClickListener(this);
        ssidEt.addTextChangedListener(textWatcher);
        passwordEt.addTextChangedListener(textWatcher);
        securityTv.addTextChangedListener(textWatcher);

        sureBtn = (Button) findViewById(R.id.id_sure_btn);
        sureBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        sureBtn.setOnClickListener(this);
        switch (activityFromFlag){
            case Constants.ACTIVITY_FROM_SETTING_STATION_DETAIL:
                sureBtn.setText(getResources().getString(R.string.setting_sure));
                break;
            default:
                sureBtn.setText(getResources().getString(R.string.next_step));
                break;
        }
        setBtnStates(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
//        if (swManualSettingEnable.isChecked()){
//            startWifiScan();
//        }
        flag = true;
    }

    @Override
    protected void onPause() {
//        if (swManualSettingEnable.isChecked()){
//            stopWifiScan();
//        }
        flag = false;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopWifiScan();
        if(mReceiver!=null){
            unregisterReceiver(mReceiver);
        }
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_STATION_WIFI_SETTING);
        StationHandler.getInstance().disconnect();
        if (null != subscription){
            subscription.unsubscribe();
            subscription = null;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked){
            scrollView.smoothScrollTo(0, bottomY);
            startWifiScan();
        } else {
            scrollView.smoothScrollTo(0, 0);
            stopWifiScan();
        }
    }

    private void setBtnStates(boolean isEnable){
        if (isEnable){
            sureBtn.setEnabled(true);
            sureBtn.setBackgroundResource(R.drawable.btn_sure);
        } else {
            sureBtn.setEnabled(false);
            sureBtn.setBackgroundResource(R.drawable.btn_sure_disable);
        }
    }

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            if (!swManualSettingEnable.isChecked()){
                setBtnStates(true);
                return;
            }
            if (StringUtils.isBlank(ssidEt.getText().toString())
            || StringUtils.isBlank(passwordEt.getText().toString())
            || StringUtils.isBlank(securityTv.getText().toString())){
                setBtnStates(false);
            } else {
                setBtnStates(true);
            }
        }
    };

    private void stopWifiScan() {
        if(wifiReceiver!=null){
           unregisterReceiver(wifiReceiver);
        }
    }

    private void startWifiScan() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        registerReceiver(wifiReceiver, intentFilter);
        wifiList.clear();
        wifiAdapter.notifyDataSetChanged();
        if (!wifiManager.isWifiEnabled()){
            if (wifiManager.setWifiEnabled(true)){
                wifiManager.startScan();
            }
        } else {
            wifiManager.startScan();
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_security_tv:
                getDialog().show();
                break;
            case R.id.id_sure_btn:
                sureBtnClicked();
                break;
            case R.id.swManualSettingEnable:
                swManualSettingEnable.toggle();
                if (swManualSettingEnable.isChecked()){
                    scrollView.smoothScrollTo(0, bottomY);
                    startWifiScan();
                } else {
                    scrollView.smoothScrollTo(0, 0);
                    stopWifiScan();
                }
            default:
                break;
        }

    }

    private void sureBtnClicked() {
        switch (activityFromFlag){
            case Constants.ACTIVITY_FROM_SETTING_STATION_DETAIL:
                showAlwaysWaitingDialog();
                modifyWifiSetting();
                break;
            default:
                mateStation();
                break;
        }
    }

    private void modifyWifiSetting(){
        StationUtil.WifiSetting setting = null;
        if (swManualSettingEnable.isChecked()){
            setting = new StationUtil.WifiSetting();
            setting.setSsid(ssidEt.getText().toString());
            setting.setPassword(passwordEt.getText().toString());
            setting.setType(securityType);
        }
        if (null == station || !BluetoothAdapter.checkBluetoothAddress(str4BDID)){
            return;
        }
        StationHandler.getInstance().modifyWifiSetting(str4BDID, setting).subscribe(new Action1<Boolean>() {
            @Override
            public void call(Boolean aBoolean) {
                hideWaitingDialog();
                ((Activity) context).finish();
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
                hideWaitingDialog();
            }
        });
    }

    /**
     * 配对蓝牙
     */
    private void mateStation(){
        if (null == station || !BluetoothAdapter.checkBluetoothAddress(str4BDID)){
            return;
        }
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (null == bluetoothAdapter){
            return;
        }

        if (!bluetoothAdapter.isEnabled())
        {
            bluetoothAdapter.enable();
        }

        BluetoothDevice device = bluetoothAdapter.getRemoteDevice(str4BDID);

        if (null == device){
            return;
        }

        if (device.getBondState() == BluetoothDevice.BOND_BONDED){
            showAlwaysWaitingDialog();
            registerStation();
        }else{
            creatMate(device);
        }


    }


    private void creatMate(BluetoothDevice device) {
        try {
            ClsUtils.createBond(device.getClass(), device);
//            ClsUtils.setPin(device.getClass(), device, Constants.STATION_PSW);
//            ClsUtils.cancelPairingUserInput(device.getClass(), device);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void registerStation(){

        final StationUtil.WifiSetting setting = getWifiSetting();
        subscription = IotPfConnectionUtils.getInstance().getEventHubInfo().flatMap(new Func1<IotPfConnectionInfo, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(IotPfConnectionInfo info) {
                return StationHandler.getInstance().registerStation(str4BDID, setting, info);
            }
        }).subscribe(new Action1<Boolean>() {
            @Override
            public void call(Boolean aBoolean) {
                hideWaitingDialog();
                DogDeviceStationRepository.getInstance().addStationFromNet(DogDeviceStationRepository.REQUEST_FROM_STATION_WIFI_SETTING, station, true);
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
                Logger.e(LOG_TAG, "Throwable " + throwable.getCause() + throwable.getMessage());
                hideWaitingDialog();
            }
        });
        //todo delete the code
//        DogDeviceStationRepository.getInstance().addStationFromNet(DogDeviceStationRepository.REQUEST_FROM_STATION_WIFI_SETTING, station, true);
    }

    private StationUtil.WifiSetting getWifiSetting() {
        //todo delete the code
//        StationUtil.WifiSetting setting = new StationUtil.WifiSetting();
//      setting.setType(Constants.SECURITY_WPA2);
//        setting.setSsid("fnst-internet");
//        setting.setPassword("fnst-internet");
        StationUtil.WifiSetting setting = null;
        if (swManualSettingEnable.isChecked()){
            setting = new StationUtil.WifiSetting();
            setting.setSsid(ssidEt.getText().toString());
            setting.setPassword(passwordEt.getText().toString());
            setting.setType(securityType);
        }
        return setting;
    }

    private Dialog getDialog() {
        if (null == securityDpv){
            securityDpv = new DatePickView(this,DatePickView.DIALOG_THEME_ARRAY,securityMap);
            securityDpv.setTargetView(securityTv);
            securityDpv.setListener(this);
            Window window = securityDpv.getWindow();
            window.setGravity(Gravity.BOTTOM);
        }
        return securityDpv;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ScanResult result = wifiList.get(position);
        ssidEt.setText(result.SSID);
        passwordEt.setText("");
        securityTv.setText(securityMap.get(getSecurity(result)));
        wifiAdapter.setSelectPosition(position);
        securityType= getSecurity(result);
//        setBtnStates(true);
    }

    @Override
    public void setDate(int year, int month, int day) {

    }

    @Override
    public void setValue(int key, String value) {
        securityType = key;
        securityTv.setText(value);
        securityDpv.dismiss();
    }


    private int getSecurity(ScanResult result){
        int security = Constants.SECURITY_OTHER;
        String capabilities = result.capabilities.toLowerCase();
        if (capabilities.contains(WPA2)){
            security = Constants.SECURITY_WPA2;
        } else if (capabilities.contains(WPA)){
            security = Constants.SECURITY_WPA;
        } else if (capabilities.contains(WEP)) {
            security = Constants.SECURITY_WEP;
        } else {
            security = Constants.SECURITY_OTHER;
        }
        return security;
    }


    @Override
    public void success(Object result, int mode) {
        hideWaitingDialog();
        StationHandler.getInstance().disconnect();
        switch (activityFromFlag){
            case Constants.ACTIVITY_FROM_SETTING_STATION_ADD:
                Intent intentAdd = new Intent();
                intentAdd.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intentAdd.setClass(this, SettingActivity.class);
                startActivity(intentAdd);
                break;
            case Constants.ACTIVITY_FROM_REGISTER:
                Intent topIntent = new Intent();
                topIntent.setClass(this, WelcomeActivity.class);
                startActivity(topIntent);
            case Constants.ACTIVITY_FROM_MAIN:
                Intent mainIntent = new Intent();
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                mainIntent.setClass(this, MainActivity.class);
                startActivity(mainIntent);
            default:
                break;
        }
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
    }
}
