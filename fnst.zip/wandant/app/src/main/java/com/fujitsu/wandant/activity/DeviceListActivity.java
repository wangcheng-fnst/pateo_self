package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.adapter.ListDeviceAdapter;
import com.fujitsu.wandant.model.DeviceModel;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.utils.Constants;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chenjie.fnst on 2015/11/06.
 */
public class DeviceListActivity extends BaseActivity{


    private static final int REQUEST_DEVICE_DETAIL = 2;
    @Bind(R.id.id_device_lv)
    ListView deviceListView;
    @Bind(R.id.id_device_add_info)
    TextView addInfoTv;

    private List<Dog> dogList;
    private List<DeviceModel> deviceList;
    private Map<Integer, DeviceModel> deviceMap = new HashMap<>();
    private ListDeviceAdapter adapter;

    private static final int RESUEST_DEVICE_DETAIL = 1;
    private static final int RESULT_DEVICE_ADD = 2;

    @Override
    public String getTitleName() {
        return getResources().getString(R.string.device_detail_title);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {

    }

    private void loadData() {
        dogList = DogDeviceStationRepository.getInstance().loadDogsFromDb();
        deviceList = DogDeviceStationRepository.getInstance().loadAllDeviceModelsFromDb();
        deviceMap.clear();
        for (Dog dog : dogList){
            for (DeviceModel device: deviceList){
                if (dog.getDog_id().equals(device.getDog_id())){
                    deviceMap.put(dog.getDog_id(),device);
                }
            }
        }
        if (null == adapter){
            adapter = new ListDeviceAdapter(this,dogList,deviceMap);
            deviceListView.setAdapter(adapter);
            adapter.setOnItemListener(this);
        } else {
            adapter.refreshList(dogList,deviceMap);
        }
        if (dogList.size() == deviceMap.size()){
            addInfoTv.setVisibility(View.GONE);
        } else {
            addInfoTv.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getLayout() {
        return R.layout.activity_device_list;
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_device_detail_rl:
                int position = (int) v.getTag();
                Dog dog = dogList.get(position);
                Intent intent = new Intent();
                if (deviceMap.containsKey(dog.getDog_id())){
                    intent.putExtra(Constants.EXTRA_DOG,dog);
                    intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,Constants.ACTIVITY_FROM_SETTING_DEVICE_LIST);
                    intent.setClass(this,DeviceDetailActivity.class);
                    startActivityForResult(intent, RESUEST_DEVICE_DETAIL);
                } else {
                    intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,
                            Constants.ACTIVITY_FROM_SETTING_DEVICE_LIST);
                    intent.putExtra(Constants.EXTRA_DOG,dog);
                    intent.setClass(this,BleSelectionActivity.class);
                    startActivityForResult(intent, RESULT_DEVICE_ADD);
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case RESUEST_DEVICE_DETAIL:
                if (adapter!=null&&data!=null){
                    adapter.removeDeviceFromAdapterByDeviceId(data.getIntExtra(Constants.EXTRA_VALUE, -1));
//                    if (!adapter.hasDeviceUpdate()){
//                        StatusRepository.getInstance().deleteAllDeviceFirmDetailsFromDb();
//                    }
                }
                loadData();
                break;
            default:
                break;
        }
    }
}
