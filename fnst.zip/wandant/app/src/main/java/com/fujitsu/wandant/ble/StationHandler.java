package com.fujitsu.wandant.ble;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.util.Log;

import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.net.model.IotPfConnectionInfo;
import com.fujitsu.wandant.utils.ClsUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.GsonUtil;
import com.fujitsu.wandant.utils.StationUtil;
import rx.Observable;
import rx.functions.Func1;

import java.util.Arrays;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Created by chenjie.fnst on 2015/12/10.
 */
public class StationHandler extends BleHandler {

    private static final String LOG_TAG = StationHandler.class.getName();
    protected static StationHandler INSTANCE = null;

    public static final int TIME_OUT = 120;

    public static final String HOST_HEAD = "tcp://";

    private StationHandler(){
        super();
    }

    public static StationHandler getInstance(){
        if (null == INSTANCE){
            INSTANCE = new StationHandler();
        }
        return INSTANCE;
    }

    public Observable<Boolean> registerStation(String address, final StationUtil.WifiSetting setting, final IotPfConnectionInfo info ){
        return connectDevice(address).timeout(TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                return registerNotification(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_W).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).first().flatMap(new Func1<Boolean, Observable<? extends Boolean>>() {
            @Override
            public Observable<? extends Boolean> call(Boolean aBoolean) {
                return setNtpServer(info.getNtp()).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "set ntp " + aBoolean);
                return (true == aBoolean);
            }
        }).first().flatMap(new Func1<Boolean, Observable<? extends Boolean>>() {
            @Override
            public Observable<? extends Boolean> call(Boolean aBoolean) {
                return setMqttInfo(info.getMqtt()).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "set mqtt " + aBoolean);
                return (true == aBoolean);
            }
        }).first().flatMap(new Func1<Boolean, Observable<? extends Boolean>>() {
            @Override
            public Observable<? extends Boolean> call(Boolean aBoolean) {
                return setEventHubInfo(info.getEventhub1(), info.getEventhub2()).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "set notification " + aBoolean);
                return (true == aBoolean);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                return setAzureInfo(info).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (true == aBoolean);
            }
        }).first().flatMap(new Func1<Boolean, Observable<? extends Boolean>>() {
            @Override
            public Observable<? extends Boolean> call(Boolean aBoolean) {

                if (null != setting) {
                    return setWifi(setting).timeout(TIME_OUT, TimeUnit.SECONDS);
                } else {
                    return Observable.just(true);
                }
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "set wifi " + aBoolean);
                return (true == aBoolean);
            }
        }).first().flatMap(new Func1<Boolean, Observable<? extends Boolean>>() {
            @Override
            public Observable<? extends Boolean> call(Boolean aBoolean) {

              return IoTpf().timeout(TIME_OUT, TimeUnit.SECONDS);

            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "IoTpf -Distinguish " + aBoolean);
                return (true == aBoolean);
            }
        }).first().flatMap(new Func1<Boolean, Observable<? extends Boolean>>() {
            @Override
            public Observable<? extends Boolean> call(Boolean aBoolean) {

                return IoTpfMsg().timeout(TIME_OUT, TimeUnit.SECONDS);

            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "IoTpf-Communication " + aBoolean);
                return (true == aBoolean);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                return resetStation().timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        });

//                .filter(new Func1<Boolean, Boolean>() {
//            @Override
//            public Boolean call(Boolean aBoolean) {
//                Logger.d(LOG_TAG, "set wifi " + aBoolean);
//                return (true == aBoolean);
//            }
//        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
//            @Override
//            public Observable<Boolean> call(Boolean aBoolean) {
//                return registerNotification(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_R).timeout(TIME_OUT, TimeUnit.SECONDS);
//            }
//        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
//            @Override
//            public Observable<Boolean> call(Boolean aBoolean) {
//                Log.e(LOG_TAG,"checkWifiConnectStatus----- start");
//                return checkWifiConnectStatus().timeout(TIME_OUT, TimeUnit.SECONDS);
//            }
//        })

//        .filter(new Func1<Boolean, Boolean>() {
//            @Override
//            public Boolean call(Boolean aBoolean) {
//                Logger.d(LOG_TAG, "checkWifiConnectStatus " + aBoolean);
//                return aBoolean == true;
//            }
//        })
//        .first().flatMap(new Func1<Boolean, Observable<? extends Boolean>>() {
//            @Override
//            public Observable<? extends Boolean> call(Boolean aBoolean) {
//                Log.e(LOG_TAG,"checkServerConnectStatus ----- start");
//                return checkServerConnectStatus().timeout(TIME_OUT, TimeUnit.SECONDS);
//            }
//        });
    }


    public boolean setDevice(String address){
        // Get a set of currently paired devices
        boolean flag = false;
        Set<BluetoothDevice> pairedDevices = BluetoothAdapter.getDefaultAdapter().getBondedDevices();
        // If there are paired devices, add each one to the ArrayAdapter
        if (pairedDevices!=null&&pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                if (device.getAddress().equals(address)) {
                    flag = true;
                    break;
                }
            }

        }
        return flag;
    }


    public Observable<Boolean> modifyWifiSetting(String address, final StationUtil.WifiSetting setting){
        return connectDevice(address).timeout(TIME_OUT, TimeUnit.SECONDS).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (true == aBoolean);
            }
        }).first().timeout(StationHandler.TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                return registerNotification(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_R);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (true == aBoolean);
            }
        }).first().timeout(StationHandler.TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                if (null == setting){
                    return checkWifiConnectStatus().timeout(TIME_OUT, TimeUnit.SECONDS);
                } else {
                    return setWifi(setting);
                }
            }
        });
    }

    public Observable<Boolean> setStationCommand(final byte type, UUID serverUUid, UUID notifyUUid, UUID writeUUid, byte[] data){
        Logger.d(LOG_TAG, "command " + type + " write: " + Arrays.toString(data));
        setCommand(serverUUid, writeUUid, data);
//        return Observable.just(true);
        return getNotification(serverUUid, notifyUUid).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                Logger.d(LOG_TAG, "response command " + GsonUtil.getInstance().toJson(responseData));
                return Observable.just(StationUtil.parseCommandResponse(type, responseData.getVal()));
            }
        });
    }

    public Observable<Boolean> setWifi(StationUtil.WifiSetting setting){
        Logger.d(LOG_TAG, "set wifi " + GsonUtil.getInstance().toJson(setting)) ;
        byte[] data = StationUtil.createWifiByteArray(setting);
        return setStationCommand(StationUtil.COMMAND_WIFI_SETTING,
                Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_W,
                Constants.STATION_IOT_CMD_W, data);
    }

    public Observable<Boolean> checkWifiConnectStatus(){
        Logger.d(LOG_TAG, "check wifi status");
        setCommand(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_CMD_R, StationUtil.createCommand(StationUtil.COMMAND_WIFI_STATUS));
        return getNotification(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_R).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                Log.e(LOG_TAG,"getNotification----- start");
                return Observable.just(StationUtil.parseCommandResponse(StationUtil.COMMAND_WIFI_STATUS, responseData.getVal()));
            }
        });
    }

    public Observable<StationUtil.WifiSetting> getWifi(){
        Logger.d(LOG_TAG, "get wifi setting");
        setCommand(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_CMD_R, StationUtil.createCommand(StationUtil.COMMAND_WIFI_SETTING));
        return getNotification(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_R).flatMap(new Func1<BleDevice.ResponseData, Observable<StationUtil.WifiSetting>>() {
            @Override
            public Observable<StationUtil.WifiSetting> call(BleDevice.ResponseData responseData) {
                return Observable.just(StationUtil.parseWifiSetting(responseData.getVal()));
            }
        });
    }


    public Observable<Boolean> setNtpServer(String ntp) {
        Logger.d(LOG_TAG, "setNtpServer " + ntp);
        byte[] data = StationUtil.createNtpServerByteArray(ntp);
        return setStationCommand(StationUtil.COMMAND_NTP_SETTING,
                Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_W,
                Constants.STATION_IOT_CMD_W, data);

    }


    public Observable<Boolean> setAzureInfo(IotPfConnectionInfo info){
        Logger.d(LOG_TAG, "set azureInfo " + GsonUtil.getInstance().toJson(info)) ;
        final byte[] baseUrlArray = StationUtil.createStringArray(StationUtil.COMMAND_BASE_URL, 65, info.getTableStorage().getBaseURL());
        final byte[] accountArray = StationUtil.createStringArray(StationUtil.COMMAND_ACCOUNT, 241, info.getTableStorage().getAccount());
        final byte[] accountKeyArray = StationUtil.createStringArray(StationUtil.COMMAND_ACCOUNT_KEY, 241, info.getTableStorage().getAccountKey());
        final byte[] tableAccountArray = StationUtil.createStringArray(StationUtil.COMMAND_TABLE_POLICY_NAME, 241, info.getEventhub3().getPolicyName());
        final byte[] tableAccountKeyArray = StationUtil.createStringArray(StationUtil.COMMAND_TABLE_POLICY_KEY, 241, info.getEventhub3().getPolicyKey());
        return setStationCommand(StationUtil.COMMAND_BASE_URL, Constants.STATION_IOT_SERVICE,
                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, baseUrlArray).timeout(TIME_OUT, TimeUnit.SECONDS)
                .filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return (true == aBoolean);
                    }
                }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                        return setStationCommand(StationUtil.COMMAND_ACCOUNT, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, accountArray).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                }).filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return (true == aBoolean);
                    }
                }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                        return setStationCommand(StationUtil.COMMAND_ACCOUNT_KEY, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, accountKeyArray).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                }).filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return (true == aBoolean);
                    }
                }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                        return setStationCommand(StationUtil.COMMAND_TABLE_POLICY_NAME, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, tableAccountArray).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                }).filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return (true == aBoolean);
                    }
                }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                        return setStationCommand(StationUtil.COMMAND_TABLE_POLICY_KEY, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, tableAccountKeyArray).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                });
    }


    public Observable<Boolean> setMqttInfo(IotPfConnectionInfo.MqttInfo info){
        Logger.d(LOG_TAG, "setMqttInfo " + GsonUtil.getInstance().toJson(info)) ;
        String host = null;
        if (null != info && null != info.getHost() && !info.getHost().isEmpty()) {
            host = info.getHost();
            if (host.contains(HOST_HEAD)) {
                host = host.replace(HOST_HEAD, "").trim();
            }
        }
        final byte[] hostArray = StationUtil.createStringArray(StationUtil.COMMAND_MQTT_HOST, 65, host);
        //final byte[] portArray = StationUtil.createStringArray(StationUtil.COMMAND_MQTT_PORT, 9, info.getPort());
        String portStr = info.getPort();
        short port = (null == portStr) ? 1883:Short.parseShort(portStr);
        final byte[] portArray = StationUtil.createShortArray(StationUtil.COMMAND_MQTT_PORT, 9, port);
        final byte[] userNameArray = StationUtil.createStringArray(StationUtil.COMMAND_MQTT_USERNAME, 65, info.getUsername());
        final byte[] passwordArray = StationUtil.createStringArray(StationUtil.COMMAND_MQTT_PASSWORD, 65, info.getPassword());
        return setStationCommand(StationUtil.COMMAND_MQTT_HOST, Constants.STATION_IOT_SERVICE,
                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, hostArray).timeout(TIME_OUT, TimeUnit.SECONDS)
                .filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return (true == aBoolean);
                    }
                })
                .flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                        return setStationCommand(StationUtil.COMMAND_MQTT_PORT, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, portArray).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                }).filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return (true == aBoolean);
                    }
                }).flatMap(new Func1<Boolean, Observable<Boolean>>() {

                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                        return setStationCommand(StationUtil.COMMAND_MQTT_USERNAME, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, userNameArray).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                }).filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return (true == aBoolean);
                    }
                }).flatMap(new Func1<Boolean, Observable<Boolean>>() {

                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                        return setStationCommand(StationUtil.COMMAND_MQTT_PASSWORD, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, passwordArray).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                });


    }


    public Observable<Boolean> setEventHubInfo(IotPfConnectionInfo.EventHubInfo info1, IotPfConnectionInfo.EventHubInfo info2) {
        Logger.d(LOG_TAG, "setEventHubInfo EventHubInfo1:" +  GsonUtil.getInstance().toJson(info1)
                + " EventHubInfo2:" + GsonUtil.getInstance().toJson(info2));
        final byte[] namespaceArray = StationUtil.createStringArray(StationUtil.COMMAND_EVENTHUB_NAMESPACE, 65, info1.getNamespace());
        final byte[] keyName1Array = StationUtil.createStringArray(StationUtil.COMMAND_EVENTHUB1_POLICY_NAME, 241, info1.getPolicyName());
        final byte[] keyValue1Array = StationUtil.createStringArray(StationUtil.COMMAND_EVENTHUB1_POLICY_KEY, 241, info1.getPolicyKey());
        final byte[] keyName2Array = StationUtil.createStringArray(StationUtil.COMMAND_EVENTHUB2_POLICY_NAME, 241, info2.getPolicyName());
        final byte[] keyValue2Array = StationUtil.createStringArray(StationUtil.COMMAND_EVENTHUB2_POLICY_KEY, 241, info2.getPolicyKey());
        return setStationCommand(StationUtil.COMMAND_EVENTHUB_NAMESPACE, Constants.STATION_IOT_SERVICE,
                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, namespaceArray).timeout(TIME_OUT, TimeUnit.SECONDS)
                .filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return aBoolean == true;
                    }
                })
                .flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
//                        return Observable.just(true);
                        return setStationCommand(StationUtil.COMMAND_EVENTHUB1_POLICY_NAME, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, keyName1Array).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                }).filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return aBoolean == true;
                    }
                }).flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
//                        return Observable.just(true);
                        return setStationCommand(StationUtil.COMMAND_EVENTHUB1_POLICY_KEY, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, keyValue1Array).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                }).filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return aBoolean == true;
                    }
                }).flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
//                        return Observable.just(true);
                        return setStationCommand(StationUtil.COMMAND_EVENTHUB2_POLICY_NAME, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, keyName2Array).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                }).filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        return aBoolean == true;
                    }
                }).flatMap(new Func1<Boolean, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(Boolean aBoolean) {
                        return setStationCommand(StationUtil.COMMAND_EVENTHUB2_POLICY_KEY, Constants.STATION_IOT_SERVICE,
                                Constants.STATION_IOT_RES_W, Constants.STATION_IOT_CMD_W, keyValue2Array).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
                });
    }


    public Observable<Boolean> checkServerConnectStatus() {
        Logger.d(LOG_TAG, "checkServerConnectStatus");
        setCommand(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_CMD_R, StationUtil.createCommand(StationUtil.COMMAND_SERVER_STATUS));
//        return Observable.just(true);
        return getNotification(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_R).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                return Observable.just(StationUtil.parseCommandResponse(StationUtil.COMMAND_SERVER_STATUS, responseData.getVal()));
            }
        });

    }


    public Observable<Boolean> IoTpf(){
        Logger.d(LOG_TAG, "IoTpf -Distinguish");
        byte[] data = StationUtil.createIoTpf();
        return setStationCommand(StationUtil.COMMAND_IOTPF,
                Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_W,
                Constants.STATION_IOT_CMD_W, data);
    }


    public Observable<Boolean> IoTpfMsg(){
        Logger.d(LOG_TAG, "IoTpf-Communication ");
        byte[] data = StationUtil.createIoTpfMsg();
        return setStationCommand(StationUtil.COMMAND_IOTPF_MSG,
                Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_W,
                Constants.STATION_IOT_CMD_W, data);
    }

    //ステーション再起動要求
    public Observable<Boolean> resetStation(){
        Logger.d(LOG_TAG, "resetStation");
        byte[] data = StationUtil.createCommand(StationUtil.COMMAND_RESET);
        return setStationCommand(StationUtil.COMMAND_WIFI_SETTING,
                Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_W,
                Constants.STATION_IOT_CMD_W, data);
    }



//    public Observable<DeviceUtil.DeviceSetting> getFirm(){
//        registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID);
//        setCommand(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_W_UUID, DeviceUtil.createFirmByteArray());
//        return getNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).flatMap(new Func1<BleDevice.ResponseData, Observable<DeviceUtil.DeviceSetting>>() {
//            @Override
//            public Observable<DeviceUtil.DeviceSetting> call(BleDevice.ResponseData responseData) {
//                return Observable.just(DeviceUtil.parseSetting(responseData.getVal()));
//            }
//        });
//    }



}
