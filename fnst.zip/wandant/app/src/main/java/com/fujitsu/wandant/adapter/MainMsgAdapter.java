package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.model.MutterModel;
import com.fujitsu.wandant.net.MutterRepository;
import com.fujitsu.wandant.net.MutterService;
import com.fujitsu.wandant.net.NetCallback;
import com.fujitsu.wandant.net.model.MurmurForapp;
import com.fujitsu.wandant.net.model.MuttersInfo;
import com.fujitsu.wandant.view.LoadMoreListView;
import com.fujitsu.wandant.view.ToastManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Top页ViewPager消息适配器
 * Created by ym-zhongxy on 2015/9/21.
 */
public class MainMsgAdapter extends PagerAdapter{
    private Context context;
    private List<View> views;
    private Map<Integer,List<MutterModel>> mDogIdMuttersMap = new HashMap<>();
    private Map<Integer,Integer> mDogIdPageMap = new HashMap<Integer,Integer>();

    public MainMsgAdapter(Context context, Map<Integer,List<MutterModel>> mDogIdMuttersMap) {
        this.context = context;
        views = new ArrayList<>();
        this.mDogIdMuttersMap = mDogIdMuttersMap;
        initViews();
    }

    /**
     * init all the child Views of the ViewPager
     */
    public void initViews(){
        views.clear();
        mDogIdPageMap.clear();
        for (Integer key : mDogIdMuttersMap.keySet()){
            mDogIdPageMap.put(key,1);
            initView(mDogIdMuttersMap.get(key), key);
        }
    }
    public void update(Map<Integer, List<MutterModel>> dogIdMuttersMap){
        this.mDogIdMuttersMap = dogIdMuttersMap;
        if (views.size() == dogIdMuttersMap.size()){
            updateViews();
        } else {
            initViews();
            notifyDataSetChanged();
        }

    }

    public void updateViews(){
        mDogIdPageMap.clear();
        int index = 0;
        for (Integer key : mDogIdMuttersMap.keySet()){
            mDogIdPageMap.put(key,1);
            updateView(index, mDogIdMuttersMap.get(key), key);
            index++;
        }
    }

    private void updateView(int position, final List<MutterModel> mutterModels, final Integer dogId) {
        View llMsg = views.get(position);
        View noMsgView = llMsg.findViewById(R.id.id_no_message_view);
        if (null == mutterModels || mutterModels.isEmpty()){
            noMsgView.setVisibility(View.VISIBLE);
        } else {
            noMsgView.setVisibility(View.GONE);
        }
        ListMsgAdapter adapter = (ListMsgAdapter) llMsg.getTag();
        adapter.refreshList(dogId, mutterModels);
    }

    public void hideLoadView(){
        for (View view:views){
            View listView = view.findViewById(R.id.lvMsg);
            if (null != listView){
                LoadMoreListView loadMoreListView = (LoadMoreListView) listView;
                loadMoreListView.onLoadMoreComplete();
            }
        }
    }

    /**
     * init a child View of the ViewPager
     *
     */
    private void initView(final List<MutterModel> mutterModels, final Integer dogId) {
        View llMsg = LayoutInflater.from(context).inflate(R.layout.viewpager_main_item, null);
        View noMsgView = llMsg.findViewById(R.id.id_no_message_view);
        if (null == mutterModels || mutterModels.isEmpty()){
            noMsgView.setVisibility(View.VISIBLE);
        } else {
            noMsgView.setVisibility(View.GONE);
        }


        final LoadMoreListView lvMsg = (LoadMoreListView) llMsg.findViewById(R.id.id_msg_lv);
        final ListMsgAdapter adapter = new ListMsgAdapter(context,dogId, mutterModels);

        lvMsg.setOnLoadMoreListener(new LoadMoreListView.OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                new LoadMoreDataTask(lvMsg, adapter,dogId).execute();
            }
        });
        lvMsg.setAdapter(adapter);
        llMsg.setTag(adapter);
        views.add(llMsg);
    }

    @Override
    public int getCount() {
        return views.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView(views.get(position));
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        container.addView(views.get(position));
        return views.get(position);
    }

    private class LoadMoreDataTask extends AsyncTask<Void, Void, Void> {

        private LoadMoreListView listView;
        private ListMsgAdapter adapter;
        private int dogId;

        public LoadMoreDataTask(LoadMoreListView listView, ListMsgAdapter adapter,int dogId){
            this.listView = listView;
            this.adapter = adapter;
            this.dogId = dogId;
        }

        @Override
        protected Void doInBackground(Void... params) {

            if (isCancelled()) {
                return null;
            }
            final int page = mDogIdPageMap.containsKey(dogId) ? mDogIdPageMap.get(dogId) : 0;
            MutterService.getInstance().getMutterByDogId(dogId, page, MutterRepository.PAGE_SIZE, MutterRepository.getInstance().getTopQueryDate(), new NetCallback<MuttersInfo>() {
                @Override
                public void success(MuttersInfo responseData) {
                    if (null == responseData || null == responseData.getMurmurList()
                            ||responseData.getMurmurList().isEmpty()){
//                        listView.setNoDataVisible(true);
                    } else {
//                        listView.setNoDataVisible(false);
                        mDogIdPageMap.put(dogId,page + 1);
                        List<MutterModel> list = new ArrayList<MutterModel>();
                        for (MurmurForapp murmurForapp : responseData.getMurmurList()){
                            list.add(MutterModel.create(murmurForapp));
                        }
                        adapter.addData(list);
                        // We need notify the adapter that the data have been changed
                        adapter.notifyDataSetChanged();
                    }
                    // Call onLoadMoreComplete when the LoadMore task, has finished
                    listView.onLoadMoreComplete();
                }

                @Override
                public void failure(String errorCode, String errorMsg) {
                    listView.onLoadMoreComplete();
                }

                @Override
                public void internalFailure(String errorMsg) {
                    ToastManager.getInstance().showFail(errorMsg);
//                    Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show();
                    listView.onLoadMoreComplete();
                }
            });

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }

        @Override
        protected void onCancelled() {
            listView.onLoadMoreComplete();
            super.onCancelled();
        }
    }

}
