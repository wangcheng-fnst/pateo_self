package com.fujitsu.wandant.activity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.ble.StationHandler;
import com.fujitsu.wandant.db.DataBaseManager;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.model.FirmDetailModel;
import com.fujitsu.wandant.model.dao.FirmDetailModelDao;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.StatusRepository;
import com.fujitsu.wandant.net.model.Station;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.BDIDUtils;
import com.fujitsu.wandant.utils.ClsUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StationUtil;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.view.PopViewHelper;
import com.fujitsu.wandant.view.ToastManager;
import me.grantland.widget.AutofitTextView;
import rx.Observable;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func1;

import java.io.Serializable;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by chenjie.fnst on 2015/10/08.
 */
public class StationDetailInfoActivity extends BaseActivity implements OnModelFinishedListener {

    @Bind(R.id.id_bdid_tv)
    AutofitTextView bdidTv;
    @Bind(R.id.id_wifi_tv)
    TextView wifiTv;
    @Bind(R.id.id_update_flag_iv)
    View updateFlagView;
    @Bind(R.id.id_firm_version_tv)
    TextView firmVersionTv;
    @Bind(R.id.id_temp_max_tv)
    TextView tempMaxTv;
    @Bind(R.id.id_humi_max_tv)
    TextView humiMaxTv;
    @Bind(R.id.id_layer)
    View layerView;

    @Bind(R.id.id_delete_btn)
    Button deleteBtn;

    private Station station = null;
    private Context context;

    private String tempUnit;
    private String humiUnit;
    private String hyphen;
    private FirmDetailModelDao firmDao;
    private FirmDetailModel firmInfo;
    private Subscription subscription;
    /** bluetooth adapter */
    private BluetoothAdapter bluetoothAdapter;
    /** request flag to open bluetooth function in the phone */
    private static final int REQUEST_OPEN_BLUETOOTH = 2;
    private static final int REQUEST_MODIFY = 1;

    private  String str4BDID = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firmDao = DataBaseManager.getInstance().getDaoSession().getFirmDetailModelDao();
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_STATION_DETAIL, this);
    }

    @Override
    protected void onDestroy() {
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_STATION_DETAIL);
        StationHandler.getInstance().disconnect();
        if (null != subscription){
            subscription.unsubscribe();;
            subscription = null;
        }
        if (null != mReceiver){
            unregisterReceiver(mReceiver);
        }
        super.onDestroy();
    }

    @Override
    public String getTitleName() {
        return getString(R.string.station);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        context = this;
        tempUnit = getResources().getString(R.string.temperature_unit);
        humiUnit = getResources().getString(R.string.percent_unit);
        hyphen = getResources().getString(R.string.hyphen);
        Serializable serializable = getIntent().getSerializableExtra(Constants.EXTRA_STATION);
        if (null != serializable){
            station = (Station) serializable;
        }
        if(null!=station){
            if (station.getBdid() != null && !station.getBdid().isEmpty()) {
                str4BDID = BDIDUtils.addMark4BDID(station.getBdid());
            }

        }
        deleteBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_white_sure_pressed, R.drawable.btn_white_sure));
        bindViews();
        setReceiver();
        showData();
        initBluetooth();
    }

    private void setReceiver() {
        IntentFilter intent = new IntentFilter();
        intent.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        registerReceiver(mReceiver, intent);
    }

    private void mateStation(){
        if (null == station || !BluetoothAdapter.checkBluetoothAddress(str4BDID)){
            return;
        }

        BluetoothDevice device = bluetoothAdapter.getRemoteDevice(str4BDID);

        if (null == device){
            return;
        }

        if (device.getBondState() == BluetoothDevice.BOND_BONDED){
            getData();
        }else{
            createMate(device);
        }

    }

    private void createMate(BluetoothDevice device) {
        try {
            ClsUtils.createBond(device.getClass(), device);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * initBluetooth
     *
     */
    private void initBluetooth() {
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);

        bluetoothAdapter = manager.getAdapter();

        if (null == bluetoothAdapter) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.bluetooth_error));
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

                startActivityForResult(intent, REQUEST_OPEN_BLUETOOTH);
            } else {
                 mateStation();
                //getData();
            }
        }
    }

    private void getData() {
        new Handler().postDelayed(new Runnable() {
            public void run() {
                //execute the task
                getDataFromBle();
            }
        }, 1000);
    }



    private void bindViews() {

        firmInfo = StatusRepository.getInstance().getFirmDbByBdid(station.getBdid());
        if (null != firmInfo && null != firmInfo.getMajor()){
            firmVersionTv.setText(firmInfo.getMajor()+"."+firmInfo.getMinor());
        } else {
            firmVersionTv.setText(hyphen);
        }

        findViewById(R.id.id_temp_rl).setOnClickListener(this);
        findViewById(R.id.id_humi_rl).setOnClickListener(this);
        findViewById(R.id.id_bdid_rl).setOnClickListener(this);
        findViewById(R.id.id_wifi_rl).setOnClickListener(this);
        findViewById(R.id.id_firm_version_rl).setOnClickListener(this);
        findViewById(R.id.id_delete_btn).setOnClickListener(this);
    }

    private void showData(){
        if (null == station){
            return;
        }
        if (StringUtils.isBlank(str4BDID)){
            bdidTv.setText(hyphen);
        } else {
            bdidTv.setText(str4BDID);
        }

        Integer tempMax = station.getTemperature();
        if (null == tempMax){
            tempMaxTv.setText(hyphen);
        } else {
            tempMaxTv.setText(String.valueOf(tempMax) + tempUnit);
        }
        Integer humiMax = station.getHumidity_down();
        if (null == humiMax){
            humiMaxTv.setText(hyphen);
        } else {
            humiMaxTv.setText(String.valueOf(humiMax) + humiUnit);
        }
//        wifiTv.setText(station.getWifi());
//        firmVersionTv.setText(station.);
    }

    private boolean isNeedUpdate() {
        boolean needUpdate = false;
        if (null == station || StringUtils.isBlank(station.getBdid())){
            needUpdate = false;
            return needUpdate;
        }
        List list = firmDao.queryBuilder()
                .where(FirmDetailModelDao.Properties.Needupdate.eq(true))
                .where(FirmDetailModelDao.Properties.Bdid.eq(station.getBdid())).list();
        if (null == list || list.isEmpty()){
            needUpdate = false;
        } else {
            needUpdate = true;
        }
        return needUpdate;
    }

    private void setUpdateFlag(){
        boolean needUpdate = isNeedUpdate();
        if (needUpdate){
            updateFlagView.setVisibility(View.VISIBLE);
            updateFlagView.setOnClickListener(this);
        } else {
            updateFlagView.setVisibility(View.GONE);
            updateFlagView.setOnClickListener(null);
        }
    }

    /**
     * register
     */
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)){
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                switch (device.getBondState()) {
                    case BluetoothDevice.BOND_BONDING:
                        break;
                    case BluetoothDevice.BOND_BONDED:  //完成配对
                        getData();
                        break;
                    case BluetoothDevice.BOND_NONE:

                    default:
                        break;
                }
            }
        }

    };

//    private void initBluetooth(){
//        BluetoothManager manager = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
//        bluetoothAdapter = manager.getAdapter();
//        if (null == bluetoothAdapter){
//            ToastManager.getInstance().showFail(getResources().getString(R.string.bluetooth_error));
////            Toast.makeText(this, getResources().getString(R.string.bluetooth_error), Toast.LENGTH_SHORT).show();
//            finish();
//            return;
//        }
//    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpdateFlag();
    }



    @Override
    public int getLayout() {
        return R.layout.activity_station_detail;
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.id_temp_rl:
            case R.id.id_humi_rl:
                intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,Constants.ACTIVITY_FROM_SETTING_STATION_DETAIL);
                intent.putExtra(Constants.EXTRA_STATION,station);
                intent.setClass(this, StationTempAndHumiditySettingActivity.class);
                startActivityForResult(intent, REQUEST_MODIFY);
                break;
            case R.id.id_bdid_rl:
                break;
            case R.id.id_wifi_rl:
                intent.putExtra(Constants.EXTRA_STATION,station);
                intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,Constants.ACTIVITY_FROM_SETTING_STATION_DETAIL);
                intent.setClass(this,StationWifiEditActivity.class);
                startActivity(intent);
                break;
            case R.id.id_firm_version_rl:
                if (updateFlagView.getVisibility() == View.VISIBLE){
                    intent.putExtra(Constants.EXTRA_FIRM_FLAG,FirmUpdateActivity.STATION_FIRM_UPDATE_FLAG);
                    intent.putExtra(Constants.EXTRA_FIRM_INFO, firmInfo);
                    intent.setClass(this,FirmUpdateActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.id_delete_btn:
                PopViewHelper.getInstance().showDeletePop(this, layerView, getResources().getString(R.string
                        .station_delete_title), getResources().getString(R.string.release));
                break;
            case R.id.id_pop_sure_txt:
                PopViewHelper.getInstance().dismissPop();
                DogDeviceStationRepository.getInstance().deleteStationFromNet(
                        DogDeviceStationRepository.REQUEST_FROM_STATION_DETAIL,station.getStation_id());
                break;
            case R.id.id_pop_cancel_txt:
                PopViewHelper.getInstance().dismissPop();
            default:
                break;
        }

    }

    private void getDataFromBle(){
        if (null == station || !BluetoothAdapter.checkBluetoothAddress(str4BDID)){
            return;
        }
        final StationHandler handler = StationHandler.getInstance();

        subscription = handler.connectDevice(str4BDID).timeout(StationHandler.TIME_OUT, TimeUnit.SECONDS).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                return handler.registerNotification(Constants.STATION_IOT_SERVICE, Constants.STATION_IOT_RES_R).timeout(StationHandler.TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<StationUtil.WifiSetting>>() {
            @Override
            public Observable<StationUtil.WifiSetting> call(Boolean aBoolean) {
                return handler.getWifi().timeout(StationHandler.TIME_OUT, TimeUnit.SECONDS);
            }
        }).subscribe(new Action1<StationUtil.WifiSetting>() {
            @Override
            public void call(StationUtil.WifiSetting setting) {
                wifiTv.setText(setting.getSsid());
                handler.disconnect();
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
                handler.disconnect();
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK){
            return;
        }
        switch (requestCode){
            case REQUEST_MODIFY:
                station = (Station) data.getSerializableExtra(Constants.EXTRA_STATION);
                showData();
                break;
            case REQUEST_OPEN_BLUETOOTH:
                mateStation();
                break;
            default:
                break;
        }
    }

    @Override
    public void success(Object result, int mode) {
        finish();
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
    }
}
