/*
 * Copyright (C) 2013 Sergej Shafarenka, halfbit.de
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import butterknife.Bind;
import rx.Subscription;
import rx.functions.Action1;

import com.fujitsu.wandant.R;
import com.fujitsu.wandant.adapter.ListDogTypeAdapter;
import com.fujitsu.wandant.ble.DeviceHandler;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.model.DeviceModel;
import com.fujitsu.wandant.model.DogIndexModel;
import com.fujitsu.wandant.model.DogTypeModel;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.BDIDUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.view.NavigationView;
import com.fujitsu.wandant.view.ToastManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;


public class DogTypeSelectActivity extends BaseActivity implements NavigationView.OnItemClickListener,OnModelFinishedListener {
    /** log tag */
    private static final String LOG_TAG = DogTypeSelectActivity.class.getName();

    @Bind(R.id.lvDogType)
    ListView typeListView;
    @Bind(R.id.naviViewDogType)
    NavigationView navigationView;

    private List<DogIndexModel> dogIndexModels;
    private ListDogTypeAdapter adapter;
    private String[] stringArray;

    private String title;
    private Dog dog;
    private DogTypeModel selectedDogType = null;
    private boolean isNeedSend = true;


    @Override
    public String getTitleName() {
        return title;
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    /** handler to connect, read and write date to wandant deivice */
    private DeviceHandler deviceHandler;
    private Subscription subscription;

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        Intent intent = getIntent();
        title = intent.getStringExtra(Constants.EXTRA_TITLE);
        dog = (Dog) intent.getSerializableExtra(Constants.EXTRA_VALUE);
        isNeedSend =  intent.getBooleanExtra(Constants.EXTRA_DOG_TYPE_SELECT_MODE,true);
        deviceHandler = new DeviceHandler();
        readDateFromFile();
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_TYPE,this);
        if (null != dogIndexModels){
            adapter = new ListDogTypeAdapter(this,dogIndexModels);
            typeListView.setAdapter(adapter);
            adapter.setOnItemClickListener(this);
            stringArray = adapter.getAlpha();
            navigationView.setStringArray(stringArray);
            navigationView.setOnItemClickListener(this);
        }
    }

    @Override
    public int getLayout() {
        return R.layout.activity_dog_select;
    }

    private void readDateFromFile(){
        try {
            InputStream is = getAssets().open("DogType.geojson");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String text = new String(buffer, "utf-8");
            text = StringUtils.replaceBlank(text);
            dogIndexModels = new Gson().fromJson(text,new TypeToken<List<DogIndexModel>>(){}.getType());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

//    @Override
//    public void finish() {
//        Intent intent = new Intent();
//        if (null != selectedDogType){
//            intent.putExtra(Constants.EXTRA_VALUE,selectedDogType);
//        }
//        setResult(RESULT_OK,intent);
//        super.finish();
//    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.rlDogType:
                showAlwaysWaitingDialog();
                getSelectType(v);
                break;
            default:
                break;
        }

    }

    private void getSelectType(View v) {
        Map<Integer,Integer> map = (Map<Integer, Integer>) v.getTag();
        int groupId = map.get(ListDogTypeAdapter.GROUP_ID_KEY);
        int childId = map.get(ListDogTypeAdapter.CHILD_ID_KEY);
        DogTypeModel selectType = null;
        for (int groupIndex = 0; groupIndex < dogIndexModels.size();groupIndex++){
            List<DogTypeModel> dogTypeModels = dogIndexModels.get(groupIndex).getData();
            for (int childIndex = 0; childIndex < dogTypeModels.size();childIndex ++){
                if (groupId == groupIndex && childId == childIndex){
                    dogTypeModels.get(childIndex).setIsSelected(true);
                    selectType = dogTypeModels.get(childIndex);
                } else {
                    dogTypeModels.get(childIndex).setIsSelected(false);
                }
            }
        }
        adapter.notifyDataSetChanged();
        if (isNeedSend) {
            if (null != selectType) {
                dog.setCategory(selectType.getType_id());
                dog.setSize(selectType.getSize());
                dog.setLeg_size(selectType.getLeg());
                selectedDogType = selectType;
                // mod  by wangcy on 2016-2-10 start
               //showWaitingDialog();
               // DogDeviceStationRepository.getInstance().modifyDogFromNet(DogDeviceStationRepository.REQUEST_FROM_TYPE,dog,true);
                if(dog != null){
                    Object device = DogDeviceStationRepository.getInstance().searchDeviceByDogId(dog.getDog_id(),true);
                    if(device!=null){
                       DeviceModel item = (DeviceModel)device;
                       String str4BDID = BDIDUtils.addMark4BDID(item.getBdid());
                       if(null!= str4BDID && !str4BDID.isEmpty() ){
                           showAlwaysWaitingDialog();
                           registerDeviceDogType(str4BDID,dog.getLeg_size());
                       }
                    }

                }

            }
        }else {
            Intent intent = new Intent();
            if (null != selectType){
                intent.putExtra(Constants.EXTRA_VALUE,selectType);
            }
            setResult(RESULT_OK, intent);
            finish();
        }

    }


    /**
     *
     * @param address
     */
    // mod  by wangcy on 2016-2-10 start
    private void registerDeviceDogType(final String address,final int leg) {

        subscription = deviceHandler.setDogType(address, leg).subscribe(new Action1<Boolean>() {
            @Override
            public void call(Boolean aBoolean) {
                hideWaitingDialog();
                deviceHandler.disconnect();
                DogDeviceStationRepository.getInstance().modifyDogFromNet(DogDeviceStationRepository.REQUEST_FROM_TYPE,dog,true);

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
                hideWaitingDialog();
                deviceHandler.disconnect();
                Logger.e(LOG_TAG, "register device address=" + address + " failed " + throwable.getMessage());
            }
        });

    }
    // mod  by wangcy on 2016-2-10 end


    @Override
    public void onItemClick(int position, String s) {
        typeListView.setSelection(position);
    }


    private void unsubscribe(){
        if (null != subscription){
            subscription.unsubscribe();
            subscription = null;
        }
    }

    @Override
    protected void onDestroy() {
        unsubscribe();
        if (null != deviceHandler){
            deviceHandler.disconnect();
        }
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_TYPE);
        super.onDestroy();
    }

    @Override
    public void success(Object dog, int type) {
        hideWaitingDialog();
        Intent intent = new Intent();
        if (null != selectedDogType){
            intent.putExtra(Constants.EXTRA_VALUE,selectedDogType);
        }
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        hideWaitingDialog();
        showErrorMessage(errorCode);
        selectedDogType = null;
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
        hideWaitingDialog();
        selectedDogType = null;
    }
}