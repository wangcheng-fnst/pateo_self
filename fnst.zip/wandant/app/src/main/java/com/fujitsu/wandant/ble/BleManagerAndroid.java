package com.fujitsu.wandant.ble;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothAdapter.LeScanCallback;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.utils.Constants;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@TargetApi(18)
public class BleManagerAndroid extends BleManager implements LeScanCallback {

	private static final String LOG_TAG = BleManagerAndroid.class.getName();
	private boolean initScan = false;
	private ArrayList<String> devicesList = new ArrayList<String>();
	
    private final static int MSG_SCAN_DELAYED = 1;
    private final static int MSG_CONNECT_DEVICE = 2;
    private BluetoothAdapter    mBluetoothAdapter;
    private BluetoothLeScanner mLEScanner;
    private ScanCallback mScanCallback;

    private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MSG_SCAN_DELAYED:
				initScan = true;
				scanBleDevice();
				break;
			case MSG_CONNECT_DEVICE:
				((BleDeviceAndroid)bleDevice).reConnect();
				break;
			default:
				break;
			}
		}
	};	
	
	public BleManagerAndroid(Context cntx, BleCallback cb) {
		super(cntx, cb);
	}

//	public BleManagerAndroid(Context cntx) {
//		super(cntx);
//	}

	@Override
	protected void enableBle(Context cntx) {
		Log.v(LOG_TAG, "bt enable ----" + bleDevice + "  " + mHandler);
		if(null != bleDevice){
			mHandler.sendEmptyMessageDelayed(MSG_SCAN_DELAYED, 1000);
		}
	}
	
	@Override
	protected void disableBle() {
		if(null != bleDevice){
			bleDevice.disableBT();		
		}
		initScan = false;
		devicesList.clear();
	}

    @SuppressLint("NewApi")
	@Override
	public void scanBleDevice() {
		//BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            /*  Check   to  make    sure    BLE is  supported   */
        if  (!mContext.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE))
        {
            return;
        }
        /*  Get a   Bluetooth   Adapter Object  */
        final   BluetoothManager    bluetoothManager    =
                (BluetoothManager)mContext.getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter   =   bluetoothManager.getAdapter();

        if(mBluetoothAdapter==null){
            return;
        }
		if (!mBluetoothAdapter.isEnabled()) {
            return ;
		}

        if  (Build.VERSION.SDK_INT  <   21)
        {
            mBluetoothAdapter.stopLeScan(this);
            mBluetoothAdapter.startLeScan(this);
        }
        else
        {

             mScanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
            /*  Connect to  device  found   */
                  //  Log.i("callbackType", String.valueOf(callbackType));

                    BluetoothDevice device = result.getDevice();
                    if(!devicesList.contains(device.getAddress())){
                        devicesList.add(device.getAddress());
                    }
                    if(null != bleDevice && devicesList.contains(bleDevice.getAddress())){
                        initScan = false;
                        stopScan();
                        mHandler.sendEmptyMessage(MSG_CONNECT_DEVICE);
                        return;
                    }
                    if(initScan){
                        return;
                    }


                }

                @Override
                public void onBatchScanResults(List<ScanResult> results) {
            /*  Process a   batch   scan    results */
                    for (ScanResult sr : results) {
                     //   Log.i("Scan Item:   ", sr.toString());
                    }
                }
            };
            mLEScanner = mBluetoothAdapter.getBluetoothLeScanner();

            if(mLEScanner==null){
                return;
            }
            if(mScanCallback==null){
                return;
            }
            mLEScanner.stopScan(mScanCallback);
            mLEScanner.startScan(mScanCallback);
        }

	}

	@Override
	public void stopScan() {

        if(mBluetoothAdapter==null){
            return;
        }

        if  (Build.VERSION.SDK_INT  <   21)
        {
            mBluetoothAdapter.stopLeScan(this);
        }
        else
        {
            if(mLEScanner==null){
                return;
            }
            if(mScanCallback==null){
                return;
            }
            mLEScanner.stopScan(mScanCallback);
        }
	}

	@Override
	public BleDevice connectBleDevice(String deviceAddress, BleDevice.BleDeviceCallback cb) {
		BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
		if (null == adapter){
			return null;
		}
		BluetoothDevice device = adapter.getRemoteDevice(deviceAddress);
		if (device == null) {
			Logger.d(LOG_TAG, "Device not found.  Unable to connect.");
			return null;
		}
		Logger.d(LOG_TAG, "begin connect bluetooth address:" + deviceAddress);
		if(devicesList.contains(device.getAddress())){
			bleDevice = BleDeviceAndroid.connectBleDevice(mContext, device, cb);
		}else{
			bleDevice = BleDeviceAndroid.createBleDevice(mContext, device, cb);
			//todo delete the reconnect
//			mHandler.sendEmptyMessageDelayed(MSG_SCAN_DELAYED, 1000);
		}
		return bleDevice;
	}

	@Override
	public BleDevice connectBleDevice(BluetoothDevice device, BleDevice.BleDeviceCallback cb) {
		if(devicesList.contains(device.getAddress())){
			bleDevice = BleDeviceAndroid.connectBleDevice(mContext, device, cb);
		}else{
			bleDevice = BleDeviceAndroid.createBleDevice(mContext, device, cb);
			mHandler.sendEmptyMessageDelayed(MSG_SCAN_DELAYED, 1000);
		}
		return bleDevice;
	}

	@Override
	public void disconnect() {
		if (null == bleDevice){
			Logger.d(LOG_TAG, "disconnect bluetooth null");
		} else {
			Logger.d(LOG_TAG, "disconnect bluetooth " + bleDevice.getAddress());
		}
		stopScan();
		initScan = false;
		if(null != bleDevice){
			bleDevice.disconnect();
		}
		bleDevice = null;
	}
	
	@Override
	public void onLeScan(BluetoothDevice dev, int rssi, byte[] scanRecord) {
        try {
            Logger.d(LOG_TAG, "advertise string is " + new String(scanRecord, "utf_8"));
            Logger.d(LOG_TAG, "advertise byte[] is " + Arrays.toString(scanRecord));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        if(!devicesList.contains(dev.getAddress())){
			devicesList.add(dev.getAddress());
		}
		if(null != bleDevice && devicesList.contains(bleDevice.getAddress())){
			initScan = false;
			stopScan();
			mHandler.sendEmptyMessage(MSG_CONNECT_DEVICE);			
			return;
		}
		if(initScan){
			return;
		}
//		mBleCallback.onFoundDevice(dev, rssi, scanRecord);
	}



}
