package com.fujitsu.wandant.ble;

import android.util.Log;

import com.fujitsu.wandant.activity.BleSelectionActivity;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.model.Device1MinDataModel;
import com.fujitsu.wandant.model.FirmDetailModel;
import com.fujitsu.wandant.net.StatusRepository;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.DeviceUtil;
import com.fujitsu.wandant.utils.GsonUtil;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.UserUtils;

import rx.Observable;
import rx.functions.Func1;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by chenjie.fnst on 2015/12/10.
 */
public class DeviceHandler extends BleHandler {

    private static final String LOG_TAG = DeviceHandler.class.getName();
    protected static DeviceHandler INSTANCE = null;



    public DeviceHandler(){
        super();
    }

//    public static DeviceHandler getInstance(){
//        if (null == INSTANCE){
//            INSTANCE = new DeviceHandler();
//        }
//        return INSTANCE;
//    }

    public Observable<Boolean> connectDeviceAndSetTime(String address){
        return super.connectDevice(address).timeout(TIME_OUT, TimeUnit.SECONDS).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "connect device " + aBoolean);
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                return setTime().timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        });
    }

    public Observable<Boolean> registerDevice(String address, final int leg, final int humi, final int temp){
        return connectDevice(address).timeout(TIME_OUT, TimeUnit.SECONDS).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "registerNotification start");
                return registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                return init().timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "init " + aBoolean);
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean o) {
                return setTime();
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "setTime " + aBoolean);
                return (aBoolean == true);
            }
//        }).first().timeout(TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<Boolean, Observable<BleDevice.ResponseData>>() {
//            @Override
//            public Observable<BleDevice.ResponseData> call(Boolean aBoolean) {
//                return getTime();
//            }
//        }).first().timeout(TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
//            @Override
//            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
//                Logger.d(LOG_TAG, "get time is " + Arrays.toString(responseData.getVal()));
//                return Observable.just(true);
//            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean o) {
                if (Constants.NUMBER_INVALID != leg) {
                    return setDogLeg(leg).timeout(TIME_OUT, TimeUnit.SECONDS);
                } else {
                    return Observable.just(true);
                }
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<DeviceUtil.FirmSetting>>() {
            @Override
            public Observable<DeviceUtil.FirmSetting> call(Boolean aBoolean) {
                return getFirm().timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS);
            }
        }).first().flatMap(new Func1<DeviceUtil.FirmSetting, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(DeviceUtil.FirmSetting firmSetting) {

                if (null != firmSetting) {
                    BleSelectionActivity.deviceVersion = firmSetting.getFirmVersion();
                }
                return Observable.just(true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean o) {
                return setAlert(temp, humi).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        });
    }

    /**
     * 设置够种注册蓝牙狗腿长
     * @return
     */
    public Observable<Boolean> setDogType(String address, final int leg){
        return connectDevice(address).timeout(TIME_OUT, TimeUnit.SECONDS).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                Logger.d(LOG_TAG, "registerNotification start");
                return registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (aBoolean == true);
            }
        }).first().flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean o) {
               return setDogLeg(leg).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        });
    }



    private Observable<Boolean> init(){
        byte[] data = DeviceUtil.createInitByteArray();
//        Logger.i(LOG_TAG, "registerNotification init");
//        registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID);
        Logger.d(LOG_TAG, "command init ");
        setCommand(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_W_UUID, data);
        return getNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                Logger.d(LOG_TAG, "response device init " + GsonUtil.getInstance().toJson(responseData));
                return Observable.just(DeviceUtil.checkCommandResponse(DeviceUtil.COMMAND_INIT, responseData.getVal()));
            }
        });
    }

    public Observable<Boolean> setTime(){
        Logger.d(LOG_TAG, "setTime ");
        return setCommand(Constants.DEVICE_IOT_SERVICE2, Constants.DEVICE_IOT_TIME_R_W_UUID, DeviceUtil.createCurrentTimeByteArray());
    }

    private Observable<BleDevice.ResponseData> getTime() {
        return readData(Constants.DEVICE_IOT_SERVICE2, Constants.DEVICE_IOT_TIME_R_W_UUID);
    }

    public Observable<Boolean> setAlert(int temp, int humi){
        byte[] data = DeviceUtil.createAlterByteArray(temp, humi);
//        Logger.i(LOG_TAG, "registerNotification alert");
//        registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID);
        Logger.d(LOG_TAG, "set alert temp= " + temp + " humi= " + humi);
        setCommand(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_W_UUID, data);
        return getNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                Logger.d(LOG_TAG, "response set alert " + GsonUtil.getInstance().toJson(responseData));
                return Observable.just(DeviceUtil.checkCommandResponse(DeviceUtil.COMMAND_ALERT_SET, responseData.getVal()));
            }
        });
    }

    private Observable<Boolean> setDogLeg(int legSize){
        byte[] data = DeviceUtil.createDogLegSizeByteArray(legSize);
//        Logger.i(LOG_TAG, "registerNotification dog leg");
//        registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID);
        Logger.d(LOG_TAG, "set dog leg " + legSize);
        setCommand(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_W_UUID, data);
        return getNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                Logger.d(LOG_TAG, "response set dog leg " + GsonUtil.getInstance().toJson(responseData));
                return Observable.just(DeviceUtil.checkCommandResponse(DeviceUtil.COMMAND_LEG_SET, responseData.getVal()));
            }
        });
    }

    public Observable<DeviceUtil.DeviceSetting> getDeviceSettingFromBle(String address){
        return connectDeviceAndSetTime(address).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return aBoolean == true;
            }
        }).first().timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<Boolean, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(Boolean aBoolean) {
                return registerNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).filter(new Func1<Boolean, Boolean>() {
            @Override
            public Boolean call(Boolean aBoolean) {
                return (aBoolean == true);
            }
        }).first().timeout(BleHandler.TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<Boolean, Observable<DeviceUtil.DeviceSetting>>() {
            @Override
            public Observable<DeviceUtil.DeviceSetting> call(Boolean aBoolean) {
                return getDeviceSetting().timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        });
    }


    public Observable<DeviceUtil.DeviceSetting> getDeviceSetting(){
        Logger.d(LOG_TAG, "get device setting");
        setCommand(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_W_UUID, DeviceUtil.createSettingByteArray());
        return getNotification(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(TIME_OUT, TimeUnit.SECONDS).flatMap(new Func1<BleDevice.ResponseData, Observable<DeviceUtil.DeviceSetting>>() {
            @Override
            public Observable<DeviceUtil.DeviceSetting> call(BleDevice.ResponseData responseData) {
                Logger.d(LOG_TAG, "response get device setting " + GsonUtil.getInstance().toJson(responseData));
                return Observable.just(DeviceUtil.parseSetting(responseData.getVal()));
            }
        });
    }

    public Observable<DeviceUtil.FirmSetting> getFirm(){
        Logger.d(LOG_TAG, "get device firm info");
        return setCommand(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_W_UUID, DeviceUtil.createFirmByteArray()).timeout(TIME_OUT, TimeUnit.SECONDS)
        .first().flatMap(new Func1<Boolean, Observable<BleDevice.ResponseData>>() {
            @Override
            public Observable<BleDevice.ResponseData> call(Boolean aBoolean) {
                        return readData(Constants.DEVICE_IOT_SERVICE1, Constants.DEVICE_IOT_CMD_R_UUID).timeout(TIME_OUT, TimeUnit.SECONDS);
                    }
        }).first() .flatMap(new Func1<BleDevice.ResponseData, Observable<DeviceUtil.FirmSetting>>() {
                    @Override
                    public Observable<DeviceUtil.FirmSetting> call(BleDevice.ResponseData responseData) {
                        Logger.d(LOG_TAG, "response get firm setting " + GsonUtil.getInstance().toJson(responseData));
                        return Observable.just(DeviceUtil.parseFirm(responseData.getVal()));
                    }
                });
    }

    public Observable<Integer> getBattery() {
        Logger.d(LOG_TAG, "get device battery info");
        return readData(Constants.DEVICE_IOT_SERVICE2, Constants.DEVICE_IOT_BATTERY_R_N_UUID).flatMap(new Func1<BleDevice.ResponseData, Observable<Integer>>() {
            @Override
            public Observable<Integer> call(BleDevice.ResponseData responseData) {
                Logger.d(LOG_TAG, "response get device battery " + GsonUtil.getInstance().toJson(responseData));
                return Observable.just(DeviceUtil.parseBattery(responseData.getVal()));

            }
        });
    }

    public Observable<Boolean> get1MinData(final String stationBdid, final String deviceBdid){
        Logger.d(LOG_TAG, "get device 1 minute data");
        return readData(Constants.DEVICE_DDS_SERVICE, Constants.DEVICE_DDS_1MIN_DATA_R_W_UUID).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                Constants.minStrings = StringUtils.hexToString(responseData.getVal());
                return setCommand(Constants.DEVICE_DDS_SERVICE, Constants.DEVICE_DDS_1MIN_DATA_R_W_UUID, DeviceUtil.createByteZreo()).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).first().flatMap(new Func1<Boolean, Observable<BleDevice.ResponseData>>() {
            @Override
            public Observable<BleDevice.ResponseData> call(Boolean aBoolean) {
                return readData(Constants.DEVICE_DDS_SERVICE, Constants.DEVICE_DDS_1MIN_DATA_R_W_UUID).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                Constants.minStrings = Constants.minStrings+StringUtils.hexToString(responseData.getVal());
                return setCommand(Constants.DEVICE_DDS_SERVICE, Constants.DEVICE_DDS_1MIN_DATA_R_W_UUID, DeviceUtil.createByteZreo()).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).first().flatMap(new Func1<Boolean, Observable<BleDevice.ResponseData>>() {
            @Override
            public Observable<BleDevice.ResponseData> call(Boolean aBoolean) {
                return readData(Constants.DEVICE_DDS_SERVICE, Constants.DEVICE_DDS_1MIN_DATA_R_W_UUID).timeout(TIME_OUT, TimeUnit.SECONDS);
            }
        }).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
               // DeviceUtil.addMinByte(responseData.getVal(),2);
                Constants.minStrings = Constants.minStrings+StringUtils.hexToString(responseData.getVal());
                return setCommand(Constants.DEVICE_DDS_SERVICE, Constants.DEVICE_DDS_1MIN_DATA_R_W_UUID, DeviceUtil.createByteZreo()).timeout(TIME_OUT, TimeUnit.SECONDS);

            }
        });
    }

    public Observable<List<Device1MinDataModel>> get1MinData2(final String stationBdid, final String deviceBdid){
        Logger.d(LOG_TAG, "get device 1 minute data");
        return readData(Constants.DEVICE_DDS_SERVICE, Constants.DEVICE_DDS_1MIN_DATA_R_W_UUID).flatMap(new Func1<BleDevice.ResponseData, Observable<List<Device1MinDataModel>>>() {
            @Override
            public Observable<List<Device1MinDataModel>> call(BleDevice.ResponseData responseData) {
                Logger.d(LOG_TAG, "response get device's 1 minute data " + GsonUtil.getInstance().toJson(responseData));
                return Observable.just(DeviceUtil.parse1MinData(stationBdid, deviceBdid, responseData.getVal()));
            }
        });
    }

}
