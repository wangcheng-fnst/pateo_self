package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.fujitsu.wandant.R;
import com.fujitsu.wandant.model.GraphInfoModel;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.TimeUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/9/25.
 */
public class ListStepsAndShakeAdapter extends BaseAdapter {

    private Context mContext;
    private boolean isToday;
    private List<GraphInfoModel> mData = new ArrayList<GraphInfoModel>();
    private int mode;
    private int height;
    private int itemHeight;

    public ListStepsAndShakeAdapter(Context context) {
        this.mContext = context;
    }

    public void refreshData(int mode, boolean isToday, List<GraphInfoModel> data){
        Log.e("huangc","#### Refresh ListData ####");
        this.mode = mode;
        this.isToday = isToday;
        if (null != data){
            this.mData = data;
        }
        notifyDataSetChanged();
    }


    public void setHeight(int height){
        this.height = height;
        itemHeight = (int)(this.height/7.0f)+1;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DataHolder holder = null;
        if (convertView == null){
            convertView = LayoutInflater.from(mContext).inflate(R.layout.graph_item,parent,false);
            holder = new DataHolder();
            holder.txtDay = (TextView) convertView.findViewById(R.id.id_txt_day);
            holder.txtWeek = (TextView) convertView.findViewById(R.id.id_txt_week);
            holder.txtStep = (TextView) convertView.findViewById(R.id.id_txt_step);
            holder.txtCount = (TextView) convertView.findViewById(R.id.id_txt_count);
            holder.imgDay = (ImageView) convertView.findViewById(R.id.id_img_day);
            holder.viewLine = convertView.findViewById(R.id.id_line_view);
            ListView.LayoutParams lp = new ListView.LayoutParams(convertView.getLayoutParams());
            lp.height = itemHeight;
            convertView.setLayoutParams(lp);
            convertView.setOnClickListener(null);
        }else{
            holder = (DataHolder) convertView.getTag();
        }
        if (isToday && 0 == position){
            holder.imgDay.setVisibility(View.VISIBLE);
            holder.txtDay.setVisibility(View.GONE);
            holder.txtDay.setTextColor(mContext.getResources().getColor(R.color.week_day_bg_pressed));
            holder.txtWeek.setTextColor(mContext.getResources().getColor(R.color.week_day_bg_pressed));
            holder.txtStep.setTextColor(mContext.getResources().getColor(R.color.week_day_bg_pressed));
            holder.txtCount.setTextColor(mContext.getResources().getColor(R.color.week_day_bg_pressed));
        }else {
            holder.imgDay.setVisibility(View.GONE);
            holder.txtDay.setVisibility(View.VISIBLE);
            holder.txtDay.setText(TimeUtils.geMonthDay(mData.get(position).getSensedAt()) + "");
            holder.txtDay.setTextColor(mContext.getResources().getColor(R.color.week_day_bg));
            holder.txtWeek.setTextColor(mContext.getResources().getColor(R.color.week_day_bg));
            holder.txtStep.setTextColor(mContext.getResources().getColor(R.color.week_day_bg));
            holder.txtCount.setTextColor(mContext.getResources().getColor(R.color.week_day_bg));

        }
        holder.txtWeek.setText(TimeUtils.getWeekDay(mData.get(position).getSensedAt())+"");

        if (mode == BarDataAdapter.STEP_MODE){
            holder.txtCount.setText(StringUtils.getFormatCount(mData.get(position).getWdSteps()) + "");
            holder.txtStep.setText(mContext.getResources().getString(R.string.step));
        }else{
            holder.txtCount.setText(StringUtils.getFormatCount(mData.get(position).getWdBuruburu()) + "");
            holder.txtStep.setText(mContext.getResources().getString(R.string.times));
        }
        convertView.setTag(holder);

        return convertView;
    }

    private class DataHolder {
        public TextView txtDay;
        public TextView txtWeek;
        public TextView txtCount;
        public TextView txtStep;
        public View viewLine;
        public ImageView imgDay;
    }
}
