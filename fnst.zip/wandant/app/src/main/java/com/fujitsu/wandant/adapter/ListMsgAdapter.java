package com.fujitsu.wandant.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.activity.AlertSettingActivity;
import com.fujitsu.wandant.model.MutterModel;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.TimeUtils;
import com.fujitsu.wandant.view.NumberView;

import java.util.ArrayList;
import java.util.List;

public class ListMsgAdapter extends BaseAdapter implements View.OnClickListener {
    private Context context;
    private Integer dogId;
    private List<MutterModel> dogMsgList;

    public ListMsgAdapter(Context context,Integer dogId, List<MutterModel> dogMsgList) {
        this.context = context;
        this.dogId = dogId;
        if (null == dogMsgList){
            this.dogMsgList = new ArrayList<>();
        } else {
            this.dogMsgList = dogMsgList;
        }
    }

    public Integer getDogId(){
        return dogId;
    }

    public void refreshList(int dogId,List<MutterModel> list){
        this.dogId = dogId;
        if (null == list){
            dogMsgList = new ArrayList<>();
        } else {
            dogMsgList = list;
        }
        notifyDataSetChanged();
    }

    public void addData(List<MutterModel> list) {
        this.dogMsgList.addAll(list);
    }

    @Override
    public int getCount() {
        return dogMsgList.size();
    }

    @Override
    public Object getItem(int position) {
        return dogMsgList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if(convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.listview_msg_item, parent,false);
            holder = new Holder();
            holder.bindViews(convertView);
            convertView.setTag(holder);
        }else{
            holder = (Holder) convertView.getTag();
        }
        MutterModel dogMsg = dogMsgList.get(position);
        String message = dogMsg.getMsg_content();
//        message = "dsadddddddddddddddddddddddqwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnm";
//        String str = "<a href=\"http://2711082222.blog.163.com\">link</a>";
        if (StringUtils.isContainUrl(message)){
            holder.msgTv.setText(Html.fromHtml(message));
            holder.msgTv.setMovementMethod(LinkMovementMethod.getInstance());
        } else {
            holder.msgTv.setText(message);
            holder.msgTv.setMovementMethod(null);
        }

        if (ApplicationUtils.checkClickableForNavigationType(dogMsg.getNavigation_type())){
            convertView.setOnClickListener(this);
            convertView.setBackground(context.getResources().getDrawable(R.drawable.info_item_middle_bg));
        } else {
            convertView.setOnClickListener(null);
            convertView.setBackgroundColor(context.getResources().getColor(R.color.white));
        }


        holder.typeIv.setImageDrawable(ApplicationUtils.getDrawableForType(dogMsg.getMsg_type()));

        if (null != dogMsg.getMsg_date()){
            holder.dateTv.setValue(TimeUtils.format(dogMsg.getMsg_date()));
        }
        return convertView;
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()){
            return;
        }
        Intent intent = new Intent();
        intent.setClass(context, AlertSettingActivity.class);
        context.startActivity(intent);
    }

    private class Holder{
       ImageView typeIv;
       TextView msgTv;
       NumberView dateTv;
       View layout;

       private void bindViews(View view) {
           typeIv = (ImageView) view.findViewById(R.id.id_msg_type_icon);
           msgTv = (TextView) view.findViewById(R.id.id_msg_tv);
           dateTv = (NumberView) view.findViewById(R.id.id_date_tv);
           layout = view.findViewById(R.id.id_item_layout);
           dateTv.setFontColor(Constants.LIGHT_GRAY);
       }
   }
}
