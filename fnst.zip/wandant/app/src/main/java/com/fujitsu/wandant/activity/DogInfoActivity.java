package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.model.DogTypeModel;
import com.fujitsu.wandant.model.ValueEditModel;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.*;
import com.fujitsu.wandant.view.CircleImageView;
import com.fujitsu.wandant.view.PhotoPopViewHelper;
import com.fujitsu.wandant.view.PopViewHelper;
import com.fujitsu.wandant.view.ToastManager;
import com.nostra13.universalimageloader.core.ImageLoader;
import me.grantland.widget.AutofitTextView;

import java.io.File;
import java.io.Serializable;
import java.util.Date;
import java.util.Map;

/**
 * Created by wangc.fnst on 2015/10/8.
 */
public class DogInfoActivity extends BaseActivity implements OnModelFinishedListener {

    @Bind(R.id.id_head_value)
    CircleImageView headValueImg;
    @Bind(R.id.id_name_value)
    AutofitTextView nameValueTxt;
    @Bind(R.id.id_sex_value)
    TextView sexValueTxt;
    @Bind(R.id.id_color_value)
    TextView colorValueTxt;
    @Bind(R.id.id_kind_value)
    AutofitTextView kindValueTxt;
//    @Bind(R.id.id_leg_value)
//    TextView legValueTxt;
//    @Bind(R.id.id_size_value)
//    TextView sizeValueTxt;

    @Bind(R.id.id_birth_value)
    TextView birthValueTxt;
    @Bind(R.id.id_home_value)
    TextView homeValueTxt;
    @Bind(R.id.id_microchip_value)
    AutofitTextView microchipValueTxt;
    @Bind(R.id.id_watch_value)
    TextView watchValueTxt;
    @Bind(R.id.id_medicine_value)
    TextView medicineValueValueTxt;
    @Bind(R.id.id_flea_value)
    TextView fleaValueValueTxt;
    @Bind(R.id.id_injection_value)
    TextView injectionValueTxt;
    @Bind(R.id.id_rabies_value)
    TextView rabiesValueTxt;
    @Bind(R.id.id_diagnose_value)
    TextView diagnoseValueTxt;
    @Bind(R.id.id_dog_info_layer)
    View layer;

    @Bind(R.id.id_dog_remove_btn )
    Button removeBtn;

    protected Dog dogInfo = new Dog();
    private int dogCount;

    private static final int NAME_REQUEST = 0;
    private static final int GENDER_REQUEST = 1;
    private static final int LEG_SIZE_REQUEST = 17;
    private static final int COLOR_REQUEST = 2;
    private static final int CATEGORY_REQUEST = 3;
    private static final int BIRTH_REQUEST = 4;
    private static final int ADOPTED_REQUEST = 5;
    private static final int MICROCHIP_REQUEST = 6;
    private static final int WATCH_REQUEST = 7;
    private static final int FLARIAL_REQUEST = 8;
    private static final int FLEA_REQUEST = 9;
    private static final int INJECTION_REQUEST = 10;

    private static final int RABIS_REQUEST = 11;
    private static final int DIAG_REQUEST = 12;
    private static final int HEAD_REQUEST = 13;

    public static final int CAMERA_REQUEST = 14;
    public static final int IMAGE_SELECT_REQUEST = 15;
    public static final int IMAGE_COMPLETE_REQUEST = 16;

    @Override
    public String getTitleName() {
        if (dogInfo != null){
            return dogInfo.getName();
        }
        return "";

    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_DOG_INFO, this);
        super.isShowHead= false;
        super.isShowName = true;
        dogInfo = (Dog)(getIntent().getSerializableExtra(Constants.EXTRA_DOG));
        dogCount = DogDeviceStationRepository.getInstance().getDogCount();
        initView();
        showDogInfo();

    }

    private void initView(){
       removeBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_white_sure_pressed, R.drawable.btn_white_sure));
        if (dogCount > 1){
            removeBtn.setVisibility(View.VISIBLE);
        }else{
            removeBtn.setVisibility(View.GONE);
        }
        removeBtn.setOnClickListener(this);
        findViewById(R.id.id_head_value).setOnClickListener(this);
        findViewById(R.id.id_name_layout).setOnClickListener(this);
        findViewById(R.id.id_sex_layout).setOnClickListener(this);
        findViewById(R.id.id_kind_layout).setOnClickListener(this);
//        findViewById(R.id.id_leg_layout).setOnClickListener(this);
        findViewById(R.id.id_color_layout).setOnClickListener(this);
        findViewById(R.id.id_birth_layout).setOnClickListener(this);
        findViewById(R.id.id_home_layout).setOnClickListener(this);
        findViewById(R.id.id_microchip_layout).setOnClickListener(this);
        findViewById(R.id.id_watch_layout).setOnClickListener(this);
        findViewById(R.id.id_medicine_layout).setOnClickListener(this);
        findViewById(R.id.id_flea_layout).setOnClickListener(this);
        findViewById(R.id.id_injection_layout).setOnClickListener(this);
        findViewById(R.id.id_rabies_layout).setOnClickListener(this);
        findViewById(R.id.id_diagnose_layout).setOnClickListener(this);
    }

    private void showDogInfo(){
        if (null == dogInfo){
            return;
        }
        showHead();

        nameValueTxt.setText(dogInfo.getName());
        Integer gender = dogInfo.getGender();
        if(null != gender){
            sexValueTxt.setText(getString(Constants.DOG_GENDER_MAP.get(gender)));
        }

        Integer category = dogInfo.getCategory();
        if (null != category){
            DogTypeModel typeModel = ApplicationUtils.getDogTypeById(category);
            if(null != typeModel){
                kindValueTxt.setText(typeModel.getName());
//                sizeValueTxt.setText(getString(Constants.DOG_SIZE_MAP.get(typeModel.getSize())));
            }
        }

//        Integer legSize = dogInfo.getLeg_size();
//        if (null != legSize){
//            legValueTxt.setText(getString(Constants.DOG_LEG_MAP.get(legSize)));
//        }

        Integer color = dogInfo.getColor();
        if (null != color){
            colorValueTxt.setText(getString(Constants.DOG_COLOR_MAP.get(color)));
        }


        Date birthday = dogInfo.getBirthday();
        Integer ageRange = dogInfo.getAge_range();
        if (null != birthday){
            birthValueTxt.setText(TimeUtils.formatWithYearMonthDay(birthday));
        } else if (null != ageRange && ageRange.equals(Constants.DOG_BIRTH_UNKNOWN)){
            birthValueTxt.setText(getResources().getString(R.string.dog_birth_unknown));
        } else {
            birthValueTxt.setText("");
        }

        Date adoptedDate = dogInfo.getAdopted_from();
        if (null != adoptedDate){
            homeValueTxt.setText(TimeUtils.formatWithYearMonthDay(adoptedDate));
        }

        microchipValueTxt.setText(dogInfo.getMicrochip_id());
        watchValueTxt.setText(dogInfo.getObserve_id());

        Integer filarialStart = dogInfo.getFilarial_start();
        Integer filarialEnd = dogInfo.getFilarial_end();
        if (null != filarialStart && null != filarialEnd){
            medicineValueValueTxt.setText(TimeUtils.formatTwoMonth(filarialStart, filarialEnd));
        }

        Integer fleaStart = dogInfo.getFlea_start();
        Integer fleaEnd = dogInfo.getFlea_end();
        if (null != fleaStart && null != fleaEnd){
            fleaValueValueTxt.setText(TimeUtils.formatTwoMonth(fleaStart, fleaEnd));
        }
        Integer vaccinatedAt = dogInfo.getVaccinated_at();
        if (null != vaccinatedAt) {
            injectionValueTxt.setText(getResources().getString(Constants.MONTH_MAP.get(dogInfo.getVaccinated_at())));
        }
        Integer rabiesMonth = dogInfo.getRabies_inoculation_at();
        if (null != rabiesMonth){
            rabiesValueTxt.setText(getResources().getString(Constants.MONTH_MAP.get(rabiesMonth)));
        }
        Integer diagMonth = dogInfo.getLast_vaccinated_at();
        if (null != diagMonth){
            diagnoseValueTxt.setText(getResources().getString(Constants.MONTH_MAP.get(diagMonth)));
        }

    }

    public void showHead() {
        if (!StringUtils.isBlank(dogInfo.getAvatar_url())){
            ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconUrl(dogInfo.getAvatar_url()), headValueImg);
        }
    }

    @Override
    public int getLayout() {
        return R.layout.dog_info_layout;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()){
            case R.id.id_head_value:
                PhotoPopViewHelper.getInstance().showPopView(this,layer);
                break;
            case R.id.id_photo_take_txt:
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File tmpImageFile = FileUtils.getNewPicFile();
                ApplicationUtils.setTmpFilePath(tmpImageFile.getAbsolutePath());
                Uri uri = Uri.fromFile(new File(tmpImageFile.getAbsolutePath()));
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
                PhotoPopViewHelper.getInstance().dismissPopView();
                break;
            case R.id.id_photo_select_txt:
                Intent selectIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                selectIntent.setType("image/*");
                startActivityForResult(selectIntent, IMAGE_SELECT_REQUEST);
                PhotoPopViewHelper.getInstance().dismissPopView();
                break;
            case R.id.id_photo_cancel_txt:
                PhotoPopViewHelper.getInstance().dismissPopView();
                break;
            case R.id.id_name_layout:
                gotoValueEditActivity(getResources().getString(R.string.dog_name),
                        ValueEditActivity.SINGLE_TEXT_TYPE,
                        ValueEditActivity.DOG_NAME,
                        NAME_REQUEST);
                break;
            case R.id.id_sex_layout:
                gotoValueSelectActivity(getResources().getString(R.string.dog_sex),
                        ValueEditActivity.SINGLE_SELECT_TYPE, ValueEditActivity.DOG_GENDER, Constants.DOG_GENDER_MAP, GENDER_REQUEST);
                break;
            case R.id.id_kind_layout:
                Intent intent = new Intent();
                intent.putExtra(Constants.EXTRA_TITLE,getString(R.string.dog_kind));
                intent.putExtra(Constants.EXTRA_VALUE,dogInfo);
                intent.setClass(this, DogTypeSelectActivity.class);
                startActivityForResult(intent, CATEGORY_REQUEST);
                break;
//            case R.id.id_leg_layout:
//                gotoValueSelectActivity(getResources().getString(R.string.dog_leg_size),
//                        ValueEditActivity.SINGLE_SELECT_TYPE, ValueEditActivity.DOG_LEG_SIZE, Constants.DOG_LEG_MAP, LEG_SIZE_REQUEST);
//                break;
            case R.id.id_color_layout:
                gotoValueSelectActivity(getResources().getString(R.string.dog_color),
                        ValueEditActivity.SINGLE_SELECT_TYPE, ValueEditActivity.DOG_COLOR, Constants.DOG_COLOR_MAP, COLOR_REQUEST);
                break;
            case R.id.id_birth_layout:
                gotoValueEditActivity(getResources().getString(R.string.dog_birthday),
                        ValueEditActivity.DATE_TYPE,
                        ValueEditActivity.DOG_BIRTH,
                        BIRTH_REQUEST);
                break;
            case R.id.id_home_layout:
                gotoValueEditActivity(getResources().getString(R.string.dog_home),
                        ValueEditActivity.DATE_TYPE,
                        ValueEditActivity.DOG_ADOPT_DATE,
                        ADOPTED_REQUEST);
                break;
            case R.id.id_microchip_layout:
                gotoValueEditActivity(getResources().getString(R.string.dog_register_self_id),
                        ValueEditActivity.SINGLE_TEXT_TYPE,
                        ValueEditActivity.DOG_MICROCHIP,
                        MICROCHIP_REQUEST);
                break;
            case R.id.id_watch_layout:
                gotoValueEditActivity(getResources().getString(R.string.dog_watch_id),
                        ValueEditActivity.SINGLE_TEXT_TYPE,
                        ValueEditActivity.DOG_WATCH,
                        WATCH_REQUEST);
                break;
            case R.id.id_medicine_layout:
                gotoValueEditActivity(getResources().getString(R.string.dog_medicine_date),
                        ValueEditActivity.TWO_MONTH_TYPE,
                        ValueEditActivity.DOG_FILARIAL_MONTH,
                        FLARIAL_REQUEST);
                break;
            case R.id.id_flea_layout:
                gotoValueEditActivity(getResources().getString(R.string.dog_flea_date),
                        ValueEditActivity.TWO_MONTH_TYPE,
                        ValueEditActivity.DOG_FLEA_MONTH,
                        FLEA_REQUEST);
                break;
            case R.id.id_injection_layout:
                gotoValueSelectActivity(getResources().getString(R.string.dog_injection_date),
                        ValueEditActivity.SINGLE_SELECT_TYPE, ValueEditActivity.DOG_INJECTION, Constants.MONTH_MAP, INJECTION_REQUEST);
                break;
            case R.id.id_rabies_layout:
                gotoValueSelectActivity(getResources().getString(R.string.dog_rabies_date),
                        ValueEditActivity.SINGLE_SELECT_TYPE, ValueEditActivity.DOG_RABIS, Constants.MONTH_MAP, RABIS_REQUEST);
                break;
            case R.id.id_diagnose_layout:
                gotoValueSelectActivity(getResources().getString(R.string.dog_diagnose_date),
                        ValueEditActivity.SINGLE_SELECT_TYPE, ValueEditActivity.DOG_DIAG, Constants.MONTH_MAP, DIAG_REQUEST);
                break;
            case R.id.id_dog_remove_btn:
                deleteDog();
                break;
            case R.id.id_pop_sure_txt:
                final int dogId = dogInfo.getDog_id();
                PopViewHelper.getInstance().dismissPop();
                showWaitingDialog();
                DogDeviceStationRepository.getInstance().deleteDogFromNet(DogDeviceStationRepository.REQUEST_FROM_DOG_INFO, dogId);
                break;
            case R.id.id_pop_cancel_txt:
                PopViewHelper.getInstance().dismissPop();
                break;
            default:
                break;
        }
    }

    private void deleteDog() {
        if (dogCount > Constants.DOG_MIN_NUM){
            PopViewHelper.getInstance().showDeletePop(this, layer,
                    getResources().getString(R.string.dog_delete_title), getResources().getString(R.string.dog_delete));
        }
    }

    private void gotoValueEditActivity(String title, int showType, int valueType, int requestCode) {
        Intent intent = new Intent();
        ValueEditModel model = new ValueEditModel();
        model.setTitle(title);
        model.setShowType(showType);
        model.setValueType(valueType);
        model.setDog(dogInfo);
        intent.putExtra(Constants.EXTRA_VALUE, model);
        intent.setClass(this, ValueEditActivity.class);
        startActivityForResult(intent, requestCode);
    }

    private void gotoValueSelectActivity(String title, int showType, int valueType, Map<Integer, Integer> map, int requestCode) {
        Intent intent = new Intent();
        ValueEditModel model = new ValueEditModel();
        model.setTitle(title);
        model.setShowType(showType);
        model.setValueType(valueType);
        model.setMap(map);
        model.setDog(dogInfo);
        intent.putExtra(Constants.EXTRA_VALUE, model);
        intent.setClass(this, ValueEditActivity.class);
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK != resultCode){
            return;
        }
        switch (requestCode){
            case CAMERA_REQUEST:
                File file = new File(ApplicationUtils.getTmpFilePath());
                if (file.exists()) {
                    File cameraSrcFile = FileUtils.getNewPicFile();
                    Intent intent = new Intent(this, ClipActivity.class);
                    intent.putExtra(Constants.EXTRA_SRC_PATH, file.getAbsolutePath());
                    intent.putExtra(Constants.EXTRA_DEST_PATH, cameraSrcFile.getAbsolutePath());
                    startActivityForResult(intent, IMAGE_COMPLETE_REQUEST);
                }
                break;
            case IMAGE_SELECT_REQUEST:
                if (null == data){
                    return;
                }
                Uri uri = data.getData();
                String selectPath = FileUtils.getPathByUri(this, uri);
                if (MediaFile.isSupportImageType(selectPath)) {
                    File selectSrcFile = FileUtils.getNewPicFile();
                    Intent intent = new Intent(this, ClipActivity.class);
                    intent.putExtra(Constants.EXTRA_SRC_PATH, selectPath);
                    intent.putExtra(Constants.EXTRA_DEST_PATH, selectSrcFile.getAbsolutePath());
                    startActivityForResult(intent, IMAGE_COMPLETE_REQUEST);
                } else {
//                        ToastManager.getInstance().showFail(getString(R.string.image_format_error));
                }
                break;
            case IMAGE_COMPLETE_REQUEST:
                String path = data.getStringExtra(Constants.EXTRA_TARGET_PATH);
//                    ImageLoader.getInstance().displayImage("file://" + path, headValueImg);
//                    dogInfo.setAvatar_url(path);
                DogDeviceStationRepository.getInstance().modifyDogHeadFromNet(
                        DogDeviceStationRepository.REQUEST_FROM_DOG_INFO,
                        dogInfo.getDog_id(), new File(path));
                break;
            case HEAD_REQUEST:
                String headUrl = data.getStringExtra(Constants.EXTRA_DOG_HEAD);
                if (!StringUtils.isBlank(headUrl)){
                    dogInfo.setAvatar_url(headUrl);
                    ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconUrl(headUrl),headValueImg);
                }
                break;
            case NAME_REQUEST:
                ValueEditModel model = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if (model.isConnectNetSuccess()){
                    dogInfo.setName(model.getDog().getName());
                    nameValueTxt.setText(model.getDog().getName());
                    titleNameTxt.setText(model.getDog().getName());
                }
                break;
            case GENDER_REQUEST:
                ValueEditModel model1 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if(model1.isConnectNetSuccess()){
                    Integer gender = model1.getDog().getGender();
                    dogInfo.setGender(gender);
                    if (null == gender) {
                        sexValueTxt.setText("");
                    } else {
                        sexValueTxt.setText(getResources().getString(Constants.DOG_GENDER_MAP.get(gender)));
                    }
                }
                break;
//            case LEG_SIZE_REQUEST:
//                ValueEditModel model13 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
//                if(model13.isConnectNetSuccess()){
//                    Integer legSize = model13.getDog().getLeg_size();
//                    dogInfo.setLeg_size(legSize);
//                    if (null == legSize) {
//                        legValueTxt.setText("");
//                    } else {
//                        legValueTxt.setText(getResources().getString(Constants.DOG_LEG_MAP.get(legSize)));
//                    }
//                }
//                break;
            case COLOR_REQUEST:
                ValueEditModel model2 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if(model2.isConnectNetSuccess()){
                    Integer color = model2.getDog().getColor();
                    dogInfo.setColor(color);
                    if (null == color) {
                        colorValueTxt.setText("");
                    } else {
                        colorValueTxt.setText(getResources().getString(Constants.DOG_COLOR_MAP.get(color)));
                    }
                }
                break;
            case CATEGORY_REQUEST:
                Serializable serializable = data.getSerializableExtra(Constants.EXTRA_VALUE);
                if (null != serializable){
                    DogTypeModel dogTypeModel = (DogTypeModel) serializable;
                    dogInfo.setCategory(dogTypeModel.getType_id());
                    dogInfo.setSize(dogTypeModel.getSize());
                    dogInfo.setLeg_size(dogTypeModel.getLeg());
                    kindValueTxt.setText(dogTypeModel.getName());
//                    legValueTxt.setText(getString(Constants.DOG_LEG_MAP.get(dogTypeModel.getLeg())));
//                    sizeValueTxt.setText(getString(Constants.DOG_SIZE_MAP.get(dogTypeModel.getSize())));

                } else {
                    dogInfo.setCategory(null);
                    dogInfo.setSize(null);
                    dogInfo.setLeg_size(null);
                    kindValueTxt.setText("");
//                    legValueTxt.setText("");
                }
                break;
            case BIRTH_REQUEST:
                ValueEditModel model3 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if (model3.isConnectNetSuccess()){
                    Date birth = model3.getDog().getBirthday();
                    Integer ageRange = model3.getDog().getAge_range();
                    dogInfo.setBirthday(birth);
                    if(null != birth){
                        birthValueTxt.setText(TimeUtils.formatWithYearMonthDay(birth));
                    } else if (null != ageRange && ageRange.equals(Constants.DOG_BIRTH_UNKNOWN)){
                        birthValueTxt.setText(getResources().getString(R.string.dog_birth_unknown));
                    } else {
                        birthValueTxt.setText("");
                    }
                }
                break;
            case ADOPTED_REQUEST:
                ValueEditModel model4 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if (model4.isConnectNetSuccess()){
                    Date adoptDate = model4.getDog().getAdopted_from();
                    dogInfo.setAdopted_from(adoptDate);
                    if (null == adoptDate){
                        homeValueTxt.setText("");
                    } else {
                        homeValueTxt.setText(TimeUtils.formatWithYearMonthDay(model4.getDog().getAdopted_from()));
                    }
                  }
                break;
            case MICROCHIP_REQUEST:
                ValueEditModel model5 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if (model5.isConnectNetSuccess()){
                    dogInfo.setMicrochip_id(model5.getDog().getMicrochip_id());
                    microchipValueTxt.setText(model5.getDog().getMicrochip_id());
                }
                break;
            case WATCH_REQUEST:
                ValueEditModel model6 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if (model6.isConnectNetSuccess()){
                    dogInfo.setObserve_id(model6.getDog().getObserve_id());
                    watchValueTxt.setText(model6.getDog().getObserve_id());
                }
                break;
            case FLARIAL_REQUEST:
                ValueEditModel model7 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if (model7.isConnectNetSuccess()){
                    Integer startMonth = model7.getDog().getFilarial_start();
                    Integer endMonth = model7.getDog().getFilarial_end();
                    dogInfo.setFilarial_start(startMonth);
                    dogInfo.setFilarial_end(endMonth);
                    if (null != startMonth && null != endMonth){
                        medicineValueValueTxt.setText(TimeUtils.formatTwoMonth(startMonth, endMonth));
                    } else {
                        medicineValueValueTxt.setText("");
                    }
                }
                break;
            case FLEA_REQUEST:
                ValueEditModel model8 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if (model8.isConnectNetSuccess()){
                    Integer startMonth = model8.getDog().getFlea_start();
                    Integer endMonth = model8.getDog().getFlea_end();
                    dogInfo.setFlea_start(startMonth);
                    dogInfo.setFlea_end(endMonth);
                    if (null != startMonth && null != endMonth) {
                        fleaValueValueTxt.setText(TimeUtils.formatTwoMonth(startMonth, endMonth));
                    } else {
                        fleaValueValueTxt.setText("");
                    }
                }
                break;
            case INJECTION_REQUEST:
                ValueEditModel model9 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if(model9.isConnectNetSuccess()){
                    Integer vaccinated = model9.getDog().getVaccinated_at();
                    if (null == vaccinated){
                        dogInfo.setVaccinated_at(null);
                        injectionValueTxt.setText("");
                    } else {
                        dogInfo.setVaccinated_at(vaccinated);
                        injectionValueTxt.setText(getResources().getString(Constants.MONTH_MAP.get(vaccinated)));
                    }
                }
                break;
            case RABIS_REQUEST:
                ValueEditModel model10 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if(model10.isConnectNetSuccess()){
                    Integer rabies = model10.getDog().getRabies_inoculation_at();
                    if (null == rabies){
                        dogInfo.setRabies_inoculation_at(null);
                        rabiesValueTxt.setText("");
                    } else {
                        dogInfo.setRabies_inoculation_at(rabies);
                        rabiesValueTxt.setText(getResources().getString(Constants.MONTH_MAP.get(rabies)));
                    }
                }
                break;
            case DIAG_REQUEST:
                ValueEditModel model11 = (ValueEditModel) data.getSerializableExtra(Constants.EXTRA_VALUE);
                if(model11.isConnectNetSuccess()){
                    Integer diag = model11.getDog().getLast_vaccinated_at();
                    if (null == diag){
                        dogInfo.setLast_vaccinated_at(null);
                        diagnoseValueTxt.setText("");
                    } else {
                        dogInfo.setLast_vaccinated_at(diag);
                        diagnoseValueTxt.setText(getResources().getString(Constants.MONTH_MAP.get(diag)));
                    }
                }
                break;

            default:
                break;
        }
    }

    @Override
    public void success(Object dog, int type) {
        if (type == DogDeviceStationRepository.DELETE_DOG_FROM_NET_MODE){
            hideWaitingDialog();
            finish();
        } else if (type == DogDeviceStationRepository.MODIFY_HEAD_FROM_NET_MODE){
            String url = ((Dog) dog).getAvatar_url();
            dogInfo.setAvatar_url(url);
            if (!StringUtils.isBlank(url)){
                ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconUrl(url), headValueImg);
            }
        }
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
        hideWaitingDialog();
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
        hideWaitingDialog();
    }

    @Override
    protected void onDestroy() {
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_DOG_INFO);
        super.onDestroy();
    }
}
