package com.fujitsu.wandant.model;

/**
 * Created by chenjie.fnst on 2015/10/19.
 */
public class DogDataModel extends BaseModel {

    private String guid;
    private String utc;
    private int dogId;

    public DogDataModel(String guid, String utc, int dogId) {
        this.guid = guid;
        this.utc = utc;
        this.dogId = dogId;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getUtc() {
        return utc;
    }

    public void setUtc(String utc) {
        this.utc = utc;
    }

    public int getDogId() {
        return dogId;
    }

    public void setDogId(int dogId) {
        this.dogId = dogId;
    }

}
