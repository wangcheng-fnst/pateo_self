package com.fujitsu.wandant.activity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.adapter.ListAllMsgAdapter;
import com.fujitsu.wandant.model.MutterAllModel;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.MutterRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.net.model.MurmurForapp;
import com.fujitsu.wandant.net.model.MuttersInfo;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.view.LoadMoreListView;
import com.fujitsu.wandant.view.ToastManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * all mutters
 * Created by ym-zhongxy on 2015/9/22.
 */
public class MutterInfoActivity extends BaseActivity implements OnModelFinishedListener {
    private LoadMoreListView lvMsg;
    private List<MutterAllModel> mutterModels;
    private ListAllMsgAdapter adapter;
    private Long queryDate = 0L;
    private Object lock = new Object();
    private int currentPage = 0;
    private Map<Integer,Dog> dogIdMap = new HashMap<>();
    private List<Integer> dogIdList = new ArrayList<>();

    @Bind(R.id.id_no_message_view)
    View noMessageView;

    @Override
    public String getTitleName() {
        return getString(R.string.history_all);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public int getLayout() {
        return R.layout.activity_msg;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        bindViews();
        initData();
        MutterRepository.getInstance().register(MutterRepository.REQUEST_FROM_MUTTER_INFO_TYPE, this);
        MutterRepository.getInstance().getMutterAll(MutterRepository.REQUEST_FROM_MUTTER_INFO_TYPE,
                currentPage, queryDate);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MutterRepository.getInstance().unRegister(MutterRepository.REQUEST_FROM_MUTTER_INFO_TYPE);
    }

    private void bindViews() {
        lvMsg = (LoadMoreListView) findViewById(R.id.lvMsg);
        lvMsg.setOnLoadMoreListener(new LoadMoreListView.OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                new LoadMoreDataTask().execute();
            }
        });
    }

    private void initData(){
        List<Dog> dogList = DogDeviceStationRepository.getInstance().loadDogsFromDb();
        dogIdList.clear();
        for (Dog dog:dogList) {
            dogIdMap.put(dog.getDog_id(),dog);
            dogIdList.add(dog.getDog_id());
        }
        mutterModels = MutterRepository.getInstance().loadMuttersFromMutterAllDB();
        if(adapter == null){
            adapter = new ListAllMsgAdapter(this, mutterModels,dogIdMap);
        }
        if (null == mutterModels || mutterModels.isEmpty()){
            noMessageView.setVisibility(View.VISIBLE);
        } else {
            noMessageView.setVisibility(View.GONE);
        }
        lvMsg.setAdapter(adapter);
    }

    private void updateMutter(MuttersInfo result) {
        synchronized (lock) {
            queryDate = result.getQuery_date();
            if(0 == currentPage){
                mutterModels.clear();
            }
            if (null != result || null != result.getMurmurList()){
                currentPage++;
                List<MurmurForapp> mutters = result.getMurmurList();
                if (null != mutters && mutters.size() > 0){
                    for (MurmurForapp mutter : mutters){
//                        if (dogIdlist.contains(mutter.getDog_id())){
                            MutterAllModel mutterModel = MutterAllModel.create(mutter);
                            mutterModels.add(mutterModel);
//                        }
                    }
                }
                adapter.refreshList(mutterModels);
                if (null == mutterModels || mutterModels.isEmpty()){
                    noMessageView.setVisibility(View.VISIBLE);
                } else {
                    noMessageView.setVisibility(View.GONE);
                }
            }
            lvMsg.onLoadMoreComplete();
        }
    }

    @Override
    public void success(Object result, int mode) {
        switch (mode){
            case MutterRepository.LOAD_ALL_MUTTER_FROM_NET_MODE:
                updateMutter( (MuttersInfo) result);
                break;
            default:
                break;
        }
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
        lvMsg.onLoadMoreComplete();
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
        lvMsg.onLoadMoreComplete();
    }

    private class LoadMoreDataTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {

            if (isCancelled()) {
                return null;
            }
            MutterRepository.getInstance().getMutterAll(MutterRepository.REQUEST_FROM_MUTTER_INFO_TYPE,
                    currentPage, queryDate);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }
    }


}
