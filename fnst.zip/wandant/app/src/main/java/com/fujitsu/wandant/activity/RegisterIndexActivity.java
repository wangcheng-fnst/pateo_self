package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;

/**
 * Created by wangc.fnst on 2015/10/14.
 */
public class RegisterIndexActivity extends BaseActivity {

    @Bind(R.id.id_login_begin_btn)
    Button loginBeginBtn;
    @Bind(R.id.id_login_txt)
    TextView loginTxt;
    @Bind(R.id.id_set_txt)
    TextView setTxt;

    @Override
    public String getTitleName() {
        return getResources().getString(R.string.register_index_title);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        super.isShowHead =  false;
        super.isShowName = true;
        loginTxt.getPaint().setFakeBoldText(true);
        setTxt.getPaint().setFakeBoldText(true);
        loginBeginBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        loginBeginBtn.setOnClickListener(this);
        findViewById(R.id.id_myCloud_txt).setOnClickListener(this);
    }

    @Override
    public int getLayout() {
        return R.layout.register_index_layout;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        int id = v.getId();
        if (id == R.id.id_myCloud_txt){

        }else if (id == R.id.id_login_begin_btn){
            Intent intent = new Intent(this,AgreementWithoutAccountActivity.class);
            startActivity(intent);
        }
    }
}
