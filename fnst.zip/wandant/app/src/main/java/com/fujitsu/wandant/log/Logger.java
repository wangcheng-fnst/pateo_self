package com.fujitsu.wandant.log;

import android.util.Log;
import com.fujitsu.wandant.utils.ApplicationUtils;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileFilter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * APPのログ情報をファイルに保存するために使用されている
 *
 * @author FNST)
 * Copyright (c) 2015年 fujitsu. All rights reserved.
 */

public final class Logger {
    /**
     * ログ出力なし
     */
    public static final int LOG_NONE = 0;

    /**
     * エラーログまで出力
     */
    public static final int LOG_ERROR = 10;

    /**
     * 警告ログまで出力
     */
    public static final int LOG_WARN = 11;

    /**
     * インフォアログまで出力
     */
    public static final int LOG_INFO = 12;

    /**
     * デバッグログまで出力
     */
    public static final int LOG_DEBUG = 13;

    /**
     * すべてのログ出力
     */
    public static final int LOG_ALL = 100;

    /**
     * Debug Logモード
     */
    public static final int MODE_DEBUG = 1;

    /**
     * Release Logモード
     */
    public static final int MODE_RELEASE = 2;

    /**
     * log フォルダ名
     */
    public static final String LOG_DIR = "wandant" + File.separator + "Log";

    /**
     * 許可される最大ファイル·サイズ
     */
    private static final long MAX_LOG_FILE_SIZE = 2 * 1024 * 1024;

    /**
     * 許可される最大保存時間
     */
    private static final long MAX_LOG_FILE_TIME = 15 * 24 * 3600 * 1000;

    /**
     * 最小残りのストレージスペース
     */
    private static final long MIN_FREESPACE = 10 * 1024 * 1024;


    private static final SimpleDateFormat dateFormat;

    /**
     * Releaseモードのフォルダ名
     */
    public static final String DEBUG_LOG_FILE_NAME = "Wandant-Debug.log";

    /**
     * Releaseモードのバックアップフォルダ名
     */
    private static final String DEBUG_LOG_FILE_NAME2 = "Wandant-Debug2.log";

    /**
     * ファイルの出力オブジェクト
     */
    private static FileWriter fileWriter;
    private static String fileName;
    private static int mode = MODE_DEBUG;
    private static String ALL_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
    private static String SIMPLE_DATE = "yyyy-MM-dd";
    private static String LOG_EXTEND = ".log";
    private static int currentLogLevel = LOG_DEBUG;
    private static boolean needSaveLogToFile = true;
    private static Object lock = new Object();

    /**
     * システムのデフォルトUncaughtExceptionハンドラ
     */
    private static Thread.UncaughtExceptionHandler mDefaultHandler;

    static {
        dateFormat = new SimpleDateFormat(ALL_DATE_FORMAT);
        //システムのデフォルトUncaughtExceptionハンドラを取得する
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        //カスタムUncaughtExceptionハンドラを設定する
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable ex) {
                //UncaughtExceptionをLogに出力する
                handlerException(ex);
                if (mDefaultHandler != null) {
                    mDefaultHandler.uncaughtException(thread, ex);
                }
            }

            /**
             * UncaughtException情報をLogに出力する
             * @param ex
             */
            private void handlerException(Throwable ex) {
                if (ex == null) {
                    return;
                }
                String errorTag = "UnCaughtError";
                StringBuilder errorMsg = new StringBuilder(ex.getMessage() + "\n");
                for (StackTraceElement stackTraceElement : ex.getStackTrace()) {
                    errorMsg.append(stackTraceElement.toString() + "\n");
                }
                if (ex.getCause() != null) {
                    for (StackTraceElement stackTraceElement : ex.getCause().getStackTrace()) {
                        errorMsg.append(stackTraceElement.toString() + "\n");
                    }
                }
                //エラーログを出力する
                e(errorTag, errorMsg.toString());
            }
        });
    }

    /**
     * 現在のログレベルを設定する
     *
     * @param log ログレベル
     */
    public static void setCurrentLogLevel(int log) {
        currentLogLevel = log;
    }

    /**
     * ァイルに保存する必要があるかどうかを設定する
     *
     * @param flag ァイルに保存
     */
    public static void setNeedSaveLogToFile(boolean flag) {
        needSaveLogToFile = flag;
    }

    /**
     * 現在のログモードを設定する
     *
     * @param aMode ログモード
     */
    public static void setMode(int aMode) {
        mode = aMode;
    }

    /**
     * デバッグログを出力する
     *
     * @param tag     ログのタグ
     * @param message ログの内容
     */
    public static void d(String tag, String message) {
        //"現在のログレベル>=デバッグレベル"、ログを出力する
        if (currentLogLevel >= LOG_DEBUG) {
            Log.d(tag, message);
            saveLogToFile(tag, message, "D");
        }
    }

    /**
     * エラーログを出力する
     *
     * @param tag     ログのタグ
     * @param message ログの内容
     */
    public static void e(String tag, String message) {
        //"現在のログレベル>=エラーレベル"、ログを出力する
        if (currentLogLevel >= LOG_ERROR) {
            Log.e(tag, message);
            saveLogToFile(tag, message, "E");
        }
    }

    /**
     * インフォアログを出力する
     *
     * @param tag     ログのタグ
     * @param message ログの内容
     */
    public static void i(String tag, String message) {
        //"現在のログレベル>=インフォアレベル"、ログを出力する
        if (currentLogLevel >= LOG_INFO) {
            Log.i(tag, message);
            saveLogToFile(tag, message, "I");
        }
    }

    /**
     * 警告ログを出力する
     *
     * @param tag     ログのタグ
     * @param message ログの内容
     */
    public static void w(String tag, String message) {
        //"現在のログレベル>=警告レベル"、ログを出力する
        if (currentLogLevel >= LOG_WARN) {
            Log.w(tag, message);
            saveLogToFile(tag, message, "W");
        }
    }

    /**
     * ファイルに出力する
     *
     * @param tag      ログのタグ
     * @param message  ログの内容
     * @param logLevel ログレベル
     */
    private static void saveLogToFile(String tag, String message, String logLevel) {
        synchronized (lock) {
            String debugFile = ApplicationUtils.getCacheFileDirPath() + File.separator + LOG_DIR + File.separator + DEBUG_LOG_FILE_NAME;
            //現在のモードがLOGをファイルに出力する必要がない場合は、直接返す
            if (!needSaveLogToFile || (mode == MODE_RELEASE && !new File(debugFile).exists())) {
                return;
            }
            //ログの出力フォーマット:    時間 <ログレベル > [クラス名 方法名 行番号](V:バージョン番号) --> ログのタグ:ログの内容
            String log = String.format(
                    "%s <%s> [%s %s:%d](V:%d) --> %s/:%s",
                    dateFormat.format(new Date()),
                    logLevel,
                    StackTraceInfo.getCurrentClassName(),
                    StackTraceInfo.getCurrentMethodName(),
                    StackTraceInfo.getCurrentMethodLineNumber(),
                    ApplicationUtils.getPackageVersion(),
                    tag,
                    message);
            try {
                //ログをファイルに出力する
                FileWriter fileWriter = getCurrentFileWriter();
                if (fileWriter != null) {
                    fileWriter.write(log + "\n");
                    fileWriter.flush();
                }
            } catch (IOException e) {
                closeWriter();
            }
        }
    }

    /**
     * 現在書き込み中のログファイルのFileWriteを取得する
     *
     * @return ログファイルのFileWrite
     * @throws IOException
     */
    private static FileWriter getCurrentFileWriter() throws IOException {
        File cacheFile = ApplicationUtils.getCacheFileDir();
        //キャッシュファイルが存在しない、または書き込むことができない場合で、nullを返す
        if (cacheFile == null) {
            return null;
        }
        String logFileName = getLogFileName(cacheFile);
        //ログファイル名を取得できない時に、nullを返す
        if (logFileName == null) {
            return null;
        }
        //ファイル名と前回のファイル名が異なる場合、ファイルを作成する必要があります
        if (!logFileName.equals(fileName) || fileWriter == null) {
            //残りのストレージスペース > デフォルト値、出力する
            if (cacheFile.getFreeSpace() > MIN_FREESPACE) {
                File logFile = new File(logFileName);
                //フォルダが存在しなければ、作成する必要がある
                if (!logFile.getParentFile().exists()) {
                    //ファイルの作成失敗、nullを返す
                    if (!logFile.getParentFile().mkdirs()) {
                        return null;
                    }
                }
                closeWriter();
                fileWriter = new FileWriter(logFileName, true);
                fileName = logFileName;
            } else {
                Log.e(Logger.class.getName(), "残りのスペースが不足している");
                closeWriter();
            }
        }
        return fileWriter;

    }

    /**
     * Logファイル名を取得する
     *
     * @param cacheFile Logファイルのストレージパス
     * @return  Logファイル名
     */
    private static String getLogFileName(File cacheFile) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(SIMPLE_DATE);

        String logFileName = null;
        if (mode == MODE_DEBUG) {  //現在のモデルはdebugモデル
            int i = 0;
            while (true) {
                StringBuilder stringBuilder = new StringBuilder();
                //ログファイル: <cache dir>/Log/<yyyy-MM-dd>_%d.log
                logFileName = stringBuilder.append(cacheFile.getAbsolutePath())
                        .append(File.separator)
                        .append(LOG_DIR).append(File.separator)
                        .append(dateFormat.format(new Date()))
                        .append("_")
                        .append(i)
                        .append(LOG_EXTEND)
                        .toString();
                File file = new File(logFileName);
                //ファイルが存在しないとファイルの上限が超えていない場合、ファイル名が返される
                if (!file.exists() || file.length() < MAX_LOG_FILE_SIZE) {
                    break;
                }
                i++;
            }

        } else if (mode == MODE_RELEASE) { //現在のモデルはreleaseモデル
            logFileName = ApplicationUtils.getCacheFileDirPath() + File.separator + LOG_DIR + File.separator + DEBUG_LOG_FILE_NAME;
            //ファイルの上限が超える場合に、logをMapMark-Debug2.logに出力する
            if (new File(logFileName).length() > MAX_LOG_FILE_SIZE) {
                try {
                    closeWriter();
                    File backupFile = new File(ApplicationUtils.getCacheFileDirPath() + File.separator + LOG_DIR + File.separator + DEBUG_LOG_FILE_NAME2);
                    if(backupFile.exists() && !backupFile.delete()) {
                        Log.e(Logger.class.getName(), "delete old file failed");
                    }
                    FileUtils.moveFile(new File(logFileName), backupFile);
                    fileWriter = new FileWriter(logFileName, true);
                } catch (IOException e) {
                    Log.e(Logger.class.getName(), "move file failed " + e.getMessage());
                }
                fileName = logFileName;
            }
        }
        return logFileName;

    }


    /**
     * オープンのログファイルを閉じる
     */
    public static void closeWriter() {
        if (fileWriter != null) {
            try {
                fileWriter.close();
            } catch (IOException e) {
                Log.e(Logger.class.getName(), e.getMessage());
            }
            fileWriter = null;
        }
    }

    /**
     * 有効期限が切れるログファイルを削除する
     */
    public static void deleteLogs() {
        //現在のモデルはreleaseモデル
        if (mode == MODE_RELEASE) {
            return;
        }
        File cacheFile = ApplicationUtils.getCacheFileDir();
        //キャッシュファイルが存在しない、または書き込むことができない場合で、nullを返す
        if (cacheFile == null) {
            return;
        }
        final Date currentTime = new Date();
        File logDir = new File(new StringBuilder().append(cacheFile.getAbsolutePath())
                .append(File.separator)
                .append(LOG_DIR)
                .append(File.separator).toString());
        //不要なログフォルダを削除する
        if (logDir.exists()) {
            for (File file : logDir.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    long currentMilTime = 0;
                    long fileMilTime = 0;
                    try {
                        fileMilTime = format.parse(pathname.getName().split("_")[0]).getTime();
                        currentMilTime = format.parse(format.format(new Date(currentTime.getTime()))).getTime();
                    } catch (ParseException e) {}
                    //有効期限が切れると、ファイルを削除する
                    return (currentMilTime - fileMilTime) >= MAX_LOG_FILE_TIME;
                }
            })) {
                file.delete();
            }
        }
    }


}
