package com.fujitsu.wandant.model;

import java.io.Serializable;

public abstract class BaseModel implements Serializable{



}
