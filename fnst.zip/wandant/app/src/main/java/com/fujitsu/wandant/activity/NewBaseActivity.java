package com.fujitsu.wandant.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.fujitsu.wandant.utils.ApplicationUtils;
import com.fujitsu.wandant.view.ProgressDialog;
import rx.Observable;
import rx.functions.Action1;

import java.util.concurrent.TimeUnit;

/**
 * Created by chenjie.fnst on 2016/01/20.
 */
public class NewBaseActivity extends Activity  implements View.OnClickListener  {

    public static NewBaseActivity activity;

    /** progress dialog to show when loading */
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = this;
    }

    @Override
    public void onClick(View v) {
        if (ApplicationUtils.isFastClick()) {
            return;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != dialog) {
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
            dialog.cancel();
        }
    }

    /**
     * show waiting dialog
     *
     */
    public void showWaitingDialog() {
        if (null == dialog) {
            dialog = new ProgressDialog(this);
        }

        dialog.setCancelable(false);
        dialog.show();
        Observable.timer(15, TimeUnit.SECONDS).subscribe(new Action1<Long>() {
            @Override
            public void call(Long aLong) {
                hideWaitingDialog();
            }
        });
    }

    /**
     * show waiting dialog
     *
     */
    public void showAlwaysWaitingDialog() {
        if (null == dialog) {
            dialog = new ProgressDialog(this);
        }

        dialog.setCancelable(false);
        dialog.show();
    }

    /**
     * hide waiting dialog
     *
     */
    public void hideWaitingDialog() {
        if ((dialog != null) && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

}
