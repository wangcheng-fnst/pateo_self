package com.fujitsu.wandant.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.*;
import android.text.style.ImageSpan;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.model.DogTypeModel;
import com.fujitsu.wandant.net.DogDeviceStationRepository;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.*;
import com.fujitsu.wandant.view.CircleImageView;
import com.fujitsu.wandant.view.PhotoPopViewHelper;
import com.fujitsu.wandant.view.ToastManager;
import com.fujitsu.wandant.view.datepicker.DatePickView;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.io.File;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by wangc.fnst on 2015/10/12.
 */
public class DogRegisterActivity extends BaseActivity implements OnModelFinishedListener {

    protected Context context;
    private DatePickView datePickView;
    private Map<Integer, String> mIdStringMap = new HashMap<Integer, String>();
    protected Dog dog = null;
    protected DogTypeModel typeModel;

    @Bind(R.id.id_head_value)
    CircleImageView headCiv;
    @Bind(R.id.id_dog_register_note)
    TextView registerNoteTv;
    @Bind(R.id.id_name_value_edit)
    EditText nameEdit;
    @Bind(R.id.id_sex_value_txt)
    TextView sexTxt;
    @Bind(R.id.id_birthday_value_txt)
    TextView birthdayTxt;
    @Bind(R.id.id_kind_value_txt)
    TextView kindTxt;
//    @Bind(R.id.id_leg_size_value_txt)
//    TextView legSizeTxt;
//    @Bind(R.id.id_size_value_edit)
//    EditText sizeEdit;
//    @Bind(R.id.id_color_value_txt)
//    TextView colorTxt;
//    @Bind(R.id.id_home_value_txt)
//    TextView homeTxt;
//    @Bind(R.id.id_self_value_edit)
//    EditText microchipEdit;
//    @Bind(R.id.id_watch_value_edit)
//    EditText watchEdit;
//    @Bind(R.id.id_medicine_value_txt)
//    TextView medicineTxt;
//    @Bind(R.id.id_flea_value_txt)
//    TextView fleaTxt;
//    @Bind(R.id.id_injection_value_txt)
//    TextView injectionTxt;
//    @Bind(R.id.id_rabies_value_txt)
//    TextView rabiesTxt;
//    @Bind(R.id.id_diagnose_value_txt)
//    TextView diagnoseTxt;
    @Bind(R.id.id_progress_flag)
    View prgressView;
    @Bind(R.id.id_next_step_btn)
    Button nextStepBtn;
    @Bind(R.id.id_dog_register_layer)
    View layer;

    private static final int KIND_RESULT_CODE = 100;
    private static final int CAMERA_REQUEST = 14;
    private static final int IMAGE_SELECT_REQUEST = 15;
    private static final int IMAGE_COMPLETE_REQUEST = 16;

    @Override
    public String getTitleName() {
        return getResources().getString(R.string.dog_register_title);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }


    @Override
    public int getLayout() {
        return R.layout.dog_register_layout;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        initView();
        dog = new Dog();
        DogDeviceStationRepository.getInstance().register(DogDeviceStationRepository.REQUEST_FROM_DOG_REGISTER, this);

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_DOG_REGISTER);
    }

    private void initView() {
        context = this;
        if (activityFromFlag == Constants.ACTIVITY_FROM_REGISTER){
            prgressView.setVisibility(View.VISIBLE);
        } else {
            prgressView.setVisibility(View.GONE);
        }
        if (activityFromFlag == Constants.ACTIVITY_FROM_REGISTER || activityFromFlag == Constants.ACTIVITY_FROM_MAIN){
            isBackable = false;
        } else {
            isBackable = true;
        }
        headCiv.setOnClickListener(this);

        String note = getString(R.string.dog_register_note);
        SpannableStringBuilder ssb = new SpannableStringBuilder(note);
        Drawable dd = getResources().getDrawable(R.drawable.photo_add_icon);
        int size = (int) ApplicationUtils.dp2px(this, 20);
        dd.setBounds(0, 0, size, size);
        ImageSpan is = new ImageSpan(dd, ImageSpan.ALIGN_BASELINE);
        ssb.setSpan(is, 1, 2, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        registerNoteTv.setText(ssb);

        setBtnStates(false);
//        nextStepBtn.setEnabled(false);
        nextStepBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        InputFilter[] nameFilter = new InputFilter[] {
                new InputFilter.LengthFilter(Constants.DOG_NAME_MAX)
        };
        nameEdit.setFilters(nameFilter);
        nameEdit.addTextChangedListener(textWatcher);
        sexTxt.addTextChangedListener(textWatcher);
        birthdayTxt.addTextChangedListener(textWatcher);
        kindTxt.addTextChangedListener(textWatcher);
//        legSizeTxt.addTextChangedListener(textWatcher);
        sexTxt.setOnClickListener(this);
        birthdayTxt.setOnClickListener(this);
        kindTxt.setOnClickListener(this);
//        legSizeTxt.setOnClickListener(this);
//        colorTxt.setOnClickListener(this);
//        homeTxt.setOnClickListener(this);
//        medicineTxt.setOnClickListener(this);
//        fleaTxt.setOnClickListener(this);
//        injectionTxt.setOnClickListener(this);
//        rabiesTxt.setOnClickListener(this);
//        diagnoseTxt.setOnClickListener(this);
        nextStepBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        nextStepBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        int id = v.getId();
        switch (id) {
            case R.id.id_head_value:
                PhotoPopViewHelper.getInstance().showPopView(this,layer);
                break;
            case R.id.id_photo_take_txt:
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File tmpImageFile = FileUtils.getNewPicFile();
                ApplicationUtils.setTmpFilePath(tmpImageFile.getAbsolutePath());
                Uri uri = Uri.fromFile(new File(tmpImageFile.getAbsolutePath()));
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
                PhotoPopViewHelper.getInstance().dismissPopView();
                break;
            case R.id.id_photo_select_txt:
                Intent selectIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                selectIntent.setType("image/*");
                startActivityForResult(selectIntent, IMAGE_SELECT_REQUEST);
                PhotoPopViewHelper.getInstance().dismissPopView();
                break;
            case R.id.id_photo_cancel_txt:
                PhotoPopViewHelper.getInstance().dismissPopView();
                break;
            case R.id.id_next_step_btn:
                addDog();
                return;
            case R.id.id_sex_value_txt:
                mIdStringMap = convertMap(Constants.DOG_GENDER_MAP);
                getDialog(DatePickView.DIALOG_THEME_ARRAY, (TextView) v);
                datePickView.show();
                break;
            case R.id.id_birthday_value_txt:
                getDialog(DatePickView.DIALOG_THEME_DATE, (TextView) v);
                datePickView.setDogBirthUnknownVisibility(View.VISIBLE);
                datePickView.show();
                break;
            case R.id.id_kind_value_txt:
                Intent intent = new Intent(this,DogTypeSelectActivity.class);
                intent.putExtra(Constants.EXTRA_TITLE,getString(R.string.dog_kind));
                intent.putExtra(Constants.EXTRA_DOG_TYPE_SELECT_MODE, false);
                startActivityForResult(intent, KIND_RESULT_CODE);
                break;
//            case R.id.id_leg_size_value_txt:
//                mIdStringMap = convertMap(Constants.DOG_LEG_MAP);
//                getDialog(DatePickView.DIALOG_THEME_ARRAY, (TextView) v);
//                datePickView.show();
//                break;
//            case R.id.id_color_value_txt:
//                mIdStringMap = convertMap(Constants.DOG_COLOR_MAP);
//                getDialog(DatePickView.DIALOG_THEME_ARRAY,(TextView)v);
//                datePickView.show();
//                break;
//            case R.id.id_home_value_txt:
//                getDialog(DatePickView.DIALOG_THEME_DATE,(TextView)v);
//                datePickView.show();
//                break;
//            case R.id.id_medicine_value_txt:
//                getDialog(DatePickView.DIALOG_THEME_TWO_MONTH,(TextView)v);
//                datePickView.show();
//                break;
//            case R.id.id_flea_value_txt:
//                getDialog(DatePickView.DIALOG_THEME_TWO_MONTH,(TextView)v);
//                datePickView.show();
//                break;
//            case R.id.id_injection_value_txt:
//                getDialog(DatePickView.DIALOG_THEME_ONE_MONTH,(TextView)v);
//                datePickView.show();
//                break;
//            case R.id.id_rabies_value_txt:
//                getDialog(DatePickView.DIALOG_THEME_ONE_MONTH,(TextView)v);
//                datePickView.show();
//                break;
//            case R.id.id_diagnose_value_txt:
//                getDialog(DatePickView.DIALOG_THEME_ONE_MONTH,(TextView)v);
//                datePickView.show();
//                break;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (RESULT_OK != resultCode){
            return;
        }
        switch (requestCode){
            case KIND_RESULT_CODE:
                if (data == null) {
                    return;
                }
                typeModel = (DogTypeModel)data.getSerializableExtra(Constants.EXTRA_VALUE);
                if (typeModel != null){
                    kindTxt.setText(typeModel.getName());
//                    int leg = typeModel.getLeg();
//                    if (Constants.DOG_LEG_MAP.containsKey(leg)){
//                        legSizeTxt.setTag(leg);
//                        legSizeTxt.setText(getResources().getString(Constants.DOG_LEG_MAP.get(typeModel.getLeg())));
//                    }
                }
                break;
            case CAMERA_REQUEST:
                File file = new File(ApplicationUtils.getTmpFilePath());
                if (file.exists()) {
                    File cameraSrcFile = FileUtils.getNewPicFile();
                    Intent intent = new Intent(this, ClipActivity.class);
                    intent.putExtra(Constants.EXTRA_SRC_PATH, file.getAbsolutePath());
                    intent.putExtra(Constants.EXTRA_DEST_PATH, cameraSrcFile.getAbsolutePath());
                    startActivityForResult(intent, IMAGE_COMPLETE_REQUEST);
                }
                break;
            case IMAGE_SELECT_REQUEST:
                if (null == data){
                    return;
                }
                Uri uri = data.getData();
                String path = FileUtils.getPathByUri(this, uri);
                if (MediaFile.isSupportImageType(path)) {
                    File selectSrcFile = FileUtils.getNewPicFile();
                    Intent intent = new Intent(this, ClipActivity.class);
                    intent.putExtra(Constants.EXTRA_SRC_PATH, path);
                    intent.putExtra(Constants.EXTRA_DEST_PATH, selectSrcFile.getAbsolutePath());
                    startActivityForResult(intent, IMAGE_COMPLETE_REQUEST);
                } else {
//                        ToastManager.getInstance().showFail(getString(R.string.image_format_error));
                }
                break;
            case IMAGE_COMPLETE_REQUEST:
                String headPath = data.getStringExtra(Constants.EXTRA_TARGET_PATH);
                ImageLoader.getInstance().displayImage(ApplicationUtils.getHeadIconPath(headPath), headCiv);
                dog.setAvatar_url(headPath);
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private Map<Integer,String> convertMap(Map<Integer,Integer> target){
        Map <Integer, String> dest = new LinkedHashMap<Integer,String>();
        for (Integer key:target.keySet()){
            dest.put(key,getResources().getString(target.get(key)));
        }
        return dest;

    }

    public void addDog(){
        if (!collectDogInfo()){
            return;
        }
        showWaitingDialog();
        DogDeviceStationRepository.getInstance().
                addDogFromNet(DogDeviceStationRepository.REQUEST_FROM_DOG_REGISTER, dog);
    }

    protected boolean collectDogInfo() {
        if (null == dog){
            dog = new Dog();
        }
        String name = nameEdit.getText().toString();
        if (StringUtils.isBlank(name)){
            return false;
        }
        dog.setName(name);
        if (StringUtils.isBlank(sexTxt.getText().toString())){
            return false;
        }
        dog.setGender((Integer) (sexTxt.getTag()));
        if (StringUtils.isBlank(kindTxt.getText().toString())){
            return false;
        }
        dog.setCategory(typeModel.getType_id());
        dog.setSize(typeModel.getSize());
        dog.setLeg_size(typeModel.getLeg());
//        dog.setLeg_size((Integer) legSizeTxt.getTag());
//        dog.setColor((Integer) colorTxt.getTag());
        if (null != birthdayTxt.getTag(R.id.dog_birth_unknown)
                && (int) birthdayTxt.getTag(R.id.dog_birth_unknown) == DatePickView.DOG_BIRTH_UNKNOWN_SELECTED) {
            dog.setBirthday(null);
            dog.setAge_range(Constants.DOG_BIRTH_UNKNOWN);
        } else if (null != birthdayTxt.getTag(R.id.year) &&
                null != birthdayTxt.getTag(R.id.month) &&
                null != birthdayTxt.getTag(R.id.day)) {
            String birthday = TimeUtils.format((Integer) birthdayTxt.getTag(R.id.year),
                    (Integer) birthdayTxt.getTag(R.id.month),
                    (Integer) birthdayTxt.getTag(R.id.day));
            dog.setBirthday(TimeUtils.parseWithYearMonthDay(birthday));
            dog.setAge_range(null);
        } else {
            return false;
        }
//        if (null != homeTxt.getTag(R.id.year) &&
//                null != homeTxt.getTag(R.id.month) &&
//                null != homeTxt.getTag(R.id.day)) {
//            String adoptedDate = TimeUtils.format((Integer) homeTxt.getTag(R.id.year),
//                    (Integer) homeTxt.getTag(R.id.month),
//                    (Integer) homeTxt.getTag(R.id.day));
//        dog.setAdopted_from(TimeUtils.parseWithYearMonthDay(adoptedDate));
//        }
//        String microchipId = microchipEdit.getText().toString();
//        dog.setMicrochip_id(microchipId);
//        String observationId = watchEdit.getText().toString();
//        dog.setObserve_id(observationId);
//        if (null != medicineTxt.getTag(R.id.start_month) &&
//                null != medicineTxt.getTag(R.id.end_month)) {
//            Integer startMonth = (Integer) (medicineTxt.getTag(R.id.start_month));
//            Integer endMonth = (Integer) (medicineTxt.getTag(R.id.end_month));
//            dog.setFilarial_start(startMonth);
//            dog.setFilarial_end(endMonth);
//        }
//        if (null != fleaTxt.getTag(R.id.start_month) &&
//                null != fleaTxt.getTag(R.id.end_month)) {
//            Integer fleaStartMonth = (Integer) (fleaTxt.getTag(R.id.start_month));
//            Integer fleaEndMonth = (Integer) (fleaTxt.getTag(R.id.end_month));
//            dog.setFlea_start(fleaStartMonth);
//            dog.setFilarial_end(fleaEndMonth);
//        }
//        if (null != injectionTxt.getTag(R.id.month)) {
//            Integer vaccinatedMonth = (Integer) (injectionTxt.getTag(R.id.month));
//            dog.setVaccinated_at(vaccinatedMonth);
//        }
//        if (null != rabiesTxt.getTag(R.id.month)) {
//            Integer rabiesStr = (Integer) (rabiesTxt.getTag(R.id.month));
//            dog.setRabies_inoculation_at(rabiesStr);
//        }
//        if (null  != diagnoseTxt.getTag(R.id.month)) {
//            Integer diagnoseMonth = (Integer) (diagnoseTxt.getTag(R.id.month));
//            dog.setLast_vaccinated_at(diagnoseMonth);
//        }
        return true;
    }

    private Dialog getDialog(int theme, TextView view) {
        datePickView = null;
        datePickView = new DatePickView(this, theme, mIdStringMap);
        datePickView.setTargetView(view);
        Window window = datePickView.getWindow();
        window.setGravity(Gravity.BOTTOM);
        return datePickView;
    }

    private void checkIfOk(){
        if (!StringUtils.isBlank(nameEdit.getText().toString()) &&
                !StringUtils.isBlank(sexTxt.getText().toString()) &&
                !StringUtils.isBlank(kindTxt.getText().toString()) &&
                !StringUtils.isBlank(birthdayTxt.getText().toString())){
            setBtnStates(true);
//            nextStepBtn.setEnabled(true);
        }else{
            setBtnStates(false);
//            nextStepBtn.setEnabled(false);
        }
    }

    private void setBtnStates(boolean isEnable){
        if (isEnable){
            nextStepBtn.setEnabled(true);
            nextStepBtn.setBackgroundResource(R.drawable.btn_sure);
        } else {
            nextStepBtn.setEnabled(false);
            nextStepBtn.setBackgroundResource(R.drawable.btn_sure_disable);
        }
    }

    private TextWatcher textWatcher =new TextWatcher() {
        private String lastString ="";
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            if (!lastString.equals(s.toString())) {
                lastString = s.toString();
                checkIfOk();
            }

        }
    };

    @Override
    public void success(Object result, int mode) {
        hideWaitingDialog();
        switch (mode){
            case DogDeviceStationRepository.ADD_DOG_FROM_NET_MODE:
                goToNextActivity((Dog) result);
                break;
            default:
                break;
        }

    }

    private void goToNextActivity(Dog result) {
        dog = (Dog) result;
        Intent intent = new Intent(this, BleSelectionActivity.class);
        intent.putExtra(Constants.EXTRA_DOG, dog);
        intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG, activityFromFlag);
        startActivity(intent);
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
        hideWaitingDialog();
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
        hideWaitingDialog();
    }

}
