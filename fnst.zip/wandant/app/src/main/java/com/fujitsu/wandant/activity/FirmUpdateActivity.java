package com.fujitsu.wandant.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.model.FirmDetailModel;
import com.fujitsu.wandant.net.NetCallback;
import com.fujitsu.wandant.net.StatusService;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.view.ToastManager;

import java.io.Serializable;

/**
 * Created by wangc.fnst on 2015/11/13.
 */
public class FirmUpdateActivity extends BaseActivity {

    @Bind(R.id.id_firm_info)
    TextView firmInfo;
    @Bind(R.id.id_current_version_txt)
    TextView oldValueTxt;
    @Bind(R.id.id_new_version_txt)
    TextView newValueTxt;
    @Bind(R.id.id_yes_btn)
    Button yesBtn;
    @Bind(R.id.id_no_btn)
    Button noBtn;

    public static final int STATION_FIRM_UPDATE_FLAG = 0;
    public static final int DEVICE_FIRM_UPDATE_FLAG = 1;
    public static final int STATION_FIRM_REUPDATE_FLAG = 2;
    public static final int DEVICE_FIRM_REUPDATE_FLAG = 3;
    private int firmFlag;
    private int firmId;

    private Context context;
    private FirmDetailModel firmDetailModel = null;
    private String dot;


    @Override
    public String getTitleName() {
        String title = null;
        switch (firmFlag){
            case STATION_FIRM_UPDATE_FLAG:
                title = getResources().getString(R.string.station_firm_title);
                break;
            case DEVICE_FIRM_UPDATE_FLAG:
                title = getResources().getString(R.string.device_firm_title);
                break;
            case STATION_FIRM_REUPDATE_FLAG:
                title = getResources().getString(R.string.station_firm_reupdate_title);
                break;
            case DEVICE_FIRM_REUPDATE_FLAG:
                title = getResources().getString(R.string.device_firm_reupdate_title);
                break;
            default:
                title = "";
                break;
        }
        return title;
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        context = this;
        yesBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        noBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_sure_pressed, R.drawable.btn_sure));
        yesBtn.setOnClickListener(this);
        noBtn.setOnClickListener(this);
        firmFlag = getIntent().getIntExtra(Constants.EXTRA_FIRM_FLAG,STATION_FIRM_UPDATE_FLAG);
        Serializable serializable = getIntent().getSerializableExtra(Constants.EXTRA_FIRM_INFO);
        dot = getResources().getString(R.string.dot);
        if (null == serializable){
            firmDetailModel = null;
        } else {
            firmDetailModel = (FirmDetailModel) serializable;
        }
        if (null != firmDetailModel){
            oldValueTxt.setText(getVersion(firmDetailModel.getMajor(),firmDetailModel.getMinor()));
            newValueTxt.setText(getVersion(firmDetailModel.getNewestmajor(), firmDetailModel.getNewestminor()));
        } else {
            oldValueTxt.setText("");
            newValueTxt.setText("");
        }
        String content = "";
        switch (firmFlag){
            case STATION_FIRM_UPDATE_FLAG:
                content = getResources().getString(R.string.station_firm_version_info);
                break;
            case DEVICE_FIRM_UPDATE_FLAG:
                content = getResources().getString(R.string.device_firm_version_info);
                break;
            case STATION_FIRM_REUPDATE_FLAG:
                content = getResources().getString(R.string.station_firm_reupdate_info);
                break;
            case DEVICE_FIRM_REUPDATE_FLAG:
                content = getResources().getString(R.string.device_firm_reupdate_info);
                break;
            default:
                content = "";
                break;
        }
        firmInfo.setText(content);
//        if (STATION_FIRM_UPDATE_FLAG == firmFlag){
//            firmInfo.setText(getResources().getString(R.string.station_firm_version_info));
//        } else {
//            firmInfo.setText(getResources().getString(R.string.device_firm_version_info));
//        }
    }

    private String getVersion(Integer major, Integer minor){
        String version = "";
        if (null == major && null == minor){
            version = "";
        } else if (null == major){
            version = String.valueOf(major);
        } else if (null == minor){
            version = String.valueOf(minor);
        } else {
            version = String.valueOf(major) + dot + String.valueOf(minor);
        }
        return version;
    }

    @Override
    public int getLayout() {
        return R.layout.activity_firm_update;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (R.id.id_yes_btn == v.getId()){
            if (Constants.NUMBER_INVALID == firmId){
                return;
            }
            String id = String.valueOf(firmId);
            if (firmFlag == STATION_FIRM_UPDATE_FLAG || firmFlag == STATION_FIRM_REUPDATE_FLAG) {
                updateStation();
            } else if (firmFlag == DEVICE_FIRM_UPDATE_FLAG || firmFlag == DEVICE_FIRM_REUPDATE_FLAG){
                updateDevice();
            }
        } else if (R.id.id_no_btn == v.getId()){
            finish();
        }
    }

    private void updateDevice() {
        StatusService.getInstance().agreeUpdateDevice(new NetCallback<Void>() {
            @Override
            public void success(Void responseData) {
                ((Activity)context).finish();
            }

            @Override
            public void failure(String errorCode, String errorMsg) {
                showErrorMessage(errorCode);
            }

            @Override
            public void internalFailure(String errorMsg) {
                ToastManager.getInstance().showFail(errorMsg);
//                Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateStation() {
        StatusService.getInstance().agreeUpdateStation(new NetCallback<Void>() {
            @Override
            public void success(Void responseData) {
                ((Activity)context).finish();
            }

            @Override
            public void failure(String errorCode, String errorMsg) {
                showErrorMessage(errorCode);
            }

            @Override
            public void internalFailure(String errorMsg) {
                ToastManager.getInstance().showFail(errorMsg);
//                Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
