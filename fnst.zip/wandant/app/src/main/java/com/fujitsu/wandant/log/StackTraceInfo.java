package com.fujitsu.wandant.log;

/**
 * StackTarceInfo ツール: ログ出力のときに、プログラムコードに関連する情報を取得する
 *
 * @author FNST) 胡恒恺
 * Copyright (c) 2014年 fujitsu. All rights reserved.
 */
public class StackTraceInfo {

    /**
     * クラスのスタック中の現在位置
     */
    private static final int CLIENT_CODE_STACK_INDEX;

    /**
     * 前レベルの関数と現在の関数のオフセット値
     */
    private static final int DEFAULT_OFFSET = 3;

    static {
        int i = 0;
        for (StackTraceElement ste : Thread.currentThread().getStackTrace()) {
            i++;
            if (ste.getClassName().equals(StackTraceInfo.class.getName())) {
                break;
            }
        }
        CLIENT_CODE_STACK_INDEX = i;
    }


    /**
     * 現在の関数名を返す
     *
     * @return 関数名
     */
    public static String getCurrentMethodName() {
        return getCurrentMethodName(DEFAULT_OFFSET);
    }


    /**
     * オフセットよって、前レベルの関数の関数名を返す
     *
     * @param offset 前レベルの関数と現在の関数のオフセット値
     * @return 関数名
     */
    private static String getCurrentMethodName(int offset) {
        return Thread.currentThread().getStackTrace()[CLIENT_CODE_STACK_INDEX + offset].getMethodName();
    }

    /**
     * 現在の行番号を返す
     *
     * @return 行番号
     */
    public static int getCurrentMethodLineNumber() {
        return getCurrentMethodLineNumber(DEFAULT_OFFSET);
    }

    /**
     * オフセットよって、前レベルの関数の行番号を返す
     *
     * @param offset 前レベルの関数と現在の関数のオフセット値
     * @return 行番号
     */
    private static int getCurrentMethodLineNumber(int offset) {
        return Thread.currentThread().getStackTrace()[CLIENT_CODE_STACK_INDEX + offset].getLineNumber();
    }


    /**
     * 現在のクラス名を返す
     *
     * @return クラス名
     */
    public static String getCurrentClassName() {
        return getCurrentClassName(DEFAULT_OFFSET);
    }

    /**
     * オフセットよって、前レベルの関数のクラス名を返す
     *
     * @param offset 前レベルの関数と現在の関数のオフセット値
     * @return クラス名
     */
    private static String getCurrentClassName(int offset) {
        return Thread.currentThread().getStackTrace()[CLIENT_CODE_STACK_INDEX + offset].getClassName();
    }

}