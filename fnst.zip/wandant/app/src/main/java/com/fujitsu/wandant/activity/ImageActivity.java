package com.fujitsu.wandant.activity;

import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.utils.BitmapUtil;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.view.ZoomImageView;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

/**
 * Created by chenjie.fnst on 2015/09/29.
 */
public class ImageActivity extends NewBaseActivity implements View.OnClickListener{

    private ZoomImageView ivBackground;
    private String fileUrl;

    private View layout;
    private TextView titleTv;

    private View deleteView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            initLandscapeView();
        } else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            initPortraitView();
        }
    }

    private void initPortraitView() {
        setContentView(R.layout.activity_image_portrait);
        layout = findViewById(R.id.layout);

        findViewById(R.id.id_title_back_img).setOnClickListener(this);

        findViewById(R.id.id_head_img).setVisibility(View.GONE);
        titleTv = (TextView) findViewById(R.id.id_title_name_txt);
        titleTv.setVisibility(View.GONE);

        TextView rightTv = (TextView) findViewById(R.id.id_right_tv);
        rightTv.setOnClickListener(this);
        rightTv.setText("");
        Drawable drawable = getResources().getDrawable(R.drawable.img_save);
        rightTv.setCompoundDrawables(drawable,null,null,null);
        rightTv.setOnClickListener(this);

        deleteView = findViewById(R.id.id_delete_iv);
        deleteView.setOnClickListener(this);

        loadImage();
    }

    private void initLandscapeView() {
        setContentView(R.layout.activity_image_landscape);
        layout = findViewById(R.id.layout);
        titleTv = null;
        deleteView = null;
        loadImage();
    }

    private void loadImage() {
        ivBackground = (ZoomImageView)findViewById(R.id.id_background_iv);
        fileUrl = getIntent().getStringExtra(Constants.EXTRA_IMAGE_URL);
        WindowManager wm = this.getWindowManager();
        final int width = wm.getDefaultDisplay().getWidth();
        final int height = wm.getDefaultDisplay().getHeight();
        ImageLoader.getInstance().loadImage(fileUrl, new SimpleImageLoadingListener() {
            @Override
            public void onLoadingComplete(String s, View view, Bitmap bitmap) {
                if (null == bitmap){
                    return;
                }
                float bWidth = bitmap.getWidth();
                float bHeight = bitmap.getHeight();
                float scaleW = width / bWidth;
                float scaleH = height / bHeight;
                float scale = Math.min(scaleW, scaleH);
                Bitmap newBitmap = BitmapUtil.zoomImg(bitmap, scale);
                ivBackground.setImageBitmap(newBitmap);
            }
        });

        ivBackground.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ivBackground.setIsZoomEnabled(true);
                setVisibility(false);
            }
        });
        ivBackground.setOnPhotoTapListener(new ZoomImageView.OnPhotoTapListener() {
            @Override
            public void onPhotoTap(View view, float x, float y) {
                ivBackground.setIsZoomEnabled(false);
                setVisibility(true);
            }
        });
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        switch (newConfig.orientation){
            case Configuration.ORIENTATION_PORTRAIT:
                initPortraitView();
                break;
            case Configuration.ORIENTATION_LANDSCAPE:
                initLandscapeView();
                break;
            default:
                break;
        }
    }

    private void setVisibility(boolean isVisible){
        if (isVisible){
            layout.setBackgroundColor(getResources().getColor(R.color.transparent));
            if (null != titleTv){
                titleTv.setVisibility(View.VISIBLE);
            }
            if (null != deleteView){
                deleteView.setVisibility(View.VISIBLE);
            }
        } else {
            layout.setBackgroundColor(getResources().getColor(R.color.black));
            if (null != titleTv) {
                titleTv.setVisibility(View.GONE);
            }
            if (null != deleteView) {
                deleteView.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
//        if (ApplicationUtils.isFastClick()){
//            return;
//        }
        switch (v.getId()){
            case R.id.id_right_tv:
                saveImg();
                break;
            case R.id.id_delete_iv:
                break;
            case R.id.id_title_back_img:
                onBackPressed();
            default:
                break;
        }
    }

    public void saveImg(){
        Drawable drawable = ivBackground.getDrawable();
        if (null == drawable){
            return;
        }
        Bitmap bitmap = BitmapUtil.drawableToBitmap(drawable);
        if (null != bitmap){
            String path = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "home", "description");
//            Toast.makeText(this,"save success " + path,Toast.LENGTH_SHORT).show();
        }

    }


}
