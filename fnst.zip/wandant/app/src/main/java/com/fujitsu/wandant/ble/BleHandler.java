package com.fujitsu.wandant.ble;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.util.Log;
import com.fujitsu.wandant.WandantApplication;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.model.Device1MinDataModel;
import com.fujitsu.wandant.utils.ClsUtils;
import com.fujitsu.wandant.utils.DeviceUtil;

import rx.Observable;
import rx.functions.Func1;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Created by chenjie.fnst on 2015/12/10.
 */
public class BleHandler implements BleManager.BleCallback {

    private static final String LOG_TAG = BleHandler.class.getName();
    protected BleManagerAndroid manager;
    protected BleDevice device;

    public static final int TIME_OUT = 60;


    protected BleHandler(){
        Context context = WandantApplication.getInstance().getApplicationContext();
        manager = new BleManagerAndroid(context,this);
    }

    private BleDevice.BleDeviceCallback callback = new BleDevice.BleDeviceCallback(){

        @Override
        public void onConnectionChanged(boolean is_connected) {
            Log.e(LOG_TAG, "onConnectionChanged " + is_connected);
        }

        @Override
        public void onWriteComplete(UUID srv_uuid, UUID ch_uuid, boolean is_ok) {
            Logger.d(LOG_TAG, "onWriteComplete ch_uuid " + ch_uuid.toString() + " " + is_ok);
        }

        @Override
        public void onReadComplete(UUID srv_uuid, UUID ch_uuid, byte[] val, boolean is_ok) {
            Logger.d(LOG_TAG, "onReadComplete ch_uuid " + ch_uuid.toString() + " val " + Arrays.toString(val) + " " + is_ok);
        }

        @Override
        public void onCharacteristicChange(UUID srv_uuid, UUID ch_uuid, byte[] val) {
            Logger.d(LOG_TAG, "onCharacteristicChange ch_uuid " + ch_uuid.toString() + " val " + Arrays.toString(val));
        }

        @Override
        public void onNotificationRegistered(UUID srv_uuid, UUID ch_uuid, boolean is_ok) {
            Logger.d(LOG_TAG, "onNotificationRegistered ch_uuid " + ch_uuid.toString() + " " + is_ok);
        }

        @Override
        public void onReadRssi(int rssi, boolean is_ok) {
            Logger.d(LOG_TAG, "onReadRssi " + is_ok);
        }
    };


    public Observable<Boolean> connectDevice(final String address){
        if (null != manager.getDevice() && manager.getDevice().isConnected()){
            return Observable.just(true);
        }
        device = manager.connectBleDevice(address, callback);
        return device.checkConnected()
                .timeout(TIME_OUT, TimeUnit.SECONDS)
                .flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                        return Observable.just(responseData.isOk());
                    }
                })
                .filter(new Func1<Boolean, Boolean>() {
                    @Override
                    public Boolean call(Boolean aBoolean) {
                        Logger.d(LOG_TAG, "connect device:" + address +  " " + aBoolean);
                        return (aBoolean == true);
                    }
                });
    }


//    public Observable<Boolean> pairDevice (final BluetoothDevice device){
//
//    }

    public Boolean isConnect(){
        if (null == device){
            return false;
        }
        return device.isConnected();
    }


    public Observable<Boolean> registerNotification(UUID serverUuid, UUID childUuid){
        return device.registerNotificationObs(serverUuid, childUuid).flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
            @Override
            public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                return Observable.just(true);
            }
        });
    }

    public void disconnect() {
        if (null != manager){
            manager.disconnect();
        }
    }

    public Observable<BleDevice.ResponseData> getNotification(UUID serviceUuid, UUID childUuid){
        return device.getNotification(serviceUuid,childUuid);
    }

    public Observable<Boolean> setCommand(final UUID serviceUuid, final UUID childUUid, byte[] data){
        return device.writeObs(serviceUuid, childUUid, data)
                .flatMap(new Func1<BleDevice.ResponseData, Observable<Boolean>>() {
                    @Override
                    public Observable<Boolean> call(BleDevice.ResponseData responseData) {
                        return Observable.just(true);
                    }
                });
    }

//    public Observable<List<Device1MinDataModel>> setCommand(final UUID serviceUuid, final UUID childUUid, byte[] data,final String stationBdid, final String deviceBdid){
//        return device.writeObs(serviceUuid, childUUid, data)
//                .flatMap(new Func1<BleDevice.ResponseData, Observable<List<Device1MinDataModel>>>() {
//                    @Override
//                    public Observable<List<Device1MinDataModel>> call(BleDevice.ResponseData responseData) {
//                        return Observable.just(DeviceUtil.parse1MinData(stationBdid, deviceBdid, responseData.getVal()));
//                    }
//                });
//    }

    public Observable<BleDevice.ResponseData> readData(UUID serviceUuid, UUID childUUid){
        return device.readObs(serviceUuid, childUUid).timeout(TIME_OUT, TimeUnit.SECONDS);
    }


    @Override
    public void onFoundDevice(BluetoothDevice device, int rssi, byte[] record) {

    }
}
