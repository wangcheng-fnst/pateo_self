package com.fujitsu.wandant.ble;

import android.annotation.SuppressLint;
import android.app.Service;
import android.bluetooth.*;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.util.Log;

import com.fujitsu.wandant.R;
import com.fujitsu.wandant.log.Logger;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.view.ToastManager;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by chenjie.fnst on 2015/10/13.
 */
public class BleService extends Service {


    private BluetoothManager bluetoothManager;
    private BluetoothAdapter bluetoothAdapter;
    private String bluetoothDeviceAddress;
    private BluetoothGatt bluetoothGatt;

    private BluetoothLeScanner mLEScanner;
    private ScanSettings settings;
    private List<ScanFilter>    filters;
    private ScanCallback mScanCallback;

    private String TAG = BleService.class.getName();
    private BleBinder bleBinder = new BleBinder();

    private Thread scanThread;
    private static final long SCAN_PERIOD = 5000;
    public static final int SEARCH_DEVICE = 1;
    public static final int SEARCH_STATION = 2;
    private int searchType = SEARCH_DEVICE;

    private String bdidNeedConnected = null;

    private List<BleReadCallBack> readCallBacks = new ArrayList<>();

    private static final UUID CLIENT_CHAR_CONFIG_UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB");;

    public final static String ACTION_GATT_CONNECTED = "ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED = "ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED = "ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_GATT_RSSI = "ACTION_GATT_RSSI";
    public final static String ACTION_DATA_AVAILABLE = "ACTION_DATA_AVAILABLE";
    public final static String ACTION_GATT_CONNECT_FAILED = "ACTION_CONNECT_FAILED";
    public final static String EXTRA_DATA = "EXTRA_DATA";
    public final static String EXTRA_MAC = "EXTRA_MAC";
    public final static String EXTRA_UUID = "EXTRA_UUID";


    public final static String ACTION_DEVICE_FOUND_SUCCESS = "ACTION_DEVICE_FOUND_SUCCESS";
    public final static String ACTION_STATION_FOUND_SUCCESS = "ACTION_STATION_FOUND_SUCCESS";
    public final static String ACTION_BLE_FOUND_TIMEOUT = "ACTION_BLE_FOUND_TIMEOUT";



    public class BleBinder extends Binder{
        public BleService getService(){
            return BleService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return bleBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback(){
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status,
                                            int newState) {
            String intentAction;
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                intentAction = ACTION_GATT_CONNECTED;
                broadcastUpdate(intentAction, gatt.getDevice().getAddress());
                Logger.d(TAG, "Connected to GATT server.");
                // Attempts to discover services after successful connection.
                Logger.d(TAG, "Attempting to start service discovery:"
                        + bluetoothGatt.discoverServices());
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                intentAction = ACTION_GATT_DISCONNECTED;
                Logger.d(TAG, "Disconnected from GATT server.");
                broadcastUpdate(intentAction, gatt.getDevice().getAddress());
            }
        }

        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_GATT_RSSI, gatt.getDevice().getAddress(), rssi);
            } else {
                Logger.d(TAG, "onReadRemoteRssi received: " + status);
            }
        };

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED, gatt.getDevice().getAddress());
            } else {
                broadcastUpdate(ACTION_GATT_CONNECT_FAILED, gatt.getDevice().getAddress());
                close();
                Logger.d(TAG, "onServicesDiscovered received: " + status);
            }
            for(BluetoothGattService service : gatt.getServices()) {
                StringBuilder sb = new StringBuilder();
                sb.append("service:" + service.getUuid() + "; " + "type:" + service.getType() + "\n");
                for(BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {
                    sb.append("---characteristic:" + characteristic.getUuid() + "; " + "permissions:" + characteristic.getProperties() + "\n");
                    for(BluetoothGattDescriptor descriptor : characteristic.getDescriptors()) {
                        sb.append("------descriptor:" + descriptor.getUuid() + "; " + "permissions:" + descriptor.getPermissions() +"\n");
                    }
                }
                Logger.d(TAG, sb.toString());
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
        }

        @Override
        public void onDescriptorWrite (BluetoothGatt gatt, BluetoothGattDescriptor desc, int status) {
            BluetoothGattCharacteristic ch = desc.getCharacteristic();
            bluetoothGatt.setCharacteristicNotification(ch, true);
        }
    };

    private void broadcastUpdate(final String action ,String address) {
        final Intent intent = new Intent(action);
        intent.putExtra(EXTRA_MAC, address);
        sendBroadcast(intent);
    }

    private void broadcastUpdate(final String action, String address, int rssi) {
        final Intent intent = new Intent(action);
        intent.putExtra(EXTRA_DATA, String.valueOf(rssi));
        sendBroadcast(intent);
    }

    private void broadcastUpdate(String action) {
        Intent intent = new Intent(action);
        sendBroadcast(intent);
    }


    private void broadcastUpdate(final String action,
                                 final BluetoothGattCharacteristic characteristic) {
        final Intent intent = new Intent(action);

        // This is special handling for the Heart Rate Measurement profile. Data
        // parsing is
        // carried out as per profile specifications:
        // http://developer.bluetooth.org/gatt/characteristics/Pages/CharacteristicViewer.aspx?u=org.bluetooth.characteristic.heart_rate_measurement.xml
        final byte[] rx = characteristic.getValue();
        StringBuilder sb = new StringBuilder();
        for(byte tmp: rx) {
            sb.append(StringUtils.getByteValue(tmp) + ";");
        }
        Logger.i(TAG, sb.toString());
        intent.putExtra(EXTRA_DATA, rx);
        intent.putExtra(EXTRA_UUID, characteristic.getUuid().toString());
        for (BleReadCallBack callBack:readCallBacks){
            callBack.onCharacteristicRead(rx,characteristic.getUuid().toString());
        }
        sendBroadcast(intent);
    }




    /**
     * Initializes a reference to the local Bluetooth adapter.
     *
     * @return Return true if the initialization is successful.
     */
    public boolean initialize() {
        // For API level 18 and above, get a reference to BluetoothAdapter
        // through
        // BluetoothManager.
        if (bluetoothManager == null) {
            bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (bluetoothManager == null) {
                Logger.d(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        bluetoothAdapter = bluetoothManager.getAdapter();
        if (bluetoothAdapter == null) {
            Logger.d(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        toApi21();

        return true;
    }

    @SuppressLint("NewApi")
    private void toApi21() {
        if  (Build.VERSION.SDK_INT  >=  21)
        {
           mScanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
            /*  Connect to  device  found   */
                    Log.i("callbackType", String.valueOf(callbackType));

                    BluetoothDevice device = result.getDevice();
                    if (null != bdidNeedConnected){
                        connect(device.getAddress());
                        stopScanThread();
                    } else {
                        switch (searchType){
                            case SEARCH_DEVICE:
                                broadcastUpdate(ACTION_DEVICE_FOUND_SUCCESS,device.getAddress());
                                break;
                            case SEARCH_STATION:
                                broadcastUpdate(ACTION_STATION_FOUND_SUCCESS,device.getAddress());
                                break;
                            default:
                                break;
                        }
                    }

                }

                @Override
                public void onBatchScanResults(List<ScanResult> results) {
            /*  Process a   batch   scan    results */
                    for (ScanResult sr : results) {
                        Log.i("Scan Item:   ", sr.toString());
                    }
                }
            };
            mLEScanner = bluetoothAdapter.getBluetoothLeScanner();
//            ScanFilter deviceFilter = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(Constants.STATION_IOT_SERVICE)).build();
//            // settings = new ScanSettings.Builder().setScanMode(ScanSettings.CALLBACK_TYPE_ALL_MATCHES).build();
//            settings = new ScanSettings.Builder().build();
//            filters = new ArrayList<ScanFilter>();
//            filters.add(deviceFilter);
        }
    }

    /**
     * Connects to the GATT server hosted on the Bluetooth LE device.
     *
     * @param address
     *            The device address of the destination device.
     *
     * @return Return true if the connection is initiated successfully. The
     *         connection result is reported asynchronously through the
     *         {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     *         callback.
     */
    public boolean connect(final String address) {
        if (bluetoothAdapter == null || address == null) {
            Logger.i(TAG,
                    "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }

        // Previously connected device. Try to reconnect.
        if (bluetoothDeviceAddress != null
                && address.equals(bluetoothDeviceAddress)
                && bluetoothGatt != null) {
            Logger.d(TAG, "Trying to use an existing mBluetoothGatt for connection.");
            if (bluetoothGatt.connect()) {
                return true;
            } else {
                return false;
            }
        }

        final BluetoothDevice device = bluetoothAdapter
                .getRemoteDevice(address);
        if (device == null) {
            Logger.d(TAG, "Device not found.  Unable to connect.");
            return false;
        }
        // We want to directly connect to the device, so we are setting the
        // autoConnect
        // parameter to false.
        bluetoothGatt = device.connectGatt(this, false, gattCallback);
        // add by wangcy for bug on 2016-2-9 start
        stopScanThread() ;//  will    stop    after   first   device  detection
        // add by wangcy for bug on 2016-2-9 stop
        Logger.d(TAG, "Trying to create a new connection.");
        bluetoothDeviceAddress = address;

        return true;
    }

    /**
     * Disconnects an existing connection or cancel a pending connection. The
     * disconnection result is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public void disconnect() {
        if (bluetoothAdapter == null || bluetoothGatt == null) {
            Logger.d(TAG, "BluetoothAdapter not initialized");
            return;
        }
        bluetoothGatt.disconnect();
    }

    /**
     * After using a given BLE device, the app must call this method to ensure
     * resources are released properly.
     */
    public void close() {
        if (bluetoothGatt == null) {
            return;
        }
        bluetoothGatt.close();
        bluetoothGatt = null;
    }

    /**
     * Request a read on a given {@code BluetoothGattCharacteristic}. The read
     * result is reported asynchronously through the
     * {@code BluetoothGattCallback#onCharacteristicRead(android.bluetooth.BluetoothGatt, android.bluetooth.BluetoothGattCharacteristic, int)}
     * callback.
     *
     * @param characteristic
     *            The characteristic to read from.
     */
    public void readCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (bluetoothAdapter == null || bluetoothGatt == null) {
            Logger.d(TAG, "BluetoothAdapter not initialized");
            return;
        }

        boolean isSuccess = bluetoothGatt.readCharacteristic(characteristic);
    }

    public void readRssi() {
        if (bluetoothAdapter == null || bluetoothGatt == null) {
            Logger.d(TAG, "BluetoothAdapter not initialized");
            return;
        }

        bluetoothGatt.readRemoteRssi();
    }

    public void writeCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (bluetoothAdapter == null || bluetoothGatt == null) {
            Logger.d(TAG, "BluetoothAdapter not initialized");
            return;
        }
        bluetoothGatt.writeCharacteristic(characteristic);
    }


    public BluetoothGattService getSupportedGattService(UUID uuid) {
        if (bluetoothGatt == null)
            return null;
        return bluetoothGatt.getService(uuid);
    }

    /**
     * Enables or disables notification on a give characteristic.
     *
     * @param characteristic
     *            Characteristic to act on.
     * @param enabled
     *            If true, enable notification. False otherwise.
     */
    public void setCharacteristicNotification(
            BluetoothGattCharacteristic characteristic, boolean enabled) {
        if (bluetoothAdapter == null || bluetoothGatt == null) {
            Logger.d(TAG, "BluetoothAdapter not initialized");
            return;
        }
        bluetoothGatt.setCharacteristicNotification(characteristic, enabled);
    }

    public void setDescriptorNotification(
            BluetoothGattCharacteristic characteristic, boolean enabled) {
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CLIENT_CHAR_CONFIG_UUID);
        descriptor.setValue(enabled ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
        bluetoothGatt.writeDescriptor(descriptor);
    }

    public void writeData(UUID serviceUuid,UUID writeUuid,byte[] data){
        BluetoothGattService service = getSupportedGattService(serviceUuid);
        if (null == service) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.service_error));
//            Toast.makeText(getApplicationContext(), getResources().getString(R.string.service_error), Toast.LENGTH_SHORT).show();
        } else {
            BluetoothGattCharacteristic characteristic = service.getCharacteristic(writeUuid);
            if (null != characteristic){
                characteristic.setValue(data);
                writeCharacteristic(characteristic);
            }

        }
    }

    public void readData(UUID serviceUuid,UUID readUuid){
        BluetoothGattService service = getSupportedGattService(serviceUuid);
        if (null == service) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.service_error));
//            Toast.makeText(getApplicationContext(), getResources().getString(R.string.service_error), Toast.LENGTH_SHORT).show();
        } else {
            BluetoothGattCharacteristic characteristic = service.getCharacteristic(readUuid);
            if (null != characteristic){
                readCharacteristic(characteristic);
            }

        }
    }

    private BluetoothAdapter.LeScanCallback leScanCallback = new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
            if (null != bdidNeedConnected){
                connect(device.getAddress());
                stopScanThread();
            } else {
                switch (searchType){
                    case SEARCH_DEVICE:
                        broadcastUpdate(ACTION_DEVICE_FOUND_SUCCESS,device.getAddress());
                        break;
                    case SEARCH_STATION:
                        broadcastUpdate(ACTION_STATION_FOUND_SUCCESS,device.getAddress());
                        break;
                    default:
                        break;
                }
            }
        }
    };



    public void searchBleDevice(int type,String bdid) {
        bdidNeedConnected = bdid;
        if (!bluetoothAdapter.isEnabled()){
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } else {
            scanThread = new Thread() {
                @Override
                public void run() {
                    if  (Build.VERSION.SDK_INT  <   21)
                    {
                        bluetoothAdapter.startLeScan(leScanCallback);
                    }
                    else
                    {
                        mLEScanner.startScan(mScanCallback);
                    }
                    try {
                        Thread.sleep(SCAN_PERIOD);
                        if  (Build.VERSION.SDK_INT  <   21)
                        {
                            bluetoothAdapter.stopLeScan(leScanCallback);
                        }
                        else
                        {
                            mLEScanner.stopScan(mScanCallback);
                        }
                        broadcastUpdate(ACTION_BLE_FOUND_TIMEOUT);
                        scanThread = null;
                        bdidNeedConnected = null;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            };
            scanThread.start();
        }
    }


    public void stopScanThread() {
        if(scanThread != null) {
            bdidNeedConnected = null;
            scanThread.interrupt();
            if  (Build.VERSION.SDK_INT  <   21)
            {
                bluetoothAdapter.stopLeScan(leScanCallback);
            }
            else
            {
                if(mScanCallback!=null){
                   mLEScanner.stopScan(mScanCallback);
                }

            }
            scanThread = null;
        }
    }


    public void setNotificationEnable(UUID serviceUuid,UUID notificationUuid,boolean isEnable){
        BluetoothGattService service = getSupportedGattService(serviceUuid);
        if (null == service) {
            ToastManager.getInstance().showFail(getResources().getString(R.string.service_error));
//            Toast.makeText(getApplicationContext(), getResources().getString(R.string.service_error), Toast.LENGTH_SHORT).show();
        } else {
            setCharacteristicNotification(service.getCharacteristic(notificationUuid),isEnable);
        }
    }

}
