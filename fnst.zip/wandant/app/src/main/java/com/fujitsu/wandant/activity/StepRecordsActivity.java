package com.fujitsu.wandant.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.model.StepBarInfoModel;
import com.fujitsu.wandant.utils.TimeUtils;
import com.fujitsu.wandant.view.StepCountBarView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by wangc.fnst on 2015/9/19.
 */
public class StepRecordsActivity extends AppCompatActivity {
    StepCountBarView bar = new StepCountBarView(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step_records);
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int width = wm.getDefaultDisplay().getWidth();
        int height = wm.getDefaultDisplay().getHeight();
//        bar = (StepCountBarView) findViewById(R.id.id_step_bar);

        bar.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Log.e("main", "draw");
                int[] data = new int[30];
                Date today = new Date();
                bar.initData(createData(today));
                bar.setListener(listener);

            }
        });

    }

    private List<StepBarInfoModel> createData(Date today){
        List<StepBarInfoModel> stepBarInfoModels = new ArrayList<StepBarInfoModel>();
        for(int i = 30;i>=0;i--){
            int count = 10000+i*100;
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(today);
            calendar.add(Calendar.DATE, i - 30);
            Date date = calendar.getTime();
            StepBarInfoModel model = new StepBarInfoModel(count);
            model.setDate(date);
            model.setWeekDay(TimeUtils.getWeekDay(date));
            stepBarInfoModels.add(model);
        }
        return stepBarInfoModels;
    }


    private StepCountBarView.OnEventListener listener = new StepCountBarView.OnEventListener() {
        @Override
        public void onMove() {
        }

        @Override
        public void onClick(StepBarInfoModel model) {
        }

        @Override
        public void getNewData(StepBarInfoModel model,int type) {
            if (type == StepBarInfoModel.STEP_MODE_AFTER_END){
                //from database
                List<StepBarInfoModel> stepBarInfoModels = new ArrayList<StepBarInfoModel>();
                for(int i = 29;i>=0;i--){
                    int count = 100+i;
                    Calendar calendar = Calendar.getInstance();
                    StepBarInfoModel modelTmp = new StepBarInfoModel(count);
                    stepBarInfoModels.add(modelTmp);
                }
                bar.setData(stepBarInfoModels,type);

            }else if (type == StepBarInfoModel.STEP_MODE_BEFORE_BEGIN){
                //first from net,than save to database,
                List<StepBarInfoModel> stepBarInfoModels = new ArrayList<StepBarInfoModel>();
                for(int i = 29;i>=0;i--){
                    int count = 300+i*10;
                    Calendar calendar = Calendar.getInstance();
                    StepBarInfoModel modelTmp = new StepBarInfoModel(count);
                    stepBarInfoModels.add(modelTmp);
                }
                bar.setData(stepBarInfoModels,type);
            }
        }
    };
}
