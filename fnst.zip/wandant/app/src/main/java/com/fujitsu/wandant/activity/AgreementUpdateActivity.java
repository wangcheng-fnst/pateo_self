//******************************************************************
//* わんダント2システム
//******************************************************************
/*
 *	わんダント2Android
 *	AgreementUpdateActivity.java
 *
 *	変更日			変更者				障害No／仕様変更No
 *	15/12/18 		FNST)Chenjie    	新規作成
 *
 */
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************

package com.fujitsu.wandant.activity;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.net.AccountService;
import com.fujitsu.wandant.net.NetCallback;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ToastManager;

/**
 *
 * AgreementUpdateActivity
 */
public class AgreementUpdateActivity extends AgreementWithAccountActivity {
    private Context context;

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        isBackable = false;
        cancelBtn.setVisibility(View.VISIBLE);
        context = this;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()) {
        case R.id.id_agree_btn :
            showWaitingDialog();
            AccountService.getInstance().agreeAgreement(new NetCallback<Void>() {
                @Override
                public void success(Void responseData) {
                    hideWaitingDialog();
                    ((Activity) context).finish();
                }
                @Override
                public void failure(String errorCode, String errorMsg) {
                    showErrorMessage(errorCode);
                    hideWaitingDialog();
                }
                @Override
                public void internalFailure(String errorMsg) {
                    ToastManager.getInstance().showFail(errorMsg);
//                    Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show();
                    hideWaitingDialog();
                }
            });

            break;

        case R.id.id_cancel_btn :
            finish();
            Intent intent = new Intent();
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            UserUtils.getInstance().logout();
            intent.setClass(context, LoginActivity.class);
            context.startActivity(intent);
            break;

        default :
            break;
        }
    }
}

