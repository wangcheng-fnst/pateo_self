package com.fujitsu.wandant.model;

/**
 * Created by chenjie.fnst on 2015/10/19.
 */
public class Device30MinDataModel extends EventHubDataModel{

    public static String DATA_TYPE = "90";
    public static String DEV_KIND = "05";

    private int battery;
    private int wdSteps;
    private int wdMomentum;
    private int wdTrot;
    private int wdBalance;
    private int wdBuruburu;
    private float wdTemp;
    private float wdHumid;

    public Device30MinDataModel() {
        this.dataType = DATA_TYPE;
        this.devKind = DEV_KIND;
    }

    public Device30MinDataModel(String gwId, String devId, String guid, String utc, int battery, int wdSteps, int wdMomentum, int wdTrot, int wdBalance, int wdBuruburu, float wdTemp, float wdHumid) {
        this.gwId = gwId;
        this.devId = devId;
        this.dataType = DATA_TYPE;
        this.guid = guid;
        this.utc = utc;
        this.devKind = DEV_KIND;
        this.battery = battery;
        this.wdSteps = wdSteps;
        this.wdMomentum = wdMomentum;
        this.wdTrot = wdTrot;
        this.wdBalance = wdBalance;
        this.wdBuruburu = wdBuruburu;
        this.wdTemp = wdTemp;
        this.wdHumid = wdHumid;
    }

    public int getBattery() {
        return battery;
    }

    public void setBattery(int battery) {
        this.battery = battery;
    }

    public int getWdSteps() {
        return wdSteps;
    }

    public void setWdSteps(int wdSteps) {
        this.wdSteps = wdSteps;
    }

    public int getWdMomentum() {
        return wdMomentum;
    }

    public void setWdMomentum(int wdMomentum) {
        this.wdMomentum = wdMomentum;
    }

    public int getWdTrot() {
        return wdTrot;
    }

    public void setWdTrot(int wdTrot) {
        this.wdTrot = wdTrot;
    }

    public int getWdBalance() {
        return wdBalance;
    }

    public void setWdBalance(int wdBalance) {
        this.wdBalance = wdBalance;
    }

    public int getWdBuruburu() {
        return wdBuruburu;
    }

    public void setWdBuruburu(int wdBuruburu) {
        this.wdBuruburu = wdBuruburu;
    }

    public float getWdTemp() {
        return wdTemp;
    }

    public void setWdTemp(float wdTemp) {
        this.wdTemp = wdTemp;
    }

    public float getWdHumid() {
        return wdHumid;
    }

    public void setWdHumid(float wdHumid) {
        this.wdHumid = wdHumid;
    }

}
