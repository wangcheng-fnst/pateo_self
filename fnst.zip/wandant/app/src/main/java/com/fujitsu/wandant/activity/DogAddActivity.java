package com.fujitsu.wandant.activity;

import com.fujitsu.wandant.R;

/**
 * Created by chenjie.fnst on 2015/10/08.
 */
public class DogAddActivity extends DogRegisterActivity {

    @Override
    public String getTitleName() {
        return getString(R.string.dog_add_title);
    }

}
