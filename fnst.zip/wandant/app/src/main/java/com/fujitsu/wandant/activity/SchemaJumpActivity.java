package com.fujitsu.wandant.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

/**
 * Created by chenjie.fnst on 2016/02/19.
 */
public class SchemaJumpActivity extends NewBaseActivity {

    private static final String LOG_TAG = SchemaJumpActivity.class.getName();

    private String apkName = "com.fujitsu.android.mapmark";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String data = getIntent().getDataString();
        if (null != data){
            Log.e(LOG_TAG, data);
        }
        Intent intent = new Intent();
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.setClass(this, MainActivity.class);
        startActivity(intent);
        finish();
//        try{
//            if (ApplicationUtils.isAppInstalled(this, apkName)){
//                moveToOtherApp(apkName);
//            } else {
//                moveToGooglePlay();
//            }
//        } catch (Exception e){
//
//        } finally {
//            finish();
//        }

    }

    public void moveToOtherApp(String apkName) throws Exception {
        Intent LaunchIntent = getPackageManager().getLaunchIntentForPackage(apkName);
        startActivity(LaunchIntent);
    }

    public void moveToGooglePlay() throws Exception {
        final String my_package_name = "map";
        String url = "";
        try {
            //Check whether Google Play store is installed or not:
            this.getPackageManager().getPackageInfo("com.android.vending", 0);
            url = "market://details?id=" + my_package_name;
        } catch ( final Exception e ) {
            url = "https://play.google.com/store/apps/details?id=" + my_package_name;
        }

        //Open the app page in Google Play store:
        final Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
//        Intent i = new Intent("com.google.android.finsky.VIEW_MY_DOWNLOADS");
//        i.setComponent(new ComponentName("com.android.vending","com.android.vending.AssetBrowserActivity"));
//        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(i);
    }


}
