package com.fujitsu.wandant.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import butterknife.Bind;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.WandantApplication;
import com.fujitsu.wandant.adapter.ListDogAdapter;
import com.fujitsu.wandant.listener.ButtonOnTouchListener;
import com.fujitsu.wandant.model.FirmDetailModel;
import com.fujitsu.wandant.mqtt.WandantMqttService;
import com.fujitsu.wandant.net.*;
import com.fujitsu.wandant.net.model.Dog;
import com.fujitsu.wandant.net.model.DogDeviceStation;
import com.fujitsu.wandant.net.model.Station;
import com.fujitsu.wandant.presenter.OnModelFinishedListener;
import com.fujitsu.wandant.utils.Constants;
import com.fujitsu.wandant.utils.StringUtils;
import com.fujitsu.wandant.utils.UserUtils;
import com.fujitsu.wandant.view.ListViewInScrollView;
import com.fujitsu.wandant.view.PopViewHelper;
import com.fujitsu.wandant.view.ToastManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenjie.fnst on 2015/09/30.
 */
public class SettingActivity extends BaseActivity implements ListView.OnItemClickListener, OnModelFinishedListener {


    @Bind(R.id.id_add_dog_tv)
    LinearLayout tvAddDog;
    @Bind(R.id.id_dog_lv)
    ListViewInScrollView lvDog;
    @Bind(R.id.id_station_add_rl)
    View addStationView;
    @Bind(R.id.id_station_detail_rl)
    View detailStationView;
    @Bind(R.id.id_station_update_flag_iv)
    View stationNeedUpdateView;
    @Bind(R.id.id_device_update_flag_iv)
    View deviceNeedUpdateView;
    @Bind(R.id.id_layer)
    View layer;

    private ListDogAdapter dogAdapter;
    private List<Dog> dogInfoList = new ArrayList<>() ;
    private List<Station> stationList = new ArrayList<>();
    private Context context;
    private DogDeviceStation dogDeviceStation;

    private static final int REQUEST_STATION_DETAIL = 1;
    private static final int REQUEST_DEVICE_DETAIL = 2;

    private int REQUEST_TYPE = DogDeviceStationRepository.REQUEST_FROM_SETTING;

    private boolean isFirstCreate = false;

    public SettingActivity() {
    }

    @Override
    public String getTitleName() {
        return getString(R.string.setting);
    }

    @Override
    public String getTitleHeadUrl() {
        return null;
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        context = this;
        isFirstCreate = true;
        DogDeviceStationRepository.getInstance().register(REQUEST_TYPE, this);
        AccountRepository.getInstance().register(AccountRepository.REQUEST_FROM_SETTING_TYPE, this);
        bindViews();

    }

    private void bindViews() {
        findViewById(R.id.id_station_add_rl).setOnClickListener(this);
        findViewById(R.id.id_station_detail_rl).setOnClickListener(this);
        findViewById(R.id.id_account_detail_rl).setOnClickListener(this);
        findViewById(R.id.id_add_dog_tv).setOnClickListener(this);
        findViewById(R.id.id_device_detail_rl).setOnClickListener(this);
        findViewById(R.id.id_alert_rl).setOnClickListener(this);
        findViewById(R.id.id_mail_rll).setOnClickListener(this);
        View logoutBtn = findViewById(R.id.id_logout_tv);
        logoutBtn.setOnClickListener(this);
        logoutBtn.setOnTouchListener(new ButtonOnTouchListener(this, R.drawable.btn_white_sure_pressed, R.drawable.btn_white_sure));

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!isFirstCreate){
            reloadData();
        } else {
            getData();
            isFirstCreate = false;
        }
    }

    @Override
    public int getLayout() {
        return R.layout.activity_setting;
    }

    private void getData(){
        DogDeviceStationRepository.getInstance().loadDogsFromDb(REQUEST_TYPE);
        DogDeviceStationRepository.getInstance().loadStationsFromDb(REQUEST_TYPE);
        DogDeviceStationRepository.getInstance().getAllInfo(REQUEST_TYPE);
        AccountRepository.getInstance().getUser(AccountRepository.REQUEST_FROM_SETTING_TYPE);
//        firmDetailModels = StatusRepository.getInstance().getAllFirmDetailFromDb();
        List<FirmDetailModel> list = StatusRepository.getInstance().getAllNeedUpdateDeviceFirmFromDb();
        if (null == list || list.isEmpty()){
            deviceNeedUpdateView.setVisibility(View.GONE);
        } else {
            deviceNeedUpdateView.setVisibility(View.VISIBLE);
        }
    }

    private void reloadData(){
        DogDeviceStationRepository.getInstance().loadDogsFromDb(REQUEST_TYPE);
        DogDeviceStationRepository.getInstance().loadStationsFromDb(REQUEST_TYPE);
        List<FirmDetailModel> list = StatusRepository.getInstance().getAllNeedUpdateDeviceFirmFromDb();
        if (null == list || list.isEmpty()){
            deviceNeedUpdateView.setVisibility(View.GONE);
        } else {
            deviceNeedUpdateView.setVisibility(View.VISIBLE);
        }
    }

    public void showData(){
        if (null == dogInfoList){
            dogInfoList = new ArrayList<>();
        }
        if (null == dogAdapter){
            dogAdapter = new ListDogAdapter(this,dogInfoList);
            lvDog.setAdapter(dogAdapter);
            lvDog.setOnItemClickListener(this);
        }else{
            dogAdapter.refreshList(dogInfoList);
        }
        if (dogInfoList.size() < Constants.DOG_MAX_NUM){
            tvAddDog.setVisibility(View.VISIBLE);
        } else {
            tvAddDog.setVisibility(View.GONE);
        }
        if (dogInfoList.size() == 0){
            tvAddDog.setBackgroundResource(R.drawable.info_item_bg);
        }else{
            tvAddDog.setBackgroundResource(R.drawable.info_item_bottom_bg);
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        Intent intent = new Intent();
        switch (v.getId()){
            case R.id.id_station_add_rl:
                intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG, Constants.ACTIVITY_FROM_SETTING_STATION_ADD);
                intent.setClass(this,StationSearchActivity.class);
                startActivity(intent);
                break;
            case R.id.id_station_detail_rl:
                if (!stationList.isEmpty()){
                    intent.putExtra(Constants.EXTRA_STATION,stationList.get(0));
                }
                intent.setClass(this, StationDetailInfoActivity.class);
                startActivityForResult(intent, REQUEST_STATION_DETAIL);
                break;
            case R.id.id_account_detail_rl:
                intent.setClass(this,UserInfoActivity.class);
                startActivity(intent);
                break;
            case R.id.id_add_dog_tv:
                intent.setClass(this,DogRegisterActivity.class);
                intent.putExtra(Constants.EXTRA_ACTIVITY_FROM_FLAG,Constants.ACTIVITY_FROM_SETTING_DOG_ADD);
                startActivity(intent);
                break;
            case R.id.id_device_detail_rl:
                intent.setClass(this,DeviceListActivity.class);
                startActivityForResult(intent,REQUEST_DEVICE_DETAIL);
                break;
            case R.id.id_alert_rl:
                intent.setClass(this, AlertSettingActivity.class);
                startActivity(intent);
                break;
            case R.id.id_mail_rll:
                intent.setClass(this,EmailListActivity.class);
                startActivity(intent);
                break;
            case R.id.id_logout_tv:
                PopViewHelper.getInstance().showLogoutPop(context,layer);
                break;
            case R.id.id_pop_sure_txt:
                PopViewHelper.getInstance().dismissPop();
                logout();
                break;
            case R.id.id_pop_cancel_txt:
                PopViewHelper.getInstance().dismissPop();
            default:
                break;
        }

    }

    private void logout() {
        AccountService.getInstance().logout(new NetCallback<Void>() {
            @Override
            public void success(Void responseData) {

            }

            @Override
            public void failure(String errorCode, String errorMsg) {
                showErrorMessage(errorCode);
            }

            @Override
            public void internalFailure(String errorMsg) {
                ToastManager.getInstance().showFail(errorMsg);
            }
        });
        WandantMqttService service = WandantApplication.getInstance().getMqttService();
        if (null != service){
            service.disconnectMqtt();
        }
        UserUtils.getInstance().logout();
        Intent intent = new Intent();
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.setClass(this, LoginActivity.class);
        startActivity(intent);
        finish();

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent();
        intent.putExtra(Constants.EXTRA_DOG,dogInfoList.get(position));
        intent.putExtra(Constants.EXTRA_DOG_COUNT, dogInfoList.size());
        intent.setClass(this, DogInfoActivity.class);
        startActivity(intent);
    }

    @Override
    public void success(Object result, int mode) {
        if (mode == DogDeviceStationRepository.LOAD_ALL_INFO_FROM_DB_MODE){
            dogInfoList.clear();
            dogInfoList = (List<Dog>) result;
            showData();
        }else if (mode == DogDeviceStationRepository.LOAD_ALL_INFO_FROM_NET_MODE){
            DogDeviceStation dataFromNet = (DogDeviceStation) result;
            dogDeviceStation = dataFromNet;
            dogInfoList = dataFromNet.getDog_list();
            showData();
            List<Station> list = ((DogDeviceStation) result).getStation_list();
            updateStationInfo(list);
        } else if (mode == DogDeviceStationRepository.LOAD_STATIONS_FROM_DB_MODE){
            List<Station> list = (List<Station>) result;
            updateStationInfo(list);
        } else if (mode == AccountRepository.LOAD_USER_FROM_NET_MODE){
            //
        }
    }

    private void updateStationInfo(List<Station> list) {
        stationList.clear();
        if (null == list || list.isEmpty()){
            addStationView.setVisibility(View.VISIBLE);
            detailStationView.setVisibility(View.GONE);
        } else {
            stationList = list;
            addStationView.setVisibility(View.GONE);
            detailStationView.setVisibility(View.VISIBLE);
            String bdid = list.get(0).getBdid();
            if (!StringUtils.isBlank(bdid) && null != StatusRepository.getInstance().getNeedUpdateFirmDbByBdid(bdid)){
                stationNeedUpdateView.setVisibility(View.VISIBLE);
            } else {
                stationNeedUpdateView.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void failed(String errorCode, String errorMsg) {
        showErrorMessage(errorCode);
    }

    @Override
    public void internalFailure(String errorMsg) {
        ToastManager.getInstance().showFail(errorMsg);
//        Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        DogDeviceStationRepository.getInstance().unRegister(DogDeviceStationRepository.REQUEST_FROM_SETTING);
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case REQUEST_STATION_DETAIL:
                stationList = DogDeviceStationRepository.getInstance().loadStations();
                updateStationStatus();
                break;
            default:
                break;
//            case REQUEST_DEVICE_DETAIL:
//                stationList = DogDeviceStationRepository.getInstance().loadStations();
//                updateStationStatus();
//                break;
        }
    }

    private void updateStationStatus() {
        if (null == stationList || stationList.isEmpty()){
            addStationView.setVisibility(View.VISIBLE);
            detailStationView.setVisibility(View.GONE);
        } else {
            addStationView.setVisibility(View.GONE);
            detailStationView.setVisibility(View.VISIBLE);
        }
    }

}
