package com.fujitsu.wandant.test;

import android.test.ActivityInstrumentationTestCase2;
import android.view.View;
import android.widget.ListView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.activity.*;
import com.robotium.solo.Solo;

/**
 * Created by chenjie.fnst on 2015/12/22.
 */
public class UserInfoTest extends ActivityInstrumentationTestCase2<LoginActivity> {

    private static final int BIG_TIMEOUT = 5000;
    private Solo solo;
    public UserInfoTest() {
        super(LoginActivity.class);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new Solo(getInstrumentation(), getActivity());
    }


    @Override
    public void tearDown() throws Exception {
        getActivity().finish();
        solo.goBackToActivity("MainActivity");
        try {
            solo.finalize();
        } catch (Throwable e) {
            e.printStackTrace();
        }

        try {
            super.tearDown();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean loginToMain(){
//        if (!solo.(LoginActivity.class,BIG_TIMEOUT)){
//            return false;
//        }
//        EditText nameEdit = (EditText) solo.getView(R.id.id_name_edit);
//        EditText pwdEdit = (EditText) solo.getView(R.id.id_password_edit);
        //        solo.enterText(nameEdit,"didida@cn.fujitsu.com");
//        solo.enterText(pwdEdit, "12@qq.com");
//        solo.takeScreenshot();
        solo.clickOnButton(0);
        if (solo.waitForActivity(MainActivity.class)){
            return true;
        } else {
            return false;
        }
    }

    public boolean mainToSetting() throws InterruptedException {
        if (loginToMain()){
            Thread.sleep(1000);
//            solo.takeScreenshot();
            View menu = solo.getView(R.id.id_menu_btn);
            solo.clickOnView(menu);
            Thread.sleep(1000);
            View setting = solo.getView(R.id.id_setting_tv);
            solo.clickOnView(setting);
            if (solo.waitForActivity(SettingActivity.class,BIG_TIMEOUT)){
                return true;
            } else {
            return false;
            }
        } else {
            return false;
        }
    }


    public void testUserInfo() throws Exception {
//        EditText nameEdit = (EditText) solo.getView(R.id.id_name_edit);
//        EditText pwdEdit = (EditText) solo.getView(R.id.id_password_edit);
//        solo.enterText(nameEdit,"didida@cn.fujitsu.com");
//        solo.enterText(pwdEdit, "12@qq.com");
//        solo.takeScreenshot();
//        solo.clickOnButton(0);
//        if (solo.waitForActivity(MainActivity.class)){
        if (loginToMain()){
//            Thread.sleep(1000);
//            solo.takeScreenshot();
//            View menu = solo.getView(R.id.id_menu_btn);
//            solo.clickOnView(menu);
//            View setting = solo.getView(R.id.id_setting_tv);
//            solo.clickOnView(setting);
//            if (solo.waitForActivity(SettingActivity.class,BIG_TIMEOUT)){
            if (mainToSetting()){
                View userAccount = solo.getView(R.id.id_account_detail_rl);
                solo.clickOnView(userAccount);
                if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                    //name
                    View name = solo.getView(R.id.id_full_name_layout);
                    solo.clickOnView(name);
                    if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                        solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                        Thread.sleep(BIG_TIMEOUT);
                    }

                    //phonetic
                    if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                        return;
                    }
                    View phonetic = solo.getView(R.id.id_phonetic_layout);
                    solo.clickOnView(phonetic);
                    if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                        solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                        Thread.sleep(BIG_TIMEOUT);
                    }

                    //sex
                    if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                        return;
                    }
                    View sex = solo.getView(R.id.id_sex_layout);
                    solo.clickOnView(sex);
                    if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                        assertTrue(solo.waitForView(ListView.class));
                        solo.clickInList(0);
                        Thread.sleep(BIG_TIMEOUT);
                    }

                    //phone
                    if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                        return;
                    }
                    View phone = solo.getView(R.id.id_phone_layout);
                    solo.clickOnView(phone);
                    if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                        solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                        Thread.sleep(BIG_TIMEOUT);
                    }
                    if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                        return;
                    }
                    //twitter
                    if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                        return;
                    }
                    View twitter = solo.getView(R.id.id_twitter_layout);
                    solo.clickOnView(twitter);
                    if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                        solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                        Thread.sleep(BIG_TIMEOUT);
                    }
                    //family
                    if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                        return;
                    }
                    View family = solo.getView(R.id.id_family_layout);
                    solo.clickOnView(family);
                    if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                        assertTrue(solo.waitForView(ListView.class));
                        solo.clickInList(0);
                        solo.clickInList(1);
                        solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                        Thread.sleep(BIG_TIMEOUT);
                    }
                    //birthday
                    if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                        return;
                    }
                    View birthday = solo.getView(R.id.id_birthday_layout);
                    solo.clickOnView(birthday);
                    if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                        solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                        Thread.sleep(BIG_TIMEOUT);
                    }
                    //job
                    if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                        return;
                    }
                    View job = solo.getView(R.id.id_job_layout);
                    solo.clickOnView(job);
                    if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                        solo.clickInList(1);
                        Thread.sleep(BIG_TIMEOUT);
                    }
                    //address
                    if (solo.waitForActivity(UserInfoActivity.class,BIG_TIMEOUT)){
                        return;
                    }
                    View address = solo.getView(R.id.id_address_layout);
                    solo.clickOnView(address);
                    if (solo.waitForActivity(UserAddressEditActivity.class,BIG_TIMEOUT)){
                        solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                        Thread.sleep(BIG_TIMEOUT);
                    }
                }
            }
        }
    }
}
