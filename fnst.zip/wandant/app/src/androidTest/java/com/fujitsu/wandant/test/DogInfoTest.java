package com.fujitsu.wandant.test;

import android.test.ActivityInstrumentationTestCase2;
import android.view.View;
import android.widget.ListView;
import com.fujitsu.wandant.R;
import com.fujitsu.wandant.activity.*;
import com.robotium.solo.Solo;

/**
 * Created by chenjie.fnst on 2015/12/22.
 */
public class DogInfoTest extends ActivityInstrumentationTestCase2<LoginActivity> {

    private static final int BIG_TIMEOUT = 5000;
    private Solo solo;
    int quality = 50;

    public DogInfoTest() {
        super(LoginActivity.class);
    }


    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new Solo(getInstrumentation(), getActivity());
    }


    @Override
    public void tearDown() throws Exception {
        solo.goBackToActivity("LoginActivity");
        try {
            solo.finalize();
        } catch (Throwable e) {
            e.printStackTrace();
        }
        getActivity().finish();
        try {
            super.tearDown();
        } catch (Exception e) {
            e.printStackTrace();
        };
    }


    public void testDogInfo() throws Exception{
//            if (loginToMain()){
                if (mainToSetting()) {
                    assertTrue(solo.waitForView(ListView.class));
                    solo.clickInList(0);
                    Thread.sleep(BIG_TIMEOUT);
                    if (solo.waitForActivity(DogInfoActivity.class, BIG_TIMEOUT)) {
                        //head
//                        View head = solo.getView(R.id.id_head_value);
//                        solo.clickOnView(head);
//                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
//                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
//                            Thread.sleep(BIG_TIMEOUT);
//                            View selectPhoto = solo.getView(R.id.id_photo_select_txt);
//                            solo.clickOnView(selectPhoto);
//                            Thread.sleep(BIG_TIMEOUT);
////                            solo.clickOnButton(0);
//                            assertTrue(solo.waitForView(GridView.class));
//                            solo.clickInList(2);
//                            if (solo.waitForActivity(ClipActivity.class)){
//                                View sure = solo.getView(R.id.id_ok_txt);
//                                solo.clickOnView(sure);
//                                Thread.sleep(BIG_TIMEOUT);
//                            }
//                        }
                        //name
                        View name = solo.getView(R.id.id_name_layout);
                        solo.clickOnView(name);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }
                        //sex
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View sex = solo.getView(R.id.id_sex_layout);
                        solo.clickOnView(sex);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            assertTrue(solo.waitForView(ListView.class));
                            solo.clickInList(2);
                            Thread.sleep(BIG_TIMEOUT);
                        }
                        //color
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View color = solo.getView(R.id.id_color_layout);
                        solo.clickOnView(color);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            assertTrue(solo.waitForView(ListView.class));
                            solo.clickInList(2);
                            Thread.sleep(BIG_TIMEOUT);
                        }

                        //type
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View type = solo.getView(R.id.id_kind_layout);
                        solo.clickOnView(type);
                        if (solo.waitForActivity(DogTypeSelectActivity.class,BIG_TIMEOUT)){
                            assertTrue(solo.waitForView(ListView.class));
                            solo.clickOnImage(5);
                            Thread.sleep(BIG_TIMEOUT);
                        }
                        //leg
//                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
//                            return;
//                        }
//                        View leg = solo.getView(R.id.id_leg_layout);
//                        solo.clickOnView(leg);
//                        if (solo.waitForActivity(DogTypeSelectActivity.class,BIG_TIMEOUT)){
//                            assertTrue(solo.waitForView(ListView.class));
//                            solo.clickInList(2);
//                            Thread.sleep(BIG_TIMEOUT);
//                        }
                        //birth
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View birth = solo.getView(R.id.id_birth_layout);
                        solo.clickOnView(birth);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }
                        //adopt
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View adopt = solo.getView(R.id.id_home_layout);
                        solo.clickOnView(adopt);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }
                        //microchip
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View microchip = solo.getView(R.id.id_microchip_layout);
                        solo.clickOnView(microchip);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }
                        //microchip
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View watch = solo.getView(R.id.id_watch_layout);
                        solo.clickOnView(watch);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }

                        //medicine
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View medicine = solo.getView(R.id.id_medicine_layout);
                        solo.clickOnView(medicine);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }

                        //flea
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View flea = solo.getView(R.id.id_flea_layout);
                        solo.clickOnView(flea);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }

                        //injection
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View injection = solo.getView(R.id.id_injection_layout);
                        solo.clickOnView(injection);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }
                        //injection
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View rabies = solo.getView(R.id.id_rabies_layout);
                        solo.clickOnView(rabies);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }
                        //injection
                        if (solo.waitForActivity(DogInfoActivity.class,BIG_TIMEOUT)){
                            return;
                        }
                        View diagnose = solo.getView(R.id.id_diagnose_layout);
                        solo.clickOnView(diagnose);
                        if (solo.waitForActivity(ValueEditActivity.class,BIG_TIMEOUT)){
                            solo.clickOnText(getActivity().getResources().getString(R.string.setting_sure));
                            Thread.sleep(BIG_TIMEOUT);
                        }
//                        findViewById(R.id.id_head_value).setOnClickListener(this);
//                        findViewById(R.id.id_name_layout).setOnClickListener(this);
//                        findViewById(R.id.id_sex_layout).setOnClickListener(this);
//                        findViewById(R.id.id_kind_layout).setOnClickListener(this);
//                        findViewById(R.id.id_leg_layout).setOnClickListener(this);
//                        findViewById(R.id.id_color_layout).setOnClickListener(this);
//                        findViewById(R.id.id_birth_layout).setOnClickListener(this);
//                        findViewById(R.id.id_home_layout).setOnClickListener(this);
//                        findViewById(R.id.id_microchip_layout).setOnClickListener(this);
//                        findViewById(R.id.id_watch_layout).setOnClickListener(this);
//                        findViewById(R.id.id_medicine_layout).setOnClickListener(this);
//                        findViewById(R.id.id_flea_layout).setOnClickListener(this);
////                        findViewById(R.id.id_injection_layout).setOnClickListener(this);
//                        findViewById(R.id.id_rabies_layout).setOnClickListener(this);
//                        findViewById(R.id.id_diagnose_layout).setOnClickListener(this);
                    }
                }
//            }
    }


    public boolean loginToMain(){
//        if (!solo.waitForActivity(LoginActivity.class,BIG_TIMEOUT)){
//            return false;
//        }
//        EditText nameEdit = (EditText) solo.getView(R.id.id_name_edit);
//        EditText pwdEdit = (EditText) solo.getView(R.id.id_password_edit);
        //        solo.enterText(nameEdit,"didida@cn.fujitsu.com");
//        solo.enterText(pwdEdit, "12@qq.com");

//        solo.takeScreenshot("login_001_c",quality);
        solo.clickOnButton(0);
        if (solo.waitForActivity(MainActivity.class,BIG_TIMEOUT)){
            return true;
        } else {
            return false;
        }
    }

    public boolean mainToSetting() throws InterruptedException {
        if (loginToMain()){
            Thread.sleep(1000);
//            solo.takeScreenshot("main_001",quality);
            View menu = solo.getView(R.id.id_menu_btn);
            solo.clickOnView(menu);
            Thread.sleep(1000);
            View setting = solo.getView(R.id.id_setting_tv);
            solo.clickOnView(setting);
            if (solo.waitForActivity(SettingActivity.class,BIG_TIMEOUT)){
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

}
