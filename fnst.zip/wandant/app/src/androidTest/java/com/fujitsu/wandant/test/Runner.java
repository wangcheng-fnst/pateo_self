//******************************************************************
//* わんダント2システム
//******************************************************************
/*
 *	わんダント2サーバー
 *	Runner.java
 *
 *	変更日			変更者				障害No／仕様変更No
 *	2015/12/25 		FNST)Chenjie	    新規作成
 *
 */
//******************************************************************
//* COPYRIGHT FUJITSU LIMITED 2015
//******************************************************************

package com.fujitsu.wandant.test;


import android.test.InstrumentationTestRunner;
import android.test.InstrumentationTestSuite;

import junit.framework.TestSuite;

/**
 *
 *Runner           
 */
public class Runner extends InstrumentationTestRunner {
    @Override
    public TestSuite getAllTests() {
        InstrumentationTestSuite suite = new InstrumentationTestSuite(this);

        suite.addTestSuite(UserInfoTest.class);
        suite.addTestSuite(DogInfoTest.class);

        return suite;
    }

    @Override
    public ClassLoader getLoader() {
        return Runner.class.getClassLoader();
    }
}
